# SentryUSB Pro UI Upgrade — v6

## Visual direction
- Obsidian Aurora: deep navy/black foundation with electric cyan + violet primary accents.
- Lime/amber/coral reserved for operational states and risk.
- Glass surfaces are subtler, with stronger hierarchy and less visual noise.
- Shared theme applied to Server and Hub screens.

## What changed
- Added `server/static/css/pro_ui.css` and `hub/static/css/pro_ui.css`.
- Linked the shared Server theme into all full-page server templates.
- Linked the shared Hub theme into the Hub base template.
- Upgraded cards, sidebars, buttons, forms, tables, badges, AI panels, focus states and responsive behavior.
- Added reduced-motion support and a restrained command-center grid background.
- No backend routes, JavaScript behavior, or data models were changed.

## Identity + full-template pass
- Added the shared Pro UI layer to every server template, including standalone/error/login screens.
- Added the shared Pro UI layer to the Hub base shell so every Hub page receives the same system.
- Reworked the server sidebar brand lockup so **SentryUSB** is always visible above **SECURE OPS**.
- Reworked the Hub identity to show **SentryUSB HUB** with a clear product badge.
- Added consistent control, modal, input, focus, badge, and divider polish across legacy screens.
