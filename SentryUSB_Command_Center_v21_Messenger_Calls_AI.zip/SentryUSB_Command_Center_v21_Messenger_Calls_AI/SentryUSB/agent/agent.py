"""
SentryUSB - Lab Agent
---------------------
Runs on each Windows exam-lab PC. Watches for USB device connect/disconnect
events via WMI, disables mass-storage devices immediately, and reports
everything (with timestamps) to the central SentryUSB server over Socket.IO.
"""
import getpass
import logging
import logging.handlers
import os
import socket
import sys
import time
import uuid
import threading
import json
import subprocess
from typing import Dict, Optional

import socketio

import config
import device_utils
import policy_ui
from usb_watcher import USBWatcher
from device_trust import is_hid, device_class, fingerprint, detect_fingerprint_change, is_trusted_hid
from behavioral_metrics import BehavioralMetrics

import sys
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

# Try importing exam lockdown module
try:
    from exam_lockdown import ExamLockdown
    EXAM_LOCKDOWN_AVAILABLE = True
    print("✅ Exam Lockdown module loaded")
except ImportError:
    EXAM_LOCKDOWN_AVAILABLE = False
    print("⚠️ Exam Lockdown module not available")

# Try importing browser monitor
try:
    from browser_monitor import BrowserMonitor
    BROWSER_MONITOR_AVAILABLE = True
    print("✅ Browser Monitor loaded")
except ImportError:
    BROWSER_MONITOR_AVAILABLE = False
    print("⚠️ Browser Monitor not available")

# Try importing RDP / remote-access monitor
try:
    from rdp_monitor import RDPMonitor
    RDP_MONITOR_AVAILABLE = True
    print("✅ RDP Monitor loaded")
except ImportError:
    RDP_MONITOR_AVAILABLE = False
    print("⚠️ RDP Monitor not available")


def setup_logging():
    logger = logging.getLogger("sentryusb")
    logger.setLevel(logging.INFO)

    stream = sys.stdout
    if hasattr(stream, "reconfigure"):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    handlers = [logging.StreamHandler(stream)]
    try:
        log_dir = os.path.dirname(config.LOG_PATH)
        if log_dir:
            os.makedirs(log_dir, exist_ok=True)
        handlers.append(
            logging.handlers.RotatingFileHandler(
                config.LOG_PATH,
                maxBytes=2_000_000,
                backupCount=3,
                encoding="utf-8",
            )
        )
    except Exception:
        pass
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s")
    for h in handlers:
        h.setFormatter(fmt)
        logger.addHandler(h)
    return logger


log = setup_logging()


def get_local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except Exception:
        return socket.gethostbyname(socket.gethostname())
    finally:
        s.close()


def is_admin() -> bool:
    try:
        import ctypes
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


class SentryUSBAgent:
    def __init__(self):
        self.hostname = socket.gethostname()
        self.ip_address = get_local_ip()
        self.username = getpass.getuser()
        self._active_sessions: Dict[str, str] = {}

        self._is_connected = False
        self._is_registered = False
        self._approval = "unaccepted"      # unaccepted | pending | approved | rejected
        self._server_policy = None
        self._register_lock = threading.Lock()
        self._reconnect_thread: Optional[threading.Thread] = None
        self._stop_reconnect = threading.Event()
        self._health_thread: Optional[threading.Thread] = None
        self._start_time: float = 0

        self.lockdown_enabled = False
        self.lockdown_exempt = config.LOCKDOWN_EXEMPT

        # Flag to indicate termination requested by server
        self._terminate_requested = False

        self.sio = socketio.Client(
            reconnection=True,
            reconnection_delay=config.RECONNECT_DELAY_SECONDS,
            reconnection_attempts=0,
            logger=False,
            engineio_logger=False
        )
        self._register_handlers()

        # Initialize all state used by monitor callbacks before starting any
        # monitor thread. Browser/RDP monitors may emit status immediately.
        self._event_queue: list = []
        self._event_queue_max = 100
        self._registration_attempts = 0
        self._max_registration_attempts = 10

        self.watcher = USBWatcher(
            on_device_detected=self.handle_new_device,
            on_device_removed=self.handle_removed_device,
            poll_interval_seconds=config.POLL_INTERVAL_SECONDS,
        )

        if EXAM_LOCKDOWN_AVAILABLE:
            self.exam_lockdown = ExamLockdown(config.SERVER_URL, config.AUTH_TOKEN)
            log.info("Exam Lockdown module initialized")
        else:
            self.exam_lockdown = None

        if BROWSER_MONITOR_AVAILABLE:
            self.browser_monitor = BrowserMonitor()
            self.browser_monitor.set_hostname(self.hostname)
            self.browser_monitor.set_send_callback(self._send_browser_event)
            self.browser_monitor.start()
            log.info("🔍 Browser Monitor initialized")
        else:
            self.browser_monitor = None

        if RDP_MONITOR_AVAILABLE:
            self.rdp_monitor = RDPMonitor()
            self.rdp_monitor.set_hostname(self.hostname)
            self.rdp_monitor.set_send_callback(self._send_rdp_event)
            self.rdp_monitor.start()
            log.info("🖥️ RDP Monitor initialized")
        else:
            self.rdp_monitor = None

        if self.lockdown_exempt:
            log.info("🔓 PC is exempt from lockdown")
        else:
            log.info("🔒 Lockdown disabled by default. Waiting for server command.")

        self.exam_active = False
        self._exam_deadline = 0.0
        self._exam_timer_generation = 0
        self._violation_count = 0
        self.browser_list = config.BLOCKED_BROWSERS
        self._device_cooldown = getattr(config, 'DEVICE_COOLDOWN_SECONDS', 5)
        self._connection_attempts = 0
        self._registration_attempts = 0
        self._max_registration_attempts = 10
        self._startup_voice_announced = False
        self.behavioral_metrics = BehavioralMetrics(self._emit_safe, config.BEHAVIORAL_METRICS_ENABLED)

    def _announce_startup(self):
        """Speak once after local monitoring is ready, without blocking it."""
        if self._startup_voice_announced or not getattr(config, "STARTUP_VOICE_ENABLED", False):
            return
        self._startup_voice_announced = True
        message = getattr(config, "STARTUP_VOICE_MESSAGE", "Welcome to SentryUSB. Security monitoring is active.")
        log.info("Playing local SentryUSB startup voice announcement.")
        try:
            threading.Thread(
                target=device_utils.speak_local_message,
                kwargs={
                    "text": message,
                    "voice_hint": getattr(config, "STARTUP_VOICE_NAME", "Zira"),
                    "rate": getattr(config, "STARTUP_VOICE_RATE", -1),
                    "volume": getattr(config, "STARTUP_VOICE_VOLUME", 88),
                },
                daemon=True,
                name="sentryusb-startup-voice",
            ).start()
        except Exception as e:
            log.debug("Startup voice announcement could not start: %s", e)

    def _start_local_exam_lease(self, duration: int):
        """Enforce a bounded local exam session even when the server disconnects."""
        self._exam_timer_generation += 1
        generation = self._exam_timer_generation
        self._exam_deadline = time.time() + max(60, int(duration))
        state_path = os.path.join(os.path.dirname(__file__), "exam_lease.json")
        try:
            with open(state_path, "w", encoding="utf-8") as handle:
                json.dump({"deadline": self._exam_deadline, "hostname": self.hostname}, handle)
        except OSError as exc:
            log.warning("Could not persist local exam lease: %s", exc)

        def watchdog():
            while self.exam_active and generation == self._exam_timer_generation:
                remaining = self._exam_deadline - time.time()
                if remaining <= 0:
                    break
                time.sleep(min(1.0, remaining))
            if generation == self._exam_timer_generation and self.exam_active and time.time() >= self._exam_deadline:
                log.warning("Local exam lease expired; releasing exam-only restrictions")
                self._release_local_exam_security()

        threading.Thread(target=watchdog, daemon=True, name="sentryusb-exam-lease").start()

    def _release_local_exam_security(self):
        """Undo only restrictions applied by Exam Control; leave general monitoring running."""
        try:
            self._unblock_all_browsers()
            self._unblock_usb()
            self._unblock_internet()
            self._enable_copy_paste()
            self._enable_print_screen()
            self._enable_alt_tab()
            self._enable_task_manager()
        except Exception as exc:
            log.exception("One or more exam restrictions could not be released: %s", exc)
        finally:
            self.exam_active = False
            self.lockdown_enabled = False
            self._exam_deadline = 0.0
            self._exam_timer_generation += 1
            state_path = os.path.join(os.path.dirname(__file__), "exam_lease.json")
            try:
                if os.path.exists(state_path):
                    os.remove(state_path)
            except OSError:
                pass
            self._emit_safe("exam_status", {"status": "expired_local", "hostname": self.hostname})

    # ===== POLICY HANDSHAKE (v20) =====
    def _control_allowed(self, what: str) -> bool:
        """Server control commands are honoured only after Policy Studio approval."""
        if self._approval == "approved":
            return True
        log.warning("Ignoring %s: policy approval state is '%s'", what, self._approval)
        self._emit_safe("agent_notice", {"hostname": self.hostname, "type": "command_ignored",
                                         "command": what, "approval": self._approval})
        return False

    def _notify_local(self, title: str, text: str):
        try:
            threading.Thread(target=device_utils.show_local_notice, args=(title, text), daemon=True).start()
        except Exception:
            pass

    def _apply_ack(self, ack: dict):
        """Single place that turns a server ack into agent state. Connected = ready, no waiting."""
        self._server_policy = ack.get("policy") or self._server_policy
        self._approval = ack.get("approval", self._approval)
        was_registered = self._is_registered
        self._is_registered = True
        self._registration_attempts = 0
        log.info("✅ Registered with server (policy approval: %s)", self._approval)
        if not was_registered:
            self._send_browser_status()
            self._send_rdp_status()
            self._flush_event_queue()
        pol = self._server_policy or {}
        if pol.get("version") is not None and policy_ui.load_accepted_version() != pol["version"]:
            self._approval = "unaccepted"
            threading.Thread(target=self._consent_flow, daemon=True, name="sentryusb-consent").start()

    def _consent_flow(self):
        """Show the policy once, then tell the server. Never blocks monitoring or connectivity."""
        pol = self._server_policy
        if not pol or policy_ui.is_showing():
            return
        accepted = policy_ui.ask_policy(pol, self.hostname)
        if accepted is None:
            log.warning("No GUI available for policy dialog; staying in monitor-only state")
            return
        if not accepted:
            log.warning("Policy declined by the local user")
            self._approval = "rejected"
            return
        policy_ui.save_accepted_version(pol["version"], self.username)
        for _ in range(60):  # until the server answers; connection loss just retries
            if self._is_connected:
                try:
                    res = self.sio.call("agent_policy_accept", {
                        "hostname": self.hostname, "version": pol["version"],
                        "ip_address": self.ip_address, "username": self.username}, timeout=8)
                    if res and res.get("status") == "ok":
                        self._approval = res.get("approval", "pending")
                        log.info("📜 Policy accepted; server state: %s", self._approval)
                        return
                    if res and res.get("status") == "stale" and res.get("policy"):
                        self._server_policy = res["policy"]
                        return self._consent_flow()
                except Exception as exc:
                    log.debug("policy accept call failed: %s", exc)
            time.sleep(2)

    def _register_handlers(self):
        @self.sio.event
        def connect():
            log.info("✅ Connected to server at %s", config.SERVER_URL)
            self._is_connected = True
            self._is_registered = False     # reset registration flag
            self._connection_attempts = 0
            self._registration_attempts = 0
            self._register_agent()       # will set _is_registered when ack received
            self._scan_existing_usb_devices()

        @self.sio.event
        def disconnect():
            log.warning("❌ Disconnected from server.")
            self._is_connected = False
            self._is_registered = False

        @self.sio.on("registration_ack")
        def on_registration_ack(data):
            self._apply_ack(data if isinstance(data, dict) else {})

        @self.sio.on("registration_rejected")
        def on_registration_rejected(data):
            log.error("❌ Registration rejected by server: %s", data)
            self._is_registered = False

        @self.sio.on("policy_decision")
        def on_policy_decision(data):
            status = (data or {}).get("status", "pending")
            self._approval = status
            log.info("📜 Server policy decision: %s", status)
            if status == "approved":
                self._notify_local("SentryUSB", "Your computer is now connected and monitored by the server.")
            elif status == "rejected":
                self._notify_local("SentryUSB", "The server rejected this computer's policy request.")

        @self.sio.on("policy_update")
        def on_policy_update(data):
            log.info("📜 New policy version pushed by server")
            self._server_policy = data
            self._approval = "unaccepted"
            threading.Thread(target=self._consent_flow, daemon=True, name="sentryusb-consent").start()

        @self.sio.on("exam_start")
        def on_exam_start(data):
            if not self._control_allowed("exam_start"):
                return
            log.info("📚 Received exam start command from server")
            if self.lockdown_exempt:
                log.info("🔓 PC is exempt from exam lockdown")
                self.sio.emit("exam_status", {"status": "exempt", "hostname": self.hostname})
                return

            if self.exam_active:
                log.info("📚 Exam already active")
                self.sio.emit("exam_status", {"status": "already_active", "hostname": self.hostname})
                return

            try:
                duration = data.get("duration", 3600)
                try:
                    duration = max(60, min(int(duration or 3600), 24 * 60 * 60))
                except (TypeError, ValueError):
                    duration = 3600
                log.info("Local exam lease duration: %s seconds", duration)
                log.info("🔪 Killing all running browsers...")
                self._kill_all_browsers()
                log.info("🔒 Blocking all browsers...")
                self._block_all_browsers()
                log.info("🔒 Blocking USB devices...")
                self._block_all_usb()
                log.info("🔒 Blocking internet...")
                self._block_internet_except_allowed()
                log.info("🔒 Disabling copy-paste...")
                self._disable_copy_paste_global()
                log.info("🔒 Disabling print screen...")
                self._disable_print_screen_global()
                log.info("🔒 Disabling Alt+Tab...")
                self._disable_alt_tab()
                log.info("🔒 Disabling Task Manager...")
                self._disable_task_manager()

                self.exam_active = True
                self.lockdown_enabled = True
                self._violation_count = 0  # fresh graduated-response count for this exam session
                self._start_local_exam_lease(duration)

                log.info("✅ Exam started on %s (local timer: %ss)", self.hostname, duration)
                self.sio.emit("exam_status", {"status": "started", "hostname": self.hostname})

            except Exception as e:
                log.error(f"❌ Failed to start exam: {e}")
                self.sio.emit("exam_status", {"status": "failed", "hostname": self.hostname, "error": str(e)})

        @self.sio.on("exam_stop")
        def on_exam_stop(data):
            log.info("📚 Received exam stop command from server")

            if self.lockdown_exempt:
                log.info("🔓 PC is exempt from exam lockdown")
                self.sio.emit("exam_status", {"status": "exempt", "hostname": self.hostname})
                return

            if not self.exam_active:
                log.info("📚 Exam not active")
                self.sio.emit("exam_status", {"status": "not_active", "hostname": self.hostname})
                return

            try:
                log.info("🔓 Unblocking all browsers...")
                self._unblock_all_browsers()
                log.info("🔓 Unblocking USB devices...")
                self._unblock_usb()
                log.info("🔓 Unblocking internet...")
                self._unblock_internet()
                log.info("🔓 Enabling copy-paste...")
                self._enable_copy_paste()
                log.info("🔓 Enabling print screen...")
                self._enable_print_screen()
                log.info("🔓 Enabling Alt+Tab...")
                self._enable_alt_tab()
                log.info("🔓 Enabling Task Manager...")
                self._enable_task_manager()

                self.exam_active = False
                self.lockdown_enabled = False
                self._exam_deadline = 0.0
                self._exam_timer_generation += 1
                lease_path = os.path.join(os.path.dirname(__file__), "exam_lease.json")
                try:
                    if os.path.exists(lease_path):
                        os.remove(lease_path)
                except OSError:
                    pass

                log.info("✅ Exam stopped on %s", self.hostname)
                self.sio.emit("exam_status", {"status": "stopped", "hostname": self.hostname})

            except Exception as e:
                log.error(f"❌ Failed to stop exam: {e}")
                self.sio.emit("exam_status", {"status": "failed", "hostname": self.hostname, "error": str(e)})

        @self.sio.on("exam_status_request")
        def on_exam_status_request(data):
            status = {
                "active": self.exam_active,
                "hostname": self.hostname,
                "lockdown_enabled": self.lockdown_enabled,
                "exam_available": EXAM_LOCKDOWN_AVAILABLE
            }
            self.sio.emit("exam_status_response", status)

        @self.sio.on("lockdown_apply")
        def on_lockdown_apply(data):
            if not self._control_allowed("lockdown_apply"):
                return
            log.info("🔒 Received lockdown apply command from server")

            if self.lockdown_exempt:
                log.info("🔓 PC is exempt from lockdown")
                self.sio.emit("lockdown_apply_result", {"success": False, "message": "PC is exempt"})
                return

            browsers = data.get("browsers", [])
            block_usb = data.get("block_usb", True)
            block_internet = data.get("block_internet", True)
            block_copy_paste = data.get("block_copy_paste", True)
            block_print_screen = data.get("block_print_screen", True)
            block_alt_tab = data.get("block_alt_tab", True)
            block_task_manager = data.get("block_task_manager", True)

            try:
                if browsers:
                    self._block_specific_browsers(browsers)
                if block_usb:
                    self._block_all_usb()
                if block_internet:
                    self._block_internet_except_allowed()
                if block_copy_paste:
                    self._disable_copy_paste_global()
                if block_print_screen:
                    self._disable_print_screen_global()
                if block_alt_tab:
                    self._disable_alt_tab()
                if block_task_manager:
                    self._disable_task_manager()

                self.lockdown_enabled = True
                log.info("✅ Lockdown applied successfully")
                self.sio.emit("lockdown_apply_result", {"success": True})
                self.sio.emit("lockdown_status", {"enabled": True, "hostname": self.hostname})

            except Exception as e:
                log.error(f"Failed to apply lockdown: {e}")
                self.sio.emit("lockdown_apply_result", {"success": False, "message": str(e)})

        @self.sio.on("lockdown_remove")
        def on_lockdown_remove(data):
            log.info("🔓 Received lockdown remove command from server")

            if self.lockdown_exempt:
                log.info("🔓 PC is exempt from lockdown")
                self.sio.emit("lockdown_remove_result", {"success": False, "message": "PC is exempt"})
                return

            try:
                self._unblock_usb()
                self._unblock_all_browsers()
                self._unblock_internet()
                self._enable_copy_paste()
                self._enable_print_screen()
                self._enable_alt_tab()
                self._enable_task_manager()

                self.lockdown_enabled = False
                log.info("✅ Lockdown removed successfully")
                self.sio.emit("lockdown_remove_result", {"success": True})
                self.sio.emit("lockdown_status", {"enabled": False, "hostname": self.hostname})

            except Exception as e:
                log.error(f"Failed to remove lockdown: {e}")
                self.sio.emit("lockdown_remove_result", {"success": False, "message": str(e)})

        @self.sio.on("get_browser_status")
        def on_get_browser_status(data):
            if BROWSER_MONITOR_AVAILABLE and self.browser_monitor:
                try:
                    status = self.browser_monitor.get_status()
                    status["hostname"] = self.hostname
                    self._emit_safe("browser_status_response", status)
                    log.info(f"📊 Sent browser status: {status['browser_count']} browsers")
                except Exception as e:
                    log.error(f"Failed to get browser status: {e}")

        @self.sio.on("get_browser_history")
        def on_get_browser_history(data):
            if BROWSER_MONITOR_AVAILABLE and self.browser_monitor:
                try:
                    history = self.browser_monitor.browser_history[-50:]
                    self._emit_safe("browser_history_response", {"history": history, "hostname": self.hostname})
                except Exception as e:
                    log.error(f"Failed to get browser history: {e}")

        @self.sio.on("get_rdp_status")
        def on_get_rdp_status(data):
            if RDP_MONITOR_AVAILABLE and self.rdp_monitor:
                try:
                    status = self.rdp_monitor.get_status()
                    status["hostname"] = self.hostname
                    self._emit_safe("rdp_status_response", status)
                    log.info(f"📊 Sent RDP status: {status['session_count']} sessions, {status['remote_tool_count']} tools")
                except Exception as e:
                    log.error(f"Failed to get RDP status: {e}")

        @self.sio.on("get_rdp_history")
        def on_get_rdp_history(data):
            if RDP_MONITOR_AVAILABLE and self.rdp_monitor:
                try:
                    history = self.rdp_monitor.get_history(50)
                    self._emit_safe("rdp_history_response", {"history": history, "hostname": self.hostname})
                except Exception as e:
                    log.error(f"Failed to get RDP history: {e}")

        @self.sio.on("override_device")
        def on_override_device(data):
            device_instance_id = data.get("device_instance_id")
            event_id = data.get("event_id")
            log.info("Received override for event %s, device %s", event_id, device_instance_id)

            if self.exam_active or self.lockdown_enabled:
                log.warning("Cannot override device during lockdown or exam")
                self._emit_safe("device_enable_result", {
                    "event_id": event_id,
                    "success": False,
                    "message": "Device override not allowed during lockdown"
                })
                return

            success, output = device_utils.enable_device(device_instance_id)
            if success:
                log.info("✅ Device %s re-enabled successfully.", device_instance_id)
            else:
                log.error("❌ Failed to re-enable device %s: %s", device_instance_id, output)
            self._emit_safe("device_enable_result", {"event_id": event_id, "success": success})

        # ===== NEW: TERMINATE HANDLER =====
        @self.sio.on("terminate_agent")
        def on_terminate(data):
            log.warning("🚨 Received termination command from server. Shutting down agent.")
            self._terminate_requested = True
            # Shutdown cleanly and exit
            if self.sio and self.sio.connected:
                self.sio.disconnect()

        # ===== NEW: ABORT SHUTDOWN HANDLER =====
        @self.sio.on("abort_shutdown")
        def on_abort_shutdown(data):
            log.warning("🛑 Received abort-shutdown command from server.")
            success, output = device_utils.abort_shutdown()
            self._emit_safe("shutdown_abort_result", {"success": success, "output": output})

        @self.sio.on("adaptive_response")
        def on_adaptive_response(data):
            """Apply a narrowly scoped, auditable response from the server.

            Network isolation and session termination are intentionally not
            performed here: they need separately approved endpoint controls.
            """
            if data.get("hostname") not in (None, self.hostname):
                return
            action = data.get("action")
            device_id = data.get("device_instance_id")
            if action == "block_device" and device_id:
                success, output = device_utils.disable_device(device_id)
            else:
                success, output = False, "Action requires local approval or is unsupported by this agent"
            self._emit_safe("adaptive_response_result", {
                "hostname": self.hostname, "action": action, "success": success,
                "output": output, "correlation_id": data.get("correlation_id"),
            })

    def _emit_safe(self, event: str, data: dict):
        """Emit event safely - with automatic retry"""
        if self._is_connected and self._is_registered:
            try:
                self.sio.emit(event, data)
                log.debug(f"✅ Emitted {event}")
                return True
            except Exception as e:
                log.error(f"Failed to emit {event}: {e}")
                self._queue_event(event, data)
                return False
        else:
            log.debug(f"Not connected/registered, queuing {event}")
            self._queue_event(event, data)
            return False

    def _queue_event(self, event: str, data: dict):
        if len(self._event_queue) < self._event_queue_max:
            self._event_queue.append({"event": event, "data": data})
            log.debug(f"Queued event: {event} (queue size: {len(self._event_queue)})")

    def _flush_event_queue(self):
        if not self._is_connected or not self._is_registered:
            return

        sent_count = 0
        while self._event_queue:
            item = self._event_queue.pop(0)
            try:
                self.sio.emit(item["event"], item["data"])
                sent_count += 1
            except Exception as e:
                log.error(f"Failed to send queued event {item['event']}: {e}")
                self._event_queue.insert(0, item)
                break

        if sent_count > 0:
            log.info(f"✅ Flushed {sent_count} queued events")

    def _scan_existing_usb_devices(self):
        log.info("🔍 Scanning for existing USB devices...")
        try:
            import wmi
            import pythoncom

            pythoncom.CoInitialize()
            try:
                c = wmi.WMI()
                usb_devices = []
                try:
                    usb_devices = c.Win32_PnPEntity(DeviceID__contains="USBSTOR")
                except Exception:
                    pass

                processed_serials = set()
                log.info(f"Found {len(usb_devices)} USB devices to scan")

                for device in usb_devices:
                    try:
                        device_id = getattr(device, "DeviceID", "") or ""
                        if not device_id:
                            continue

                        if "USBSTOR" not in device_id.upper():
                            continue

                        if "VOLUME" in device_id.upper() or "SWD\\WPDBUSENUM" in device_id.upper():
                            continue

                        serial = device_utils.parse_serial(device_id)
                        if serial and serial in processed_serials:
                            continue
                        if serial:
                            processed_serials.add(serial)

                        if device_utils.is_mass_storage(device):
                            if not device_utils.is_device_recently_processed(device_id, self._device_cooldown):
                                device_name = device_utils.get_device_description(device)
                                log.info(f"🔍 Found existing USB device: {device_name}")
                                success, _ = device_utils.disable_device(device_id)
                                if success:
                                    log.info(f"✅ Disabled existing device: {device_name}")
                                else:
                                    log.warning(f"⚠️ Could not disable existing device: {device_name}")
                    except Exception as e:
                        log.debug(f"Error scanning device: {e}")
            except Exception as e:
                log.warning(f"WMI scan error: {e}")
            finally:
                try:
                    pythoncom.CoUninitialize()
                except Exception:
                    pass
        except Exception as e:
            log.warning(f"Failed to initialize WMI for USB scan: {e}")

    def _send_browser_status(self):
        if BROWSER_MONITOR_AVAILABLE and self.browser_monitor and self._is_registered:
            try:
                status = self.browser_monitor.get_status()
                status["hostname"] = self.hostname
                self._emit_safe("browser_status_response", status)
                log.info(f"📊 Sent browser status: {status['browser_count']} browsers")
            except Exception as e:
                log.error(f"Failed to send browser status: {e}")

    def _kill_all_browsers(self):
        killed = []
        for browser in self.browser_list:
            try:
                result = subprocess.run(
                    ["taskkill", "/f", "/im", browser],
                    capture_output=True,
                    timeout=5,
                    shell=True
                )
                if result.returncode == 0:
                    killed.append(browser)
                    log.info(f"🔪 Killed browser: {browser}")
            except Exception:
                pass
        if killed:
            log.info(f"✅ Killed browsers: {', '.join(killed)}")
        return killed

    def _block_all_browsers(self):
        return self._block_specific_browsers(self.browser_list)

    def _block_specific_browsers(self, browsers):
        try:
            import winreg
            blocked_count = 0
            for browser in browsers:
                try:
                    key_path = f"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\{browser}"
                    key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, key_path)
                    winreg.SetValueEx(key, "Debugger", 0, winreg.REG_SZ,
                                     f"cmd.exe /c echo Browser '{browser}' is blocked by SentryUSB & timeout /t 2")
                    winreg.CloseKey(key)
                    log.info(f"🔒 Blocked browser: {browser}")
                    blocked_count += 1
                except Exception:
                    pass
            log.info(f"✅ Blocked {blocked_count} browsers")
            return blocked_count
        except Exception as e:
            log.error(f"Failed to block browsers: {e}")
            return 0

    def _unblock_all_browsers(self):
        try:
            import winreg
            unblocked_count = 0
            for browser in self.browser_list:
                try:
                    key_path = f"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\{browser}"
                    try:
                        winreg.DeleteKey(winreg.HKEY_LOCAL_MACHINE, key_path)
                        log.info(f"🔓 Unblocked browser: {browser}")
                        unblocked_count += 1
                    except FileNotFoundError:
                        pass
                except Exception:
                    pass
            log.info(f"✅ Unblocked {unblocked_count} browsers")
            return unblocked_count
        except Exception as e:
            log.error(f"Failed to unblock browsers: {e}")
            return 0

    def _block_all_usb(self):
        try:
            import winreg
            key_path = "SYSTEM\\CurrentControlSet\\Services\\USBSTOR"
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, key_path)
            winreg.SetValueEx(key, "Start", 0, winreg.REG_DWORD, 4)
            winreg.CloseKey(key)
            log.info("🔒 USB devices blocked")
            return True
        except Exception:
            return False

    def _unblock_usb(self):
        try:
            import winreg
            key_path = "SYSTEM\\CurrentControlSet\\Services\\USBSTOR"
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, key_path)
            winreg.SetValueEx(key, "Start", 0, winreg.REG_DWORD, 3)
            winreg.CloseKey(key)
            log.info("🔓 USB devices unblocked")
            return True
        except Exception:
            return False

    def _block_internet_except_allowed(self):
        try:
            allowed_websites = getattr(config, 'LOCKDOWN_ALLOWED_WEBSITES', [])
            subprocess.run([
                "netsh", "advfirewall", "firewall", "add", "rule",
                "name=SentryUSB_Block_All_Out", "dir=out", "action=block",
                "remoteip=0.0.0.0/0"
            ], capture_output=True, timeout=10, shell=True)

            allowed_count = 0
            for website in allowed_websites:
                if website.strip():
                    try:
                        ip = socket.gethostbyname(website.strip())
                        subprocess.run([
                            "netsh", "advfirewall", "firewall", "add", "rule",
                            f"name=SentryUSB_Allow_{website.replace('.', '_')}",
                            "dir=out", "action=allow", f"remoteip={ip}"
                        ], capture_output=True, timeout=10, shell=True)
                        allowed_count += 1
                    except Exception:
                        pass
            log.info(f"🔒 Internet blocked, {allowed_count} websites allowed")
            return True
        except Exception:
            return False

    def _unblock_internet(self):
        try:
            subprocess.run([
                "netsh", "advfirewall", "firewall", "delete", "rule",
                "name=SentryUSB_Block_All_Out"
            ], capture_output=True, timeout=10, shell=True)
            subprocess.run([
                "netsh", "advfirewall", "firewall", "delete", "rule",
                "name=SentryUSB_Allow_*"
            ], capture_output=True, timeout=10, shell=True)
            log.info("🔓 Internet unblocked")
            return True
        except Exception:
            return False

    def _disable_copy_paste_global(self):
        try:
            import winreg
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisableClipboard", 0, winreg.REG_DWORD, 1)
            winreg.CloseKey(key)
            log.info("🔒 Copy-paste disabled")
            return True
        except Exception:
            return False

    def _enable_copy_paste(self):
        try:
            import winreg
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisableClipboard", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            log.info("🔓 Copy-paste enabled")
            return True
        except Exception:
            return False

    def _disable_print_screen_global(self):
        try:
            import winreg
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisablePrintScreen", 0, winreg.REG_DWORD, 1)
            winreg.CloseKey(key)
            log.info("🔒 Print screen disabled")
            return True
        except Exception:
            return False

    def _enable_print_screen(self):
        try:
            import winreg
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisablePrintScreen", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            log.info("🔓 Print screen enabled")
            return True
        except Exception:
            return False

    def _disable_alt_tab(self):
        try:
            import winreg
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "NoAltTab", 0, winreg.REG_DWORD, 1)
            winreg.CloseKey(key)
            log.info("🔒 Alt+Tab disabled")
            return True
        except Exception:
            return False

    def _enable_alt_tab(self):
        try:
            import winreg
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "NoAltTab", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            log.info("🔓 Alt+Tab enabled")
            return True
        except Exception:
            return False

    def _disable_task_manager(self):
        try:
            import winreg
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisableTaskMgr", 0, winreg.REG_DWORD, 1)
            winreg.CloseKey(key)
            log.info("🔒 Task Manager disabled")
            return True
        except Exception:
            return False

    def _enable_task_manager(self):
        try:
            import winreg
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisableTaskMgr", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            log.info("🔓 Task Manager enabled")
            return True
        except Exception:
            return False

    def _send_browser_event(self, event, data):
        if self._is_connected and self._is_registered:
            try:
                data["hostname"] = self.hostname
                self._emit_safe(event, data)
                log.info(f"📤 Sent browser event: {event}")
            except Exception as e:
                log.error(f"Failed to send browser event: {e}")
        else:
            data["hostname"] = self.hostname
            self._queue_event(event, data)
            log.debug(f"📤 Queued browser event: {event}")

    def _send_rdp_event(self, event, data):
        if self._is_connected and self._is_registered:
            try:
                data["hostname"] = self.hostname
                self._emit_safe(event, data)
                log.info(f"📤 Sent RDP event: {event}")
            except Exception as e:
                log.error(f"Failed to send RDP event: {e}")
        else:
            data["hostname"] = self.hostname
            self._queue_event(event, data)
            log.debug(f"📤 Queued RDP event: {event}")

    def _send_rdp_status(self):
        if RDP_MONITOR_AVAILABLE and self.rdp_monitor and self._is_registered:
            try:
                status = self.rdp_monitor.get_status()
                status["hostname"] = self.hostname
                self._emit_safe("rdp_status_response", status)
                log.info(f"📊 Sent RDP status: {status['session_count']} sessions, {status['remote_tool_count']} tools")
            except Exception as e:
                log.error(f"Failed to send RDP status: {e}")

    def _register_agent(self):
        """Register agent with server - supports multiple token attempts"""
        if not self._is_connected:
            log.warning("Not connected to server, cannot register")
            return

        if self._is_registered:
            log.debug("Already registered, skipping...")
            return

        if not self._register_lock.acquire(blocking=False):
            return  # another attempt is already running
        try:
            self._register_agent_locked()
        finally:
            self._register_lock.release()

    def _register_agent_locked(self):
        self._registration_attempts += 1

        log.info(f"🔄 Registering agent with server (attempt {self._registration_attempts})...")

        tokens_to_try = [
            config.AUTH_TOKEN,
            getattr(config, 'BACKUP_AUTH_TOKEN', None),
            self._get_token_from_cache(),
        ]
        tokens_to_try = [t for t in tokens_to_try if t]

        fresh_token = self._fetch_token_from_server()
        if fresh_token and fresh_token not in tokens_to_try:
            tokens_to_try.append(fresh_token)

        for token in tokens_to_try:
            if self._try_register_with_token(token):
                return

        log.warning("All registration attempts failed; retrying (unlimited, backoff)")
        self._is_registered = False
        delay = min(30, 2 ** min(self._registration_attempts, 5))
        threading.Timer(delay, self._register_agent).start()

    def _try_register_with_token(self, token):
        """Try to register with a specific token"""
        if not token:
            return False

        if self._is_registered:
            return True

        browser_status = {}
        if BROWSER_MONITOR_AVAILABLE and self.browser_monitor:
            try:
                browser_status = self.browser_monitor.get_status()
            except Exception:
                pass

        rdp_status = {}
        if RDP_MONITOR_AVAILABLE and self.rdp_monitor:
            try:
                rdp_status = self.rdp_monitor.get_status()
            except Exception:
                pass

        registration_data = {
            "token": token,
            "hostname": self.hostname,
            "ip_address": self.ip_address,
            "username": self.username,
            "exam_available": EXAM_LOCKDOWN_AVAILABLE,
            "exam_active": self.exam_active,
            "browser_monitor": BROWSER_MONITOR_AVAILABLE,
            "browser_count": browser_status.get("browser_count", 0),
            "rdp_monitor": RDP_MONITOR_AVAILABLE,
            "rdp_session_count": rdp_status.get("session_count", 0),
            "rdp_remote_tool_count": rdp_status.get("remote_tool_count", 0),
            "lockdown_enabled": self.lockdown_enabled,
            "lockdown_exempt": self.lockdown_exempt,
            "version": "2.0.0",
            "token_attempt": self._registration_attempts,
            "policy_accepted_version": policy_ui.load_accepted_version(),
        }

        try:
            result = self.sio.call("agent_register", registration_data, timeout=10)
            if result and result.get("status") == "ok":
                log.info("✅ Registration successful with token")
                self._save_token_to_cache(token)
                self._apply_ack(result)
                return True
        except Exception as e:
            log.debug(f"Registration with token failed: {e}")

        return False

    def _fetch_token_from_server(self):
        """Fetch token from server endpoint"""
        try:
            import requests
            response = requests.get(
                f"{config.SERVER_URL}/api/agent-token",
                timeout=5,
                headers={"X-Requested-With": "SentryUSB-Agent"}
            )
            if response.status_code == 200:
                data = response.json()
                token = data.get("token")
                if token:
                    log.info("✅ Fetched fresh token from server")
                    return token
        except Exception as e:
            log.debug(f"Failed to fetch token: {e}")
        return None

    def _get_token_from_cache(self):
        """Get token from local cache file"""
        try:
            cache_path = os.path.join(os.path.dirname(__file__), "token_cache.json")
            if os.path.exists(cache_path):
                with open(cache_path, 'r') as f:
                    data = json.load(f)
                    token = data.get("token")
                    expiry = data.get("expiry", 0)
                    if time.time() < expiry:
                        log.debug(f"Using cached token from {cache_path}")
                        return token
        except Exception:
            pass
        return None

    def _save_token_to_cache(self, token):
        """Save working token to cache"""
        try:
            cache_path = os.path.join(os.path.dirname(__file__), "token_cache.json")
            data = {
                "token": token,
                "expiry": time.time() + 3600  # 1 hour
            }
            with open(cache_path, 'w') as f:
                json.dump(data, f)
            log.debug(f"Saved token to cache: {cache_path}")
        except Exception:
            pass

    def _reset_registration_attempts(self):
        """Reset registration attempts after timeout"""
        self._registration_attempts = 0
        if self._is_connected and not self._is_registered:
            log.info("🔄 Registration attempts reset, retrying...")
            self._register_agent()

    def _health_report(self):
        while not self._stop_reconnect.is_set():
            time.sleep(getattr(config, 'HEALTH_REPORT_INTERVAL', 30))
            if self._is_connected and self._is_registered:
                try:
                    status = {
                        "hostname": self.hostname,
                        "timestamp": time.time(),
                        "uptime": time.time() - self._start_time if self._start_time else 0,
                        "exam_active": self.exam_active,
                        "lockdown_enabled": self.lockdown_enabled,
                        "browser_count": len(self.browser_monitor.active_browsers) if self.browser_monitor else 0,
                        "rdp_session_count": len(self.rdp_monitor.active_sessions) if self.rdp_monitor else 0,
                        "rdp_remote_tool_count": len(self.rdp_monitor.active_remote_tools) if self.rdp_monitor else 0
                    }
                    self._emit_safe("agent_health", status)
                except Exception:
                    pass

    def _process_violation_response(self, success: bool, device_name: str) -> tuple:
        """
        Shared response logic for any blocked device (USB or Bluetooth):
        graduated response, local alarm, and evidence capture.
        Returns (extra_payload_fields: dict, trigger_shutdown: bool).
        """
        extras = {}
        if not success:
            return extras, False

        self._violation_count += 1
        extras["violation_count"] = self._violation_count

        if config.SHUTDOWN_REQUIRE_EXAM_MODE:
            active = self.exam_active or self.lockdown_enabled
        else:
            active = True
        trigger_shutdown = False

        if config.SHUTDOWN_ON_USB_VIOLATION and active:
            if config.GRADUATED_RESPONSE_ENABLED:
                if self._violation_count >= config.GRADUATED_RESPONSE_THRESHOLD:
                    trigger_shutdown = True
                    extras["critical_action"] = "auto_" + config.SHUTDOWN_ACTION
                else:
                    extras["critical_action"] = "warning"
                    log.warning(
                        f"⚠️ Violation {self._violation_count}/{config.GRADUATED_RESPONSE_THRESHOLD} "
                        f"for this session — warning only, not yet triggering {config.SHUTDOWN_ACTION}."
                    )
            else:
                trigger_shutdown = True
                extras["critical_action"] = "auto_" + config.SHUTDOWN_ACTION

        if getattr(config, "LOCAL_ALARM_ENABLED", False):
            try:
                threading.Thread(target=device_utils.local_alarm, daemon=True).start()
            except Exception as e:
                log.debug(f"Local alarm failed to start: {e}")

        if getattr(config, "EVIDENCE_CAPTURE_ENABLED", False):
            try:
                ok, shot_b64 = device_utils.capture_screenshot()
                if ok:
                    extras["evidence_screenshot"] = shot_b64
                else:
                    log.debug("Screenshot evidence not captured.")
            except Exception as e:
                log.debug(f"Screenshot capture error: {e}")

            if getattr(config, "EVIDENCE_CAPTURE_WEBCAM", False):
                try:
                    ok, frame_b64 = device_utils.capture_webcam_frame()
                    if ok:
                        extras["evidence_webcam"] = frame_b64
                except Exception as e:
                    log.debug(f"Webcam capture error: {e}")

        return extras, trigger_shutdown

    def _fire_shutdown_action(self, device_name: str):
        """Actually perform the configured lock/logoff/shutdown action."""
        log.warning(f"🛑 Exam-integrity violation on {device_name} — action={config.SHUTDOWN_ACTION}")
        if config.SHUTDOWN_ACTION == "lock":
            device_utils.lock_workstation()
        elif config.SHUTDOWN_ACTION == "logoff":
            device_utils.logoff_user()
        else:
            device_utils.shutdown_system(
                delay_seconds=config.SHUTDOWN_DELAY_SECONDS,
                force=config.SHUTDOWN_FORCE_CLOSE_APPS,
                message="SentryUSB: unauthorized device detected. "
                        "Workstation shutting down for exam integrity enforcement."
            )

    def handle_new_bluetooth_device(self, pnp_entity):
        """Same treatment as handle_new_device, for Bluetooth connect events."""
        device_id = device_utils.get_device_instance_id(pnp_entity)
        if not device_id:
            return

        if device_utils.is_device_recently_processed(device_id, self._device_cooldown):
            return

        device_name = device_utils.get_device_description(pnp_entity) or "Bluetooth device"
        log.warning(f"📶 Bluetooth device detected: {device_name} ({device_id})")

        success = False
        if config.BLUETOOTH_BLOCK_ENABLED:
            success, output = device_utils.disable_device(device_id)
            if not success:
                log.warning(f"Bluetooth disable failed for {device_id}: {output}")

        extras, trigger_shutdown = self._process_violation_response(success, device_name)

        session_id = str(uuid.uuid4())
        payload = {
            "session_id": session_id,
            "hostname": self.hostname,
            "ip_address": self.ip_address,
            "username": self.username,
            "vendor_id": "unknown",
            "product_id": "unknown",
            "serial_number": "unknown",
            "device_instance_id": device_id,
            "device_name": device_name,
            "device_type": "bluetooth",
            "status": "blocked" if success else "detected",
            "exam_mode": self.exam_active,
            "lockdown_mode": self.lockdown_enabled,
        }
        payload.update(extras)

        try:
            if self._is_connected and self._is_registered:
                self.sio.emit("usb_event", payload)
            else:
                self._queue_event("usb_event", payload)
        except Exception as e:
            log.error(f"Failed to send Bluetooth event: {e}")
            self._queue_event("usb_event", payload)

        if trigger_shutdown:
            self._fire_shutdown_action(device_name)

    def handle_new_device(self, pnp_entity):
        """Handle USB device detection - always send event to server"""
        device_id = device_utils.get_device_instance_id(pnp_entity)
        if not device_id:
            return

        device_id_upper = device_id.upper()

        if "VOLUME" in device_id_upper or "SWD\\WPDBUSENUM" in device_id_upper:
            log.debug(f"Skipping volume/SWD device: {device_id}")
            return

        if not device_utils.is_mass_storage(pnp_entity):
            if config.BLUETOOTH_WATCH_ENABLED and device_utils.is_bluetooth_device(pnp_entity):
                self.handle_new_bluetooth_device(pnp_entity)
            elif is_hid(pnp_entity):
                # HID handling is monitor-only by default. Enforce mode is a
                # deliberate deployment choice because disabling the wrong HID
                # can remove the keyboard/mouse needed to recover the PC.
                vendor_id, product_id = device_utils.parse_vid_pid(device_id)
                serial_number = device_utils.parse_serial(device_id)
                device_fp, _ = fingerprint(pnp_entity, vendor_id, product_id, serial_number)
                fingerprint_changed, previous_fp = detect_fingerprint_change(device_id, device_fp) if config.FIRMWARE_FINGERPRINT_MONITORING else (False, None)
                trusted = is_trusted_hid(device_id, device_fp, config.TRUSTED_HID_IDS)
                enforce = config.ZERO_TRUST_HID_MODE == "enforce" and not trusted
                success, output = (False, "monitor-only")
                if enforce:
                    success, output = device_utils.disable_device(device_id)
                payload = {
                    "session_id": str(uuid.uuid4()), "hostname": self.hostname, "ip_address": self.ip_address,
                    "username": self.username, "vendor_id": vendor_id or "unknown", "product_id": product_id or "unknown",
                    "serial_number": serial_number or "unknown", "device_instance_id": device_id,
                    "device_name": device_utils.get_device_description(pnp_entity), "device_type": "hid",
                    "device_class": device_class(pnp_entity), "device_fingerprint": device_fp,
                    "firmware_fingerprint_changed": fingerprint_changed, "previous_fingerprint": previous_fp,
                    "zero_trust_mode": config.ZERO_TRUST_HID_MODE, "trusted": trusted,
                    "status": "blocked" if success else ("approval_required" if not trusted else "allowed"),
                    "enforcement_detail": output, "exam_mode": self.exam_active, "lockdown_mode": self.lockdown_enabled,
                }
                self._emit_safe("usb_event", payload)
            else:
                log.debug(f"Skipping non-storage device: {device_id}")
            return

        if device_utils.is_device_recently_processed(device_id, self._device_cooldown):
            log.debug(f"Device {device_id} on cooldown, skipping")
            return

        device_name = device_utils.get_device_description(pnp_entity)
        vendor_id, product_id = device_utils.parse_vid_pid(device_id)
        serial_number = device_utils.parse_serial(device_id)

        log.info(f"🔌 USB Device Detected: {device_name}")
        log.info(f"   VID: {vendor_id}, PID: {product_id}, SN: {serial_number}")

        should_block = self.lockdown_enabled or self.exam_active

        if not should_block:
            log.info("🔒 General mode: Blocking USB device by default")
            should_block = True

        success = False
        if should_block:
            log.warning(f"🔒 USB mass storage detected: {device_name} - disabling.")
            success, output = device_utils.disable_device(device_id)

            if not success:
                log.warning(f"First disable attempt failed: {output}")
                log.info(f"Searching for physical USB device with serial: {serial_number}")

                try:
                    import wmi
                    import pythoncom
                    pythoncom.CoInitialize()
                    try:
                        c = wmi.WMI()
                        usb_devices = c.Win32_PnPEntity(DeviceID__contains="USBSTOR")
                        for dev in usb_devices:
                            dev_id = getattr(dev, "DeviceID", "")
                            if dev_id and serial_number:
                                dev_serial = device_utils.parse_serial(dev_id)
                                if dev_serial and serial_number in dev_serial:
                                    if "USBSTOR" in dev_id.upper() and "DISK&VEN" in dev_id.upper():
                                        if "VOLUME" not in dev_id.upper() and "SWD" not in dev_id.upper():
                                            log.info(f"🔍 Found physical USB device: {dev_id}")
                                            success2, output2 = device_utils.disable_device(dev_id)
                                            if success2:
                                                log.info(f"✅ Successfully disabled physical device: {dev_id}")
                                                device_id = dev_id
                                                success = True
                                                break
                    except Exception as e:
                        log.error(f"Error searching for physical device: {e}")
                    finally:
                        try:
                            pythoncom.CoUninitialize()
                        except Exception:
                            pass
                except Exception as e:
                    log.error(f"Failed to search for physical device: {e}")

            if success:
                log.info(f"✅ USB device blocked: {device_name}")
                status = "blocked"
            else:
                log.error(f"❌ Failed to disable USB device: {device_name} (device_id={device_id}) — "
                          f"last attempted pnputil/PowerShell output logged above. If this keeps "
                          f"failing, the drive letter WILL still be visible/usable in Explorer, "
                          f"since Windows already auto-mounted it before this ran.")
                status = "allowed"
        else:
            log.info(f"✅ USB device allowed (not blocking): {device_name}")
            status = "allowed"

        session_id = str(uuid.uuid4())
        self._active_sessions[device_id] = session_id

        extras, trigger_shutdown = self._process_violation_response(success, device_name)

        payload = {
            "session_id": session_id,
            "hostname": self.hostname,
            "ip_address": self.ip_address,
            "username": self.username,
            "vendor_id": vendor_id or "unknown",
            "product_id": product_id or "unknown",
            "serial_number": serial_number or "unknown",
            "device_instance_id": device_id,
            "device_name": device_name,
            "device_type": "storage",
            "device_class": device_utils.get_device_class_label(pnp_entity),
            "status": status,
            "exam_mode": self.exam_active,
            "lockdown_mode": self.lockdown_enabled,
        }
        device_fp, _ = fingerprint(pnp_entity, vendor_id, product_id, serial_number)
        fingerprint_changed, previous_fp = detect_fingerprint_change(device_id, device_fp) if config.FIRMWARE_FINGERPRINT_MONITORING else (False, None)
        payload.update({"device_fingerprint": device_fp, "firmware_fingerprint_changed": fingerprint_changed,
                        "previous_fingerprint": previous_fp, "zero_trust_mode": "storage-default-block"})
        payload.update(extras)

        log.info(f"📤 Sending USB event to server: {device_name} ({status}, "
                 f"violation #{extras.get('violation_count', 0)})")

        try:
            if self._is_connected and self._is_registered:
                self.sio.emit("usb_event", payload)
                log.info("✅ USB event sent successfully")
            else:
                self._queue_event("usb_event", payload)
                log.warning("⚠️ Not connected, queued USB event")
        except Exception as e:
            log.error(f"Failed to send USB event: {e}")
            self._queue_event("usb_event", payload)

        if trigger_shutdown:
            self._fire_shutdown_action(device_name)

    def handle_removed_device(self, pnp_entity):
        """Handle USB device removal"""
        device_id = device_utils.get_device_instance_id(pnp_entity)
        if not device_id:
            return

        device_id_upper = device_id.upper()
        if "VOLUME" in device_id_upper or "SWD\\WPDBUSENUM" in device_id_upper:
            return

        if not device_utils.is_mass_storage(pnp_entity):
            return

        session_id = self._active_sessions.pop(device_id, None)
        device_name = device_utils.get_device_description(pnp_entity)
        log.info("🔌 USB device removed: %s", device_name)

        payload = {
            "session_id": session_id,
            "hostname": self.hostname,
            "device_instance_id": device_id,
            "device_name": device_name,
        }

        self._emit_safe("usb_event_removed", payload)

        # Clear the device cache to allow immediate re-detection
        device_utils.clear_device_cache_entry(device_id)

    def _monitor_connection(self):
        while not self._stop_reconnect.is_set():
            time.sleep(5)
            if self._is_connected and not self._is_registered:
                log.info("🔄 Not registered, attempting registration...")
                self._register_agent()

    # ===== SHUTDOWN METHOD =====
    def shutdown(self):
        """Clean up resources and unblock everything."""
        log.info("🛑 Shutting down agent...")
        self._stop_reconnect.set()

        # Stop USB watcher
        if hasattr(self, 'watcher'):
            self.watcher.stop()

        # Stop browser monitor
        if hasattr(self, 'browser_monitor') and self.browser_monitor:
            self.browser_monitor.stop()

        # Stop RDP monitor
        if hasattr(self, 'rdp_monitor') and self.rdp_monitor:
            self.rdp_monitor.stop()

        # If exam/lockdown active, unblock everything
        if self.exam_active:
            log.info("Unblocking exam lockdown during shutdown...")
            self._unblock_all_browsers()
            self._unblock_usb()
            self._unblock_internet()
            self._enable_copy_paste()
            self._enable_print_screen()
            self._enable_alt_tab()
            self._enable_task_manager()
            self.exam_active = False
            self.lockdown_enabled = False

        # Disconnect socket
        if self.sio and self.sio.connected:
            self.sio.disconnect()

        log.info("✅ Agent shutdown complete.")

    def run(self):
        if not is_admin():
            log.error("⚠️ SentryUSB agent must run with Administrator privileges.")
            sys.exit(1)

        self._start_time = time.time()
        log.info("=" * 60)
        log.info("🚀 Starting SentryUSB Agent on %s", self.hostname)
        log.info("📡 Server URL: %s", config.SERVER_URL)
        log.info("👤 User: %s", self.username)
        log.info("🌐 IP: %s", self.ip_address)
        log.info("=" * 60)
        if EXAM_LOCKDOWN_AVAILABLE:
            log.info("🔒 Exam Lockdown: AVAILABLE")
        if BROWSER_MONITOR_AVAILABLE:
            log.info("🔍 Browser Monitor: AVAILABLE")
        if RDP_MONITOR_AVAILABLE:
            log.info("🖥️ RDP Monitor: AVAILABLE")
        log.info("=" * 60)

        self.watcher.start()
        self._announce_startup()
        log.info("👀 USB watcher started - waiting for USB devices...")

        # Health thread can stay
        self._health_thread = threading.Thread(target=self._health_report, daemon=True)
        self._health_thread.start()
        threading.Thread(target=self._monitor_connection, daemon=True, name="sentryusb-conn-monitor").start()

        while not self._terminate_requested:
            try:
                # Only connect if not already connected
                if not self.sio.connected:
                    log.info("🔌 Connecting to server at %s ...", config.SERVER_URL)
                    self.sio.connect(config.SERVER_URL, wait_timeout=10)
                    self._connection_attempts = 0
                else:
                    log.debug("Already connected, waiting...")

                # Wait for the connection to close (blocks until disconnect)
                self.sio.wait()

            except socketio.exceptions.ConnectionError as e:
                self._connection_attempts += 1
                delay = min(30, config.RECONNECT_DELAY_SECONDS + self._connection_attempts)  # unlimited, capped backoff
                log.warning("Connection failed (%s); retrying in %ss. Attempt %s", e, delay, self._connection_attempts)
                time.sleep(delay)

            except KeyboardInterrupt:
                log.info("Shutting down (keyboard interrupt).")
                break

            except Exception as e:
                log.error("Unexpected error: %s", e)
                time.sleep(config.RECONNECT_DELAY_SECONDS)

            if self._terminate_requested:
                break

        log.info("Cleaning up...")
        self.shutdown()
        log.info("✅ SentryUSB Agent stopped.")

if __name__ == "__main__":
    agent = SentryUSBAgent()
    agent.run()
