"""
SentryUSB - Exam Lockdown Module
Handles browser blocking, USB lockdown, and exam mode activation
"""
import os
import sys
import logging
import subprocess
import time
import threading
import json
import socket
import winreg
import ctypes
from datetime import datetime

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("WARNING: psutil not installed. Some features disabled.")

log = logging.getLogger("sentryusb.exam_lockdown")
try:
    from offline_exam_runtime import OfflineExamRuntime
except ImportError:  # package-style launch
    from .offline_exam_runtime import OfflineExamRuntime


# ============================================================
# CONFIGURATION
# ============================================================

EXAM_CONFIG = {
    "enabled": False,
    "exam_url": "",
    "allowed_browsers": [],  # Empty = block all browsers
    "block_usb": True,
    "block_internet": True,
    "block_copy_paste": True,
    "block_print_screen": True,
    "block_task_manager": True,
    "block_alt_tab": True,
    "exam_duration": 3600,  # 1 hour default
    "start_time": "",
    "end_time": "",
}

# Browsers to block
BLOCKED_BROWSERS = [
    "chrome.exe",
    "firefox.exe", 
    "msedge.exe",
    "brave.exe",
    "opera.exe",
    "iexplore.exe",
    "vivaldi.exe",
    "chromium.exe",
    "browser.exe",
    "safari.exe",
    "maxthon.exe",
    "avast.exe",
    "avant.exe",
]

# Critical system processes to protect
PROTECTED_PROCESSES = [
    "csrss.exe",
    "winlogon.exe",
    "services.exe",
    "lsass.exe",
    "svchost.exe",
    "explorer.exe",
    "taskmgr.exe",
]


class ExamLockdown:
    """Main Exam Lockdown Controller"""
    
    def __init__(self, server_url=None, auth_token=None):
        self.server_url = server_url
        self.auth_token = auth_token
        self.is_active = False
        self.exam_thread = None
        self.monitor_thread = None
        self.blocked_ips = []
        self.allowed_ips = []
        self._stop_event = threading.Event()
        self._lock = threading.Lock()
        
        # Durable local timer and append-only event queue survive server/network loss.
        self.offline_runtime = OfflineExamRuntime()
        # Load config
        self.load_config()
        self._recover_exam_state()
        
    def _recover_exam_state(self):
        """Resume a previously active local timer after an agent process restart."""
        try:
            state = self.offline_runtime.current()
            if not state:
                return
            if state.get("status") == "completed":
                EXAM_CONFIG["enabled"] = False
                self.save_config()
                return
            if state.get("status") != "active":
                return
            remaining = int(state.get("remaining_seconds", 0))
            if remaining <= 0:
                EXAM_CONFIG["enabled"] = False
                self.save_config()
                self.offline_runtime.record("exam_deadline_expired_during_restart", {"exam_id": state.get("exam_id")})
                return
            # Use the original absolute deadline; never restart the full duration.
            EXAM_CONFIG["enabled"] = True
            EXAM_CONFIG["exam_duration"] = int(state.get("duration_seconds", remaining))
            EXAM_CONFIG["end_time"] = float(state["deadline_epoch"])
            self.is_active = True
            self._stop_event.clear()
            # Re-apply the configured, disclosed exam restrictions locally; the
            # absolute deadline remains unchanged and does not depend on the server.
            self.kill_browsers()
            self.block_browser_launch()
            if EXAM_CONFIG.get("block_usb"):
                self.block_usb_devices()
            if EXAM_CONFIG.get("block_internet") and EXAM_CONFIG.get("exam_url"):
                self.block_internet_except_exam(EXAM_CONFIG.get("exam_url"))
            if EXAM_CONFIG.get("block_copy_paste"):
                self.disable_copy_paste()
            if EXAM_CONFIG.get("block_print_screen"):
                self.disable_print_screen()
            if EXAM_CONFIG.get("block_task_manager"):
                self.disable_task_manager()
            if EXAM_CONFIG.get("block_alt_tab"):
                self.disable_alt_tab()
            if EXAM_CONFIG.get("exam_url"):
                self.launch_exam_browser(EXAM_CONFIG["exam_url"])
            self.start_monitoring()
            self.offline_runtime.record("exam_recovered_after_restart", {"exam_id": state.get("exam_id"), "remaining_seconds": remaining})
            log.warning("Recovered active exam locally with %s seconds remaining", remaining)
        except Exception as exc:
            log.exception("Could not recover local exam state: %s", exc)

    def load_config(self):
        """Load exam configuration from file"""
        config_path = os.path.join(os.path.dirname(__file__), "exam_config.json")
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    loaded = json.load(f)
                    EXAM_CONFIG.update(loaded)
                log.info("Exam config loaded from %s", config_path)
            except Exception as e:
                log.error("Failed to load exam config: %s", e)
        else:
            self.save_config()
    
    def save_config(self):
        """Save exam configuration to file"""
        config_path = os.path.join(os.path.dirname(__file__), "exam_config.json")
        try:
            with open(config_path, 'w') as f:
                json.dump(EXAM_CONFIG, f, indent=4)
            log.info("Exam config saved to %s", config_path)
        except Exception as e:
            log.error("Failed to save exam config: %s", e)
    
    # ============================================================
    # MAIN EXAM CONTROL
    # ============================================================
    
    def start_exam(self, exam_url=None, duration=3600):
        """Start exam lockdown mode"""
        if self.is_active:
            log.warning("Exam mode already active")
            return False
        
        log.info("🚀 Starting exam lockdown mode...")
        
        # Update config
        if exam_url:
            EXAM_CONFIG["exam_url"] = exam_url
        EXAM_CONFIG["enabled"] = True
        EXAM_CONFIG["start_time"] = datetime.now().isoformat()
        EXAM_CONFIG["exam_duration"] = duration
        EXAM_CONFIG["end_time"] = (datetime.now().timestamp() + duration)
        self.save_config()
        try:
            self.offline_runtime.start(duration, policy_version=EXAM_CONFIG.get("policy_version"))
        except Exception as exc:
            log.error("Could not persist local exam deadline: %s", exc)
            return False
        
        self.is_active = True
        self._stop_event.clear()
        
        # Start lockdown
        try:
            # 1. Kill all browsers
            self.kill_browsers()
            
            # 2. Block browsers from launching
            self.block_browser_launch()
            
            # 3. Block USB devices
            if EXAM_CONFIG["block_usb"]:
                self.block_usb_devices()
            
            # 4. Block internet (except exam server)
            if EXAM_CONFIG["block_internet"] and exam_url:
                self.block_internet_except_exam(exam_url)
            
            # 5. Disable copy-paste
            if EXAM_CONFIG["block_copy_paste"]:
                self.disable_copy_paste()
            
            # 6. Disable print screen
            if EXAM_CONFIG["block_print_screen"]:
                self.disable_print_screen()
            
            # 7. Disable task manager
            if EXAM_CONFIG["block_task_manager"]:
                self.disable_task_manager()
            
            # 8. Disable Alt+Tab
            if EXAM_CONFIG["block_alt_tab"]:
                self.disable_alt_tab()
            
            # 9. Launch exam browser if URL provided
            if exam_url:
                self.launch_exam_browser(exam_url)
            
            # 10. Start monitoring threads
            self.start_monitoring()
            
            log.info("✅ Exam lockdown mode started successfully!")
            
            # Notify server
            self.notify_server("exam_started", {
                "exam_url": exam_url,
                "duration": duration,
                "start_time": EXAM_CONFIG["start_time"]
            })
            
            return True
            
        except Exception as e:
            log.error("Failed to start exam: %s", e)
            self.is_active = False
            return False
    
    def stop_exam(self):
        """Stop exam lockdown mode"""
        if not self.is_active:
            log.warning("Exam mode is not active")
            return False
        
        log.info("🛑 Stopping exam lockdown mode...")
        
        self._stop_event.set()
        self.is_active = False
        
        try:
            # 1. Unblock browsers
            self.unblock_browser_launch()
            
            # 2. Unblock USB
            if EXAM_CONFIG["block_usb"]:
                self.unblock_usb_devices()
            
            # 3. Unblock internet
            if EXAM_CONFIG["block_internet"]:
                self.unblock_internet()
            
            # 4. Enable copy-paste
            if EXAM_CONFIG["block_copy_paste"]:
                self.enable_copy_paste()
            
            # 5. Enable print screen
            if EXAM_CONFIG["block_print_screen"]:
                self.enable_print_screen()
            
            # 6. Enable task manager
            if EXAM_CONFIG["block_task_manager"]:
                self.enable_task_manager()
            
            # 7. Enable Alt+Tab
            if EXAM_CONFIG["block_alt_tab"]:
                self.enable_alt_tab()
            
            # 8. Kill exam browser
            self.kill_exam_browser()
            
            EXAM_CONFIG["enabled"] = False
            self.save_config()
            try:
                self.offline_runtime.finish("operator_or_policy_stop")
            except Exception as exc:
                log.error("Could not persist exam completion: %s", exc)
            
            log.info("✅ Exam lockdown mode stopped!")
            
            # Notify server
            self.notify_server("exam_stopped", {
                "end_time": datetime.now().isoformat()
            })
            
            return True
            
        except Exception as e:
            log.error("Failed to stop exam: %s", e)
            return False
    
    # ============================================================
    # BROWSER CONTROL
    # ============================================================
    
    def kill_browsers(self):
        """Kill all running browsers"""
        if not PSUTIL_AVAILABLE:
            log.warning("psutil not available, using taskkill")
            for browser in BLOCKED_BROWSERS:
                try:
                    subprocess.run(["taskkill", "/f", "/im", browser], 
                                 capture_output=True, timeout=5)
                except:
                    pass
            return
        
        killed = []
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                proc_name = proc.info['name'].lower()
                if proc_name in [b.lower() for b in BLOCKED_BROWSERS]:
                    proc.kill()
                    killed.append(proc_name)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        
        if killed:
            log.info("Killed browsers: %s", killed)
    
    def block_browser_launch(self):
        """Prevent browsers from launching"""
        # Method 1: Image File Execution Options (IFEO)
        for browser in BLOCKED_BROWSERS:
            try:
                key_path = f"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\{browser}"
                key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, key_path)
                winreg.SetValueEx(key, "Debugger", 0, winreg.REG_SZ, 
                                 f"cmd.exe /c echo Browser '{browser}' is blocked in exam mode & timeout /t 2")
                winreg.CloseKey(key)
                log.debug("Blocked browser: %s", browser)
            except Exception as e:
                log.debug("Failed to block %s: %s", browser, e)
        
        # Method 2: Software Restriction Policies (SRP)
        try:
            key_path = "SOFTWARE\\Policies\\Microsoft\\Windows\\Safer\\CodeIdentifiers"
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, key_path)
            winreg.SetValueEx(key, "DefaultLevel", 0, winreg.REG_DWORD, 262144)
            
            # Add blocked browsers to SRP
            for i, browser in enumerate(BLOCKED_BROWSERS, 1):
                app_key = winreg.CreateKey(key, str(i))
                winreg.SetValueEx(app_key, "ItemData", 0, winreg.REG_SZ, browser)
                winreg.SetValueEx(app_key, "SaferFlags", 0, winreg.REG_DWORD, 0)
                winreg.CloseKey(app_key)
            
            winreg.CloseKey(key)
            log.info("Browser launch blocking enabled via SRP")
        except Exception as e:
            log.debug("SRP blocking failed: %s", e)
    
    def unblock_browser_launch(self):
        """Allow browsers to launch again"""
        # Remove IFEO entries
        for browser in BLOCKED_BROWSERS:
            try:
                key_path = f"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\{browser}"
                winreg.DeleteKey(winreg.HKEY_LOCAL_MACHINE, key_path)
            except:
                pass
        
        # Remove SRP entries
        try:
            key_path = "SOFTWARE\\Policies\\Microsoft\\Windows\\Safer\\CodeIdentifiers"
            winreg.DeleteKey(winreg.HKEY_LOCAL_MACHINE, key_path)
        except:
            pass
        
        log.info("Browser launch blocking removed")
    
    def launch_exam_browser(self, exam_url):
        """Launch exam browser in kiosk mode"""
        # Find Chrome
        chrome_paths = [
            "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe",
        ]
        
        chrome_path = None
        for path in chrome_paths:
            if os.path.exists(path):
                chrome_path = path
                break
        
        if not chrome_path:
            log.warning("Chrome not found, trying to launch default browser")
            subprocess.Popen([os.environ.get('COMSPEC'), '/c', 'start', exam_url])
            return
        
        # Launch Chrome in kiosk mode
        chrome_args = [
            chrome_path,
            "--kiosk",
            "--disable-extensions",
            "--disable-plugins",
            "--disable-printing",
            "--disable-save-password-bubble",
            "--disable-infobars",
            "--disable-session-crashed-bubble",
            "--disable-default-apps",
            "--disable-component-update",
            "--disable-background-networking",
            "--disable-sync",
            "--disable-features=TranslateUI",
            "--disable-features=ChromeWhatsNewUI",
            "--disable-features=ChromeTips",
            "--disable-features=ChromeLabs",
            "--disable-features=ChromeFlags",
            "--disable-features=ChromeAdPrivacy",
            "--disable-features=ChromeSearch",
            "--no-default-browser-check",
            "--no-first-run",
            "--noerrdialogs",
            "--disable-welcome-page",
            "--disable-gpu",
            "--enable-features=KioskMode",
            f"--app={exam_url}",
        ]
        
        try:
            subprocess.Popen(chrome_args)
            log.info("Exam browser launched: %s", exam_url)
        except Exception as e:
            log.error("Failed to launch exam browser: %s", e)
    
    def kill_exam_browser(self):
        """Kill the exam browser"""
        subprocess.run(["taskkill", "/f", "/im", "chrome.exe"], capture_output=True)
        log.info("Exam browser killed")
    
    # ============================================================
    # USB CONTROL
    # ============================================================
    
    def block_usb_devices(self):
        """Block USB storage devices via registry"""
        try:
            # USBSTOR registry key
            key_path = "SYSTEM\\CurrentControlSet\\Services\\USBSTOR"
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, key_path)
            winreg.SetValueEx(key, "Start", 0, winreg.REG_DWORD, 4)  # 4 = Disabled
            winreg.CloseKey(key)
            
            # Also disable USB devices
            usb_key_path = "SYSTEM\\CurrentControlSet\\Services\\USB"
            try:
                key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, usb_key_path)
                winreg.SetValueEx(key, "Start", 0, winreg.REG_DWORD, 4)
                winreg.CloseKey(key)
            except:
                pass
            
            log.info("USB devices blocked")
        except Exception as e:
            log.error("Failed to block USB: %s", e)
    
    def unblock_usb_devices(self):
        """Unblock USB storage devices"""
        try:
            key_path = "SYSTEM\\CurrentControlSet\\Services\\USBSTOR"
            key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, key_path)
            winreg.SetValueEx(key, "Start", 0, winreg.REG_DWORD, 3)  # 3 = Manual
            winreg.CloseKey(key)
            
            # Also enable USB devices
            usb_key_path = "SYSTEM\\CurrentControlSet\\Services\\USB"
            try:
                key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, usb_key_path)
                winreg.SetValueEx(key, "Start", 0, winreg.REG_DWORD, 3)
                winreg.CloseKey(key)
            except:
                pass
            
            log.info("USB devices unblocked")
        except Exception as e:
            log.error("Failed to unblock USB: %s", e)
    
    # ============================================================
    # NETWORK CONTROL
    # ============================================================
    
    def block_internet_except_exam(self, exam_url):
        """Block all internet except the exam server"""
        try:
            import urllib.parse
            
            # Extract domain/IP from URL
            parsed = urllib.parse.urlparse(exam_url)
            exam_domain = parsed.netloc or parsed.path
            exam_ip = self.resolve_domain(exam_domain)
            
            if not exam_ip:
                log.warning("Could not resolve exam URL")
                return
            
            # Add Windows Firewall rules
            # Block all outbound
            subprocess.run([
                "netsh", "advfirewall", "firewall", "add", "rule",
                "name=Exam_Block_All_Out", "dir=out", "action=block",
                "remoteip=0.0.0.0/0"
            ], capture_output=True)
            
            # Allow only exam server
            subprocess.run([
                "netsh", "advfirewall", "firewall", "add", "rule",
                "name=Exam_Allow_Server", "dir=out", "action=allow",
                f"remoteip={exam_ip}"
            ], capture_output=True)
            
            # Also allow local network (for agent-server communication)
            local_ip = self.get_local_ip()
            if local_ip:
                subprocess.run([
                    "netsh", "advfirewall", "firewall", "add", "rule",
                    "name=Exam_Allow_Local", "dir=out", "action=allow",
                    f"remoteip={local_ip}"
                ], capture_output=True)
            
            log.info("Internet blocked except for %s (%s)", exam_url, exam_ip)
            
        except Exception as e:
            log.error("Failed to block internet: %s", e)
    
    def unblock_internet(self):
        """Remove internet blocking rules"""
        try:
            subprocess.run([
                "netsh", "advfirewall", "firewall", "delete", "rule",
                "name=Exam_Block_All_Out"
            ], capture_output=True)
            
            subprocess.run([
                "netsh", "advfirewall", "firewall", "delete", "rule",
                "name=Exam_Allow_Server"
            ], capture_output=True)
            
            subprocess.run([
                "netsh", "advfirewall", "firewall", "delete", "rule",
                "name=Exam_Allow_Local"
            ], capture_output=True)
            
            log.info("Internet blocking removed")
        except Exception as e:
            log.error("Failed to remove internet blocking: %s", e)
    
    # ============================================================
    # SYSTEM RESTRICTIONS
    # ============================================================
    
    def disable_copy_paste(self):
        """Disable copy-paste globally"""
        try:
            # Disable Clipboard
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisableClipboard", 0, winreg.REG_DWORD, 1)
            winreg.CloseKey(key)
            
            log.info("Copy-paste disabled")
        except Exception as e:
            log.error("Failed to disable copy-paste: %s", e)
    
    def enable_copy_paste(self):
        """Enable copy-paste globally"""
        try:
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisableClipboard", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            
            log.info("Copy-paste enabled")
        except Exception as e:
            log.error("Failed to enable copy-paste: %s", e)
    
    def disable_print_screen(self):
        """Disable Print Screen key"""
        try:
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisablePrintScreen", 0, winreg.REG_DWORD, 1)
            winreg.CloseKey(key)
            
            log.info("Print Screen disabled")
        except Exception as e:
            log.error("Failed to disable print screen: %s", e)
    
    def enable_print_screen(self):
        """Enable Print Screen key"""
        try:
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisablePrintScreen", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            
            log.info("Print Screen enabled")
        except Exception as e:
            log.error("Failed to enable print screen: %s", e)
    
    def disable_task_manager(self):
        """Disable Task Manager"""
        try:
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisableTaskMgr", 0, winreg.REG_DWORD, 1)
            winreg.CloseKey(key)
            
            # Also disable Ctrl+Shift+Esc
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisableTaskMgr", 0, winreg.REG_DWORD, 1)
            winreg.CloseKey(key)
            
            log.info("Task Manager disabled")
        except Exception as e:
            log.error("Failed to disable task manager: %s", e)
    
    def enable_task_manager(self):
        """Enable Task Manager"""
        try:
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisableTaskMgr", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "DisableTaskMgr", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            
            log.info("Task Manager enabled")
        except Exception as e:
            log.error("Failed to enable task manager: %s", e)
    
    def disable_alt_tab(self):
        """Disable Alt+Tab switching"""
        try:
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "NoAltTab", 0, winreg.REG_DWORD, 1)
            winreg.CloseKey(key)
            
            log.info("Alt+Tab disabled")
        except Exception as e:
            log.error("Failed to disable Alt+Tab: %s", e)
    
    def enable_alt_tab(self):
        """Enable Alt+Tab switching"""
        try:
            key_path = "SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\Explorer"
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, key_path)
            winreg.SetValueEx(key, "NoAltTab", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            
            log.info("Alt+Tab enabled")
        except Exception as e:
            log.error("Failed to enable Alt+Tab: %s", e)
    
    # ============================================================
    # MONITORING
    # ============================================================
    
    def start_monitoring(self):
        """Start monitoring threads"""
        # Monitor for browsers
        self.monitor_thread = threading.Thread(target=self._monitor_browsers, daemon=True)
        self.monitor_thread.start()
        
        # Monitor for exam duration
        exam_thread = threading.Thread(target=self._monitor_exam_duration, daemon=True)
        exam_thread.start()
        
        log.info("Monitoring threads started")
    
    def _monitor_browsers(self):
        """Continuously kill browsers during exam"""
        while not self._stop_event.is_set() and self.is_active:
            try:
                self.kill_browsers()
            except Exception as e:
                log.debug("Browser monitoring error: %s", e)
            time.sleep(2)
    
    def _monitor_exam_duration(self):
        """Monitor exam duration and auto-stop"""
        if not EXAM_CONFIG.get("exam_duration"):
            return
        
        end_time = EXAM_CONFIG.get("end_time", 0)
        if isinstance(end_time, str):
            try:
                end_time = float(end_time)
            except:
                end_time = 0
        
        while not self._stop_event.is_set() and self.is_active:
            if end_time and time.time() >= end_time:
                log.info("Exam duration expired, auto-stopping...")
                self.stop_exam()
                break
            time.sleep(10)
    
    # ============================================================
    # SERVER COMMUNICATION
    # ============================================================
    
    def notify_server(self, event, data=None):
        """Send exam status to server"""
        try:
            self.offline_runtime.record("server_status_event", {"event": event, "data": data or {}})
        except Exception as exc:
            log.error("Could not journal exam event locally: %s", exc)
        if not self.server_url:
            return
        
        import requests
        try:
            payload = {
                "event": event,
                "hostname": socket.gethostname(),
                "timestamp": datetime.now().isoformat(),
                "data": data or {}
            }
            headers = {"X-Auth-Token": self.auth_token} if self.auth_token else {}
            
            response = requests.post(
                f"{self.server_url}/api/exam/status",
                json=payload,
                headers=headers,
                timeout=5
            )
            if response.ok:
                # Keep the queued record until the server has a dedicated event-ID
                # acknowledgement endpoint; this avoids silently dropping audit data.
                log.info("Exam status sent to server: %s", event)
            else:
                log.warning("Server did not accept exam status (%s); event remains queued", response.status_code)
        except Exception as e:
            log.info("Server unavailable; exam event remains queued for reconciliation: %s", e)
    
    # ============================================================
    # HELPERS
    # ============================================================
    
    def resolve_domain(self, domain):
        """Resolve domain to IP address"""
        try:
            # Remove port if present
            if ':' in domain:
                domain = domain.split(':')[0]
            return socket.gethostbyname(domain)
        except:
            return None
    
    def get_local_ip(self):
        """Get local IP address"""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return None
    
    def is_admin(self):
        """Check if running as administrator"""
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except:
            return False
    
    def get_status(self):
        """Get current exam status"""
        return {
            "active": self.is_active,
            "exam_url": EXAM_CONFIG.get("exam_url"),
            "start_time": EXAM_CONFIG.get("start_time"),
            "duration": EXAM_CONFIG.get("exam_duration"),
            "remaining": self.get_remaining_time() if self.is_active else 0
        }
    
    def get_remaining_time(self):
        """Get remaining exam time in seconds"""
        if not self.is_active:
            return 0
        end_time = EXAM_CONFIG.get("end_time", 0)
        if isinstance(end_time, str):
            try:
                end_time = float(end_time)
            except:
                return 0
        return max(0, end_time - time.time())


# ============================================================
# STANDALONE COMMAND-LINE INTERFACE
# ============================================================

def main():
    """Command-line interface for exam lockdown"""
    import argparse
    
    parser = argparse.ArgumentParser(description="SentryUSB Exam Lockdown")
    parser.add_argument("action", choices=["start", "stop", "status", "config"],
                       help="Action to perform")
    parser.add_argument("--url", help="Exam URL for browser kiosk mode")
    parser.add_argument("--duration", type=int, default=3600,
                       help="Exam duration in seconds")
    
    args = parser.parse_args()
    
    lockdown = ExamLockdown()
    
    if args.action == "start":
        if not lockdown.is_admin():
            print("⚠️  This requires Administrator privileges!")
            print("Please run as Administrator.")
            sys.exit(1)
        
        success = lockdown.start_exam(args.url, args.duration)
        if success:
            print("✅ Exam lockdown started!")
            print(f"📍 Exam URL: {args.url}")
            print(f"⏱️  Duration: {args.duration} seconds")
        else:
            print("❌ Failed to start exam lockdown")
    
    elif args.action == "stop":
        if not lockdown.is_admin():
            print("⚠️  This requires Administrator privileges!")
            sys.exit(1)
        
        success = lockdown.stop_exam()
        if success:
            print("✅ Exam lockdown stopped!")
        else:
            print("❌ Failed to stop exam lockdown")
    
    elif args.action == "status":
        status = lockdown.get_status()
        print("📊 Exam Status:")
        print(f"  Active: {status['active']}")
        if status['active']:
            print(f"  URL: {status['exam_url']}")
            print(f"  Started: {status['start_time']}")
            print(f"  Remaining: {status['remaining']:.0f} seconds")
    
    elif args.action == "config":
        print("📋 Current Configuration:")
        for key, value in EXAM_CONFIG.items():
            print(f"  {key}: {value}")


if __name__ == "__main__":
    main()