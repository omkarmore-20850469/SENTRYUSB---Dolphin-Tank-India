"""Durable, transparent offline exam timer and event journal for SentryUSB agent.

This module preserves a signed-off exam deadline across agent restarts and network
outages. It does not hide monitoring or disable OS recovery/security controls.
The caller remains responsible for applying the institution-approved exam policy.
"""
from __future__ import annotations
import json, os, time, uuid, threading
from pathlib import Path
from datetime import datetime, timezone

class OfflineExamRuntime:
    def __init__(self, state_dir=None):
        self.root = Path(state_dir or Path(__file__).resolve().parent / 'runtime_state')
        self.root.mkdir(parents=True, exist_ok=True)
        self.state_path = self.root / 'exam_state.json'
        self.events_path = self.root / 'exam_events.jsonl'
        self.queue_path = self.root / 'pending_events.jsonl'
        self._lock = threading.RLock()

    @staticmethod
    def _now():
        return datetime.now(timezone.utc).isoformat()

    def record(self, event, details=None, queue_for_server=True):
        row = {'event_id': uuid.uuid4().hex, 'event': str(event), 'timestamp_utc': self._now(),
               'details': details or {}}
        line = json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n'
        with self._lock:
            with self.events_path.open('a', encoding='utf-8') as f:
                f.write(line); f.flush(); os.fsync(f.fileno())
            if queue_for_server:
                with self.queue_path.open('a', encoding='utf-8') as f:
                    f.write(line); f.flush(); os.fsync(f.fileno())
        return row

    def start(self, duration_seconds, exam_id=None, policy_version=None):
        duration = int(duration_seconds)
        if duration < 1 or duration > 24 * 60 * 60:
            raise ValueError('Exam duration must be between 1 second and 24 hours')
        state = {'exam_id': exam_id or uuid.uuid4().hex, 'policy_version': policy_version,
                 'started_at_epoch': time.time(), 'deadline_epoch': time.time() + duration,
                 'duration_seconds': duration, 'status': 'active'}
        with self._lock:
            tmp = self.state_path.with_suffix('.tmp')
            tmp.write_text(json.dumps(state, indent=2), encoding='utf-8')
            os.replace(tmp, self.state_path)
        self.record('exam_started_local', {'exam_id': state['exam_id'], 'deadline_epoch': state['deadline_epoch'],
                                           'duration_seconds': duration, 'policy_version': policy_version})
        return state

    def current(self):
        with self._lock:
            if not self.state_path.exists(): return None
            try: state = json.loads(self.state_path.read_text(encoding='utf-8'))
            except (OSError, ValueError):
                self.record('exam_state_corrupt', {}, queue_for_server=True); return None
        if state.get('status') != 'active': return state
        remaining = max(0, int(state.get('deadline_epoch', 0) - time.time()))
        state['remaining_seconds'] = remaining
        if remaining == 0:
            self.finish('deadline_expired')
            state['status'] = 'completed'
            state['remaining_seconds'] = 0
        return state

    def finish(self, reason='operator_ended'):
        with self._lock:
            state = {}
            if self.state_path.exists():
                try: state = json.loads(self.state_path.read_text(encoding='utf-8'))
                except (OSError, ValueError): pass
            state.update({'status': 'completed', 'ended_at_epoch': time.time(), 'end_reason': reason})
            tmp = self.state_path.with_suffix('.tmp')
            tmp.write_text(json.dumps(state, indent=2), encoding='utf-8'); os.replace(tmp, self.state_path)
        self.record('exam_finished_local', {'exam_id': state.get('exam_id'), 'reason': reason})
        return state

    def pending(self, limit=500):
        with self._lock:
            if not self.queue_path.exists(): return []
            rows=[]
            for line in self.queue_path.read_text(encoding='utf-8').splitlines():
                try: rows.append(json.loads(line))
                except ValueError: continue
            return rows[:max(1, min(int(limit), 5000))]

    def acknowledge(self, event_ids):
        acknowledged = set(event_ids or [])
        with self._lock:
            if not self.queue_path.exists(): return 0
            keep=[]; removed=0
            for line in self.queue_path.read_text(encoding='utf-8').splitlines():
                try: row=json.loads(line)
                except ValueError: keep.append(line); continue
                if row.get('event_id') in acknowledged: removed += 1
                else: keep.append(json.dumps(row, ensure_ascii=False, separators=(',', ':')))
            tmp=self.queue_path.with_suffix('.tmp')
            tmp.write_text(('\n'.join(keep)+'\n') if keep else '', encoding='utf-8'); os.replace(tmp, self.queue_path)
            return removed

    def reconcile(self, sender, batch_size=100):
        """Deliver queued events in order. sender(rows) must return acknowledged event IDs."""
        sent=0
        while True:
            batch=self.pending(batch_size)
            if not batch: break
            try: ack=sender(batch)
            except Exception: break
            if not ack: break
            sent += self.acknowledge(ack)
            if len(ack) < len(batch): break
        return sent
