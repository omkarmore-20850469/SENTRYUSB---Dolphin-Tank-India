"""SentryUSB agent - full-screen policy consent dialog (glass UI).

The policy text scrolls independently while the action bar remains visible.
Consent is explicit: the user must choose Accept or Decline.

Visual design: a frosted-glass card floating over a deep gradient with soft
colour orbs, the SentryUSB shield logo in the header / watermark / footer, a
reading-progress bar and pill buttons. Everything is rendered with Pillow and
drawn on a Tk canvas, so no extra files are needed when the agent is packaged.
If Pillow is missing, the original flat dialog is used instead - consent
behaviour is identical either way.
"""
import json
import logging
import os
import threading
import time

log = logging.getLogger("sentryusb.policy_ui")
STATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "policy_state.json")

_lock = threading.Lock()
_showing = False

# Palette
BG, CARD, FG, MUTED, ACC, OK, NO = (
    "#070b18", "#10172e", "#f1f5f9", "#94a3b8",
    "#4dd6ff", "#34d399", "#334155"
)


def load_accepted_version():
    try:
        with open(STATE_PATH, "r", encoding="utf-8") as fh:
            return int(json.load(fh).get("accepted_version"))
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        return None


def save_accepted_version(version, user=""):
    try:
        with open(STATE_PATH, "w", encoding="utf-8") as fh:
            json.dump({"accepted_version": int(version), "accepted_at": time.time(), "user": user}, fh)
    except (OSError, TypeError, ValueError) as exc:
        log.warning("Could not persist policy acceptance: %s", exc)


def is_showing():
    return _showing


# ---------------------------------------------------------------------------
# Glass rendering helpers (Pillow)
# ---------------------------------------------------------------------------
def _rounded_mask(size, radius, ss=4):
    from PIL import Image, ImageDraw
    w, h = size
    m = Image.new("L", (w * ss, h * ss), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, w * ss - 1, h * ss - 1), radius=radius * ss, fill=255)
    return m.resize((w, h), Image.LANCZOS)


def _gradient(size, c1, c2, vertical=True):
    """Two-colour linear gradient as an RGB image."""
    from PIL import Image
    w, h = size
    g = Image.linear_gradient("L")
    if not vertical:
        g = g.rotate(90, expand=True).transpose(Image.FLIP_LEFT_RIGHT)
    g = g.resize((w, h), Image.BILINEAR)
    return Image.composite(Image.new("RGB", (w, h), c2), Image.new("RGB", (w, h), c1), g)


def _make_background(W, H, S):
    """Deep gradient + blurred colour orbs + faint grid."""
    from PIL import Image, ImageDraw, ImageFilter
    base = _gradient((W, H), (5, 8, 24), (16, 14, 52)).convert("RGBA")
    sw, sh = max(1, W // 4), max(1, H // 4)
    orbs = Image.new("RGBA", (sw, sh), (0, 0, 0, 0))
    d = ImageDraw.Draw(orbs)
    m = min(sw, sh)
    for fx, fy, fr, col in (
        (0.10, 0.14, 0.52, (34, 211, 238, 215)),
        (0.90, 0.30, 0.58, (139, 92, 246, 225)),
        (0.20, 0.95, 0.46, (244, 114, 182, 185)),
        (0.78, 0.98, 0.44, (59, 130, 246, 205)),
        (0.52, 0.02, 0.30, (56, 189, 248, 120)),
    ):
        r = fr * m * 0.5
        d.ellipse((fx * sw - r, fy * sh - r, fx * sw + r, fy * sh + r), fill=col)
    orbs = orbs.filter(ImageFilter.GaussianBlur(max(6, int(m * 0.16))))
    base.alpha_composite(orbs.resize((W, H), Image.BICUBIC))
    # faint grid for a "tech" feel
    grid = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    gd = ImageDraw.Draw(grid)
    step = max(32, int(64 * S))
    for x in range(0, W, step):
        gd.line((x, 0, x, H), fill=(255, 255, 255, 6))
    for y in range(0, H, step):
        gd.line((0, y, W, y), fill=(255, 255, 255, 6))
    base.alpha_composite(grid)
    return base


def _crisp_orb(img, cx, cy, r, c1, c2):
    """Sharp gradient disc straddling the card edge - this is what makes the
    frosted glass visibly blur what is behind it."""
    from PIL import Image
    d = int(r * 2)
    disc = _gradient((d, d), c1, c2).convert("RGBA")
    disc.putalpha(_rounded_mask((d, d), d // 2))
    img.alpha_composite(disc, (int(cx - r), int(cy - r)))


def _glass_scene(W, H, S, box, radius, pane_box, logo, hostname_unused=None):
    """Compose the full-screen scene: background, orbs, glass card, inset
    reading pane, watermark and header/footer logos. Returns (RGBA image,
    pane colour)."""
    from PIL import Image, ImageDraw, ImageFilter

    scene = _make_background(W, H, S)
    x0, y0, x1, y1 = box
    cw, ch = x1 - x0, y1 - y0
    _crisp_orb(scene, x0 + cw * 0.03, y0 + ch * 0.10, H * 0.13, (34, 211, 238), (59, 130, 246))
    _crisp_orb(scene, x1 - cw * 0.02, y1 - ch * 0.06, H * 0.17, (244, 114, 182), (139, 92, 246))
    _crisp_orb(scene, x1 - cw * 0.08, y0 - ch * 0.01, H * 0.065, (103, 232, 249), (34, 211, 238))

    # drop shadow
    sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle((x0, y0 + int(26 * S), x1, y1 + int(26 * S)), radius=radius, fill=(0, 0, 0, 125))
    scene.alpha_composite(sh.filter(ImageFilter.GaussianBlur(int(38 * S))))

    # frosted glass: blur what is behind, tint, add a top-lit sheen
    region = scene.crop(box).convert("RGB").filter(ImageFilter.GaussianBlur(int(24 * S)))
    glass = Image.blend(region, Image.new("RGB", region.size, (12, 16, 44)), 0.48)
    sheen = Image.linear_gradient("L").rotate(180).resize((cw, ch)).point(lambda v: int(v * 0.17))
    glass = Image.composite(Image.new("RGB", glass.size, (255, 255, 255)), glass, sheen).convert("RGBA")

    # watermark logo (large, very faint) inside the card
    wm = int(ch * 0.62)
    mark = logo.resize((wm, wm), Image.LANCZOS)
    a = mark.getchannel("A").point(lambda v: int(v * 0.075))
    mark.putalpha(a)
    glass.alpha_composite(mark, (cw - wm - int(18 * S), ch - wm - int(10 * S)))

    # inset reading pane (near-opaque so the Text widget can match it exactly)
    px0, py0, px1, py1 = pane_box
    pw, ph = px1 - px0, py1 - py0
    pane_rgb = (10, 14, 36)
    pane = Image.new("RGBA", (pw, ph), pane_rgb + (246,))
    pane.putalpha(_rounded_mask((pw, ph), int(18 * S)).point(lambda v: int(v * 246 / 255)))
    glass.alpha_composite(pane, (px0 - x0, py0 - y0))
    ImageDraw.Draw(glass).rounded_rectangle(
        (px0 - x0, py0 - y0, px1 - x0 - 1, py1 - y0 - 1), radius=int(18 * S), outline=(255, 255, 255, 34), width=1)

    # header + footer logos
    hl = int(78 * S)
    glass.alpha_composite(logo.resize((hl, hl), Image.LANCZOS), (int(30 * S), int(30 * S)))

    # card border: soft outer line + brighter top edge
    border = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    bd = ImageDraw.Draw(border)
    bd.rounded_rectangle((0, 0, cw - 1, ch - 1), radius=radius, outline=(255, 255, 255, 58), width=1)
    bd.rounded_rectangle((2, 2, cw - 3, ch - 3), radius=radius - 2, outline=(255, 255, 255, 14), width=1)
    bd.line((radius, 1, cw - radius, 1), fill=(255, 255, 255, 110), width=1)
    glass.alpha_composite(border)

    glass.putalpha(_rounded_mask((cw, ch), radius))
    scene.alpha_composite(glass, (x0, y0))
    return scene, pane_rgb


def _pill(size, c1, c2, glow=None, outline=None, alpha=255):
    """Rounded pill image: gradient (c1->c2 left to right) or flat glass."""
    from PIL import Image, ImageDraw, ImageFilter
    w, h = size
    pad = 14 if glow else 0
    out = Image.new("RGBA", (w + 2 * pad, h + 2 * pad), (0, 0, 0, 0))
    if glow:
        gl = Image.new("RGBA", out.size, (0, 0, 0, 0))
        ImageDraw.Draw(gl).rounded_rectangle((pad, pad + 4, pad + w, pad + h + 4), radius=h // 2, fill=glow + (120,))
        out.alpha_composite(gl.filter(ImageFilter.GaussianBlur(9)))
    body = _gradient((w, h), c1, c2, vertical=False).convert("RGBA")
    body.putalpha(_rounded_mask((w, h), h // 2).point(lambda v: int(v * alpha / 255)))
    if outline:
        ImageDraw.Draw(body).rounded_rectangle((0, 0, w - 1, h - 1), radius=h // 2, outline=outline, width=1)
    # top highlight
    hi = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(hi).rounded_rectangle((2, 1, w - 3, h // 2), radius=h // 4, fill=(255, 255, 255, 26))
    body.alpha_composite(hi)
    out.alpha_composite(body, (pad, pad))
    return out


def _chip(size, fill=(255, 255, 255, 22), outline=(255, 255, 255, 60)):
    from PIL import Image, ImageDraw
    w, h = size
    img = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    ImageDraw.Draw(img).rounded_rectangle((0, 0, w - 1, h - 1), radius=h // 2, fill=fill, outline=outline, width=1)
    return img


def _build_glass(root, tk, font_mod, policy, hostname, decide):
    from PIL import ImageTk
    from tkinter import ttk
    import policy_assets

    root.update_idletasks()
    W, H = root.winfo_screenwidth(), root.winfo_screenheight()
    S = max(0.8, min(1.5, H / 1080.0))

    def px(v):
        return int(round(v * S))

    cw = min(W - px(120), px(1200))
    ch = H - px(100)
    x0, y0 = (W - cw) // 2, (H - ch) // 2
    x1, y1 = x0 + cw, y0 + ch
    radius = px(32)
    pane_top = y0 + px(142)
    pane_bot = y1 - px(112)
    pane_box = (x0 + px(34), pane_top, x1 - px(34), pane_bot)

    logo = policy_assets.load_logo()
    scene, pane_rgb = _glass_scene(W, H, S, (x0, y0, x1, y1), radius, pane_box, logo)
    pane_hex = "#%02x%02x%02x" % pane_rgb
    keep = []  # keep PhotoImage references alive

    canvas = tk.Canvas(root, width=W, height=H, highlightthickness=0, bd=0, bg=BG)
    canvas.pack(fill="both", expand=True)
    bg_tk = ImageTk.PhotoImage(scene.convert("RGB"))
    keep.append(bg_tk)
    canvas.create_image(0, 0, image=bg_tk, anchor="nw")

    F = "Segoe UI"
    # ---- header texts ----
    tx = x0 + px(34) + px(78) + px(20)
    canvas.create_text(tx, y0 + px(34), text="S E N T R Y U S B     \u00b7     P O L I C Y   R E V I E W",
                       fill=ACC, anchor="w", font=(F, max(8, px(10)), "bold"))
    title = policy.get("title") or "Monitoring Policy"
    avail = (x1 - px(34)) - tx
    tsize = max(14, px(25))
    tf = font_mod.Font(family=F, size=tsize, weight="bold")
    while tf.measure(title) > avail and tsize > 12:
        tsize -= 1
        tf.configure(size=tsize)
    canvas.create_text(tx, y0 + px(72), text=title, fill=FG, anchor="w", font=tf)
    canvas.create_text(tx, y0 + px(110), text="Please review how this device is monitored, then choose to continue.",
                       fill=MUTED, anchor="w", font=(F, max(8, px(11))))

    # ---- header chips (version + device), top-right ----
    chip_h = px(32)
    chip_y = y0 + px(18)
    host_txt = "\U0001F5A5  " + (hostname or "This PC")
    ver_txt = "Policy v%s" % policy.get("version", "\u2014")
    cf = font_mod.Font(family=F, size=max(8, px(10)), weight="bold")
    cx = x1 - px(34)
    for txt_, tint in ((ver_txt, ACC), (host_txt, FG)):
        wchip = cf.measure(txt_) + px(36)
        ci = ImageTk.PhotoImage(_chip((wchip, chip_h)))
        keep.append(ci)
        canvas.create_image(cx - wchip, chip_y, image=ci, anchor="nw")
        canvas.create_text(cx - wchip // 2, chip_y + chip_h // 2, text=txt_, fill=tint, font=cf)
        cx -= wchip + px(10)

    # ---- reading pane ----
    px0, py0, px1, py1 = pane_box
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
        style.configure("Glass.Vertical.TScrollbar", background="#2b3a6b", troughcolor=pane_hex,
                        bordercolor=pane_hex, lightcolor="#2b3a6b", darkcolor="#2b3a6b",
                        arrowcolor="#7dd3fc", relief="flat", gripcount=0)
        style.map("Glass.Vertical.TScrollbar", background=[("active", "#4059a8")])
    except Exception:
        pass

    holder = tk.Frame(canvas, bg=pane_hex)
    progress = {"frac": 0.0}

    def on_scroll(first, last):
        sb.set(first, last)
        try:
            progress["frac"] = float(last)
            bar_w = int((px1 - px0 - px(8)) * float(last))
            canvas.coords(bar, px0 + px(4), py1 + px(8), px0 + px(4) + max(0, bar_w), py1 + px(10))
        except Exception:
            pass

    sb = ttk.Scrollbar(holder, orient="vertical", style="Glass.Vertical.TScrollbar")
    txt = tk.Text(holder, bg=pane_hex, fg="#dbe5f5", insertbackground=pane_hex, relief="flat", wrap="word",
                  font=(F, max(10, px(13))), padx=px(30), pady=px(24), borderwidth=0, highlightthickness=0,
                  spacing1=px(2), spacing2=px(5), spacing3=px(8), cursor="arrow", yscrollcommand=on_scroll)
    sb.configure(command=txt.yview)
    sb.pack(side="right", fill="y", padx=(0, px(6)), pady=px(10))
    txt.pack(side="left", fill="both", expand=True, padx=(px(4), 0), pady=px(6))
    canvas.create_window(px0 + px(6), py0 + px(4), window=holder, anchor="nw",
                         width=px1 - px0 - px(12), height=py1 - py0 - px(8))
    # reading progress track + fill (below the pane)
    canvas.create_rectangle(px0 + px(4), py1 + px(8), px1 - px(4), py1 + px(10), fill="#1b2547", outline="")
    bar = canvas.create_rectangle(px0 + px(4), py1 + px(8), px0 + px(4), py1 + px(10), fill=ACC, outline="")

    txt.tag_configure("heading", foreground=ACC, font=(F, max(10, px(12)), "bold"), spacing1=px(18), spacing3=px(8))
    txt.tag_configure("bullet", foreground="#a78bfa", font=(F, max(10, px(12)), "bold"), lmargin1=px(6), lmargin2=px(34))
    txt.tag_configure("rule", foreground="#e7eefb", lmargin1=px(34), lmargin2=px(34), spacing3=px(6))
    txt.insert("end", (policy.get("body") or "Please review the policy below.") + "\n")
    rules = policy.get("rules") or []
    if rules:
        txt.insert("end", "\nWHAT THIS COVERS\n", "heading")
        for rule in rules:
            txt.insert("end", "\u25c6  ", "bullet")
            txt.insert("end", str(rule) + "\n", "rule")
    txt.configure(state="disabled")

    # ---- footer: brand + helper text + pill buttons ----
    foot_y = y1 - px(56)
    ml = int(px(26))
    mini = ImageTk.PhotoImage(logo.resize((ml, ml)))
    keep.append(mini)
    canvas.create_image(x0 + px(38), foot_y, image=mini, anchor="w")
    canvas.create_text(x0 + px(38) + ml + px(12), foot_y - px(9), anchor="w", fill=FG,
                       text="Protected by SentryUSB", font=(F, max(8, px(10)), "bold"))
    canvas.create_text(x0 + px(38) + ml + px(12), foot_y + px(11), anchor="w", fill=MUTED,
                       text="Read the policy, then choose Accept or Decline to continue.",
                       font=(F, max(8, px(10))))

    bh = px(54)
    acc_w, dec_w = px(290), px(150)
    acc_n = ImageTk.PhotoImage(_pill((acc_w, bh), (16, 185, 129), (34, 211, 238), glow=(34, 211, 238)))
    acc_h = ImageTk.PhotoImage(_pill((acc_w, bh), (52, 211, 153), (103, 232, 249), glow=(103, 232, 249)))
    dec_n = ImageTk.PhotoImage(_pill((dec_w, bh), (255, 255, 255), (255, 255, 255), outline=(255, 255, 255, 80), alpha=26))
    dec_h = ImageTk.PhotoImage(_pill((dec_w, bh), (255, 255, 255), (255, 255, 255), outline=(255, 255, 255, 140), alpha=55))
    keep += [acc_n, acc_h, dec_n, dec_h]
    pad = 14
    ax1 = x1 - px(34)
    ax0 = ax1 - acc_w
    dx1 = ax0 - px(16)
    dx0 = dx1 - dec_w
    by = foot_y - bh // 2
    a_img = canvas.create_image(ax0 - pad, by - pad, image=acc_n, anchor="nw", tags=("btn_accept",))
    d_img = canvas.create_image(dx0, by, image=dec_n, anchor="nw", tags=("btn_decline",))
    canvas.create_text(ax0 + acc_w // 2, foot_y, text="\u2713   Accept Policy & Connect", fill="#032b1d",
                       font=(F, max(10, px(13)), "bold"), tags=("btn_accept",))
    canvas.create_text(dx0 + dec_w // 2, foot_y, text="Decline", fill=FG,
                       font=(F, max(10, px(13))), tags=("btn_decline",))

    def hover(tag, item, img, on):
        canvas.itemconfigure(item, image=img)
        canvas.configure(cursor="hand2" if on else "")

    canvas.tag_bind("btn_accept", "<Enter>", lambda _e: hover("a", a_img, acc_h, True))
    canvas.tag_bind("btn_accept", "<Leave>", lambda _e: hover("a", a_img, acc_n, False))
    canvas.tag_bind("btn_accept", "<Button-1>", lambda _e: decide(True))
    canvas.tag_bind("btn_decline", "<Enter>", lambda _e: hover("d", d_img, dec_h, True))
    canvas.tag_bind("btn_decline", "<Leave>", lambda _e: hover("d", d_img, dec_n, False))
    canvas.tag_bind("btn_decline", "<Button-1>", lambda _e: decide(False))
    root._sentry_keep = keep  # prevent garbage collection of images


def _build_flat(root, tk, policy, hostname, decide):
    """Original flat dialog - used only when Pillow is unavailable."""
    from tkinter import scrolledtext
    shell = tk.Frame(root, bg=BG)
    shell.pack(fill="both", expand=True, padx=36, pady=24)
    shell.grid_columnconfigure(0, weight=1)
    shell.grid_rowconfigure(2, weight=1)

    head = tk.Frame(shell, bg=BG)
    head.grid(row=0, column=0, sticky="ew", pady=(0, 16))
    tk.Label(
        head, text="🛡  SENTRYUSB  /  POLICY REVIEW", bg=BG, fg=ACC,
        font=("Segoe UI", 12, "bold")
    ).pack(anchor="w", pady=(0, 8))
    tk.Label(
        head, text=policy.get("title") or "Monitoring Policy", bg=BG, fg=FG,
        font=("Segoe UI", 24, "bold"), wraplength=1200, justify="left",
        anchor="w"
    ).pack(anchor="w", fill="x")
    tk.Label(
        head, text=f"Policy version {policy.get('version', '—')}   •   Device: {hostname or 'This PC'}",
        bg=BG, fg=MUTED, font=("Segoe UI", 11)
    ).pack(anchor="w", pady=(8, 0))

    card = tk.Frame(shell, bg=CARD, highlightbackground="#2a3560", highlightthickness=1)
    card.grid(row=2, column=0, sticky="nsew")
    card.grid_columnconfigure(0, weight=1)
    card.grid_rowconfigure(0, weight=1)
    txt = scrolledtext.ScrolledText(
        card, bg=CARD, fg=FG, insertbackground=FG, relief="flat",
        wrap="word", font=("Segoe UI", 12), padx=24, pady=22,
        borderwidth=0, spacing2=5, undo=False
    )
    txt.grid(row=0, column=0, sticky="nsew", padx=8, pady=8)
    txt.insert("end", (policy.get("body") or "Please review the policy below.") + "\n\n")
    rules = policy.get("rules") or []
    if rules:
        txt.insert("end", "WHAT THIS COVERS\n", "heading")
        for rule in rules:
            txt.insert("end", f"  •  {rule}\n")
    txt.tag_configure("heading", foreground=ACC, font=("Segoe UI", 12, "bold"), spacing1=8, spacing3=8)
    txt.configure(state="disabled")

    footer = tk.Frame(shell, bg=BG)
    footer.grid(row=3, column=0, sticky="ew", pady=(16, 0))
    footer.grid_columnconfigure(0, weight=1)
    tk.Label(
        footer, text="Please read the policy, then choose Accept or Decline to continue.",
        bg=BG, fg=MUTED, font=("Segoe UI", 10), anchor="w", wraplength=700
    ).grid(row=0, column=0, sticky="w", padx=(0, 18), pady=4)

    buttons = tk.Frame(footer, bg=BG)
    buttons.grid(row=0, column=1, sticky="e")
    tk.Button(
        buttons, text="Decline", bg=NO, fg=FG, activebackground="#475569",
        activeforeground=FG, relief="flat", font=("Segoe UI", 12),
        padx=28, pady=12, cursor="hand2", command=lambda: decide(False)
    ).pack(side="right", padx=(12, 0))
    accept = tk.Button(
        buttons, text="✓  Accept Policy & Connect", bg=OK, fg="#04210f",
        activebackground="#6ee7b7", activeforeground="#04210f", relief="flat",
        font=("Segoe UI", 12, "bold"), padx=30, pady=12, cursor="hand2",
        command=lambda: decide(True)
    )
    accept.pack(side="right")
    accept.focus_set()
    root.bind("<Return>", lambda _event: decide(True))
    root.bind("<KP_Enter>", lambda _event: decide(True))


def ask_policy(policy, hostname="", timeout=None):
    """Display full-screen consent. Returns True, False, or None if GUI is unavailable."""
    global _showing
    with _lock:
        if _showing:
            return None
        _showing = True

    result = {"v": None}
    root = None
    try:
        import tkinter as tk
        from tkinter import font as font_mod

        root = tk.Tk()
        root.title("SentryUSB \u2014 Policy Acceptance")
        root.configure(bg=BG)
        root.attributes("-topmost", True)
        # True full-screen view on the agent PC; geometry fallback for window managers
        try:
            root.geometry("%dx%d+0+0" % (root.winfo_screenwidth(), root.winfo_screenheight()))
            root.attributes("-fullscreen", True)
        except tk.TclError:
            root.state("zoomed")
        root.minsize(640, 480)
        root.resizable(True, True)

        def decide(val):
            if result["v"] is not None:
                return
            result["v"] = val
            try:
                root.quit()
                root.destroy()
            except tk.TclError:
                pass

        # Require an explicit choice; prevent common window-close shortcuts.
        root.protocol("WM_DELETE_WINDOW", lambda: None)
        root.bind("<Alt-F4>", lambda _event: "break")
        root.bind("<Escape>", lambda _event: "break")
        root.bind("<Control-w>", lambda _event: "break")
        root.bind("<Return>", lambda _event: decide(True))
        root.bind("<KP_Enter>", lambda _event: decide(True))

        try:
            _build_glass(root, tk, font_mod, policy, hostname, decide)
        except Exception as exc:  # Pillow missing or rendering problem -> flat UI
            log.warning("Glass policy UI unavailable (%s); using flat dialog", exc)
            for child in root.winfo_children():
                child.destroy()
            _build_flat(root, tk, policy, hostname, decide)

        if timeout:
            root.after(max(1, int(timeout * 1000)), lambda: decide(None))
        root.mainloop()
    except Exception as exc:
        log.warning("Policy dialog unavailable: %s", exc)
        result["v"] = None
        if root is not None:
            try:
                root.destroy()
            except Exception:
                pass
    finally:
        _showing = False
    return result["v"]
