"""Privacy-preserving behavioural telemetry collector interface.

Callers submit aggregate timing and mouse metrics. Text, key names, window
titles and screen content are never accepted, retained or transmitted.
"""
import time


class BehavioralMetrics:
    def __init__(self, emit_callback, enabled=False):
        self.emit_callback = emit_callback
        self.enabled = enabled
        self._last_emit = 0.0

    def submit_summary(self, subject_token, dwell_ms=0, flight_ms=0, mouse_speed=0, event_rate_hz=0):
        if not self.enabled or not subject_token:
            return False
        now = time.monotonic()
        if now - self._last_emit < 5:
            return False
        self._last_emit = now
        self.emit_callback("behavioral_metrics", {
            "subject_token": str(subject_token)[:128],
            "dwell_ms": max(0, min(float(dwell_ms or 0), 5000)),
            "flight_ms": max(0, min(float(flight_ms or 0), 5000)),
            "mouse_speed": max(0, min(float(mouse_speed or 0), 50000)),
            "event_rate_hz": max(0, min(float(event_rate_hz or 0), 1000)),
            "privacy": "aggregate_only_no_raw_input",
        })
        return True
