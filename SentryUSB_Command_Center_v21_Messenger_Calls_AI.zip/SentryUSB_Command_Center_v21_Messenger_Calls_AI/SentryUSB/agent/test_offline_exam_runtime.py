import tempfile, unittest, time
from offline_exam_runtime import OfflineExamRuntime

class OfflineExamRuntimeTests(unittest.TestCase):
    def test_deadline_survives_new_instance(self):
        with tempfile.TemporaryDirectory() as d:
            a=OfflineExamRuntime(d); state=a.start(30, exam_id='test-exam')
            b=OfflineExamRuntime(d); current=b.current()
            self.assertEqual(current['exam_id'], 'test-exam')
            self.assertLessEqual(current['remaining_seconds'], 30)
            self.assertGreater(current['remaining_seconds'], 0)
            self.assertEqual(state['deadline_epoch'], current['deadline_epoch'])
    def test_event_queue_acknowledgement(self):
        with tempfile.TemporaryDirectory() as d:
            r=OfflineExamRuntime(d); row=r.record('network_disconnected', {})
            self.assertEqual(len(r.pending()), 1)
            self.assertEqual(r.acknowledge([row['event_id']]), 1)
            self.assertEqual(r.pending(), [])
    def test_duration_validation(self):
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(ValueError): OfflineExamRuntime(d).start(0)

if __name__ == '__main__': unittest.main()
