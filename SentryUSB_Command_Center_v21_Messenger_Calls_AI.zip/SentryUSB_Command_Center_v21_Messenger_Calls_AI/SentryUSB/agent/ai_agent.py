# agent/ai_agent.py
"""
AI-enhanced agent capabilities
- Local anomaly detection
- Smart caching of AI models
- Predictive blocking
"""
import pickle
import os
import numpy as np
from datetime import datetime
import logging
from collections import deque

log = logging.getLogger("sentryusb.ai_agent")

class LocalAIEngine:
    """Runs lightweight AI models on the agent"""
    
    def __init__(self):
        self.model_cache = {}
        self.device_behavior = {}
        self.predictions = deque(maxlen=100)
        self.anomaly_threshold = 0.7
        
    def load_model(self, model_name, model_path):
        """Load a pre-trained AI model"""
        if model_name in self.model_cache:
            return self.model_cache[model_name]
        
        if os.path.exists(model_path):
            try:
                with open(model_path, 'rb') as f:
                    model = pickle.load(f)
                    self.model_cache[model_name] = model
                    log.info(f"✅ Loaded AI model: {model_name}")
                    return model
            except Exception as e:
                log.error(f"Failed to load model {model_name}: {e}")
        return None
    
    def analyze_usb_device(self, device_id, device_info):
        """Analyze a USB device for suspicious behavior"""
        # Build device profile
        if device_id not in self.device_behavior:
            self.device_behavior[device_id] = {
                'first_seen': datetime.now(),
                'connection_count': 0,
                'hosts': set(),
                'avg_duration': 0,
                'last_seen': None,
                'connection_times': deque(maxlen=20)
            }
        
        profile = self.device_behavior[device_id]
        profile['connection_count'] += 1
        profile['last_seen'] = datetime.now()
        profile['hosts'].add(device_info.get('hostname'))
        profile['connection_times'].append(datetime.now())
        
        # Calculate features for anomaly detection
        features = self._extract_features(profile)
        anomaly_score = self._calculate_anomaly_score(features)
        
        return {
            'anomaly_score': anomaly_score,
            'is_suspicious': anomaly_score > self.anomaly_threshold,
            'profile': profile
        }
    
    def _extract_features(self, profile):
        """Extract features from device profile"""
        now = datetime.now()
        features = {
            'connection_count': profile['connection_count'],
            'unique_hosts': len(profile['hosts']),
            'age_hours': (now - profile['first_seen']).total_seconds() / 3600,
        }
        
        # Connection frequency
        if profile['connection_times']:
            times = list(profile['connection_times'])
            if len(times) > 1:
                intervals = [(times[i+1] - times[i]).total_seconds() 
                           for i in range(len(times)-1)]
                features['avg_interval'] = np.mean(intervals)
                features['interval_std'] = np.std(intervals)
            else:
                features['avg_interval'] = 0
                features['interval_std'] = 0
            
            # Recency
            features['hours_since_last'] = (now - profile['last_seen']).total_seconds() / 3600
        
        return features
    
    def _calculate_anomaly_score(self, features):
        """Calculate anomaly score using heuristic rules"""
        score = 0
        
        # High connection frequency
        if features.get('connection_count', 0) > 10:
            score += 0.2
        
        # Many hosts
        if features.get('unique_hosts', 0) > 3:
            score += 0.3
        
        # Very new device with high activity
        if features.get('age_hours', 24) < 1 and features.get('connection_count', 0) > 5:
            score += 0.4
        
        return min(score, 1.0)
    
    def predict_browser_blocking(self, browser_name, hostname):
        """
        Predict if a browser should be blocked based on historical patterns
        Returns: (should_block, confidence)
        """
        # Simple rule-based prediction for now
        # Could be enhanced with ML
        
        # Whitelist pattern
        if browser_name.lower() in ['chrome.exe', 'msedge.exe']:
            # Allow these during non-exam times
            return False, 0.1
        
        # Unknown browsers - more suspicious
        if browser_name.lower() not in ['chrome.exe', 'msedge.exe', 'firefox.exe']:
            return True, 0.6
        
        return False, 0.0