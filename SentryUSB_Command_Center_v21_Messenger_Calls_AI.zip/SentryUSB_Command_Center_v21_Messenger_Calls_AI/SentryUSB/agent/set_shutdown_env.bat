@echo off
REM SentryUSB Agent - Auto-Shutdown-on-Violation environment overrides
REM NOTE: config.py's defaults were already changed to match these values,
REM so this script is OPTIONAL. Only run it if you specifically want these
REM values set as persistent machine-wide environment variables (e.g. so
REM they're visible to other tools/scripts, survive a config.py replacement,
REM or you want to flip them per-machine without editing code).
REM Must be run as Administrator (setx /M writes to the machine, not just the user).

REM --- current session (affects only this cmd window / processes it launches) ---
set SENTRYUSB_SHUTDOWN_ON_VIOLATION=true
set SENTRYUSB_SHUTDOWN_REQUIRE_EXAM_MODE=false
set SENTRYUSB_SHUTDOWN_ACTION=shutdown
set SENTRYUSB_SHUTDOWN_DELAY_SECONDS=3
set SENTRYUSB_GRADUATED_RESPONSE=false

REM --- persistent, machine-wide (requires admin; needs a new process/reboot to take effect) ---
setx /M SENTRYUSB_SHUTDOWN_ON_VIOLATION true
setx /M SENTRYUSB_SHUTDOWN_REQUIRE_EXAM_MODE false
setx /M SENTRYUSB_SHUTDOWN_ACTION shutdown
setx /M SENTRYUSB_SHUTDOWN_DELAY_SECONDS 3
setx /M SENTRYUSB_GRADUATED_RESPONSE false

echo Done. These env vars now override config.py's defaults machine-wide.
echo Restart the SentryUSB agent service/process for changes to take effect.
pause
