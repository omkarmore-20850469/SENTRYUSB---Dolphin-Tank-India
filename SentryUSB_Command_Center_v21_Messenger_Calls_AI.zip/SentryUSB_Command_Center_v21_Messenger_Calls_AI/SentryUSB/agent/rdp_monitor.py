"""
SentryUSB - RDP & Remote Access Monitor (agent-side)
------------------------------------------------------
Detects Remote Desktop (RDP) sessions and third-party remote-access tools
(AnyDesk, TeamViewer, Chrome Remote Desktop, VNC variants, Splashtop,
Parsec, ConnectWise/ScreenConnect, etc.) running ON THIS MACHINE, and
reports findings to the server.

This intentionally runs on the agent (the exam PC), not on the lab
server. The server has no way to see who is remoted into a student's
machine - only the machine itself does.
"""
import os
import re
import time
import json
import logging
import threading
import subprocess
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Callable

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("⚠️ psutil not installed. RDP monitoring limited.")

try:
    import winreg
    WINREG_AVAILABLE = True
except ImportError:
    WINREG_AVAILABLE = False

try:
    import win32evtlog
    WIN32EVT_AVAILABLE = True
except ImportError:
    WIN32EVT_AVAILABLE = False

log = logging.getLogger("sentryusb.rdp_monitor")

# ============================================================
# CONFIGURATION / SIGNATURES
# ============================================================

DEFAULT_RDP_PORT = 3389

# Present on the machine being remoted INTO (i.e. this PC, as the RDP host)
RDP_HOST_PROCESSES = ["rdpclip.exe", "rdpinit.exe", "rdpshell.exe"]

# Present on a machine that is remoting OUT to somewhere else (informational only)
RDP_CLIENT_PROCESSES = ["mstsc.exe"]

# Third-party remote-access tools: lowercase process name -> display name.
# These are at least as likely to be used to bypass exam lockdown as native
# RDP, and native RDP detection alone is blind to all of them.
THIRD_PARTY_REMOTE_TOOLS = {
    "anydesk.exe": "AnyDesk",
    "teamviewer.exe": "TeamViewer",
    "teamviewer_service.exe": "TeamViewer",
    "tv_w32.exe": "TeamViewer",
    "tv_x64.exe": "TeamViewer",
    "remoting_host.exe": "Chrome Remote Desktop",
    "winvnc.exe": "UltraVNC / VNC Server",
    "uvnc_service.exe": "UltraVNC",
    "vncviewer.exe": "VNC Viewer",
    "tvnserver.exe": "TightVNC",
    "srserver.exe": "Splashtop Streamer",
    "srservice.exe": "Splashtop Streamer",
    "splashtopstreamer.exe": "Splashtop Streamer",
    "strwinclt.exe": "Splashtop Client",
    "parsecd.exe": "Parsec",
    "parsec.exe": "Parsec",
    "screenconnect.clientservice.exe": "ScreenConnect (ConnectWise Control)",
    "screenconnect.windowsclient.exe": "ScreenConnect (ConnectWise Control)",
    "gotomypc.exe": "GoToMyPC",
    "g2mcomm.exe": "GoToMyPC",
    "logmein.exe": "LogMeIn",
    "lmiignition.exe": "LogMeIn",
    "todesk.exe": "ToDesk",
    "aweray_ars.exe": "AweRay",
}


class RDPMonitor:
    """Monitors this machine for RDP sessions and third-party remote-access tools"""

    def __init__(self):
        self.is_running = False
        self._stop_event = threading.Event()
        self.monitor_thread: Optional[threading.Thread] = None
        self._send_to_server: Optional[Callable] = None
        self._hostname = "unknown"

        self.rdp_port = DEFAULT_RDP_PORT
        self.active_sessions: Dict[str, dict] = {}       # native RDP, keyed by a stable connection/session key
        self.active_remote_tools: Dict[int, dict] = {}   # third-party tools, keyed by pid
        self.event_history: List[dict] = []
        self._max_history = 500
        self._cycle_count = 0

        # Rolling counters from the Windows Security Event Log (best-effort)
        self._recent_rdp_logons = 0
        self._recent_failed_logons = 0
        self._event_log_available = False

        self.load_config()

        if WINREG_AVAILABLE and os.name == "nt":
            self._refresh_rdp_port_from_registry()

        self._load_history()

    # ============================================================
    # CONFIG
    # ============================================================

    def load_config(self):
        config_path = os.path.join(os.path.dirname(__file__), "rdp_config.json")
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    self.config = json.load(f)
                log.info("RDP config loaded")
            except Exception as e:
                log.error(f"Failed to load RDP config: {e}")
                self.config = {}
        else:
            self.config = {
                "monitor_enabled": True,
                "poll_interval_seconds": 15,
                "detect_third_party_tools": True,
                "detect_native_rdp": True,
                "use_event_log": True,
                "event_log_lookback_minutes": 15,
                "event_log_poll_every_n_cycles": 4,
                "alert_on_detection": True
            }
            self.save_config()

    def save_config(self):
        config_path = os.path.join(os.path.dirname(__file__), "rdp_config.json")
        try:
            with open(config_path, 'w') as f:
                json.dump(self.config, f, indent=4)
            log.info("RDP config saved")
        except Exception as e:
            log.error(f"Failed to save RDP config: {e}")

    def set_hostname(self, hostname: str):
        self._hostname = hostname

    def set_send_callback(self, callback: Callable):
        self._send_to_server = callback

    # ============================================================
    # HISTORY PERSISTENCE
    # ============================================================

    def _history_path(self):
        return os.path.join(os.path.dirname(__file__), "rdp_history.json")

    def _load_history(self):
        path = self._history_path()
        if os.path.exists(path):
            try:
                with open(path, 'r') as f:
                    data = json.load(f)
                    self.event_history = data.get('history', [])
                log.info(f"Loaded {len(self.event_history)} RDP history entries")
            except Exception as e:
                log.error(f"Failed to load RDP history: {e}")

    def _save_history(self):
        path = self._history_path()
        try:
            with open(path, 'w') as f:
                json.dump({'history': self.event_history[-self._max_history:]}, f, indent=2)
        except Exception as e:
            log.error(f"Failed to save RDP history: {e}")

    # ============================================================
    # MONITORING LIFECYCLE
    # ============================================================

    def start(self):
        if not PSUTIL_AVAILABLE:
            log.warning("psutil not available. RDP monitoring limited.")
            return
        if not self.config.get("monitor_enabled", True):
            log.info("RDP monitor disabled in config")
            return
        if self.is_running:
            return

        self.is_running = True
        self._stop_event.clear()
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        log.info("🖥️ RDP monitor started (port=%s)", self.rdp_port)

    def stop(self):
        self.is_running = False
        self._stop_event.set()
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        log.info("🖥️ RDP monitor stopped")

    def _monitor_loop(self):
        while not self._stop_event.is_set():
            try:
                self._cycle_count += 1

                if self.config.get("detect_native_rdp", True):
                    self._check_native_rdp()

                if self.config.get("detect_third_party_tools", True):
                    self._check_third_party_tools()

                every_n = max(1, int(self.config.get("event_log_poll_every_n_cycles", 4)))
                if self.config.get("use_event_log", True) and self._cycle_count % every_n == 0:
                    self._check_event_log()

                # Periodic status push so the dashboard stays fresh even with
                # no state change (mirrors browser_monitor's heartbeat).
                if self._send_to_server:
                    self._send_rdp_status()

            except Exception as e:
                log.debug(f"RDP monitor error: {e}")

            time.sleep(max(5, int(self.config.get("poll_interval_seconds", 15))))

    # ============================================================
    # NATIVE RDP DETECTION
    # ============================================================

    def _refresh_rdp_port_from_registry(self):
        """RDP port is hardcoded to 3389 by default; read the real configured
        port so a changed registry value doesn't slip past detection."""
        try:
            key = winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE,
                r"SYSTEM\CurrentControlSet\Control\Terminal Server\WinStations\RDP-Tcp"
            )
            value, _ = winreg.QueryValueEx(key, "PortNumber")
            winreg.CloseKey(key)
            if value:
                if int(value) != self.rdp_port:
                    log.info(f"🖥️ RDP port from registry: {value} (was assuming {self.rdp_port})")
                self.rdp_port = int(value)
        except Exception as e:
            log.debug(f"Could not read RDP port from registry, using default {self.rdp_port}: {e}")

    def _check_native_rdp(self):
        """
        Detect active RDP sessions using structured, cross-platform psutil
        data instead of parsing netstat/query-session text output.
        """
        if not PSUTIL_AVAILABLE:
            return

        current: Dict[str, dict] = {}

        # Method 1: established TCP connections where WE are the RDP host
        # (local port == RDP port). This is the actual "someone is remoted
        # into this machine" signal - checking the local, not remote, port.
        try:
            conns = psutil.net_connections(kind='inet')
        except (psutil.AccessDenied, PermissionError):
            conns = []
        except Exception as e:
            log.debug(f"net_connections failed: {e}")
            conns = []

        for c in conns:
            try:
                if not c.laddr or c.laddr.port != self.rdp_port:
                    continue
                if getattr(c, "status", None) != psutil.CONN_ESTABLISHED:
                    continue
                if not c.raddr:
                    continue
                key = f"conn:{c.raddr.ip}:{c.raddr.port}"
                current[key] = {
                    "type": "rdp_connection",
                    "local_port": c.laddr.port,
                    "remote_ip": c.raddr.ip,
                    "remote_port": c.raddr.port,
                    "pid": c.pid,
                }
            except Exception:
                continue

        # Method 2: Terminal Services session enumeration (Windows only)
        if os.name == "nt":
            for sess in self._query_sessions():
                if sess.get("is_rdp") and sess.get("is_active"):
                    key = f"session:{sess.get('id')}"
                    current[key] = {"type": "rdp_session", **sess}

        # Method 3: host-side clipboard/session helper processes running is a
        # secondary confirmation signal (present while an RDP session is live
        # on the machine being remoted into).
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                name = (proc.info['name'] or "").lower()
                if name in [p.lower() for p in RDP_HOST_PROCESSES]:
                    key = f"proc:{proc.info['pid']}"
                    current[key] = {
                        "type": "rdp_host_process",
                        "process": proc.info['name'],
                        "pid": proc.info['pid'],
                    }
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
            except Exception:
                continue

        self._diff_and_emit(self.active_sessions, current, "rdp_session_started", "rdp_session_ended")
        self.active_sessions = current

    def _query_sessions(self) -> List[dict]:
        """Query Windows Terminal Services sessions via `query session`."""
        sessions = []
        try:
            result = subprocess.run(
                ["query", "session"],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                for line in result.stdout.splitlines()[1:]:  # skip header
                    if not line.strip():
                        continue
                    parsed = self._parse_session_line(line)
                    if parsed:
                        sessions.append(parsed)
        except subprocess.TimeoutExpired:
            log.debug("query session timed out")
        except FileNotFoundError:
            pass  # not on a Windows machine / command unavailable
        except Exception as e:
            log.debug(f"query session failed: {e}")
        return sessions

    def _parse_session_line(self, line: str) -> Optional[Dict]:
        """Parse a line from `query session` output, e.g.:
        ' rdp-tcp#0        jdoe                    2  Active  rdpwd'
        """
        parts = re.split(r"\s{2,}", line.strip())
        if len(parts) < 3:
            return None
        try:
            name = parts[0]
            info = {
                "name": name,
                "is_rdp": name.lower().startswith("rdp-tcp"),
            }
            # Depending on whether a username is present, the ID column
            # shifts. Find the first purely-numeric token as the session ID.
            id_idx = None
            for i, p in enumerate(parts[1:], start=1):
                if p.isdigit():
                    id_idx = i
                    break
            if id_idx is not None:
                info["id"] = int(parts[id_idx])
                if id_idx > 1:
                    info["username"] = parts[1]
                if len(parts) > id_idx + 1:
                    info["state"] = parts[id_idx + 1]
            info["is_active"] = info.get("state", "").lower() == "active"
            return info
        except Exception as e:
            log.debug(f"Failed to parse session line '{line}': {e}")
            return None

    # ============================================================
    # THIRD-PARTY REMOTE-ACCESS TOOL DETECTION
    # ============================================================

    def _check_third_party_tools(self):
        if not PSUTIL_AVAILABLE:
            return

        current: Dict[int, dict] = {}
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                name = (proc.info['name'] or "").lower()
                display = THIRD_PARTY_REMOTE_TOOLS.get(name)
                if display:
                    pid = proc.info['pid']
                    current[pid] = {
                        "type": "third_party_remote_tool",
                        "tool": display,
                        "process": proc.info['name'],
                        "pid": pid,
                    }
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
            except Exception:
                continue

        self._diff_and_emit(self.active_remote_tools, current, "remote_tool_detected", "remote_tool_closed")
        self.active_remote_tools = current

    # ============================================================
    # WINDOWS SECURITY EVENT LOG (best-effort brute-force / RDP-logon signal)
    # ============================================================

    def _check_event_log(self):
        """
        Best-effort read of the Security event log for RDP-relevant logon
        events. Requires the agent to run elevated (it already does) and
        the log to be accessible; fails silently and just leaves the
        counters at their last known value if it can't run.

        Event 4624 (logon type 10 = RemoteInteractive/RDP) = successful RDP logon
        Event 4625 = failed logon
        """
        if not WIN32EVT_AVAILABLE or os.name != "nt":
            return

        lookback = timedelta(minutes=self.config.get("event_log_lookback_minutes", 15))
        cutoff = datetime.now() - lookback
        rdp_logons = 0
        failed_logons = 0

        try:
            hand = win32evtlog.OpenEventLog(None, "Security")
            flags = win32evtlog.EVENTLOG_BACKWARDS_READ | win32evtlog.EVENTLOG_SEQUENTIAL_READ
            reached_cutoff = False

            while not reached_cutoff:
                events = win32evtlog.ReadEventLog(hand, flags, 0)
                if not events:
                    break
                for ev in events:
                    try:
                        event_time = datetime.fromtimestamp(int(ev.TimeGenerated))
                    except Exception:
                        continue
                    if event_time < cutoff:
                        reached_cutoff = True
                        break

                    event_id = ev.EventID & 0xFFFF  # mask off the qualifier bits
                    if event_id == 4624:
                        inserts = ev.StringInserts or []
                        # LogonType is StringInserts[8] per the standard 4624 schema
                        logon_type = inserts[8] if len(inserts) > 8 else None
                        if logon_type == "10":
                            rdp_logons += 1
                    elif event_id == 4625:
                        failed_logons += 1

            win32evtlog.CloseEventLog(hand)
            self._recent_rdp_logons = rdp_logons
            self._recent_failed_logons = failed_logons
            self._event_log_available = True

        except Exception as e:
            # Common causes: not elevated, log access restricted by policy.
            # Degrade gracefully rather than claiming a signal we don't have.
            log.debug(f"Security event log check unavailable: {e}")
            self._event_log_available = False

    # ============================================================
    # EVENT HANDLING
    # ============================================================

    def _diff_and_emit(self, previous: dict, current: dict, started_event: str, ended_event: str):
        for key, info in current.items():
            if key not in previous:
                log.warning(f"🖥️ RDP/remote-access event: {started_event} - {info}")
                self._on_event(started_event, info)
        for key, info in previous.items():
            if key not in current:
                self._on_event(ended_event, info)

    def _on_event(self, event_type: str, info: dict):
        entry = dict(info)
        entry["event"] = event_type
        entry["hostname"] = self._hostname
        entry["timestamp"] = datetime.now().isoformat()

        self.event_history.append(entry)
        if len(self.event_history) > self._max_history:
            self.event_history = self.event_history[-self._max_history:]
        self._save_history()

        if self._send_to_server and self.config.get("alert_on_detection", True):
            try:
                self._send_to_server("rdp_event", entry)
                log.info(f"📤 Sent RDP event to server: {event_type}")
            except Exception as e:
                log.error(f"Failed to send RDP event: {e}")

    def _send_rdp_status(self):
        if not self._send_to_server:
            return
        try:
            status = self.get_status()
            status["hostname"] = self._hostname
            self._send_to_server("rdp_status_response", status)
            log.debug(f"📤 Sent RDP status: {status['session_count']} sessions, {status['remote_tool_count']} tools")
        except Exception as e:
            log.error(f"Failed to send RDP status: {e}")

    # ============================================================
    # STATUS & QUERY
    # ============================================================

    def get_status(self) -> dict:
        return {
            "is_running": self.is_running,
            "rdp_port": self.rdp_port,
            "active_sessions": list(self.active_sessions.values()),
            "session_count": len(self.active_sessions),
            "active_remote_tools": list(self.active_remote_tools.values()),
            "remote_tool_count": len(self.active_remote_tools),
            "history_count": len(self.event_history),
            "recent_rdp_logons": self._recent_rdp_logons,
            "recent_failed_logons": self._recent_failed_logons,
            "event_log_available": self._event_log_available,
        }

    def get_history(self, limit: int = 50) -> List[dict]:
        return self.event_history[-limit:]

    def clear_history(self):
        self.event_history = []
        self._save_history()
        log.info("RDP history cleared")


# ============================================================
# STANDALONE TEST
# ============================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)

    monitor = RDPMonitor()
    monitor.set_hostname("test-host")
    monitor.start()

    print("🖥️ RDP monitor running. Press Ctrl+C to stop.")

    try:
        while True:
            time.sleep(10)
            status = monitor.get_status()
            print(f"\n📊 Status: {status['session_count']} RDP sessions, "
                  f"{status['remote_tool_count']} third-party tools")
    except KeyboardInterrupt:
        monitor.stop()
        print("\n✅ Monitor stopped")
