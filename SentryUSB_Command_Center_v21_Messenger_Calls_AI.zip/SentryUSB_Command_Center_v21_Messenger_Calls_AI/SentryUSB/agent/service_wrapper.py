"""
SentryUSB Agent - Windows Service Wrapper
------------------------------------------
Wraps agent.py so it can be installed and run as a native Windows service
(runs under LocalSystem by default, which has the privileges needed to
disable/enable PnP devices, and survives user logoff).

Install (as Administrator):
    python service_wrapper.py install

Start / stop:
    python service_wrapper.py start
    python service_wrapper.py stop

Remove:
    python service_wrapper.py remove

Requires: pip install pywin32
"""
import threading

import servicemanager
import win32event
import win32service
import win32serviceutil

from agent import SentryUSBAgent


class SentryUSBService(win32serviceutil.ServiceFramework):
    _svc_name_ = "SentryUSBAgent"
    _svc_display_name_ = "SentryUSB Exam Monitoring Agent"
    _svc_description_ = (
        "Detects and blocks unauthorized USB storage devices during lab "
        "examinations and reports events to the SentryUSB server."
    )

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        self.agent = None
        self.agent_thread = None

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.stop_event)
        # Wait for agent thread to finish (optional)
        if self.agent_thread:
            self.agent_thread.join(timeout=5)

    def SvcDoRun(self):
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, ""),
        )
        self.agent = SentryUSBAgent()
        self.agent_thread = threading.Thread(target=self.agent.run, daemon=True)
        self.agent_thread.start()

        # Block until the service is asked to stop
        win32event.WaitForSingleObject(self.stop_event, win32event.INFINITE)


if __name__ == "__main__":
    win32serviceutil.HandleCommandLine(SentryUSBService)