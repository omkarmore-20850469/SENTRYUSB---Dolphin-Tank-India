"""
SentryUSB Agent - Device utilities
Handles parsing of USB hardware IDs and issuing enable/disable commands
via pnputil (built into Windows 10 1803+ / Windows 11, no extra tooling needed).

Disabling/enabling a PnP device instance requires the agent process to run
elevated (as Administrator / SYSTEM), typically via a Windows service.
"""
import re
import subprocess
import logging
import time
import os
from typing import Optional, Tuple, Dict

log = logging.getLogger("sentryusb.device_utils")

VID_PID_RE = re.compile(r"VID_([0-9A-Fa-f]{4}).*?PID_([0-9A-Fa-f]{4})", re.IGNORECASE)
SERIAL_RE = re.compile(r"\\([^\\&]+)(?:&\d+)?$")

# Cache for recently processed devices to prevent duplicates
_device_cache: Dict[str, float] = {}
_DEVICE_CACHE_TTL = 5

# Known USB Vendor IDs
KNOWN_VENDORS = {
    "SANDISK": "0781",
    "KINGSTON": "0951",
    "SAMSUNG": "04E8",
    "SONY": "054C",
    "TOSHIBA": "0480",
    "SEAGATE": "0BC2",
    "WD": "1058",
    "WESTERN_DIGITAL": "1058",
    "HP": "03F0",
    "DELL": "0A5C",
    "APPLE": "05AC",
    "INTEL": "8086",
    "AMD": "1022",
    "REALTEK": "0BDA",
    "ASUS": "0B05",
    "LENOVO": "17EF",
    "ACER": "0502",
    "BENQ": "04A5",
    "CANON": "04A9",
    "EPSON": "04B8",
    "LOGITECH": "046D",
    "MICROSOFT": "045E",
    "NVIDIA": "10DE",
    "BROADCOM": "14E4",
    "QUALCOMM": "05C6",
    "MEDIATEK": "0E8D",
    "SILICON_MOTION": "090C",
    "PHISON": "13FE",
    "JMICRON": "152D",
    "ASMEDIA": "174C",
    "VIA": "1106",
    "NEC": "1033",
    "RENESAS": "04B4",
    "FTDI": "0403",
    "PROLIFIC": "067B",
}

# Known USB Product IDs
KNOWN_PRODUCTS = {
    # SanDisk
    "SANDISK_3.2_GEN1": "55B1",
    "SANDISK_ULTRA": "5581",
    "SANDISK_CRUZER": "5567",
    "SANDISK_EXTREME": "5583",
    # Kingston
    "DT_101_G2": "1625",
    "DT_100_G2": "1665",
    "DT_111_G2": "1653",
    "DTSE9": "164C",
    # Samsung
    "BAR_PLUS": "0901",
    "FIT_PLUS": "0902",
    "DUO_PLUS": "0903",
    # Sony
    "STORAGE_MEDIA": "05BA",
    "MICRO_VAULT": "05D5",
}


def _get_pnputil_path() -> str:
    """Get the full path to pnputil.exe"""
    possible_paths = [
        "pnputil.exe",
        r"C:\Windows\System32\pnputil.exe",
        r"C:\Windows\SysWOW64\pnputil.exe",
    ]
    
    for path in possible_paths:
        try:
            if os.path.exists(path) or path == "pnputil.exe":
                result = subprocess.run(
                    [path, "/?"],
                    capture_output=True,
                    timeout=2,
                    shell=True
                )
                if result.returncode == 0 or "Microsoft PnP Utility" in result.stdout:
                    log.debug(f"Found pnputil at: {path}")
                    return path
        except Exception:
            continue
    
    try:
        result = subprocess.run(
            ["where", "pnputil"],
            capture_output=True,
            text=True,
            timeout=5,
            shell=True
        )
        if result.returncode == 0 and result.stdout.strip():
            path = result.stdout.strip().split('\n')[0]
            log.debug(f"Found pnputil via where: {path}")
            return path
    except Exception:
        pass
    
    log.warning("pnputil.exe not found, using default")
    return "pnputil.exe"


def parse_vid_pid(device_id: str) -> Tuple[Optional[str], Optional[str]]:
    """
    Parse Vendor ID and Product ID from device ID string.
    Handles multiple formats:
    1. VID_xxxx&PID_xxxx (standard USB hex codes)
    2. VEN_xxxx&PROD_xxxx (USBSTOR format with hex codes)
    3. VEN_TEXT&PROD_TEXT (USBSTOR format with text names)
    4. Known vendor/product name mapping
    """
    if not device_id:
        return None, None
    
    device_id_upper = device_id.upper()
    
    # Format 1: VID_xxxx&PID_xxxx (standard USB hex codes)
    m = VID_PID_RE.search(device_id_upper)
    if m:
        return m.group(1).upper(), m.group(2).upper()
    
    # Format 2: VEN_xxxx&PROD_xxxx (USBSTOR format with hex codes)
    ven_match = re.search(r"VEN_([0-9A-Fa-f]{4})", device_id_upper)
    prod_match = re.search(r"PROD_([0-9A-Fa-f]{4})", device_id_upper)
    
    if ven_match and prod_match:
        return ven_match.group(1).upper(), prod_match.group(1).upper()
    
    # Format 3: Try to extract from description or other fields
    vid_alt = re.search(r"VID[_\s]*([0-9A-F]{4})", device_id_upper)
    pid_alt = re.search(r"PID[_\s]*([0-9A-F]{4})", device_id_upper)
    
    if vid_alt and pid_alt:
        return vid_alt.group(1).upper(), pid_alt.group(1).upper()
    
    # Format 4: VEN_TEXT&PROD_TEXT (USBSTOR format with text names)
    ven_text_match = re.search(r"VEN_([A-Z0-9_]+)", device_id_upper)
    prod_text_match = re.search(r"PROD_([A-Z0-9_]+)", device_id_upper)
    
    if ven_text_match and prod_text_match:
        ven_text = ven_text_match.group(1)
        prod_text = prod_text_match.group(1)
        
        # Try to convert vendor text to hex
        vid = KNOWN_VENDORS.get(ven_text)
        
        # Try to get product ID from known products mapping
        pid = KNOWN_PRODUCTS.get(prod_text)
        
        # If not found in mapping, try to extract hex from product text
        if not pid:
            pid_hex_match = re.search(r"([0-9A-F]{4})", prod_text)
            if pid_hex_match:
                pid = pid_hex_match.group(1)
            else:
                # If no hex found, use first 4 chars
                pid = prod_text[:4] if len(prod_text) >= 4 else prod_text
        
        if vid:
            return vid, pid
    
    return None, None


def parse_serial(device_id: str) -> Optional[str]:
    """Parse serial number from device ID string"""
    if not device_id:
        return None
    
    # Try to extract serial from USBSTOR format
    if "USBSTOR" in device_id.upper():
        parts = device_id.split("\\")
        if len(parts) >= 2:
            serial_part = parts[-1]
            if "&" in serial_part:
                serial_part = serial_part.split("&")[0]
            return serial_part
    
    m = SERIAL_RE.search(device_id)
    if m:
        return m.group(1)
    
    return None


def is_mass_storage(pnp_entity) -> bool:
    """
    Determine if a PnP entity is a mass storage device.
    Returns True ONLY for the physical USB storage device, not volumes.
    """
    device_id = (getattr(pnp_entity, "DeviceID", "") or "").upper()
    pnp_class = (getattr(pnp_entity, "PNPClass", "") or "").upper()
    description = (getattr(pnp_entity, "Description", "") or "").upper()

    # SKIP duplicate/volume devices
    if "VOLUME" in device_id or "STORAGE\\VOLUME" in device_id:
        return False
    
    if "SWD\\WPDBUSENUM" in device_id:
        return False

    # ACCEPT only physical USB storage devices
    if "USBSTOR" in device_id and "DISK&VEN" in device_id:
        return True
    
    if pnp_class == "DISKDRIVE" and ("USB" in device_id or "USBSTOR" in device_id):
        return True

    storage_keywords = ["MASS STORAGE", "DISK DRIVE", "USB STORAGE", "FLASH DRIVE", "PEN DRIVE"]
    if any(keyword in description for keyword in storage_keywords):
        if "VOLUME" not in device_id:
            return True
    
    return False


def is_bluetooth_device(pnp_entity) -> bool:
    """
    Determine if a PnP entity is a Bluetooth radio/peripheral connection event
    (paired device connecting, PAN/tethering adapter coming up, etc).
    Used to extend violation coverage beyond USB mass storage.
    """
    device_id = (getattr(pnp_entity, "DeviceID", "") or "").upper()
    pnp_class = (getattr(pnp_entity, "PNPClass", "") or "").upper()
    description = (getattr(pnp_entity, "Description", "") or getattr(pnp_entity, "Name", "") or "").upper()

    if device_id.startswith("BTHENUM") or device_id.startswith("BTH\\"):
        return True

    if pnp_class == "BLUETOOTH":
        return True

    if "BLUETOOTH" in description and any(
        kw in description for kw in ("PAN", "NETWORK", "PERSONAL AREA", "TETHER")
    ):
        return True

    return False


def is_usb_device(pnp_entity) -> bool:
    """Check if a PnP entity is a USB device"""
    device_id = (getattr(pnp_entity, "DeviceID", "") or "").upper()
    return device_id.startswith("USB") or "USBSTOR" in device_id or "USB\\" in device_id


def get_device_class_label(pnp_entity) -> str:
    """Get the PNP class label for a device"""
    pnp_class = (getattr(pnp_entity, "PNPClass", "") or "").strip()
    return pnp_class or "Unknown"


def get_device_instance_id(pnp_entity) -> Optional[str]:
    """Get the device instance ID safely"""
    return getattr(pnp_entity, "DeviceID", None)


def get_device_description(pnp_entity) -> str:
    """Get the device description safely"""
    desc = getattr(pnp_entity, "Description", "") or ""
    name = getattr(pnp_entity, "Name", "") or ""
    return desc or name or "Unknown USB Device"


def classify_device(pnp_entity) -> str:
    """Classify device as storage, peripheral, or other"""
    if is_mass_storage(pnp_entity):
        return "storage"
    if is_usb_device(pnp_entity):
        return "peripheral"
    return "other"


def is_device_recently_processed(device_id: str, cooldown_seconds: int = 3) -> bool:
    """Check if a device has been recently processed to prevent duplicates."""
    global _device_cache
    
    if not device_id:
        return False
    
    current_time = time.time()
    expired = [d for d, t in _device_cache.items() if current_time - t > _DEVICE_CACHE_TTL]
    for d in expired:
        del _device_cache[d]
    
    serial = parse_serial(device_id)
    cache_key = serial or device_id
    
    if cache_key in _device_cache:
        elapsed = current_time - _device_cache[cache_key]
        if elapsed < cooldown_seconds:
            log.debug(f"Device {cache_key} recently processed ({elapsed:.1f}s ago), skipping")
            return True
    
    _device_cache[cache_key] = current_time
    return False


def _run_pnputil(args: list, timeout: int = 15) -> Tuple[bool, str]:
    """Run pnputil with given arguments"""
    pnputil_path = _get_pnputil_path()
    
    try:
        cmd = [pnputil_path] + args
        log.debug(f"Running: {' '.join(cmd)}")
        
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            shell=True
        )
        output = result.stdout + result.stderr
        log.debug("pnputil %s -> rc=%s", args, result.returncode)
        
        if result.returncode == 0:
            return True, output
        else:
            if "already disabled" in output.lower():
                return True, output
            return False, output
    except FileNotFoundError:
        return False, "pnputil.exe not found. Please run as Administrator."
    except subprocess.TimeoutExpired:
        return False, "timeout"
    except Exception as e:
        return False, str(e)


def disable_device(device_instance_id: str) -> Tuple[bool, str]:
    """Disable a device by instance ID with improved error handling"""
    if not device_instance_id:
        return False, "No device ID provided"
    
    log.info("Disabling device: %s", device_instance_id)
    
    # Try pnputil first
    success, output = _run_pnputil(["/disable-device", f'"{device_instance_id}"'])
    
    if success:
        log.info("✅ Device disabled via pnputil")
        return True, output
    
    # If pnputil fails, try PowerShell (works better for some devices)
    try:
        ps_cmd = f'''
        $device = Get-PnpDevice -InstanceId "{device_instance_id}" -ErrorAction SilentlyContinue
        if ($device) {{
            if ($device.Status -ne "Error") {{
                Disable-PnpDevice -InstanceId "{device_instance_id}" -Confirm:$false
                Write-Host "Disabled via PowerShell"
            }} else {{
                Write-Host "Device already disabled"
            }}
        }} else {{
            Write-Host "Device not found"
        }}
        '''
        result = subprocess.run(
            ["powershell", "-Command", ps_cmd],
            capture_output=True,
            text=True,
            timeout=15,
            shell=True
        )
        if "Disabled via PowerShell" in result.stdout or "already disabled" in result.stdout.lower():
            log.info("✅ Device disabled via PowerShell")
            return True, result.stdout
    except Exception as e:
        log.debug(f"PowerShell disable failed: {e}")
    
    return False, f"Failed to disable device: {output}"


def enable_device(device_instance_id: str) -> Tuple[bool, str]:
    """Enable a device by instance ID with better error handling"""
    if not device_instance_id:
        return False, "No device ID provided"
    
    log.info("Enabling device: %s", device_instance_id)
    
    # Try pnputil first
    success, output = _run_pnputil(["/enable-device", f'"{device_instance_id}"'])
    if success:
        log.info("✅ Device enabled via pnputil")
        return True, output
    
    # If pnputil fails, try PowerShell
    try:
        ps_cmd = f'''
        $device = Get-PnpDevice -InstanceId "{device_instance_id}" -ErrorAction SilentlyContinue
        if ($device) {{
            if ($device.Status -ne "OK") {{
                Enable-PnpDevice -InstanceId "{device_instance_id}" -Confirm:$false
                Write-Host "Enabled via PowerShell"
            }} else {{
                Write-Host "Device already enabled"
            }}
        }} else {{
            Write-Host "Device not found"
        }}
        '''
        result = subprocess.run(
            ["powershell", "-Command", ps_cmd],
            capture_output=True,
            text=True,
            timeout=15,
            shell=True
        )
        if "Enabled via PowerShell" in result.stdout or "already enabled" in result.stdout.lower():
            log.info("✅ Device enabled via PowerShell")
            return True, result.stdout
    except Exception as e:
        log.debug(f"PowerShell enable failed: {e}")
    
    return False, f"Failed to enable device: {output}"


# ============================================================
# WORKSTATION RESPONSE ACTIONS (auto-shutdown on violation)
# ============================================================

def lock_workstation() -> Tuple[bool, str]:
    """Immediately lock the workstation (like Win+L). Least destructive option."""
    try:
        result = subprocess.run(["rundll32.exe", "user32.dll,LockWorkStation"],
                                 capture_output=True, text=True, timeout=10, shell=True)
        return result.returncode == 0, (result.stdout + result.stderr)
    except Exception as e:
        return False, str(e)


def logoff_user() -> Tuple[bool, str]:
    """Force log off the current user session."""
    try:
        result = subprocess.run(["shutdown", "/l"], capture_output=True, text=True, timeout=10, shell=True)
        return result.returncode == 0, (result.stdout + result.stderr)
    except Exception as e:
        return False, str(e)


def shutdown_system(delay_seconds: int = 15, message: str = "", force: bool = False) -> Tuple[bool, str]:
    """Schedule a full power-off. Cancel with abort_shutdown() during the delay window."""
    try:
        cmd = ["shutdown", "/s", "/t", str(delay_seconds)]
        if force:
            cmd.append("/f")
        if message:
            cmd += ["/c", message[:512]]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10, shell=True)
        if result.returncode == 0:
            log.warning(f"🛑 Shutdown scheduled in {delay_seconds}s: {message}")
            return True, result.stdout
        return False, result.stdout + result.stderr
    except Exception as e:
        log.error(f"Failed to schedule shutdown: {e}")
        return False, str(e)


def abort_shutdown() -> Tuple[bool, str]:
    """Cancel a pending scheduled shutdown (only works during the delay window)."""
    try:
        result = subprocess.run(["shutdown", "/a"], capture_output=True, text=True, timeout=10, shell=True)
        return result.returncode == 0, (result.stdout + result.stderr)
    except Exception as e:
        return False, str(e)


def speak_local_message(text: str, voice_hint: str = "", rate: int = -1, volume: int = 88) -> bool:
    """Speak a short local status message with Windows SAPI.

    This uses the endpoint's built-in speech engine instead of an online TTS
    provider, so no audio or message content leaves the machine. The caller
    should run it in a daemon thread: voice availability must never delay USB
    security monitoring.

    Windows services run in Session 0 and cannot play into a signed-in user's
    desktop session. For audible confirmation, run the agent in user context
    (or use a user-context scheduled task) rather than LocalSystem service.
    """
    if os.name != "nt":
        log.debug("Startup voice is only available on Windows.")
        return False

    message = " ".join(str(text or "").split())[:300]
    if not message:
        return False
    try:
        safe_message = message.replace("'", "''")
        safe_hint = " ".join(str(voice_hint or "").split()).replace("'", "''")[:80]
        safe_rate = max(-10, min(10, int(rate)))
        safe_volume = max(0, min(100, int(volume)))
        script = f"""
Add-Type -AssemblyName System.Speech
$speaker = New-Object System.Speech.Synthesis.SpeechSynthesizer
$speaker.Rate = {safe_rate}
$speaker.Volume = {safe_volume}
if ('{safe_hint}') {{
  $candidate = $speaker.GetInstalledVoices() | Where-Object {{ $_.VoiceInfo.Name -like '*{safe_hint}*' }} | Select-Object -First 1
  if ($candidate) {{ $speaker.SelectVoice($candidate.VoiceInfo.Name) }}
}}
$speaker.Speak('{safe_message}')
$speaker.Dispose()
"""
        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        subprocess.Popen(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", script],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=creation_flags,
        )
        return True
    except Exception as e:
        log.debug("Local voice announcement could not start: %s", e)
        # Modest local fallback for Windows images without the speech feature.
        try:
            import winsound
            winsound.MessageBeep(winsound.MB_OK)
        except Exception:
            pass
        return False


def local_alarm(duration_seconds: float = 2.5, text: str = "⚠ UNAUTHORIZED USB DEVICE DETECTED ⚠"):
    """
    Beep + full-screen red flash on the local machine so the invigilator in
    the room notices immediately, without needing to watch the dashboard.

    NOTE: if the agent runs as a LocalSystem Windows service, this call runs
    in Session 0 and Windows will NOT show it on the logged-in user's
    desktop (session isolation) — that's an OS restriction, not a bug here.
    It works when the agent runs as a normal foreground/user-context process
    (e.g. during dev testing, or if deployed via a logged-in-user scheduled
    task instead of a LocalSystem service).
    """
    try:
        import winsound
        for _ in range(2):
            winsound.Beep(2500, 350)
    except Exception as e:
        log.debug(f"Local alarm beep failed: {e}")

    try:
        import tkinter as tk

        def _show():
            root = tk.Tk()
            root.attributes("-fullscreen", True)
            root.attributes("-topmost", True)
            root.configure(bg="red")
            label = tk.Label(root, text=text, font=("Segoe UI", 32, "bold"), fg="white", bg="red")
            label.pack(expand=True)
            root.after(int(duration_seconds * 1000), root.destroy)
            root.mainloop()

        _show()
    except Exception as e:
        log.debug(f"Local alarm flash failed: {e}")


def capture_screenshot(max_width: int = 1280, jpeg_quality: int = 60) -> Tuple[bool, Optional[str]]:
    """
    Capture the current screen as a base64-encoded JPEG for the violation
    evidence record. Downscaled/compressed to keep the socket payload small.
    Returns (success, base64_string_or_None).
    """
    try:
        from PIL import ImageGrab
        import io
        import base64

        img = ImageGrab.grab()
        if img.width > max_width:
            ratio = max_width / float(img.width)
            img = img.resize((max_width, int(img.height * ratio)))

        buf = io.BytesIO()
        img.convert("RGB").save(buf, format="JPEG", quality=jpeg_quality)
        encoded = base64.b64encode(buf.getvalue()).decode("ascii")
        return True, encoded
    except Exception as e:
        log.warning(f"Screenshot evidence capture failed: {e}")
        return False, None


def capture_webcam_frame(cam_index: int = 0, jpeg_quality: int = 60) -> Tuple[bool, Optional[str]]:
    """
    Best-effort single webcam frame capture (optional — requires opencv-python
    and an available camera; degrades silently if either is missing).
    Returns (success, base64_string_or_None).
    """
    try:
        import cv2
        import base64

        cap = cv2.VideoCapture(cam_index)
        if not cap.isOpened():
            cap.release()
            return False, None

        ok, frame = cap.read()
        cap.release()
        if not ok or frame is None:
            return False, None

        ok2, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), jpeg_quality])
        if not ok2:
            return False, None

        encoded = base64.b64encode(buf.tobytes()).decode("ascii")
        return True, encoded
    except Exception as e:
        log.debug(f"Webcam evidence capture skipped: {e}")
        return False, None


def clear_device_cache_entry(device_id: str):
    """Remove a specific device from the cache to allow re-detection."""
    global _device_cache
    serial = parse_serial(device_id)
    cache_key = serial or device_id
    _device_cache.pop(cache_key, None)
    log.debug(f"Cleared cache entry for {cache_key}")


def show_local_notice(title: str, text: str, seconds: float = 4.0) -> None:
    """Small non-blocking toast in the bottom-right corner (policy results etc.)."""
    try:
        import tkinter as tk
        root = tk.Tk()
        root.overrideredirect(True)
        root.attributes("-topmost", True)
        root.configure(bg="#10172e")
        w, h = 340, 84
        root.geometry(f"{w}x{h}+{root.winfo_screenwidth() - w - 24}+{root.winfo_screenheight() - h - 70}")
        tk.Label(root, text=title, bg="#10172e", fg="#4dd6ff", font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=14, pady=(10, 0))
        tk.Label(root, text=text, bg="#10172e", fg="#f1f5f9", font=("Segoe UI", 9), wraplength=w - 28,
                 justify="left").pack(anchor="w", padx=14)
        root.after(int(seconds * 1000), root.destroy)
        root.mainloop()
    except Exception as e:
        log.debug(f"Local notice unavailable: {e}")
