"""
SentryUSB Agent - Configuration
Auto-sync token from server on first connection
"""
import os
import json
import time

# ===== REMOTE ACCESS via ngrok =====
# Set this to your ngrok HTTPS URL, e.g. "https://abc123.ngrok.io"
# The agent will use this to connect to the server, whether locally or remotely.
SERVER_URL = os.environ.get("SENTRYUSB_SERVER_URL", "https://outfit-favorable-scribing.ngrok-free.dev")

# Primary token - can be auto-synced from server
AUTH_TOKEN = os.environ.get("SENTRYUSB_AUTH_TOKEN", "sentryusb-token-2024")

# Backup token - used if primary fails
BACKUP_AUTH_TOKEN = os.environ.get("SENTRYUSB_BACKUP_AUTH_TOKEN", "sentryusb-backup-token-2024")

# Auto-sync token from server on startup
AUTO_SYNC_TOKEN = os.environ.get("SENTRYUSB_AUTO_SYNC_TOKEN", "true").lower() == "true"

RECONNECT_DELAY_SECONDS = 5
POLL_INTERVAL_SECONDS = 2

LOG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs", "agent.log")

# ========== 🔒 LOCKDOWN MODE (AGENT) ==========
LOCKDOWN_ENABLED = os.environ.get("SENTRYUSB_LOCKDOWN_ENABLED", "false").lower() == "true"
LOCKDOWN_BLOCK_USB = os.environ.get("SENTRYUSB_LOCKDOWN_BLOCK_USB", "false").lower() == "true"
LOCKDOWN_BLOCK_BROWSERS = os.environ.get("SENTRYUSB_LOCKDOWN_BLOCK_BROWSERS", "false").lower() == "true"
LOCKDOWN_BLOCK_INTERNET = os.environ.get("SENTRYUSB_LOCKDOWN_BLOCK_INTERNET", "false").lower() == "true"
LOCKDOWN_BLOCK_COPY_PASTE = os.environ.get("SENTRYUSB_LOCKDOWN_BLOCK_COPY_PASTE", "false").lower() == "true"
LOCKDOWN_BLOCK_PRINT_SCREEN = os.environ.get("SENTRYUSB_LOCKDOWN_BLOCK_PRINT_SCREEN", "false").lower() == "true"
LOCKDOWN_BLOCK_ALT_TAB = os.environ.get("SENTRYUSB_LOCKDOWN_BLOCK_ALT_TAB", "false").lower() == "true"
LOCKDOWN_BLOCK_TASK_MANAGER = os.environ.get("SENTRYUSB_LOCKDOWN_BLOCK_TASK_MANAGER", "false").lower() == "true"
LOCKDOWN_EXEMPT = os.environ.get("SENTRYUSB_LOCKDOWN_EXEMPT", "false").lower() == "true"
LOCKDOWN_ALLOWED_USB = os.environ.get("SENTRYUSB_LOCKDOWN_ALLOWED_USB", "").split(",")
LOCKDOWN_ALLOWED_WEBSITES = os.environ.get("SENTRYUSB_LOCKDOWN_ALLOWED_WEBSITES", "").split(",")

# ========== 🛑 AUTO-SHUTDOWN ON VIOLATION ==========
# Defaults below are now baked in (previously required env vars to enable):
#   SHUTDOWN_ON_USB_VIOLATION = True   -> any qualifying USB event triggers the action
#   SHUTDOWN_ACTION           = shutdown -> full OS shutdown (not lock/logoff)
#   SHUTDOWN_DELAY_SECONDS    = 3      -> 3s grace period before it fires
#   SHUTDOWN_REQUIRE_EXAM_MODE= False  -> fires in general mode too, not just during an active exam
# Env vars (SENTRYUSB_SHUTDOWN_*) still override these if set, for per-machine tuning.
SHUTDOWN_ON_USB_VIOLATION = os.environ.get("SENTRYUSB_SHUTDOWN_ON_VIOLATION", "true").lower() == "true"
SHUTDOWN_ACTION = os.environ.get("SENTRYUSB_SHUTDOWN_ACTION", "shutdown")   # "lock" | "logoff" | "shutdown"
SHUTDOWN_DELAY_SECONDS = int(os.environ.get("SENTRYUSB_SHUTDOWN_DELAY_SECONDS", "3"))
SHUTDOWN_FORCE_CLOSE_APPS = os.environ.get("SENTRYUSB_SHUTDOWN_FORCE", "false").lower() == "true"
# If true, the action only fires once exam_active/lockdown_enabled is
# on (via the dashboard's Start Exam / Apply Lockdown). Now defaulted to
# "false" so ANY storage device triggers the action immediately, general
# mode included — same as how blocking already behaves unconditionally.
SHUTDOWN_REQUIRE_EXAM_MODE = os.environ.get("SENTRYUSB_SHUTDOWN_REQUIRE_EXAM_MODE", "false").lower() == "true"

# ========== 🔁 GRADUATED RESPONSE ==========
# 1st violation in a session = block + warn only. From the Nth violation
# onward (GRADUATED_RESPONSE_THRESHOLD), also fire SHUTDOWN_ACTION.
# Now defaulted to disabled, so SHUTDOWN_ACTION fires on the very first
# violation instead of waiting for GRADUATED_RESPONSE_THRESHOLD violations.
GRADUATED_RESPONSE_ENABLED = os.environ.get("SENTRYUSB_GRADUATED_RESPONSE", "false").lower() == "true"
GRADUATED_RESPONSE_THRESHOLD = int(os.environ.get("SENTRYUSB_GRADUATED_THRESHOLD", "2"))

# ========== 🚨 LOCAL ALARM ==========
LOCAL_ALARM_ENABLED = os.environ.get("SENTRYUSB_LOCAL_ALARM", "false").lower() == "true"

# Agent startup voice: local Windows SAPI feedback with no cloud TTS dependency.
STARTUP_VOICE_ENABLED = os.environ.get("SENTRYUSB_STARTUP_VOICE", "true").lower() == "true"
STARTUP_VOICE_MESSAGE = os.environ.get(
    "SENTRYUSB_STARTUP_VOICE_MESSAGE",
    "Welcome to SentryUSB. Security monitoring is active.",
)
STARTUP_VOICE_NAME = os.environ.get("SENTRYUSB_STARTUP_VOICE_NAME", "Zira")
try:
    STARTUP_VOICE_RATE = max(-10, min(10, int(os.environ.get("SENTRYUSB_STARTUP_VOICE_RATE", "-1"))))
    STARTUP_VOICE_VOLUME = max(0, min(100, int(os.environ.get("SENTRYUSB_STARTUP_VOICE_VOLUME", "88"))))
except ValueError:
    STARTUP_VOICE_RATE = -1
    STARTUP_VOICE_VOLUME = 88

# ========== 📸 EVIDENCE CAPTURE ==========
EVIDENCE_CAPTURE_ENABLED = os.environ.get("SENTRYUSB_EVIDENCE_CAPTURE", "false").lower() == "true"
EVIDENCE_CAPTURE_WEBCAM = os.environ.get("SENTRYUSB_EVIDENCE_WEBCAM", "false").lower() == "true"

# ========== 📶 BLUETOOTH COVERAGE ==========
# Reuses the existing PnP watcher (it already sees Bluetooth connect events);
# this just decides whether to treat them as violations.
BLUETOOTH_WATCH_ENABLED = os.environ.get("SENTRYUSB_BLUETOOTH_WATCH", "false").lower() == "true"
BLUETOOTH_BLOCK_ENABLED = os.environ.get("SENTRYUSB_BLUETOOTH_BLOCK", "false").lower() == "true"

BLOCKED_BROWSERS = os.environ.get("SENTRYUSB_BLOCKED_BROWSERS", 
    "chrome.exe,firefox.exe,msedge.exe,brave.exe,opera.exe,vivaldi.exe,iexplore.exe,chromium.exe"
).split(",")

DEVICE_COOLDOWN_SECONDS = 3
DEVICE_CACHE_CLEANUP_INTERVAL = 60
HEALTH_REPORTING_ENABLED = os.environ.get("SENTRYUSB_HEALTH_REPORTING", "true").lower() == "true"
HEALTH_REPORT_INTERVAL = 30

# ========== V10 ZERO-TRUST DEVICE CONTROLS ==========
# monitor is the safe default: it emits HID/fingerprint risk telemetry but
# never disables a keyboard. Set enforce only after enrolling every required
# keyboard, mouse and accessibility device in SENTRYUSB_TRUSTED_HID_IDS.
ZERO_TRUST_HID_MODE = os.environ.get("SENTRYUSB_ZERO_TRUST_HID_MODE", "monitor").lower()
TRUSTED_HID_IDS = [entry.strip().upper() for entry in os.environ.get("SENTRYUSB_TRUSTED_HID_IDS", "").split(",") if entry.strip()]
FIRMWARE_FINGERPRINT_MONITORING = os.environ.get("SENTRYUSB_FIRMWARE_FINGERPRINT_MONITORING", "true").lower() == "true"
BEHAVIORAL_METRICS_ENABLED = os.environ.get("SENTRYUSB_BEHAVIORAL_METRICS_ENABLED", "false").lower() == "true"


def get_token_from_server():
    """Try to get token from server's /api/token endpoint"""
    try:
        import requests
        response = requests.get(
            f"{SERVER_URL}/api/agent-token",
            timeout=5,
            headers={"X-Requested-With": "SentryUSB-Agent"}
        )
        if response.status_code == 200:
            data = response.json()
            return data.get("token")
    except Exception as e:
        print(f"⚠️ Failed to fetch token from server: {e}")
    return None


def get_cached_token():
    """Get token from local cache file"""
    try:
        cache_path = os.path.join(os.path.dirname(__file__), "token_cache.json")
        if os.path.exists(cache_path):
            with open(cache_path, 'r') as f:
                data = json.load(f)
                token = data.get("token")
                expiry = data.get("expiry", 0)
                if time.time() < expiry:
                    return token
    except Exception:
        pass
    return None


def save_token_to_cache(token):
    """Save working token to cache"""
    try:
        cache_path = os.path.join(os.path.dirname(__file__), "token_cache.json")
        data = {
            "token": token,
            "expiry": time.time() + 3600  # 1 hour
        }
        with open(cache_path, 'w') as f:
            json.dump(data, f)
        print(f"✅ Saved token to cache: {cache_path}")
    except Exception as e:
        print(f"⚠️ Failed to save token to cache: {e}")


def get_agent_token():
    """Get token with auto-sync fallback"""
    # Try cached token first
    cached = get_cached_token()
    if cached:
        print("✅ Using cached token")
        return cached
    
    token = AUTH_TOKEN
    
    # Auto-sync from server if enabled
    if AUTO_SYNC_TOKEN:
        server_token = get_token_from_server()
        if server_token:
            token = server_token
            save_token_to_cache(token)
            print("✅ Auto-synced token from server")
    
    return token


# Auto-sync on import if enabled
if AUTO_SYNC_TOKEN:
    synced_token = get_token_from_server()
    if synced_token:
        AUTH_TOKEN = synced_token
        save_token_to_cache(synced_token)
        print("✅ Auto-synced token from server at startup")
    else:
        cached = get_cached_token()
        if cached:
            AUTH_TOKEN = cached
            print("✅ Using cached token")
