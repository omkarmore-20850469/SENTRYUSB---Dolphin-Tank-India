"""Zero-trust USB helpers for the Windows agent.

This is a user-space monitor/enforcer. It fingerprints PnP metadata only; it
does not read or modify USB firmware. Firmware identity changes are therefore
reported as review signals, not proof of tampering.
"""
import hashlib
import json
import os
from datetime import datetime, timezone


STATE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "device_fingerprint_state.json")


def is_hid(pnp_entity):
    device_id = (getattr(pnp_entity, "DeviceID", "") or "").upper()
    pnp_class = (getattr(pnp_entity, "PNPClass", "") or "").upper()
    description = (getattr(pnp_entity, "Description", "") or getattr(pnp_entity, "Name", "") or "").upper()
    return pnp_class in {"HIDCLASS", "KEYBOARD", "MOUSE"} or "HID" in device_id or "KEYBOARD" in description or "MOUSE" in description


def device_class(pnp_entity):
    if is_hid(pnp_entity):
        return "hid"
    return (getattr(pnp_entity, "PNPClass", "") or "unknown").lower()


def fingerprint(pnp_entity, vendor_id=None, product_id=None, serial_number=None):
    components = {
        "id": getattr(pnp_entity, "DeviceID", "") or "",
        "class": device_class(pnp_entity),
        "name": getattr(pnp_entity, "Description", "") or getattr(pnp_entity, "Name", "") or "",
        "manufacturer": getattr(pnp_entity, "Manufacturer", "") or "",
        "vid": vendor_id or "",
        "pid": product_id or "",
        "serial": serial_number or "",
    }
    canonical = json.dumps(components, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest(), components


def detect_fingerprint_change(device_id, fingerprint_value):
    """Persist the last locally observed fingerprint and report a change."""
    try:
        state = {}
        if os.path.exists(STATE_PATH):
            with open(STATE_PATH, "r", encoding="utf-8") as stream:
                state = json.load(stream)
        previous = state.get(device_id, {}).get("fingerprint")
        state[device_id] = {"fingerprint": fingerprint_value, "seen_at": datetime.now(timezone.utc).isoformat()}
        tmp_path = STATE_PATH + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as stream:
            json.dump(state, stream, sort_keys=True)
        os.replace(tmp_path, STATE_PATH)
        return bool(previous and previous != fingerprint_value), previous
    except Exception:
        return False, None


def is_trusted_hid(device_id, fingerprint_value, trusted_ids):
    values = {str(device_id or "").upper(), str(fingerprint_value or "").upper()}
    return bool(values.intersection(set(trusted_ids or [])))
