"""
SentryUSB - Browser Activity Monitor
Detects browser logins, tracks active browsers, and reports to server
"""
import os
import logging
import time
import threading
import json
import re
from datetime import datetime
from typing import Optional, Dict, List, Callable

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False
    print("⚠️ psutil not installed. Browser monitoring limited.")

try:
    import win32gui
    WIN32_AVAILABLE = True
except ImportError:
    WIN32_AVAILABLE = False
    print("⚠️ win32gui not installed. Window monitoring limited.")

log = logging.getLogger("sentryusb.browser_monitor")

# ============================================================
# CONFIGURATION
# ============================================================

# Browsers to monitor
BROWSERS = [
    "chrome.exe",
    "firefox.exe",
    "msedge.exe",
    "brave.exe",
    "opera.exe",
    "vivaldi.exe",
    "iexplore.exe",
    "chromium.exe",
]

# Browser executable to display name mapping
BROWSER_NAMES = {
    "chrome.exe": "Google Chrome",
    "firefox.exe": "Mozilla Firefox",
    "msedge.exe": "Microsoft Edge",
    "brave.exe": "Brave Browser",
    "opera.exe": "Opera Browser",
    "vivaldi.exe": "Vivaldi",
    "iexplore.exe": "Internet Explorer",
    "chromium.exe": "Chromium",
}

# Login URL patterns (regex)
LOGIN_URL_PATTERNS = [
    r'https?://[^/]+/login',
    r'https?://[^/]+/signin',
    r'https?://[^/]+/sign-in',
    r'https?://[^/]+/auth',
    r'https?://[^/]+/oauth',
    r'https?://[^/]+/accounts\.google\.com',
    r'https?://[^/]+/login\.microsoftonline\.com',
    r'https?://[^/]+/facebook\.com/login',
    r'https?://[^/]+/twitter\.com/login',
    r'https?://[^/]+/instagram\.com/accounts/login',
    r'https?://[^/]+/linkedin\.com/login',
    r'https?://[^/]+/amazon\.com/ap/signin',
    r'https?://[^/]+/appleid\.apple\.com',
    r'https?://[^/]+/github\.com/login',
    r'https?://[^/]+/stackoverflow\.com/users/login',
]

# Login page patterns to detect (for service identification)
LOGIN_SERVICE_PATTERNS = {
    "gmail": ["mail.google.com", "accounts.google.com"],
    "outlook": ["outlook.office.com", "login.microsoftonline.com", "outlook.live.com"],
    "yahoo": ["mail.yahoo.com", "login.yahoo.com"],
    "facebook": ["facebook.com/login", "m.facebook.com"],
    "twitter": ["twitter.com/login", "x.com/login"],
    "instagram": ["instagram.com/accounts/login"],
    "linkedin": ["linkedin.com/login"],
    "amazon": ["amazon.com/ap/signin"],
    "google": ["accounts.google.com"],
    "microsoft": ["login.microsoftonline.com"],
    "apple": ["appleid.apple.com"],
    "github": ["github.com/login"],
    "stackoverflow": ["stackoverflow.com/users/login"],
    "reddit": ["reddit.com/login"],
}

# Suspicious login indicators in window titles
LOGIN_TITLE_PATTERNS = [
    "sign in",
    "login",
    "log in",
    "sign-in",
    "log-in",
    "authentication",
    "access",
    "verify",
    "password",
    "credential",
    "session",
    "secure",
    "account",
    "profile",
    "settings",
    "2fa",
    "two-factor",
    "mfa",
    "otp",
    "verification",
]


class BrowserMonitor:
    """Monitors browser activity and detects login attempts"""
    
    def __init__(self):
        self.active_browsers: Dict[int, dict] = {}
        self.login_attempts: List[dict] = []
        self.is_running = False
        self._stop_event = threading.Event()
        self.monitor_thread: Optional[threading.Thread] = None
        self.detected_logins: List[str] = []
        self.browser_history: List[dict] = []
        self._send_to_server: Optional[Callable] = None
        self._window_cache: Dict[int, dict] = {}
        self._window_cache_ttl = 10
        self._hostname = "unknown"
        
        # Load config
        self.load_config()
        
        # Compile regex patterns
        self._login_url_regex = [re.compile(p, re.IGNORECASE) for p in LOGIN_URL_PATTERNS]
        
        # Flag to track if we should send browser status
        self._status_sent = False
    
    def load_config(self):
        """Load monitoring configuration"""
        config_path = os.path.join(os.path.dirname(__file__), "browser_config.json")
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    self.config = json.load(f)
                log.info("Browser config loaded")
            except Exception as e:
                log.error(f"Failed to load browser config: {e}")
                self.config = {}
        else:
            self.config = {
                "monitor_enabled": True,
                "log_browsers": True,
                "detect_logins": True,
                "block_logins_during_exam": True,
                "alert_on_login": True,
                "log_all_urls": False
            }
            self.save_config()
    
    def save_config(self):
        """Save monitoring configuration"""
        config_path = os.path.join(os.path.dirname(__file__), "browser_config.json")
        try:
            with open(config_path, 'w') as f:
                json.dump(self.config, f, indent=4)
            log.info("Browser config saved")
        except Exception as e:
            log.error(f"Failed to save browser config: {e}")
    
    def set_hostname(self, hostname: str):
        """Set the hostname for this agent"""
        self._hostname = hostname
    
    # ============================================================
    # MONITORING
    # ============================================================
    
    def start(self):
        """Start browser monitoring"""
        if not PSUTIL_AVAILABLE:
            log.warning("psutil not available. Browser monitoring limited.")
            return
        
        if self.is_running:
            return
        
        self.is_running = True
        self._stop_event.clear()
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
        log.info("🔍 Browser monitor started")
    
    def stop(self):
        """Stop browser monitoring"""
        self.is_running = False
        self._stop_event.set()
        if self.monitor_thread:
            self.monitor_thread.join(timeout=5)
        log.info("🔍 Browser monitor stopped")
    
    def _monitor_loop(self):
        """Main monitoring loop"""
        while not self._stop_event.is_set():
            try:
                self._check_browsers()
                self._check_windows()
                
                # Send status update every 5 seconds if browsers are detected
                if self.active_browsers and self._send_to_server:
                    self._send_browser_status()
                    
            except Exception as e:
                log.debug(f"Monitor error: {e}")
            time.sleep(10)  # Check every 2 seconds
    
    # ============================================================
    # BROWSER PROCESS MONITORING
    # ============================================================
    
    def _check_browsers(self):
        """Check for running browsers"""
        if not PSUTIL_AVAILABLE:
            return
        
        current_browsers: Dict[int, dict] = {}
        
        for proc in psutil.process_iter(['pid', 'name', 'cmdline', 'create_time']):
            try:
                proc_name = proc.info['name'].lower()
                if proc_name in [b.lower() for b in BROWSERS]:
                    pid = proc.info['pid']
                    cmdline = ' '.join(proc.info['cmdline'] or [])
                    
                    # Extract URL from command line
                    url = self._extract_url_from_cmdline(cmdline)
                    
                    current_browsers[pid] = {
                        'pid': pid,
                        'name': proc_name,
                        'cmdline': cmdline[:100],
                        'url': url,
                        'started': datetime.fromtimestamp(proc.info['create_time']).isoformat(),
                        'last_seen': datetime.now().isoformat(),
                        'hostname': self._hostname
                    }
                    
                    # Check if this is a new browser
                    if pid not in self.active_browsers:
                        browser_name = BROWSER_NAMES.get(proc_name, proc_name)
                        log.info(f"🌐 Browser detected: {browser_name} (PID: {pid})")
                        self._on_browser_opened(proc_name, pid, url)
                        
                        # Send status update immediately when new browser is detected
                        if self._send_to_server:
                            self._send_browser_status()
                    
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
            except Exception as e:
                log.debug(f"Error checking process: {e}")
                continue
        
        # Check for closed browsers
        for pid in list(self.active_browsers.keys()):
            if pid not in current_browsers:
                browser_name = BROWSER_NAMES.get(self.active_browsers[pid]['name'], 
                                                self.active_browsers[pid]['name'])
                log.info(f"🔚 Browser closed: {browser_name} (PID: {pid})")
                self._on_browser_closed(pid)
                
                # Send status update when browser closes
                if self._send_to_server:
                    self._send_browser_status()
        
        self.active_browsers = current_browsers
    
    def _extract_url_from_cmdline(self, cmdline: str) -> Optional[str]:
        """Extract URL from browser command line"""
        url_match = re.search(r'(https?://[^\s]+)', cmdline)
        if url_match:
            return url_match.group(1)
        return None
    
    def _is_login_page(self, url: str) -> bool:
        """Check if URL is a login page using regex patterns"""
        if not url:
            return False
        for pattern in self._login_url_regex:
            if pattern.search(url):
                return True
        return False
    
    def _identify_login_service(self, url: str, title: str = "") -> Optional[str]:
        """Identify the login service from URL or title"""
        combined = (url or "").lower() + " " + (title or "").lower()
        
        for service, patterns in LOGIN_SERVICE_PATTERNS.items():
            if any(p in combined for p in patterns):
                return service
        return None
    
    # ============================================================
    # WINDOW TITLE MONITORING
    # ============================================================
    
    def _check_windows(self):
        """Check browser windows for login indicators"""
        if not WIN32_AVAILABLE:
            return
        
        current_time = time.time()
        for hwnd in list(self._window_cache.keys()):
            if current_time - self._window_cache[hwnd].get('_timestamp', 0) > self._window_cache_ttl:
                del self._window_cache[hwnd]
        
        def enum_callback(hwnd, windows):
            if win32gui.IsWindowVisible(hwnd):
                title = win32gui.GetWindowText(hwnd)
                if title:
                    windows.append((hwnd, title))
        
        windows = []
        win32gui.EnumWindows(enum_callback, windows)
        
        for hwnd, title in windows:
            if self._is_browser_window(title):
                self._check_login_title(title, hwnd)
    
    def _is_browser_window(self, title: str) -> bool:
        """Check if window title is from a browser"""
        browser_indicators = [
            "Google Chrome",
            "Firefox",
            "Microsoft Edge",
            "Brave",
            "Opera",
            "Vivaldi",
            "Internet Explorer",
            "Chromium"
        ]
        return any(indicator in title for indicator in browser_indicators)
    
    def _check_login_title(self, title: str, hwnd: int):
        """Check if window title indicates a login attempt"""
        if not self.config.get("detect_logins", True):
            return
        
        title_lower = title.lower()
        
        for pattern in LOGIN_TITLE_PATTERNS:
            if pattern in title_lower:
                login_key = f"{hwnd}_{pattern}"
                if login_key not in self.detected_logins:
                    self.detected_logins.append(login_key)
                    
                    service = self._identify_login_service("", title)
                    
                    log.warning(f"🔐 Login attempt detected in browser: '{title}' (service: {service or 'unknown'})")
                    self._on_login_detected("window_title", title, service)
                    
                    if len(self.detected_logins) > 100:
                        self.detected_logins = self.detected_logins[-50:]
    
    # ============================================================
    # EVENT HANDLERS
    # ============================================================
    
    def _on_browser_opened(self, browser_name: str, pid: int, url: Optional[str]):
        """Handle browser opened event"""
        display_name = BROWSER_NAMES.get(browser_name, browser_name)
        
        self.browser_history.append({
            'event': 'opened',
            'browser': browser_name,
            'browser_display': display_name,
            'pid': pid,
            'url': url,
            'timestamp': datetime.now().isoformat(),
            'hostname': self._hostname
        })
        
        if url and self.config.get("detect_logins", True):
            if self._is_login_page(url):
                service = self._identify_login_service(url)
                log.warning(f"🔐 Login page detected: {service or 'unknown'} - {url}")
                self._on_login_detected("url", url, service)
        
        if len(self.browser_history) > 1000:
            self.browser_history = self.browser_history[-500:]
    
    def _on_browser_closed(self, pid: int):
        """Handle browser closed event"""
        if pid in self.active_browsers:
            browser_name = self.active_browsers[pid]['name']
            display_name = BROWSER_NAMES.get(browser_name, browser_name)
            self.browser_history.append({
                'event': 'closed',
                'browser': browser_name,
                'browser_display': display_name,
                'pid': pid,
                'timestamp': datetime.now().isoformat(),
                'hostname': self._hostname
            })
            del self.active_browsers[pid]
    
    def _on_login_detected(self, detection_type: str, value: str, service: Optional[str] = None):
        """Handle login detection"""
        login_info = {
            'type': detection_type,
            'value': value[:200],
            'service': service or 'unknown',
            'timestamp': datetime.now().isoformat(),
            'browser_count': len(self.active_browsers),
            'hostname': self._hostname
        }
        
        self.login_attempts.append(login_info)
        
        if len(self.login_attempts) > 100:
            self.login_attempts = self.login_attempts[-50:]
        
        # Send login detection immediately
        if self._send_to_server:
            try:
                self._send_to_server('login_detected', login_info)
                log.info(f"📤 Sent login detection to server: {service or 'unknown'}")
            except Exception as e:
                log.error(f"Failed to send login detection: {e}")
    
    def _send_browser_status(self):
        """Send current browser status to server"""
        if not self._send_to_server:
            return
        
        try:
            status = self.get_status()
            status["hostname"] = self._hostname
            self._send_to_server('browser_status_response', status)
            log.debug(f"📤 Sent browser status: {status['browser_count']} browsers")
        except Exception as e:
            log.error(f"Failed to send browser status: {e}")
    
    def set_send_callback(self, callback: Callable):
        """Set the callback for sending events to server"""
        self._send_to_server = callback
    
    # ============================================================
    # STATUS & QUERY
    # ============================================================
    
    def get_status(self) -> dict:
        """Get current monitoring status"""
        return {
            'is_running': self.is_running,
            'browsers': list(self.active_browsers.values()),
            'login_attempts': self.login_attempts[-20:],
            'browser_count': len(self.active_browsers),
            'history_count': len(self.browser_history)
        }
    
    def get_active_browsers(self) -> List[dict]:
        """Get list of currently running browsers"""
        return list(self.active_browsers.values())
    
    def get_login_attempts(self, limit: int = 20) -> List[dict]:
        """Get recent login attempts"""
        return self.login_attempts[-limit:]
    
    def clear_history(self):
        """Clear monitoring history"""
        self.browser_history = []
        self.login_attempts = []
        self.detected_logins = []
        log.info("Browser history cleared")


# ============================================================
# STANDALONE TEST
# ============================================================

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    monitor = BrowserMonitor()
    monitor.start()
    
    print("🔍 Browser monitor running. Press Ctrl+C to stop.")
    
    try:
        while True:
            time.sleep(10)
            status = monitor.get_status()
            print(f"\n📊 Status: {status['browser_count']} browsers, {len(status['login_attempts'])} login attempts")
            for browser in status['browsers']:
                display_name = BROWSER_NAMES.get(browser['name'], browser['name'])
                print(f"  🌐 {display_name} (PID: {browser['pid']})")
    except KeyboardInterrupt:
        monitor.stop()
        print("\n✅ Monitor stopped")