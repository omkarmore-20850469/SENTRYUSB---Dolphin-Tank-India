"""
SentryUSB Agent - USB Watcher
Uses WMI to watch for USB device creation (plug-in) and deletion
(unplug) events in real time.
"""
import logging
import threading
import time

log = logging.getLogger("sentryusb.usb_watcher")


class USBWatcher:
    def __init__(self, on_device_detected, on_device_removed=None, poll_interval_seconds=2):
        self.on_device_detected = on_device_detected
        self.on_device_removed = on_device_removed
        self.poll_interval_seconds = poll_interval_seconds
        self._stop_event = threading.Event()
        self._thread = None

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True, name="USBWatcherThread")
        self._thread.start()
        log.info("USB watcher started.")

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
        log.info("USB watcher stopped.")

    def _run(self):
        import pythoncom
        import wmi

        pythoncom.CoInitialize()
        try:
            while not self._stop_event.is_set():
                try:
                    c = wmi.WMI()
                    creation_watcher = c.Win32_PnPEntity.watch_for(
                        notification_type="creation",
                        delay_secs=self.poll_interval_seconds
                    )
                    deletion_watcher = c.Win32_PnPEntity.watch_for(
                        notification_type="deletion",
                        delay_secs=self.poll_interval_seconds
                    )
                    log.info("WMI watchers created")

                    # Cache for deduplication (store serial number and timestamp)
                    processed_serials = {}

                    while not self._stop_event.is_set():
                        # ---------- CREATION EVENTS ----------
                        try:
                            new_device = creation_watcher(timeout_ms=1000)
                            if new_device is not None:
                                device_id = getattr(new_device, "DeviceID", "")
                                log.debug(f"USB creation event: {device_id}")

                                # Skip volume devices and software devices
                                if device_id and "VOLUME" not in device_id.upper() and "SWD\\WPDBUSENUM" not in device_id.upper():
                                    # Extract serial number for deduplication
                                    serial = None
                                    if "\\" in device_id:
                                        parts = device_id.split("\\")
                                        if len(parts) >= 2:
                                            serial = parts[-1].split("&")[0] if "&" in parts[-1] else parts[-1]
                                    if serial:
                                        current_time = time.time()
                                        if serial in processed_serials:
                                            if current_time - processed_serials[serial] < 2:
                                                log.debug(f"Device {serial} recently processed, skipping")
                                                continue
                                        processed_serials[serial] = current_time
                                    self.on_device_detected(new_device)
                        except wmi.x_wmi_timed_out:
                            pass
                        except Exception as e:
                            log.error("Creation watcher error: %s", e)
                            break

                        # ---------- DELETION EVENTS ----------
                        try:
                            removed_device = deletion_watcher(timeout_ms=1000)
                            if removed_device is not None and self.on_device_removed:
                                self.on_device_removed(removed_device)
                        except wmi.x_wmi_timed_out:
                            pass
                        except Exception as e:
                            log.error("Deletion watcher error: %s", e)
                            break

                        # Clean up old entries from processed_serials (keep last 60 seconds)
                        current_time = time.time()
                        expired = [s for s, t in processed_serials.items() if current_time - t > 60]
                        for s in expired:
                            del processed_serials[s]

                    # If we exited the inner loop, recreate WMI watchers after a short pause
                    if not self._stop_event.is_set():
                        log.warning("Restarting WMI watchers...")
                        time.sleep(1)
                except Exception as e:
                    log.error("Failed to create WMI watchers: %s", e)
                    time.sleep(5)
        finally:
            pythoncom.CoUninitialize()