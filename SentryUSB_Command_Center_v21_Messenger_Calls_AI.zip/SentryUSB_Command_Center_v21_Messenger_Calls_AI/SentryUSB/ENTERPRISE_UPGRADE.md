# SentryUSB Command Center — Enterprise Upgrade

This build extends the existing v8/v10 command center with a v11 enterprise layer.

## Included
- Animated SVG-like canvas topology with hub → lab → seat visualization.
- Real-time Socket.IO updates for agents, USB events and AI alerts.
- Risk history and explainable EWMA-style trend slope per host.
- Proactive AI copilot feed generated from live telemetry.
- Incident replay timeline with host filtering and scrubber.
- Pre-exam readiness dashboard (telemetry-aware; does not falsely claim an agent scan when the agent has not reported one).
- Persistent USB/device trust scoring based on historical host fan-out and block activity.
- Lab health ranking.
- Incident claiming and inline comments with audit-log entries.
- Verifiable incident PDF reports containing evidence-chain verification and tail hash.
- Slack/Teams/generic webhook notification hooks.
- Natural-language policy drafting for common tools (draft-only; admin review is required before enforcement).

## New server module
`server/enterprise_command_center.py`

State is stored in:
`server/ai_models/enterprise_state.json`

The state file is created automatically at runtime.

## New API surface
- `GET /api/enterprise/topology`
- `GET /api/enterprise/risk-history`
- `GET /api/enterprise/insights`
- `GET /api/enterprise/replay?hostname=...`
- `GET /api/enterprise/trust`
- `GET /api/enterprise/labs`
- `GET /api/enterprise/readiness?lab=...`
- `GET /api/enterprise/incident/<id>`
- `POST /api/enterprise/incident/<id>/claim`
- `POST /api/enterprise/incident/<id>/comments`
- `GET /api/enterprise/incident/<id>/report.pdf`
- `POST /api/enterprise/policy/from-text`
- `POST /api/enterprise/notifications/test`

## Environment variables
- `SENTRYUSB_WEBHOOK_URL`
- `SENTRYUSB_SLACK_WEBHOOK_URL`
- `SENTRYUSB_TEAMS_WEBHOOK_URL`
- `SENTRYUSB_PROACTIVE_AI_INTERVAL` (default: 60 seconds)

Existing SentryUSB Slack/Discord/email/Telegram settings remain unchanged.

## Important readiness behavior
The hub cannot honestly scan a remote Windows agent's filesystem merely from server-side code. The readiness endpoint therefore marks an agent offline as not ready and labels integrity/malware checks as telemetry/review unless corresponding agent telemetry exists. This avoids presenting a false security guarantee.

For a production deployment, add a signed `readiness_scan` Socket.IO command to the agent and have it return signed integrity/malware/RDP results; the existing RDP agent telemetry channel is already a suitable integration point.

## Run
Install the project's existing `server/requirements.txt`, then start the server using the project's normal launcher.

For production, set a unique `SENTRYUSB_SECRET_KEY` and `SENTRYUSB_EVIDENCE_HMAC_KEY`.
