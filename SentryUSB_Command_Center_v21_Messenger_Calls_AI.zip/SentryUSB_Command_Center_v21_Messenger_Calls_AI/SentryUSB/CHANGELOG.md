# SentryUSB — Revision Changelog

## v10 — Zero-trust and evidence upgrade

- Added centrally stored, priority-ordered device policies with explicit
  `allow`, `monitor`, `approval_required` and `block` decisions.
- Added HID/BadUSB-oriented telemetry, device PnP fingerprint-change review
  signals and a monitor-first zero-trust HID mode. HID enforcement is opt-in.
- Added an agent adaptive-response handler that applies a server-requested
  device block and reports its success/failure. Unsupported network isolation
  is explicitly refused rather than silently claimed.
- Added HMAC-linked evidence-chain records plus a verification API and
  opt-in incident manifests for high-risk events.
- Added privacy-preserving behavioural scoring for aggregate dwell/flight and
  mouse metrics. Raw keystrokes and typed text are not collected or stored.
- Added bounded media/file inspection, conservative ZIP-based Office CDR,
  SIEM JSON export and optional UDP syslog forwarding.
- Added time-bounded HMAC peer-event envelopes for limited outage-tolerant
  threat/health/policy notices.

## 🐛 Fixes from live test run (agent + server)

- **Agent: fixed constant "--- Logging error ---" spam on Windows.** `agent.py`'s
  `StreamHandler` wrote to `sys.stdout` using the console's default codepage
  (cp1252 on most Windows setups), which can't encode the emoji used in almost
  every log line (✅ 🔒 🔍 🚀 etc.) - every single `log.info`/`log.warning` call
  was throwing `UnicodeEncodeError` and dumping a traceback. Now reconfigures
  stdout to UTF-8 (`errors="replace"` as a safety net) and writes the rotating
  log file as UTF-8 too.
- **Server: `GET /api/admin/users` returned 405.** The Admin page's user-analytics
  panel calls `fetch('/api/admin/users')` (a GET) to list users, but only a
  `POST` route existed (for creating a user). Added the missing `GET` handler.
- **Server: `POST /api/ai/enhanced/browser/analyze` returned 400 on startup.**
  The browser-control page calls this before the agent has reported any browsers
  yet, sending an empty `browser_data` list; the endpoint was rejecting empty
  lists as an error instead of returning an empty (but valid) analysis. It now
  returns a normal empty result, matching the frontend's existing fallback path.
- **Server: malware scanner logged `Permission denied` as an ERROR** for
  `hiberfil.sys`, `swapfile.sys`, `DumpStack.log.tmp`, etc. - Windows OS files
  that are always locked to a normal user process. These are expected/benign,
  so they're now logged at debug level instead of cluttering the log as errors.

## 🤖 AI + real-time enhancements (this pass)

- **Fixed a real bug blocking the whole Enhanced AI subsystem**: `ai_enhanced/rdp_detector.py`
  called `psutil.Process.connections()`, which was renamed to `net_connections()`
  in psutil 6.0+. On any modern psutil install this silently broke RDP session
  detection (and, since it's imported at module load, could take the rest of
  the Enhanced AI package down with it). Now tries `net_connections()` first
  and falls back to `connections()` on older psutil.
- **New: AI chat assistant** (`server/ai_chat.py`, `/api/ai/chat`). Ask plain-English
  questions - "any blocked devices?", "what's our security score?", "any
  suspicious logins?" - and get an answer built from the live database and
  whatever AI subsystems are loaded, no external calls by default. Optionally
  upgrades to the Anthropic API for open-ended questions if you set
  `SENTRYUSB_AI_CHAT_USE_ANTHROPIC=true` and `ANTHROPIC_API_KEY`; automatically
  falls back to the local engine if that call fails for any reason.
- **New: floating AI chat widget** on every authenticated page (injected via
  `_sidebar.html` → `static/js/ai_chat_widget.js` + `static/css/ai_chat_widget.css`).
  Lights up when a live `ai_alert` event comes in while the panel is closed.
- **New: Live Map** (`/live-map`, `/api/live-map/state`). Real-time grid of every
  lab PC - online/offline status, last-seen time, and a rolling alert feed -
  updated instantly via the existing Socket.IO connection (`agent_online`,
  `agent_offline`, `new_event`, `login_alert`, `ai_alert`). Added to the sidebar nav.
- **Wired up previously-dead anomaly detection code.** `ai_anomaly.py` already
  had a full `DeviceBehaviorProfiler` and `LoginAnomalyDetector`, but nothing
  ever called them. `usb_event` now runs every event through
  `device_profiler.build_profile()`, and `login_detected` now runs through
  `login_detector.analyze_login()` (using hostname/service as best-effort
  stand-ins for username/IP, since the agent's login-detection payload
  doesn't carry those fields). Both broadcast a live `ai_alert` socket event
  to every dashboard client when the anomaly score crosses
  `SENTRYUSB_AI_LIVE_ALERT_THRESHOLD` (default 50).
- Added `AI_CHAT_*` and `AI_LIVE_ALERT_THRESHOLD` settings to `config.py`.

Scope note: this pass focused on the server (`server/`), where all the
security-sensitive logic (auth, sessions, data storage) lives. The Windows
agent, installer, and its bundled `.exe`/`agent.zip` binaries were left
untouched — rebuilding/repackaging those wasn't attempted here.

## 🐛 Bug fixes

- **"Change password" silently did nothing.** `/api/admin/change-password`
  checked the current password but never wrote the new one anywhere. Now it
  verifies the current password against the stored hash and actually saves
  the new one.
- **Users created in the Admin panel could never log in.** `login()` only
  ever checked the hardcoded config admin account (or LDAP) — the `users`
  table populated by "Add User" in the admin page was never consulted. Login
  now checks any user in the `users` table.
- **Agent auth token comparison wasn't constant-time**, which is a (minor,
  local-network) timing side-channel. Switched to `hmac.compare_digest`.

## 🔒 Security hardening

- **Passwords are now hashed** (`werkzeug.security`, already a Flask
  dependency — no new install needed) instead of stored in plaintext in
  `sentryusb.db`. The default admin account and any new users are hashed on
  creation. If you're upgrading an existing install with old plaintext rows,
  they're detected and **transparently upgraded to a hash on next login** —
  no manual migration step, no lockout.
- **Login rate limiting / lockout**: 5 failed attempts (per username+IP)
  locks that combination out for 5 minutes. Failed attempts and lockouts are
  written to the audit log.
- **Secure session cookies**: `HttpOnly` and `SameSite=Lax` always on;
  `Secure` is on when `SENTRYUSB_FORCE_HTTPS=true` is set (enable this once
  you're behind TLS).
- **Basic CSRF/origin check** on mutating `/api/*` requests (POST/PUT/
  DELETE/PATCH): rejects requests whose `Origin`/`Referer` host doesn't match
  the server's own host. This is a pragmatic layer given the app is a
  same-origin `fetch()`-driven JSON API, not a full per-form CSRF token
  scheme.
- Startup now prints a warning if `SECRET_KEY` or the admin password are
  still at their insecure defaults.
- Tightened input handling on a few endpoints (`change-password`, `add
  user`, `update user`) so a missing/malformed JSON body returns a clean 400
  instead of a 500, and enforces a minimum password length (8 chars).
- `db.get_users()` no longer includes password hashes in its result — it's
  used to populate the Admin page's user list, which has no business seeing
  even hashed passwords.

## ✨ New features

- **CSV export** of USB events (`/api/report/csv`) and of the audit log
  (`/api/admin/audit-logs/csv`), alongside the existing PDF/Excel reports.
  Wired into the Reports page as a third "CSV Export" card.
- **Login activity panel** on the Security page: a real, live table of
  recent logins, failed attempts, and lockouts (pulled from the audit log),
  with its own CSV export button. Previously none of this was visible
  anywhere in the UI even though the data existed.

## 🎨 Restyle / cleanup

- Every template had its own copy-pasted ~100–300 line block of the same
  dark-glass theme (root variables, sidebar, buttons, tables). Added
  `server/static/css/base.css` as the single canonical copy of the shared
  tokens and a small set of reusable components (`.badge-*`, `.btn-*`,
  `.alert-banner`, `.empty-state`), and used it for all the new UI above so
  it stops accumulating more duplicated CSS. It's linked in addition to (not
  a replacement for) the existing per-page styles for now — retiring the
  duplicated blocks in each of the 16 templates is a bigger follow-up job if
  you want it done (it needs visual regression-checking page by page, which
  wasn't feasible without a browser in this environment).
- Removed two stray files that had ended up inside `server/` and don't
  belong in the repo: a Windows desktop shortcut (`New Volume (D) -
  Shortcut.lnk`) and a stray `5.9.0` file.

## Not done / explicitly out of scope this pass

- The Windows agent (`agent/`) and installer code weren't modified, and the
  pre-built `agent.exe` / `SentryUSBInstaller.exe` / `agent.zip` binaries are
  unchanged and untested by this pass.
- A full CSS de-duplication across all 16 templates (see above).
- CSRF is origin/referer-based, not a per-form token — fine for a same-
  origin SPA-style app, but worth knowing if you ever add a public API
  consumed cross-origin.

## v15.0.0 — Unified Expert Live Map
- Unified advanced Live Map controls from both expert builds.
- Added state-aware agent disconnect/reconnect visualization and alerts.
- Added functional 3D Incident Replay with scrub/play/return-live controls.
- Added richer readiness gate with per-seat checks and live scan state.
- Added live lab health drill-down and device trust identity presentation.
- Added incident correlation API derived from recorded telemetry.
- Added 15-second command-center telemetry refresh.

## v16.0.0 — Expert Event Pulse Layer
- Expanded the 3D Live Map event-pulse system so recorded/live events create spatial, event-aware pulses at the affected agent.
- Added distinct visual treatments for blocked USB, malware, suspicious activity, RDP/remote activity, policy violations, device removal, allowed devices, agent online/reconnect, and connection loss.
- Added multi-ring shockwaves, vertical event beacons, floating event labels, and short-lived particle halos.
- Fixed disconnect/reconnect pulse lifecycle handling so disconnect alerts cannot corrupt the shared burst animation loop.
- Preserved the existing stopped-packet behavior for offline agents.

## v17.0.0 — 3D Render Recovery

- Fixed a fatal JavaScript module parse error caused by duplicate `disconnectAlert`, `reconnectAlert`, `focusHost`, and `focusLab` declarations in the Live Map module.
- Renamed the internal lab camera helper to `focusLabEntry` and routed lab selection through the correct 3D scene helper.
- Restored execution of the Three.js renderer, animation loop, event pulses, live data-flow, minimap, and 3D interactions.
- Verified the Live Map ES module with Node.js syntax validation.

## v20 — Policy Studio & policy handshake
- Fixed: agent "waiting for response from server" after accepting policy. Root cause: `agent_register` handler returned nothing, so the agent's `sio.call()` timed out (10 s per token). It now returns the ack directly; the agent is connected/ready immediately.
- New: Policy Studio (server sidebar) — pending requests, accept/reject/revoke, approved list, versioned policies, push-to-all-agents, optional auto-approve.
- New: modern agent-side consent dialog (agent/policy_ui.py); acceptance stored per policy version.
- Agent ignores exam_start / lockdown_apply until the server approves it in Policy Studio (stop commands and the local exam lease are never gated).
- Registration and connection retries are now unlimited with capped backoff.
