# SentryUSB v21.0.0 - upgrade notes

## What's new
1. **New brand identity** - full-colour shield + USB-plug mark with a radar ring and a "Command Center" tag. Used in the Lab Server sidebar, login page and browser tab (`server/static/img/sentryusb-mark.svg`, `sentryusb-logo.svg`, `favicon.svg`).
2. **Messenger v2 (Hub <-> Lab Server)** - images, voice notes, voice calls, video calls, delivery ticks, typing indicator, emoji, drag/drop/paste. See `MESSENGER_UPGRADE.md`.
3. **AI Assistant v2** (`server/ai_chat.py`, `ai_chat_widget.js`)
   - Understands hostnames, time windows ("last 6 hours") and follow-ups; answers with metric cards and follow-up chips.
   - Prioritised advice ("what should I do?"), security briefing, Hub-message awareness.
   - Actions are *proposals*: start/stop exam, override, allow/unblock device, retrain model, generate report, **message the Hub**, **call the Hub** - each needs a confirmation click (extra confirm for risky ones). New `/api/ai/action` allow-list endpoint executes allow/unblock/message.
   - **Autopilot**: background watcher pushes new warnings/critical insights (offline agents, blocked-USB bursts, risky devices, exam with no agents online, unread Hub messages) to the widget and its launcher badge. `/api/ai/insights` exposes them.
   - Slash commands (`/brief /risky /agents /offline /blocked /hub <msg> /next /clear /help`), voice input (browser speech recognition), read-aloud, copy, persistent history.
   - Optional Claude mode (`SENTRYUSB_AI_CHAT_USE_ANTHROPIC=true` + `ANTHROPIC_API_KEY`) now uses read-only tools plus a confirm-only `propose_action` tool. **This path was written to the Messages API tool-use format but could not be exercised without an API key here - test it once with your key.**
4. **Agent policy window** (`agent/policy_ui.py`) - full-screen frosted-glass design: gradient/orb background, glass card, SentryUSB logo in header + watermark + footer, device/version chips, reading-progress bar, pill buttons. Same explicit Accept / Decline behaviour and keyboard handling; falls back to the old flat window if Pillow is unavailable (Pillow is already in `agent/requirements.txt`).

## Upgrade steps
- Replace the folders; no new Python packages are required.
- Restart Hub, Lab Server and Agent. Databases migrate automatically.
- Rebuild the agent EXE if you ship it packaged (`agent.spec` now lists `policy_assets`, `PIL.ImageTk`).

## Testing status
Verified here: Hub and Lab-client messenger APIs end to end (text, image, voice, call log, per-lab media isolation, SVG rejection, signalling both directions), AI engine against a copy of your data, widget code in a simulated browser, and the policy window rendered under a virtual 1920x1080 display. **Not verifiable here:** real WebRTC audio/video between two machines, the messenger/assistant panels' final look in a real browser, and the policy window on Windows (fonts/DPI). Please run one real call and one policy prompt on your setup before relying on them.
