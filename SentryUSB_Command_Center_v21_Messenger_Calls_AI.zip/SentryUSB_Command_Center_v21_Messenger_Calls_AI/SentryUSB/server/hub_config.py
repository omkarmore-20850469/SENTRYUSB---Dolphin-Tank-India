HUB_ENABLED = True
HUB_URL = "https://providing-wronged-province.ngrok-free.dev"
HUB_REGISTRATION_SECRET = "change…cret"
HUB_LAB_NAME = "B401"  # shown on the hub dashboard
HUB_CONTACT_EMAIL = "omkarmore2085@gmail.com"
HUB_LOCATION = "Block B, Room 401"
HUB_REGISTER_RETRY_INTERVAL = 5 # seconds between retries while pending
HUB_HEARTBEAT_INTERVAL = 5 # seconds between heartbeats once approved