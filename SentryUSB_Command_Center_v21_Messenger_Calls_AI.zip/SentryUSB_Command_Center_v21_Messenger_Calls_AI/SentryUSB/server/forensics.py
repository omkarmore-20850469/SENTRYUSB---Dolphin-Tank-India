"""Opt-in, privacy-conscious incident bundle creation.

This produces a signed manifest of SentryUSB evidence. Full memory acquisition
and filesystem imaging are intentionally delegated to approved endpoint tools;
they require privileged, platform-specific collection and retention approvals.
"""
import hashlib
import json
import os
import uuid
from datetime import datetime, timezone


def _digest(path):
    hasher = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def create_incident_bundle(base_dir, event, evidence_rows, chain_verification):
    incident_id = "inc-" + uuid.uuid4().hex
    folder = os.path.join(base_dir, incident_id)
    os.makedirs(folder, exist_ok=False)
    manifest = {
        "schema": "sentryusb-incident-bundle/v1",
        "incident_id": incident_id,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "event": event,
        "evidence_chain": evidence_rows,
        "chain_verification": chain_verification,
        "collection_notice": "Contains SentryUSB event evidence only. No RAM dump or full filesystem image was collected.",
    }
    manifest_path = os.path.join(folder, "manifest.json")
    with open(manifest_path, "w", encoding="utf-8") as stream:
        json.dump(manifest, stream, indent=2, sort_keys=True)
    return {"incident_id": incident_id, "folder": folder, "manifest": manifest_path, "sha256": _digest(manifest_path)}
