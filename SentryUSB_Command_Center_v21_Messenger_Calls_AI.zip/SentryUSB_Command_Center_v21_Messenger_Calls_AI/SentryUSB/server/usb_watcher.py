"""
SentryUSB Agent - USB Watcher
Uses WMI to watch for USB device creation (plug-in) and deletion
(unplug) events in real time.
"""
import logging
import threading

import wmi
import pythoncom

log = logging.getLogger("sentryusb.usb_watcher")


class USBWatcher:
    def __init__(self, on_device_detected, on_device_removed=None, poll_interval_seconds=2):
        self.on_device_detected = on_device_detected
        self.on_device_removed = on_device_removed
        self.poll_interval_seconds = poll_interval_seconds
        self._stop_event = threading.Event()
        self._thread = None

    def start(self):
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        log.info("USB watcher started.")

    def stop(self):
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)

    def _run(self):
        pythoncom.CoInitialize()
        try:
            c = wmi.WMI()
            creation_watcher = c.Win32_PnPEntity.watch_for("creation", delay_secs=self.poll_interval_seconds)
            deletion_watcher = c.Win32_PnPEntity.watch_for("deletion", delay_secs=self.poll_interval_seconds)

            log.info("Listening for WMI PnP device creation/removal events...")
            while not self._stop_event.is_set():
                try:
                    new_device = creation_watcher(timeout_ms=1000)
                    if new_device:
                        self.on_device_detected(new_device)
                except wmi.x_wmi_timed_out:
                    pass
                except Exception as e:
                    log.error("Error watching for device creation: %s", e)

                try:
                    removed_device = deletion_watcher(timeout_ms=1000)
                    if removed_device and self.on_device_removed:
                        self.on_device_removed(removed_device)
                except wmi.x_wmi_timed_out:
                    pass
                except Exception as e:
                    log.error("Error watching for device deletion: %s", e)
        finally:
            pythoncom.CoUninitialize()