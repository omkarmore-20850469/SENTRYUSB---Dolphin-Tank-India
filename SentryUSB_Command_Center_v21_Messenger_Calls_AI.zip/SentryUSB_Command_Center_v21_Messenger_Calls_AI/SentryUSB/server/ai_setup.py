# server/ai_setup.py
"""
One-time AI setup script
Run: python ai_setup.py
"""
import os
import sys
import pickle
from datetime import datetime
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger(__name__)

# Import AI modules
try:
    from ai_anomaly import device_profiler, login_detector, network_analyzer
    import db
    AI_AVAILABLE = True
except ImportError as e:
    log.error(f"Failed to import AI modules: {e}")
    AI_AVAILABLE = False
    sys.exit(1)

def setup_ai():
    """Initialize AI system"""
    print("\n" + "="*60)
    print("🔧 Setting up SentryUSB AI System")
    print("="*60 + "\n")
    
    # Create directories
    print("📁 Creating directories...")
    os.makedirs("ai_models", exist_ok=True)
    os.makedirs("logs", exist_ok=True)
    print("  ✅ Directories created\n")
    
    # Check database
    print("📊 Checking database...")
    try:
        events = db.get_all_events(limit=100)
        print(f"  ✅ Found {len(events)} events in database\n")
    except Exception as e:
        log.error(f"Database error: {e}")
        print("  ❌ Failed to connect to database\n")
        return False
    
    # Build device profiles
    if events:
        print("🔍 Building device profiles...")
        device_count = 0
        for event in events:
            device_id = event.get('device_instance_id')
            if device_id:
                device_profiler.build_profile(device_id, event)
                device_count += 1
        
        print(f"  ✅ Built profiles for {device_count} devices\n")
        
        # Train model
        print("🧠 Training anomaly detection model...")
        try:
            device_profiler.train_anomaly_model({})
            print("  ✅ Model trained successfully\n")
        except Exception as e:
            log.error(f"Model training error: {e}")
            print("  ⚠️ Model training failed (will retry with more data)\n")
    else:
        print("⚠️ No events found in database.")
        print("   AI will automatically train as data accumulates.\n")
    
    # Create AI model version info
    print("📝 Creating model metadata...")
    model_info = {
        'version': '1.0.0',
        'created_at': datetime.now().isoformat(),
        'device_count': device_count if events else 0,
        'status': 'ready' if events else 'waiting_for_data'
    }
    
    with open('ai_models/model_info.json', 'w') as f:
        json.dump(model_info, f, indent=2)
    print("  ✅ Model metadata created\n")
    
    print("="*60)
    print("✅ AI Setup Complete!")
    print("="*60)
    print("\n📋 Next steps:")
    print("  1. Start the server: python app.py")
    print("  2. Go to Dashboard → AI Insights panel")
    print("  3. Train model with more data when available")
    print("\n🔗 AI Endpoints:")
    print("  • /api/ai/device-analysis/<device_id>")
    print("  • /api/ai/network-insights")
    print("  • /api/ai/predictions")
    print("  • /api/ai/train-model")
    print("="*60 + "\n")
    
    return True

if __name__ == "__main__":
    # Need to import json for model_info
    import json
    setup_ai()