# server/fix_imports.py
"""
Fix datetime import conflict in app.py
"""
import os

def fix_app_py():
    """Fix datetime import conflict"""
    try:
        with open('app.py', 'r') as f:
            content = f.read()
        
        # Remove the conflicting import
        content = content.replace('import datetime\n', '')
        content = content.replace('import datetime\r\n', '')
        
        # Make sure we have the correct import
        if 'from datetime import datetime, timedelta' not in content:
            # Add it after the first import block
            lines = content.split('\n')
            new_lines = []
            added = False
            
            for i, line in enumerate(lines):
                new_lines.append(line)
                if line.startswith('import') and not added:
                    # Find the last import
                    if i+1 < len(lines) and lines[i+1].strip() == '':
                        new_lines.insert(i+1, 'from datetime import datetime, timedelta')
                        added = True
                        print("  ✅ Added datetime import")
            
            if not added:
                new_lines.insert(0, 'from datetime import datetime, timedelta')
                print("  ✅ Added datetime import at top")
            
            content = '\n'.join(new_lines)
        
        # Also fix any datetime.datetime usage
        content = content.replace('datetime.datetime', 'datetime')
        content = content.replace('datetime.timedelta', 'timedelta')
        
        with open('app.py', 'w') as f:
            f.write(content)
        
        print("✅ Fixed app.py datetime imports")
        return True
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def fix_db_py():
    """Fix datetime in db.py if needed"""
    try:
        if os.path.exists('db.py'):
            with open('db.py', 'r') as f:
                content = f.read()
            
            # Make sure db.py has correct import
            if 'import datetime' in content and 'from datetime import datetime' not in content:
                content = content.replace('import datetime', 'from datetime import datetime, timedelta')
                with open('db.py', 'w') as f:
                    f.write(content)
                print("✅ Fixed db.py datetime imports")
            else:
                print("✅ db.py already fixed")
    except Exception as e:
        print(f"⚠️ Could not check db.py: {e}")

if __name__ == "__main__":
    print("="*60)
    print("🔧 Fixing datetime imports")
    print("="*60)
    
    if fix_app_py():
        print("\n✅ All fixes applied!")
        print("\n🔄 Restart your server: python app.py")
    else:
        print("\n❌ Manual fix required:")
        print("1. Open app.py in Notepad")
        print("2. Find and DELETE: import datetime")
        print("3. Make sure you have: from datetime import datetime, timedelta")
        print("4. Save and restart")