(function () {
  "use strict";
  const POLICY_URL = "/policy-studio";
  const seen = new Set();
  let socketBound = false;
  let activeAlert = null;
  let soundContext = null;

  function ensureSocketIO(callback) {
    if (typeof window.io === "function") return callback();
    const existing = document.querySelector('script[data-policy-socketio]');
    if (existing) {
      existing.addEventListener("load", callback, { once: true });
      return;
    }
    const script = document.createElement("script");
    script.src = "https://cdnjs.cloudflare.com/ajax/libs/socket.io/4.7.5/socket.io.min.js";
    script.async = true;
    script.dataset.policySocketio = "true";
    script.onload = callback;
    script.onerror = function () { console.warn("Policy alerts: Socket.IO client failed to load."); };
    document.head.appendChild(script);
  }

  function playAttentionSound() {
    // Optional short in-page chime; gracefully respects browsers that block audio.
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      soundContext = soundContext || new AudioCtx();
      if (soundContext.state === "suspended") soundContext.resume().catch(function(){});
      const osc = soundContext.createOscillator();
      const gain = soundContext.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(880, soundContext.currentTime);
      osc.frequency.setValueAtTime(660, soundContext.currentTime + 0.14);
      gain.gain.setValueAtTime(0.0001, soundContext.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.13, soundContext.currentTime + 0.025);
      gain.gain.exponentialRampToValueAtTime(0.0001, soundContext.currentTime + 0.32);
      osc.connect(gain); gain.connect(soundContext.destination);
      osc.start(); osc.stop(soundContext.currentTime + 0.34);
    } catch (_) {}
  }

  function closeAlert() {
    if (!activeAlert) return;
    activeAlert.remove();
    activeAlert = null;
  }

  function showAlert(data) {
    const hostname = String(data.hostname || "A new PC").slice(0, 180);
    const version = data.policy_version == null ? "—" : String(data.policy_version);
    const key = hostname + "|" + version;
    let persisted = [];
    try { persisted = JSON.parse(sessionStorage.getItem("sentry-policy-alert-seen") || "[]"); } catch (_) {}
    if (seen.has(key) || persisted.includes(key)) return;
    seen.add(key);
    persisted.push(key);
    try { sessionStorage.setItem("sentry-policy-alert-seen", JSON.stringify(persisted.slice(-200))); } catch (_) {}
    closeAlert();

    const overlay = document.createElement("section");
    overlay.className = "policy-request-alert";
    overlay.setAttribute("role", "alertdialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.setAttribute("aria-labelledby", "policy-request-alert-title");
    overlay.setAttribute("aria-describedby", "policy-request-alert-message");
    overlay.innerHTML =
      '<div class="policy-request-alert__card" role="document">' +
        '<div class="policy-request-alert__eyebrow"><i class="fas fa-shield-halved" aria-hidden="true"></i> Action required · Policy Studio</div>' +
        '<h2 class="policy-request-alert__title" id="policy-request-alert-title">New PC connection request</h2>' +
        '<p class="policy-request-alert__message" id="policy-request-alert-message"></p>' +
        '<div class="policy-request-alert__meta"><span class="policy-alert-host"></span><span class="policy-alert-ip"></span><span class="policy-alert-user"></span><span class="policy-alert-version"></span></div>' +
        '<div class="policy-request-alert__actions">' +
          '<button type="button" class="policy-request-alert__button policy-request-alert__button--secondary policy-alert-dismiss">Remind me later</button>' +
          '<a class="policy-request-alert__button policy-request-alert__button--primary" href="' + POLICY_URL + '"><i class="fas fa-arrow-up-right-from-square" aria-hidden="true"></i> Review in Policy Studio</a>' +
        '</div>' +
      '</div>';
    const message = data.message ||
      (hostname + " accepted the policy on the Agent PC and wants to connect to your system. Please review this request in Policy Studio.");
    overlay.querySelector("#policy-request-alert-message").textContent = message;
    overlay.querySelector(".policy-alert-host").textContent = "PC: " + hostname;
    overlay.querySelector(".policy-alert-ip").textContent = data.ip_address ? "IP: " + String(data.ip_address).slice(0,80) : "";
    overlay.querySelector(".policy-alert-user").textContent = data.username ? "User: " + String(data.username).slice(0,80) : "";
    overlay.querySelector(".policy-alert-version").textContent = "Policy v" + version;
    overlay.querySelector(".policy-alert-dismiss").addEventListener("click", closeAlert);
    overlay.addEventListener("click", function (event) {
      if (event.target === overlay) closeAlert();
    });
    document.body.appendChild(overlay);
    activeAlert = overlay;
    playAttentionSound();
    const link = overlay.querySelector("a");
    link.addEventListener("click", function () { closeAlert(); });
    overlay.querySelector(".policy-alert-dismiss").focus();
  }

  function shouldAlert(data) {
    return data && data.hostname &&
      data.event_type === "agent_policy_consent" &&
      data.status === "pending" &&
      !data.refresh;
  }

  function bindSocket() {
    if (socketBound || typeof window.io !== "function") return;
    socketBound = true;
    const socket = window.io({ reconnection: true, reconnectionAttempts: Infinity,
      reconnectionDelay: 500, reconnectionDelayMax: 5000 });
    socket.on("policy_request", function (data) {
      if (shouldAlert(data)) showAlert(data);
    });
  }

  // Socket events provide instant alerts; polling recovers requests missed while this
  // browser tab was offline. Existing pending requests are not repeatedly popped up.
  async function recoverPending() {
    try {
      const response = await fetch("/api/policy-studio/state", {
        credentials: "same-origin", headers: { "Accept": "application/json" }
      });
      if (!response.ok) return;
      const state = await response.json();
      const pending = (state.requests || []).filter(function (r) { return r.status === "pending"; });
      // Recover a notification missed during disconnect/reload. Each pending host/version
      // is surfaced once per browser session until the invigilator reviews it.
      let persisted = [];
      try { persisted = JSON.parse(sessionStorage.getItem("sentry-policy-alert-seen") || "[]"); } catch (_) {}
      const known = new Set(persisted);
      const next = pending.find(function (r) {
        return !known.has(String(r.hostname) + "|" + String(r.policy_version == null ? "—" : r.policy_version));
      });
      if (next && !activeAlert) {
        showAlert({
          hostname: next.hostname,
          ip_address: next.ip_address,
          username: next.username,
          policy_version: next.policy_version,
          requested_at: next.requested_at,
          status: "pending",
          event_type: "agent_policy_consent",
          message: String(next.hostname) + " has a pending connection request. Please review and approve or reject it in Policy Studio."
        });
      }
    } catch (_) {}
  }

  function init() {
    ensureSocketIO(bindSocket);
    recoverPending();
    window.setInterval(recoverPending, 30000);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init, { once: true });
  else init();
})();
