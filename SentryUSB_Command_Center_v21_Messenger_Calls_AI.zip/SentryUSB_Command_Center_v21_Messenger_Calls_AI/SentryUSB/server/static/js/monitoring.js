// server/static/js/monitoring.js
/**
 * Monitoring Dashboard - Real-time system metrics and performance monitoring
 * Integrated as a sub-panel in the main dashboard
 */

let monitoringState = {
    eventChart: null,
    statusChart: null,
    metricsInterval: null,
    chartsInterval: null,
    initialized: false
};

// ============================================================
// INITIALIZATION
// ============================================================

function initMonitoring() {
    if (monitoringState.initialized) return;
    
    console.log('📊 Initializing monitoring panel...');
    
    // Initialize charts
    initMonitoringCharts();
    
    // Load initial data
    refreshMonitoringMetrics();
    
    // Set up auto-refresh
    monitoringState.metricsInterval = setInterval(refreshMonitoringMetrics, 10000);
    monitoringState.chartsInterval = setInterval(updateMonitoringCharts, 30000);
    
    monitoringState.initialized = true;
}

function destroyMonitoring() {
    if (monitoringState.metricsInterval) {
        clearInterval(monitoringState.metricsInterval);
        monitoringState.metricsInterval = null;
    }
    if (monitoringState.chartsInterval) {
        clearInterval(monitoringState.chartsInterval);
        monitoringState.chartsInterval = null;
    }
    if (monitoringState.eventChart) {
        monitoringState.eventChart.destroy();
        monitoringState.eventChart = null;
    }
    if (monitoringState.statusChart) {
        monitoringState.statusChart.destroy();
        monitoringState.statusChart = null;
    }
    monitoringState.initialized = false;
}

// ============================================================
// CHARTS
// ============================================================

function initMonitoringCharts() {
    // Event Chart
    const ctx1 = document.getElementById('monitorEventChart');
    if (ctx1) {
        monitoringState.eventChart = new Chart(ctx1.getContext('2d'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Cumulative Events',
                    data: [],
                    borderColor: '#3d7bff',
                    backgroundColor: 'rgba(61,123,255,0.1)',
                    fill: true,
                    tension: 0.3,
                    pointBackgroundColor: '#3d7bff',
                    pointRadius: 3
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        labels: { color: '#94a3b8', font: { size: 11 } }
                    }
                },
                scales: {
                    x: {
                        ticks: { color: '#64748b', maxTicksLimit: 10, font: { size: 10 } },
                        grid: { color: 'rgba(255,255,255,0.03)' }
                    },
                    y: {
                        beginAtZero: true,
                        ticks: { color: '#64748b', font: { size: 10 } },
                        grid: { color: 'rgba(255,255,255,0.03)' }
                    }
                }
            }
        });
    }

    // Status Chart
    const ctx2 = document.getElementById('monitorStatusChart');
    if (ctx2) {
        monitoringState.statusChart = new Chart(ctx2.getContext('2d'), {
            type: 'doughnut',
            data: {
                labels: ['Blocked', 'Allowed', 'Connected', 'Overridden'],
                datasets: [{
                    data: [0, 0, 0, 0],
                    backgroundColor: ['#ef4444', '#34d399', '#4dd6ff', '#fbbf24'],
                    borderColor: 'rgba(15,22,45,0.5)',
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: '#94a3b8',
                            font: { size: 11 },
                            padding: 12
                        }
                    }
                }
            }
        });
    }
}

function updateMonitoringCharts() {
    fetch('/api/events?limit=50')
        .then(r => r.json())
        .then(events => {
            if (!monitoringState.eventChart && !monitoringState.statusChart) return;
            
            // Event Chart - last 50 events
            const labels = events.slice(0, 30).map(e => {
                try { 
                    const d = new Date(e.timestamp + 'Z');
                    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                } catch { return ''; }
            }).reverse();
            
            // Cumulative sum for better visualization
            let cum = 0;
            const cumValues = events.slice(0, 30).reverse().map(() => { cum += 1; return cum; });
            
            if (monitoringState.eventChart) {
                monitoringState.eventChart.data.labels = labels;
                monitoringState.eventChart.data.datasets[0].data = cumValues;
                monitoringState.eventChart.update('none');
            }
            
            // Status Chart
            const statuses = { blocked: 0, allowed: 0, connected: 0, overridden: 0 };
            events.forEach(e => {
                const s = e.status || 'connected';
                if (statuses[s] !== undefined) statuses[s]++;
            });
            
            if (monitoringState.statusChart) {
                monitoringState.statusChart.data.datasets[0].data = [
                    statuses.blocked,
                    statuses.allowed,
                    statuses.connected,
                    statuses.overridden
                ];
                monitoringState.statusChart.update('none');
            }
        })
        .catch(err => console.debug('Chart data error:', err));
}

// ============================================================
// METRICS
// ============================================================

function refreshMonitoringMetrics() {
    // Use the existing /api/stats endpoint
    fetch('/api/stats')
        .then(r => r.json())
        .then(data => {
            updateMonitoringMetrics(data);
        })
        .catch(err => console.debug('Metrics error:', err));
    
    // Also get system info from health endpoint
    fetch('/api/health')
        .then(r => r.json())
        .then(data => {
            if (data.status === 'ok') {
                document.getElementById('monitorSystemStatus').textContent = '✅ Operational';
                document.getElementById('monitorSystemStatus').style.color = 'var(--accent-4)';
            }
        })
        .catch(() => {
            document.getElementById('monitorSystemStatus').textContent = '⚠️ Degraded';
            document.getElementById('monitorSystemStatus').style.color = 'var(--accent-warning)';
        });
}

function updateMonitoringMetrics(data) {
    // Update metric cards
    const activeAgents = data.online_agents || 0;
    const totalAgents = data.total_agents || 0;
    
    document.getElementById('monitorActiveAgents').textContent = activeAgents;
    document.getElementById('monitorTotalEvents').textContent = data.total_events || 0;
    document.getElementById('monitorBlockedDevices').textContent = data.blocked_events || 0;
    
    // Calculate cache hit rate (simulated for now)
    const cacheRate = data.total_events > 0 ? Math.min(Math.round((data.total_events - data.blocked_events) / data.total_events * 100), 100) : 0;
    document.getElementById('monitorCacheRate').textContent = cacheRate + '%';
    
    // System info
    document.getElementById('monitorExamMode').textContent = data.exam_active ? '🔴 Active' : '🟢 Inactive';
    document.getElementById('monitorExamMode').style.color = data.exam_active ? 'var(--accent-danger)' : 'var(--accent-4)';
    
    document.getElementById('monitorLockdown').textContent = data.lockdown_active ? '🔴 Active' : '🟢 Inactive';
    document.getElementById('monitorLockdown').style.color = data.lockdown_active ? 'var(--accent-danger)' : 'var(--accent-4)';
    
    // Update timestamp
    const now = new Date();
    document.getElementById('monitorLastUpdated').textContent = now.toLocaleString();
}

// ============================================================
// SOCKET.IO INTEGRATION
// ============================================================

function setupMonitoringSocket(socket) {
    if (!socket) return;
    
    socket.on('new_event', function(data) {
        // Update metrics on new event
        refreshMonitoringMetrics();
        // Update charts after a short delay
        setTimeout(updateMonitoringCharts, 500);
    });
    
    socket.on('agent_online', function(data) {
        refreshMonitoringMetrics();
    });
    
    socket.on('agent_offline', function(data) {
        refreshMonitoringMetrics();
    });
}

// ============================================================
// EXPOSE FOR DASHBOARD INTEGRATION
// ============================================================

window.monitoring = {
    init: initMonitoring,
    destroy: destroyMonitoring,
    refresh: refreshMonitoringMetrics,
    updateCharts: updateMonitoringCharts,
    setupSocket: setupMonitoringSocket
};

console.log('📊 Monitoring module loaded');