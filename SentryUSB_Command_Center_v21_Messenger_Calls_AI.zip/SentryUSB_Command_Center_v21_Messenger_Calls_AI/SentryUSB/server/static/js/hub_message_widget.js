/* Hub Message Widget
 * ------------------
 * Shows a live banner whenever the central SentryUSB Hub admin sends a
 * message down to THIS lab server. The hub can only look (read-only
 * monitoring) and speak (this banner) - it never acts on this server
 * directly. Whoever is at this lab decides what to do about it.
 *
 * Included on every authenticated page via _sidebar.html, same pattern as
 * ai_chat_widget.js.
 */
(function () {
  if (document.getElementById('sentryusb-hubmsg-container')) return;

  const container = document.createElement('div');
  container.id = 'sentryusb-hubmsg-container';
  document.body.appendChild(container);

  function iconFor(severity) {
    if (severity === 'critical') return 'fa-triangle-exclamation';
    if (severity === 'warning') return 'fa-circle-exclamation';
    return 'fa-tower-broadcast';
  }

  function showToast(data) {
    const sev = ['info', 'warning', 'critical'].includes(data.severity) ? data.severity : 'info';
    const toast = document.createElement('div');
    toast.className = 'sentryusb-hubmsg-toast sentryusb-hubmsg-' + sev;
    toast.innerHTML =
      '<i class="fas ' + iconFor(sev) + ' sentryusb-hubmsg-icon"></i>' +
      '<div class="sentryusb-hubmsg-body">' +
        '<div class="sentryusb-hubmsg-title">Message from ' + (data.sent_by || 'Hub Admin') + '</div>' +
        '<div class="sentryusb-hubmsg-text"></div>' +
      '</div>' +
      '<button class="sentryusb-hubmsg-close" aria-label="Dismiss">&times;</button>';
    toast.querySelector('.sentryusb-hubmsg-text').textContent = data.message || '';
    toast.querySelector('.sentryusb-hubmsg-close').addEventListener('click', () => toast.remove());
    container.prepend(toast);

    // Info banners self-dismiss; warning/critical stay until someone reads
    // and closes them, since those are the ones worth not missing.
    if (sev === 'info') {
      setTimeout(() => { if (toast.parentNode) toast.remove(); }, 20000);
    }
  }

  function connectSocket() {
    try {
      const socket = io();
      socket.on('hub_message', showToast);
    } catch (e) {
      console.warn('SentryUSB hub message widget: could not connect socket', e);
    }
  }

  if (typeof io === 'function') {
    connectSocket();
  } else {
    const script = document.createElement('script');
    script.src = 'https://cdnjs.cloudflare.com/ajax/libs/socket.io/4.7.5/socket.io.min.js';
    script.onload = connectSocket;
    script.onerror = () => console.warn('SentryUSB hub message widget: failed to load socket.io client');
    document.head.appendChild(script);
  }
})();
