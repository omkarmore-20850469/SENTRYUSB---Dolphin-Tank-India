/* SentryUSB AI Assistant widget v2
 * Rich replies (markdown-lite, metric cards, follow-up chips), confirm-before-act
 * buttons, proactive insights from the server autopilot, slash commands,
 * voice input + read-aloud, and a persistent conversation. */
(function () {
  'use strict';
  if (document.getElementById('sentryusb-chat-launcher')) return;

  const STORE = 'sentryusb_ai_chat_v2';
  const SLASH = [
    { cmd: '/brief', hint: 'Security briefing', text: 'brief me' },
    { cmd: '/risky', hint: 'Flagged / risky devices', text: 'show risky devices' },
    { cmd: '/agents', hint: 'Agent status', text: 'agent status' },
    { cmd: '/offline', hint: 'Offline agents', text: 'which agents are offline?' },
    { cmd: '/blocked', hint: 'Blocked USB (24h)', text: 'blocked devices today' },
    { cmd: '/hub', hint: '/hub <text> sends a message to the Hub', text: null },
    { cmd: '/next', hint: 'What should I do?', text: 'what should I do?' },
    { cmd: '/clear', hint: 'Clear this conversation', text: null },
    { cmd: '/help', hint: 'What I can do', text: 'help' },
  ];
  const START_CHIPS = ['📊 Brief me', '🧭 What should I do?', '🖥️ Agents', '🚫 Blocked today', '💬 Hub messages'];

  const $ = (t, c, html) => { const e = document.createElement(t); if (c) e.className = c; if (html != null) e.innerHTML = html; return e; };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  function md(text) {                                   // escape first, then a tiny safe subset
    return esc(text).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/^(?:•|-)\s+(.*)$/gm, '<span class="sucw-bullet">•</span>$1').replace(/\n/g, '<br>');
  }

  // ---- DOM ----
  const launcher = $('button', null, '<i class="fas fa-robot"></i><span class="alert-dot"></span><span class="sucw-count">0</span>');
  launcher.id = 'sentryusb-chat-launcher'; launcher.setAttribute('aria-label', 'Open AI security assistant');
  const panel = $('div'); panel.id = 'sentryusb-chat-panel';
  panel.innerHTML = `
    <div id="sentryusb-chat-header">
      <div class="sucw-avatar"><i class="fas fa-robot"></i></div>
      <div class="sucw-title"><div class="t">SentryUSB AI</div><div class="status" id="chatStatus"><span class="dot"></span> Connecting…</div></div>
      <button class="sucw-hbtn" id="sucw-speak" title="Read replies aloud" aria-label="Toggle read aloud"><i class="fas fa-volume-xmark"></i></button>
      <button class="sucw-hbtn" id="sucw-clear" title="Clear conversation" aria-label="Clear conversation"><i class="fas fa-broom"></i></button>
      <button class="sucw-hbtn" id="sentryusb-chat-close" aria-label="Close"><i class="fas fa-xmark"></i></button>
    </div>
    <div class="sucw-insights" id="sucw-insights" hidden></div>
    <div id="sentryusb-chat-messages" role="log" aria-live="polite"></div>
    <div class="sucw-suggestions" id="sentryusb-chat-suggestions"></div>
    <div class="sucw-slash" id="sucw-slash" hidden></div>
    <div id="sentryusb-chat-inputbar">
      <button class="sucw-mic" id="sucw-mic" aria-label="Voice input" title="Voice input"><i class="fas fa-microphone"></i></button>
      <input id="sentryusb-chat-input" type="text" placeholder="Ask anything, or type / for commands" autocomplete="off" />
      <button id="sentryusb-chat-send" aria-label="Send"><i class="fas fa-paper-plane"></i></button>
    </div>`;
  document.body.append(launcher, panel);
  const msgsEl = panel.querySelector('#sentryusb-chat-messages'), inputEl = panel.querySelector('#sentryusb-chat-input');
  const sendBtn = panel.querySelector('#sentryusb-chat-send'), chipsEl = panel.querySelector('#sentryusb-chat-suggestions');
  const statusEl = panel.querySelector('#chatStatus'), insightsEl = panel.querySelector('#sucw-insights');
  const slashEl = panel.querySelector('#sucw-slash'), micBtn = panel.querySelector('#sucw-mic'), speakBtn = panel.querySelector('#sucw-speak');

  let isOpen = false, busy = false, socket = null, speak = false, alerts = 0;
  let log = [];
  const insights = new Map();

  // ---- persistence ----
  const save = () => { try { localStorage.setItem(STORE, JSON.stringify(log.slice(-40))); } catch (_) { /* storage blocked */ } };
  const load = () => { try { log = JSON.parse(localStorage.getItem(STORE) || '[]'); } catch (_) { log = []; } };

  // ---- rendering ----
  function render(entry, opts) {
    opts = opts || {};
    const row = $('div', 'sucw-msg ' + entry.role);
    if (entry.role === 'bot') {
      const body = $('div', 'sucw-body'); row.append(body);
      const fill = () => { body.innerHTML = md(entry.text); };
      if (opts.animate) typeInto(body, entry.text, fill); else fill();
      if (entry.cards && entry.cards.length) {
        const g = $('div', 'sucw-cards');
        entry.cards.forEach(c => g.append($('div', 'sucw-card ' + (c.tone || 'ok'), `<b>${esc(c.value)}</b><span>${esc(c.label)}</span>`)));
        row.append(g);
      }
      if (entry.actions && entry.actions.length) {
        const a = $('div', 'msg-actions');
        entry.actions.forEach(act => a.append(actionButton(act)));
        row.append(a);
      }
      const tools = $('div', 'sucw-tools');
      const copy = $('button', null, '<i class="fas fa-copy"></i>'); copy.title = 'Copy';
      copy.onclick = () => { navigator.clipboard && navigator.clipboard.writeText(entry.text); copy.innerHTML = '<i class="fas fa-check"></i>'; setTimeout(() => { copy.innerHTML = '<i class="fas fa-copy"></i>'; }, 1200); };
      const say = $('button', null, '<i class="fas fa-volume-high"></i>'); say.title = 'Read aloud'; say.onclick = () => speakText(entry.text);
      tools.append(copy, say); row.append(tools);
    } else row.textContent = entry.text;
    msgsEl.append(row); msgsEl.scrollTop = msgsEl.scrollHeight;
    return row;
  }
  function typeInto(el, text, done) {                   // quick "streaming" reveal
    const words = text.split(/(\s+)/); let i = 0;
    const step = () => { i = Math.min(words.length, i + 4); el.innerHTML = md(words.slice(0, i).join('')); msgsEl.scrollTop = msgsEl.scrollHeight; if (i < words.length) setTimeout(step, 18); else done(); };
    step();
  }
  function add(role, text, extra) {
    const entry = Object.assign({ role, text }, extra || {});
    log.push(entry); save();
    return render(entry, { animate: role === 'bot' });
  }
  function setChips(list) {
    chipsEl.replaceChildren();
    (list || []).slice(0, 5).forEach(label => {
      const b = $('button', 'sucw-chip'); b.textContent = label;
      b.onclick = () => send(label.replace(/^[^\w/]+\s*/, '')); chipsEl.append(b);
    });
  }

  // ---- actions (propose -> confirm -> execute) ----
  function actionButton(act) {
    const b = $('button', 'sucw-act risk-' + (act.risk || 'low')); b.textContent = act.label;
    b.onclick = () => {
      if (act.risk === 'low') return runAction(act, b);
      const wrap = $('span', 'sucw-confirm', `<span>Confirm?</span>`);
      const yes = $('button', 'yes'); yes.textContent = 'Yes, do it';
      const no = $('button', 'no'); no.textContent = 'Cancel';
      yes.onclick = () => { wrap.replaceWith(b); runAction(act, b); }; no.onclick = () => wrap.replaceWith(b);
      wrap.append(yes, no); b.replaceWith(wrap);
    };
    return b;
  }
  async function post(url, body) {
    const r = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) });
    let d = {}; try { d = await r.json(); } catch (_) { /* empty */ }
    return { ok: r.ok, d };
  }
  async function runAction(act, btn) {
    btn.disabled = true;
    const p = act.params || {};
    try {
      let r;
      switch (act.type) {
        case 'override_device': r = await post('/api/override/' + encodeURIComponent(p.event_id)); break;
        case 'start_exam': r = await post('/api/exam/start', {}); break;
        case 'stop_exam': r = await post('/api/exam/stop'); break;
        case 'train_ai': r = await post('/api/ai/ml/train'); break;
        case 'generate_report': r = await post('/api/ai/report/generate'); break;
        case 'allow_device': case 'unblock_device': case 'message_hub': r = await post('/api/ai/action', { type: act.type, params: p }); break;
        case 'call_hub': if (window.SentryMessenger) { closePanel(); window.SentryMessenger.startCall('audio'); add('system', '📞 Calling the Hub…'); } else add('system', 'Messenger is not available on this page.'); return;
        case 'open_messenger': closePanel(); document.getElementById('sentryusb-messenger-launcher')?.click(); return;
        default: add('system', 'Action "' + act.type + '" is not supported.'); return;
      }
      const msg = (r.d && (r.d.message || r.d.error)) || (r.ok ? 'Done.' : 'That did not work.');
      add('system', (r.ok && r.d.success !== false && r.d.status !== 'error' ? '✅ ' : '⚠️ ') + msg);
    } catch (e) { add('system', '⚠️ Could not reach the server.'); }
    btn.disabled = false;
  }

  // ---- chat flow ----
  async function send(text) {
    text = (text || inputEl.value).trim();
    if (!text || busy) return;
    inputEl.value = ''; hideSlash(); chipsEl.replaceChildren();
    const sl = SLASH.find(s => text.toLowerCase() === s.cmd);
    if (text.toLowerCase() === '/clear') return clearChat();
    if (sl && sl.text) text = sl.text;
    busy = true; sendBtn.disabled = true;
    add('user', text);
    const typing = $('div', 'sucw-msg bot typing', '<span></span><span></span><span></span>'); msgsEl.append(typing); msgsEl.scrollTop = msgsEl.scrollHeight;
    try {
      const res = await fetch('/api/ai/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: text }) });
      const d = await res.json(); typing.remove();
      add('bot', d.answer || "Sorry, I couldn't get an answer just now.", { cards: d.cards, actions: d.actions });
      setChips(d.suggestions);
      if (speak && d.answer) speakText(d.answer);
    } catch (_) { typing.remove(); add('bot', "I couldn't reach the server. Check your connection and try again."); }
    busy = false; sendBtn.disabled = false; inputEl.focus();
  }
  async function clearChat() {
    log = []; save(); msgsEl.replaceChildren(); chipsEl.replaceChildren();
    try { await post('/api/ai/chat/reset'); } catch (_) { /* best effort */ }
    greet();
  }
  function greet() {
    add('bot', "Hi, I'm the SentryUSB AI assistant. I can brief you, explain what's happening, suggest next steps and — with your confirmation — act. Type **/** for commands.");
    setChips(START_CHIPS);
  }

  // ---- slash menu ----
  function showSlash(q) {
    const items = SLASH.filter(s => s.cmd.startsWith(q.toLowerCase()));
    if (!items.length) return hideSlash();
    slashEl.replaceChildren(); slashEl.hidden = false;
    items.forEach(s => {
      const r = $('button', null, `<b>${esc(s.cmd)}</b><span>${esc(s.hint)}</span>`);
      r.onclick = () => { inputEl.value = s.cmd === '/hub' ? '/hub ' : s.cmd; inputEl.focus(); if (s.cmd !== '/hub') send(); hideSlash(); };
      slashEl.append(r);
    });
  }
  const hideSlash = () => { slashEl.hidden = true; };

  // ---- voice in / out ----
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) micBtn.style.display = 'none';
  let rec = null;
  micBtn.onclick = () => {
    if (!SR) return;
    if (rec) { rec.stop(); return; }
    rec = new SR(); rec.lang = navigator.language || 'en-US'; rec.interimResults = true;
    micBtn.classList.add('live');
    rec.onresult = (e) => { inputEl.value = Array.from(e.results).map(r => r[0].transcript).join(''); };
    rec.onend = () => { micBtn.classList.remove('live'); rec = null; if (inputEl.value.trim()) send(); };
    rec.onerror = () => { micBtn.classList.remove('live'); rec = null; };
    rec.start();
  };
  function speakText(t) {
    if (!('speechSynthesis' in window)) return;
    speechSynthesis.cancel();
    speechSynthesis.speak(new SpeechSynthesisUtterance(String(t).replace(/\*\*/g, '').replace(/[•·]/g, ',')));
  }
  speakBtn.onclick = () => { speak = !speak; speakBtn.classList.toggle('on', speak); speakBtn.innerHTML = '<i class="fas ' + (speak ? 'fa-volume-high' : 'fa-volume-xmark') + '"></i>'; if (!speak && 'speechSynthesis' in window) speechSynthesis.cancel(); };

  // ---- proactive insights ----
  function setCount() {
    const n = Array.from(insights.values()).filter(i => i.severity !== 'info').length + alerts;
    launcher.querySelector('.sucw-count').textContent = n > 9 ? '9+' : n;
    launcher.classList.toggle('has-alert', n > 0);
  }
  function paintInsights() {
    const list = Array.from(insights.values()).sort((a, b) => ({ critical: 0, warning: 1, info: 2 }[a.severity] - { critical: 0, warning: 1, info: 2 }[b.severity]));
    insightsEl.hidden = !list.length; insightsEl.replaceChildren();
    if (!list.length) return;
    const head = $('div', 'sucw-ins-head', `<i class="fas fa-bolt"></i> Autopilot · ${list.length} item${list.length > 1 ? 's' : ''}`);
    insightsEl.append(head);
    list.slice(0, 3).forEach(i => {
      const row = $('button', 'sucw-ins ' + i.severity, `<b>${esc(i.title)}</b><span>${esc(i.detail || '')}</span>`);
      row.onclick = () => send('what should I do?');
      insightsEl.append(row);
    });
    setCount();
  }
  async function loadInsights() {
    try { const d = await (await fetch('/api/ai/insights')).json(); insights.clear(); (d.insights || []).forEach(i => insights.set(i.id, i)); paintInsights(); } catch (_) { /* offline */ }
  }

  // ---- socket ----
  function initSocket() {
    if (socket || typeof io === 'undefined') return;
    try {
      socket = io();
      socket.on('connect', () => { statusEl.className = 'status'; statusEl.innerHTML = '<span class="dot"></span> Online · autopilot on'; });
      socket.on('disconnect', () => { statusEl.className = 'status offline'; statusEl.innerHTML = '<span class="dot"></span> Disconnected'; });
      socket.on('ai_insight', (i) => { insights.set(i.id, i); paintInsights(); if (isOpen) add('system', (i.severity === 'critical' ? '🚨 ' : '⚠️ ') + i.title + (i.detail ? ' — ' + i.detail : '')); });
      socket.on('ai_alert', (data) => {
        const t = data.type === 'login_anomaly' ? `⚠️ Suspicious login on ${data.hostname} (score ${data.score})` : `⚠️ Anomalous device "${data.device_name}" on ${data.hostname} (score ${data.score})`;
        if (isOpen) add('system', t); else { alerts++; setCount(); }
      });
      socket.on('new_event', (ev) => { if (isOpen && ev.status === 'blocked') add('system', `🚨 USB blocked: ${ev.device_name} on ${ev.hostname}`); });
    } catch (e) { console.warn('AI widget socket failed', e); }
  }

  // ---- open / close ----
  function openPanel() {
    document.dispatchEvent(new CustomEvent('sentryusb:ai-open'));
    isOpen = true; panel.classList.add('open'); alerts = 0; setCount();
    if (!msgsEl.children.length) { load(); if (log.length) { log.forEach(e => render(e)); } else greet(); }
    loadInsights(); initSocket(); inputEl.focus();
  }
  function closePanel() { isOpen = false; panel.classList.remove('open'); }
  launcher.onclick = () => (isOpen ? closePanel() : openPanel());
  panel.querySelector('#sentryusb-chat-close').onclick = closePanel;
  panel.querySelector('#sucw-clear').onclick = clearChat;
  sendBtn.onclick = () => send();
  inputEl.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); send(); } if (e.key === 'Escape') hideSlash(); });
  inputEl.addEventListener('input', () => { const v = inputEl.value; v.startsWith('/') && !v.includes(' ') ? showSlash(v) : hideSlash(); });
  document.addEventListener('sentryusb:messenger-open', () => { if (isOpen) closePanel(); });

  // The /hub command is a message, not a question: turn it into a confirmable action.
  const origSend = send;
  send = async function (t) {                           // eslint-disable-line no-func-assign
    const v = (t || inputEl.value).trim();
    if (/^\/hub\s+\S/.test(v)) return origSend('message hub: ' + v.replace(/^\/hub\s+/, ''));
    return origSend(t);
  };

  setTimeout(() => { initSocket(); loadInsights(); }, 1200);
  setInterval(() => { if (!document.hidden) loadInsights(); }, 60000);
})();
