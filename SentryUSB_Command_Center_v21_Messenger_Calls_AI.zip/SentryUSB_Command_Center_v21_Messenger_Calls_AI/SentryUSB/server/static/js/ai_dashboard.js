// server/static/js/ai_dashboard.js
/**
 * AI Dashboard enhancements for SentryUSB
 */

// Global state
let aiData = {
    insights: [],
    predictions: {},
    deviceAnalysis: {}
};

// ============================================================
// AI INSIGHTS PANEL
// ============================================================

function loadAIAnalysis() {
    const container = document.getElementById('aiInsightsContainer');
    if (!container) return;
    
    container.innerHTML = `
        <div style="text-align:center;padding:20px;color:var(--text-muted);">
            <i class="fas fa-spinner fa-spin" style="font-size:24px;display:block;margin-bottom:10px;"></i>
            Analyzing network patterns...
        </div>
    `;
    
    fetch('/api/ai/network-insights')
        .then(r => r.json())
        .then(data => {
            aiData.insights = data.insights || [];
            renderAIAnalysis(data);
        })
        .catch(error => {
            console.error('AI analysis error:', error);
            container.innerHTML = `
                <div style="text-align:center;padding:20px;color:var(--text-muted);">
                    <i class="fas fa-exclamation-triangle" style="font-size:28px;color:var(--accent-warning);display:block;margin-bottom:10px;"></i>
                    Unable to fetch AI insights
                    <div style="font-size:12px;margin-top:5px;">${error.message}</div>
                </div>
            `;
        });
}

function renderAIAnalysis(data) {
    const container = document.getElementById('aiInsightsContainer');
    const insights = data.insights || [];
    
    if (insights.length === 0) {
        container.innerHTML = `
            <div style="text-align:center;padding:20px;color:var(--text-muted);">
                <i class="fas fa-check-circle" style="font-size:28px;color:var(--accent-4);display:block;margin-bottom:10px;"></i>
                No suspicious patterns detected
                <div style="font-size:12px;margin-top:5px;">Analyzed ${data.total_analyzed || 0} events</div>
            </div>
        `;
        return;
    }
    
    let html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">';
    insights.forEach(insight => {
        const severityColor = insight.severity === 'high' ? 'var(--accent-danger)' : 
                             insight.severity === 'medium' ? 'var(--accent-warning)' : 'var(--accent-1)';
        const badgeClass = insight.severity === 'high' ? 'badge-danger' : 
                          insight.severity === 'medium' ? 'badge-warning' : 'badge-info';
        
        html += `
            <div style="background:rgba(255,255,255,0.03);border-radius:8px;padding:14px;border-left:3px solid ${severityColor};">
                <div style="display:flex;justify-content:space-between;align-items:center;">
                    <div style="font-weight:600;font-size:14px;">${insight.type.replace(/_/g, ' ').toUpperCase()}</div>
                    <span class="badge ${badgeClass}">${insight.severity}</span>
                </div>
                <div style="font-size:13px;color:var(--text-secondary);margin-top:4px;">${insight.description}</div>
                ${insight.count ? `<div style="font-size:11px;color:var(--text-muted);margin-top:6px;">Count: ${insight.count}</div>` : ''}
            </div>
        `;
    });
    html += '</div>';
    
    // Add timestamp
    html += `
        <div style="text-align:right;font-size:11px;color:var(--text-muted);margin-top:12px;">
            Last analysis: ${data.timestamp ? new Date(data.timestamp).toLocaleString() : 'Just now'}
        </div>
    `;
    
    container.innerHTML = html;
}

// ============================================================
// AI PREDICTIONS
// ============================================================

function loadAIPredictions() {
    fetch('/api/ai/predictions')
        .then(r => r.json())
        .then(data => {
            aiData.predictions = data;
            renderPredictions(data);
        })
        .catch(error => {
            console.error('Prediction error:', error);
        });
}

function renderPredictions(data) {
    const elements = {
        predictedBlockRate: document.getElementById('predictedBlockRate'),
        riskLevel: document.getElementById('riskLevel'),
        recommendedAction: document.getElementById('recommendedAction')
    };
    
    if (elements.predictedBlockRate) {
        elements.predictedBlockRate.textContent = data.predicted_block_rate + '%';
    }
    
    if (elements.riskLevel) {
        elements.riskLevel.textContent = data.risk_level;
        const colors = {
            'High': 'var(--accent-danger)',
            'Medium': 'var(--accent-warning)',
            'Low': 'var(--accent-4)',
            'Learning': 'var(--accent-1)'
        };
        elements.riskLevel.style.color = colors[data.risk_level] || 'var(--text-secondary)';
    }
    
    if (elements.recommendedAction) {
        elements.recommendedAction.textContent = data.recommended_action || 'No recommendation';
    }
}

// ============================================================
// DEVICE ANALYSIS
// ============================================================

function analyzeDevice(deviceId) {
    if (!deviceId) return;
    
    const container = document.getElementById('deviceAIAnalysis');
    if (!container) return;
    
    container.innerHTML = `
        <div style="text-align:center;padding:10px;color:var(--text-muted);font-size:13px;">
            <i class="fas fa-spinner fa-spin"></i> Analyzing device...
        </div>
    `;
    
    fetch(`/api/ai/device-analysis/${encodeURIComponent(deviceId)}`)
        .then(r => r.json())
        .then(data => {
            renderDeviceAnalysis(data);
        })
        .catch(error => {
            container.innerHTML = `
                <div style="text-align:center;padding:10px;color:var(--accent-danger);font-size:13px;">
                    <i class="fas fa-exclamation-circle"></i> Analysis failed
                </div>
            `;
        });
}

function renderDeviceAnalysis(data) {
    const container = document.getElementById('deviceAIAnalysis');
    if (!container) return;
    
    const score = data.anomaly_score || 0;
    const scoreColor = score > 70 ? 'var(--accent-danger)' : 
                       score > 40 ? 'var(--accent-warning)' : 'var(--accent-4)';
    
    let html = `
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:13px;">
            <div>
                <div style="color:var(--text-muted);font-size:11px;">Anomaly Score</div>
                <div style="font-size:20px;font-weight:700;color:${scoreColor};">${score}%</div>
            </div>
            <div>
                <div style="color:var(--text-muted);font-size:11px;">Profile Status</div>
                <div style="font-size:14px;font-weight:600;">${data.profile_status || 'Unknown'}</div>
            </div>
        </div>
    `;
    
    if (data.features) {
        html += `
            <div style="margin-top:8px;border-top:1px solid var(--border-glass);padding-top:8px;">
                <div style="font-size:11px;color:var(--text-muted);">Features</div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;font-size:12px;margin-top:4px;">
                    ${Object.entries(data.features).map(([key, value]) => `
                        <div><span style="color:var(--text-muted);">${key}:</span> ${typeof value === 'number' ? value.toFixed(1) : value}</div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    if (data.recent_events && data.recent_events.length > 0) {
        html += `
            <div style="margin-top:8px;border-top:1px solid var(--border-glass);padding-top:8px;">
                <div style="font-size:11px;color:var(--text-muted);">Recent Events</div>
                <div style="font-size:12px;max-height:100px;overflow-y:auto;">
                    ${data.recent_events.map(e => `
                        <div style="padding:2px 0;border-bottom:1px solid var(--border-glass);">
                            ${e.device_name} - ${e.status} (${e.hostname})
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    container.innerHTML = html;
}

// ============================================================
// TRAIN AI MODEL
// ============================================================

function trainAIModel() {
    if (!confirm('Train AI model on current data?\nThis may take a few moments.')) return;
    
    const btn = document.getElementById('trainModelBtn');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Training...';
    }
    
    fetch('/api/ai/train-model', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    })
    .then(r => r.json())
    .then(data => {
        alert(`✅ Model trained on ${data.devices_trained || 0} devices`);
        loadAIAnalysis();
        loadAIPredictions();
    })
    .catch(error => {
        alert('❌ Training failed: ' + error.message);
    })
    .finally(() => {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-brain"></i> Train AI Model';
        }
    });
}

// ============================================================
// GENERATE AI REPORT
// ============================================================

function generateAIReport(period) {
    const btn = document.getElementById('generateReportBtn');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
    }
    
    fetch('/api/ai/report/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ period: period || 'week' })
    })
    .then(r => r.json())
    .then(data => {
        const container = document.getElementById('aiReportContainer');
        if (container) {
            container.innerHTML = `
                <div style="background:rgba(255,255,255,0.05);border-radius:8px;padding:16px;white-space:pre-wrap;font-family:monospace;font-size:13px;max-height:400px;overflow-y:auto;">
                    ${data.summary}
                </div>
                <div style="text-align:right;font-size:11px;color:var(--text-muted);margin-top:8px;">
                    Generated: ${data.generated_at ? new Date(data.generated_at).toLocaleString() : 'Just now'}
                </div>
            `;
        }
    })
    .catch(error => {
        alert('❌ Report generation failed: ' + error.message);
    })
    .finally(() => {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = '<i class="fas fa-file-alt"></i> Generate AI Report';
        }
    });
}

// ============================================================
// INITIALIZATION
// ============================================================

// Auto-load on page ready
document.addEventListener('DOMContentLoaded', function() {
    // Load AI insights if container exists
    if (document.getElementById('aiInsightsContainer')) {
        loadAIAnalysis();
        // Refresh every 60 seconds
        setInterval(loadAIAnalysis, 60000);
    }
    
    // Load predictions if container exists
    if (document.getElementById('predictedBlockRate')) {
        loadAIPredictions();
        // Refresh every 30 seconds
        setInterval(loadAIPredictions, 30000);
    }
});

// Export for use in other scripts
window.ai = {
    loadAIAnalysis,
    loadAIPredictions,
    analyzeDevice,
    trainAIModel,
    generateAIReport
};