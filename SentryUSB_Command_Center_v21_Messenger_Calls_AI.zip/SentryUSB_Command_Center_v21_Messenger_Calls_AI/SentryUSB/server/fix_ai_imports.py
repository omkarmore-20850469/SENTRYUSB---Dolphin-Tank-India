# server/fix_all.py
"""
Fix all issues at once
"""
import os
import re

def fix_app_py():
    """Fix datetime import in app.py"""
    with open('app.py', 'r') as f:
        content = f.read()
    
    # Check if datetime is imported
    if "from datetime import datetime" not in content:
        print("Adding datetime import to app.py...")
        # Add import after the first import block
        lines = content.split('\n')
        new_lines = []
        import_block = True
        added = False
        
        for line in lines:
            new_lines.append(line)
            if line.startswith('import') and not added:
                # Check if we're at the end of imports
                if not line.startswith('import') or line.startswith('from'):
                    continue
            # Add the import after all imports
            if line.strip() == '' and not added and 'import' in ''.join(new_lines[-5:]):
                # Check if datetime already imported
                if 'datetime' not in ''.join(new_lines):
                    new_lines.append('from datetime import datetime, timedelta')
                    added = True
        
        if not added:
            # Add at the top
            new_lines.insert(0, 'from datetime import datetime, timedelta')
        
        with open('app.py', 'w') as f:
            f.write('\n'.join(new_lines))
        print("✅ Fixed app.py")
    else:
        print("✅ datetime already imported in app.py")

def fix_ai_files():
    """Fix datetime imports in AI files"""
    ai_files = ['ai_anomaly.py', 'ai_reports.py']
    
    for file in ai_files:
        if os.path.exists(file):
            with open(file, 'r') as f:
                content = f.read()
            
            if "from datetime import datetime" not in content:
                print(f"Adding datetime import to {file}...")
                content = "from datetime import datetime, timedelta\n" + content
                with open(file, 'w') as f:
                    f.write(content)
                print(f"✅ Fixed {file}")
            else:
                print(f"✅ datetime already imported in {file}")

def check_tokens():
    """Check if tokens match"""
    print("\n🔑 Checking tokens...")
    
    # Check server config
    with open('config.py', 'r') as f:
        server_config = f.read()
    
    # Check agent config
    agent_path = os.path.join('..', 'agent', 'config.py')
    if os.path.exists(agent_path):
        with open(agent_path, 'r') as f:
            agent_config = f.read()
        
        # Extract tokens
        server_token = None
        agent_token = None
        
        for line in server_config.split('\n'):
            if 'AGENT_AUTH_TOKEN' in line:
                if '=' in line:
                    server_token = line.split('=', 1)[1].strip().strip('"').strip("'")
                    break
        
        for line in agent_config.split('\n'):
            if 'AUTH_TOKEN' in line:
                if '=' in line:
                    agent_token = line.split('=', 1)[1].strip().strip('"').strip("'")
                    break
        
        print(f"Server token: {server_token}")
        print(f"Agent token:  {agent_token}")
        
        if server_token == agent_token:
            print("✅ Tokens match!")
        else:
            print("❌ Tokens DO NOT match!")
            print("\nTo fix:")
            print("1. Open server/config.py and change:")
            print(f'   AGENT_AUTH_TOKEN = "your-secret-token"')
            print("2. Open agent/config.py and change:")
            print(f'   AUTH_TOKEN = "your-secret-token"')
            print("   (use the SAME token in both files)")
    else:
        print("⚠️ Agent config not found at:", agent_path)

if __name__ == "__main__":
    print("="*60)
    print("🔧 Fixing SentryUSB Issues")
    print("="*60)
    
    fix_app_py()
    fix_ai_files()
    check_tokens()
    
    print("\n" + "="*60)
    print("✅ All fixes applied!")
    print("="*60)
    print("\n🔄 Next steps:")
    print("1. Restart your server: python app.py")
    print("2. Restart your agent: python agent.py")
    print("3. Check that tokens match!")