"""
SentryUSB Enterprise Command Center extensions.

Adds:
- animated topology data + risk history
- proactive AI insight feed
- incident replay timeline
- pre-exam readiness scans
- device trust history
- incident claiming/comments
- lab health ranking
- webhook/Slack/Teams notifications
- verifiable incident PDF reports

All signals are aggregated security telemetry; no keystroke/biometric collection.
"""
import json, os, threading, time, urllib.request
from datetime import datetime, timedelta
from pathlib import Path

import db
from security_upgrade import utc_now

DATA_DIR = Path(os.path.dirname(__file__)) / "ai_models"
DATA_DIR.mkdir(parents=True, exist_ok=True)
STATE_FILE = DATA_DIR / "enterprise_state.json"
_LOCK = threading.RLock()
_PROACTIVE_STARTED = False
_SOCKETIO = None


def _load():
    try:
        return json.loads(STATE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {"risk_history": {}, "insights": [], "incidents": {}, "claims": {}, "comments": {}, "trust": {}}


def _save(state):
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2, default=str), encoding="utf-8")
    tmp.replace(STATE_FILE)


def _events(limit=2000):
    try:
        return db.get_all_events(limit=limit) or []
    except Exception:
        return []


def _ts(e):
    try:
        return datetime.fromisoformat(str(e.get("timestamp", "")).replace("Z", "+00:00")).replace(tzinfo=None)
    except Exception:
        return datetime.now()


def _risk_for_event(e):
    explicit = e.get("risk_score")
    if explicit is not None:
        try:
            return max(0, min(100, float(explicit)))
        except Exception:
            pass
    status = str(e.get("status", "")).lower()
    score = {"blocked": 75, "overridden": 55, "removed": 35, "allowed": 10, "connected": 15}.get(status, 20)
    # Fan-out is a useful explainable trust signal.
    return score


def risk_snapshot():
    now = datetime.now()
    cutoff = now - timedelta(hours=1)
    rows = [e for e in _events(3000) if _ts(e) >= cutoff]
    by_host = {}
    for e in rows:
        h = e.get("hostname") or "unknown"
        by_host.setdefault(h, []).append((_ts(e), _risk_for_event(e)))
    result = {}
    for host, points in by_host.items():
        points.sort()
        score = sum(p[1] for p in points[-12:]) / max(1, len(points[-12:]))
        # EWMA-like recency weighting.
        ewma = points[0][1]
        for _, v in points[1:]:
            ewma = 0.35 * v + 0.65 * ewma
        slope = 0.0
        if len(points) >= 2:
            slope = (points[-1][1] - points[0][1]) / max(1, (points[-1][0]-points[0][0]).total_seconds()/60)
        result[host] = {"risk": round(max(0, min(100, ewma)), "2"),
                        "slope_per_min": round(slope, 3),
                        "samples": len(points),
                        "history": [{"t": p[0].isoformat(), "v": p[1]} for p in points[-30:]]}
    return result


def topology_state():
    try:
        agents = db.get_agents() or []
    except Exception:
        agents = []
    risks = risk_snapshot()
    events = _events(300)
    by_host_events = {}
    for e in events:
        by_host_events.setdefault(e.get("hostname"), []).append(e)
    nodes = []
    for a in agents:
        h = a.get("hostname") or "unknown"
        r = risks.get(h, {"risk": 0, "slope_per_min": 0, "samples": 0, "history": []})
        lab = (a.get("lab_name") or a.get("lab") or (h.split("-")[0] if h else "Lab"))
        nodes.append({
            "id": h, "type": "agent", "hostname": h, "lab": lab,
            "status": a.get("status", "offline"), "ip_address": a.get("ip_address"),
            "username": a.get("username"), "last_seen": a.get("last_seen"),
            "risk": r["risk"], "slope_per_min": r["slope_per_min"],
            "risk_history": r["history"],
            "event_count": len(by_host_events.get(h, [])),
        })
    labs = {}
    for n in nodes:
        labs.setdefault(n["lab"], []).append(n)
    return {"generated_at": utc_now(), "labs": [
        {"id": lab, "name": lab, "risk": round(sum(n["risk"] for n in ns)/len(ns), 1), "agents": len(ns)}
        for lab, ns in labs.items()
    ], "nodes": nodes}


def incident_timeline(hostname=None, limit=200):
    rows = _events(3000)
    if hostname:
        rows = [e for e in rows if e.get("hostname") == hostname]
    rows = sorted(rows, key=_ts)[-limit:]
    out = []
    for e in rows:
        out.append({"id": e.get("id"), "timestamp": e.get("timestamp"), "hostname": e.get("hostname"),
                    "kind": e.get("event_type") or e.get("status") or "event",
                    "status": e.get("status"), "device": e.get("device_name"),
                    "device_id": e.get("device_instance_id"), "risk": _risk_for_event(e),
                    "detail": e.get("message") or e.get("block_reason") or e.get("status")})
    return out


def incident_list(limit=50, hostname=None):
    """Return explainable security incidents derived from recorded telemetry.

    An incident is a correlated security-relevant event, not a claim of malicious intent.
    """
    rows = incident_timeline(hostname=hostname, limit=1000)
    incidents = []
    incident_kinds = ("blocked", "overridden", "malware", "rdp", "remote", "disconnect", "offline", "critical", "violation", "suspicious")
    for e in reversed(rows):
        blob = f"{e.get('kind','')} {e.get('status','')} {e.get('detail','')}".lower()
        if e.get('risk', 0) >= 65 or any(k in blob for k in incident_kinds):
            iid = f"INC-{e.get('id') or abs(hash((e.get('hostname'),e.get('timestamp'),e.get('kind')))) % 1000000:06d}"
            sev = "critical" if e.get('risk', 0) >= 80 else "high" if e.get('risk', 0) >= 65 else "medium"
            incidents.append({"incident_id": iid, "timestamp": e.get("timestamp"), "hostname": e.get("hostname"), "kind": e.get("kind"), "risk": e.get("risk",0), "severity": sev, "detail": e.get("detail"), "device_id": e.get("device_id")})
            if len(incidents) >= limit: break
    return incidents


def device_trust(device_id=None):
    rows = _events(5000)
    groups = {}
    for e in rows:
        did = e.get("device_instance_id") or e.get("device_id")
        if not did or (device_id and str(did) != str(device_id)):
            continue
        g = groups.setdefault(str(did), {"device_id": str(did), "events": 0, "hosts": set(), "blocked": 0, "first_seen": None, "last_seen": None})
        g["events"] += 1
        if e.get("hostname"): g["hosts"].add(e["hostname"])
        if e.get("status") == "blocked": g["blocked"] += 1
        stamp = e.get("timestamp")
        if stamp:
            if not g["first_seen"] or stamp < g["first_seen"]: g["first_seen"] = stamp
            if not g["last_seen"] or stamp > g["last_seen"]: g["last_seen"] = stamp
    out = []
    for g in groups.values():
        fanout = len(g["hosts"])
        trust = max(0, min(100, 100 - fanout*8 - g["blocked"]*5 - max(0, g["events"]-20)*1.5))
        out.append({**g, "hosts": sorted(g["hosts"]), "trust_score": round(trust,1), "risk_score": round(100-trust,1)})
    return sorted(out, key=lambda x: x["trust_score"])


def lab_health():
    top = topology_state()
    return sorted(top["labs"], key=lambda x: x["risk"], reverse=True)


def readiness_scan(lab=None):
    top = topology_state()
    selected = [n for n in top["nodes"] if not lab or n["lab"] == lab]
    timeline = incident_timeline(limit=1000)
    results = []
    for n in selected:
        host = n["hostname"]
        host_events = [e for e in timeline if e["hostname"] == host]
        blocked = sum(1 for e in host_events if e["status"] == "blocked")
        rdp = [x for x in host_events if "rdp" in str(x["kind"]).lower() or "remote" in str(x["detail"]).lower()]
        integrity = "pass"
        malware = "pass"
        # Server-side readiness cannot claim an agent scan if no agent result exists.
        # Instead, report telemetry readiness honestly.
        if not n["last_seen"] or n["status"] != "online": integrity = "fail"
        if blocked >= 3: malware = "review"
        if rdp: malware = "review"
        checks = {"agent_online": n["status"] == "online", "integrity_telemetry": integrity,
                  "malware_telemetry": malware, "rdp_clear": not bool(rdp)}
        passed = sum(1 for v in checks.values() if v is True or v == "pass")
        score = round(passed/len(checks)*100)
        results.append({"hostname": host, "lab": n["lab"], "ready": score == 100,
                        "score": score, "checks": checks, "risk": n["risk"]})
    return {"generated_at": utc_now(), "lab": lab, "seats": results,
            "ready": bool(results) and all(x["ready"] for x in results),
            "note": "Readiness is based on telemetry available to the hub; agent-reported integrity/malware/RDP results are required for a full pass."}


def _insight():
    snap = topology_state()
    risky = [n for n in snap["nodes"] if n["risk"] >= 65]
    rising = [n for n in snap["nodes"] if n["slope_per_min"] >= 0.5]
    labs = sorted(snap["labs"], key=lambda x: x["risk"], reverse=True)
    if not snap["nodes"]:
        return None
    if risky:
        n = max(risky, key=lambda x: x["risk"])
        return {"severity": "high", "title": f"{len(risky)} elevated-risk seat(s)",
                "body": f"{n['hostname']} is at risk {n['risk']:.0f}/100. Review its recent event timeline before the next exam.",
                "host": n["hostname"]}
    if rising:
        n = max(rising, key=lambda x: x["slope_per_min"])
        return {"severity": "medium", "title": "Risk is trending upward",
                "body": f"{n['hostname']} is rising about {n['slope_per_min']:.1f} points/min. Consider a readiness scan.",
                "host": n["hostname"]}
    if labs and labs[0]["risk"] > 35:
        return {"severity": "medium", "title": f"{labs[0]['name']} needs a review",
                "body": f"Lab health risk is {labs[0]['risk']:.0f}/100 based on recent telemetry.",
                "host": None}
    return {"severity": "low", "title": "Command center stable",
            "body": "No high-risk or sharply rising device patterns are visible in the latest telemetry.",
            "host": None}


def proactive_tick():
    global _PROACTIVE_STARTED
    insight = _insight()
    if not insight: return
    with _LOCK:
        state = _load()
        state["insights"].insert(0, {**insight, "timestamp": utc_now()})
        state["insights"] = state["insights"][:100]
        _save(state)
    if _SOCKETIO:
        _SOCKETIO.emit("ai_proactive_insight", insight | {"timestamp": utc_now()})


def start_proactive(socketio, interval=60):
    global _PROACTIVE_STARTED, _SOCKETIO
    _SOCKETIO = socketio
    if _PROACTIVE_STARTED: return
    _PROACTIVE_STARTED = True
    def loop():
        while True:
            try: proactive_tick()
            except Exception: pass
            time.sleep(max(15, interval))
    threading.Thread(target=loop, name="sentryusb-proactive-ai", daemon=True).start()


def insights(limit=30):
    return _load().get("insights", [])[:limit]


def claim_incident(incident_id, username):
    with _LOCK:
        s = _load()
        existing = s["claims"].get(str(incident_id))
        if existing and existing.get("username") != username:
            return {"ok": False, "claim": existing}
        claim = {"incident_id": str(incident_id), "username": username, "claimed_at": utc_now()}
        s["claims"][str(incident_id)] = claim; _save(s)
        return {"ok": True, "claim": claim}


def add_comment(incident_id, username, text):
    text = str(text or "").strip()[:2000]
    if not text: return {"ok": False, "error": "comment is required"}
    with _LOCK:
        s = _load()
        item = {"incident_id": str(incident_id), "username": username, "text": text, "timestamp": utc_now()}
        s["comments"].setdefault(str(incident_id), []).append(item); _save(s)
        try: db.add_audit_log(username, "incident_comment", json.dumps(item))
        except Exception: pass
        return {"ok": True, "comment": item}


def incident_details(incident_id):
    s = _load()
    return {"claim": s["claims"].get(str(incident_id)), "comments": s["comments"].get(str(incident_id), [])}


def push_webhook(payload, url=None):
    url = url or os.environ.get("SENTRYUSB_WEBHOOK_URL", "")
    if not url: return False
    try:
        req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={"Content-Type":"application/json"}, method="POST")
        urllib.request.urlopen(req, timeout=5).read()
        return True
    except Exception:
        return False


def push_slack_or_teams(payload):
    ok = False
    for env in ("SENTRYUSB_SLACK_WEBHOOK_URL", "SENTRYUSB_TEAMS_WEBHOOK_URL"):
        url = os.environ.get(env, "")
        if url: ok = push_webhook(payload, url) or ok
    return ok


def generate_incident_pdf(incident_id):
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet
    from io import BytesIO
    from security_upgrade import verify_chain
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=45, leftMargin=45, topMargin=45, bottomMargin=45)
    styles = getSampleStyleSheet()
    chain = db.get_evidence_chain(limit=10000) or []
    verification = verify_chain(chain)
    timeline = incident_timeline(limit=250)
    story = [Paragraph("SentryUSB — Verifiable Incident Report", styles["Title"]),
             Paragraph(f"Incident: {incident_id}", styles["Normal"]),
             Paragraph(f"Generated: {datetime.now().isoformat()}", styles["Normal"]), Spacer(1,12),
             Paragraph(f"Evidence chain: {'VALID' if verification.get('valid') else 'INVALID'}", styles["Heading2"]),
             Paragraph(f"Tail hash: {verification.get('tail_hash','—')}", styles["Normal"]), Spacer(1,12)]
    rows = [["Time","Host","Kind","Risk","Detail"]]
    for e in timeline[-80:]:
        rows.append([str(e["timestamp"] or ""), str(e["hostname"] or ""), str(e["kind"]), str(e["risk"]), str(e["detail"] or "")[:80]])
    tab = Table(rows, repeatRows=1, colWidths=[95,80,70,40,180])
    tab.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.4,colors.grey),("BACKGROUND",(0,0),(-1,0),colors.HexColor("#18243d")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTSIZE",(0,0),(-1,-1),7)]))
    story += [tab, Spacer(1,10), Paragraph("This report is a review aid. Evidence-chain verification is cryptographic integrity evidence, not proof of intent.", styles["Normal"])]
    doc.build(story); return buf.getvalue()


def author_policy_from_text(text, created_by="admin"):
    """Conservative NL -> policy translator. Returns a draft unless explicit verbs match."""
    import re
    q = str(text or "").strip()
    low = q.lower()
    action = "monitor"
    if re.search(r"\bblock\b", low): action = "block"
    elif re.search(r"\ballow\b|\bwhitelist\b", low): action = "allow"
    elif re.search(r"\bapproval\b|\brequire approval\b", low): action = "approval_required"
    tools = re.findall(r"\b(anydesk|teamviewer|rustdesk|splashtop|ultravnc|rdp)\b", low)
    if not tools:
        return {"ok": False, "draft": True, "error": "Could not identify a supported device/tool value."}
    tool = tools[0]
    policy_id = "nl-" + "".join(c for c in tool if c.isalnum()) + "-" + datetime.now().strftime("%Y%m%d%H%M%S")
    from security_upgrade import normalize_policy
    policy = normalize_policy({"policy_id": policy_id, "match_type": "device_type",
                               "match_value": tool, "action": action, "enabled": True,
                               "priority": 20, "reason": q, "created_by": created_by})
    # Do not silently enforce: return a ready-to-review object.
    return {"ok": True, "draft": True, "policy": policy}
