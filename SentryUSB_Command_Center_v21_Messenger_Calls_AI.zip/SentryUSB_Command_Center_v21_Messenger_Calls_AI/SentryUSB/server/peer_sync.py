"""Signed, bounded peer event envelopes for outage-tolerant lab synchronisation.

Peers only exchange validated metadata. This is not an unauthenticated P2P
overlay and does not remotely execute policy changes.
"""
import hashlib
import hmac
import json
import os
import time


def _key():
    return os.environ.get("SENTRYUSB_PEER_SYNC_KEY", "")


def enabled():
    return bool(_key()) and os.environ.get("SENTRYUSB_PEER_SYNC_ENABLED", "false").lower() == "true"


def sign(envelope):
    body = json.dumps(envelope, sort_keys=True, separators=(",", ":"))
    return hmac.new(_key().encode("utf-8"), body.encode("utf-8"), hashlib.sha256).hexdigest()


def verify(envelope, signature, max_age_seconds=300):
    if not enabled() or not signature:
        return False
    issued_at = float(envelope.get("issued_at", 0))
    if abs(time.time() - issued_at) > max_age_seconds:
        return False
    return hmac.compare_digest(sign(envelope), signature)
