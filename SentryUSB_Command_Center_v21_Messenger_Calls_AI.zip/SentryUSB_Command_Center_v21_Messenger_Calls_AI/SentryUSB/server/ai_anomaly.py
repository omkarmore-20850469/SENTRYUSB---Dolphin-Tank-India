# server/ai_anomaly.py - Pure Python Version (No numpy needed!)
"""
AI-Powered Anomaly Detection for SentryUSB
- Device behavior profiling  
- Login attempt anomaly detection
- Pattern recognition across agents
"""
from datetime import datetime
from collections import defaultdict
import os
import logging
import json
import math

log = logging.getLogger("sentryusb.ai_anomaly")

class DeviceBehaviorProfiler:
    """Profiles USB device behavior to detect anomalies"""
    
    def __init__(self, model_path="ai_models/"):
        self.model_path = model_path
        os.makedirs(model_path, exist_ok=True)
        self.device_profiles = {}
        self.anomaly_model = None
        
    def extract_device_features(self, device_history):
        """Extract behavioral features from device history"""
        if not device_history:
            return None
            
        features = {}
        
        # Connection frequency
        features['total_connections'] = len(device_history)
        
        # Unique hosts
        hosts = set()
        for event in device_history:
            if event.get('hostname'):
                hosts.add(event.get('hostname'))
        features['unique_hosts'] = len(hosts)
        
        # Timing patterns
        timestamps = []
        hours = []
        for event in device_history:
            ts_str = event.get('timestamp')
            if ts_str:
                try:
                    ts = datetime.fromisoformat(ts_str)
                    timestamps.append(ts)
                    hours.append(ts.hour)
                except:
                    pass
        
        if timestamps:
            if hours:
                hour_counts = defaultdict(int)
                for h in hours:
                    hour_counts[h] += 1
                features['dominant_hour'] = max(hour_counts, key=hour_counts.get) if hour_counts else -1
                if len(hours) > 1:
                    avg_hour = sum(hours) / len(hours)
                    variance = sum((h - avg_hour) ** 2 for h in hours) / len(hours)
                    features['activity_variance'] = variance
                else:
                    features['activity_variance'] = 0
            
            if len(timestamps) > 1:
                sorted_ts = sorted(timestamps)
                intervals = []
                for i in range(len(sorted_ts)-1):
                    diff = (sorted_ts[i+1] - sorted_ts[i]).total_seconds()
                    intervals.append(diff)
                if intervals:
                    features['avg_interval'] = sum(intervals) / len(intervals)
                    avg = features['avg_interval']
                    variance = sum((i - avg) ** 2 for i in intervals) / len(intervals)
                    features['interval_std'] = math.sqrt(variance) if variance >= 0 else 0
                else:
                    features['avg_interval'] = 0
                    features['interval_std'] = 0
            else:
                features['avg_interval'] = 0
                features['interval_std'] = 0
            
            now = datetime.now()
            recent_24h = [ts for ts in timestamps if (now - ts).total_seconds() < 86400]
            features['connections_last_24h'] = len(recent_24h)
        
        # Duration patterns
        durations = []
        for event in device_history:
            duration = event.get('duration_seconds')
            if duration is not None:
                durations.append(duration)
        if durations:
            features['avg_duration'] = sum(durations) / len(durations)
            features['max_duration'] = max(durations)
            features['min_duration'] = min(durations)
        
        # Status distribution
        status_counts = defaultdict(int)
        for event in device_history:
            status = event.get('status', 'unknown')
            status_counts[status] += 1
        total = len(device_history) if device_history else 1
        features['block_rate'] = status_counts.get('blocked', 0) / total
        features['override_rate'] = status_counts.get('overridden', 0) / total
        
        if timestamps:
            features['device_age_days'] = (datetime.now() - min(timestamps)).days
        else:
            features['device_age_days'] = 0
        
        return features
    
    def build_profile(self, device_id, event_data):
        """Build or update a device profile"""
        if device_id not in self.device_profiles:
            self.device_profiles[device_id] = {
                'history': [],
                'features': None,
                'anomaly_score': 0,
                'profile_status': 'learning'
            }
        
        self.device_profiles[device_id]['history'].append(event_data)
        if len(self.device_profiles[device_id]['history']) > 100:
            self.device_profiles[device_id]['history'] = self.device_profiles[device_id]['history'][-100:]
        
        if len(self.device_profiles[device_id]['history']) >= 5:
            features = self.extract_device_features(self.device_profiles[device_id]['history'])
            if features:
                self.device_profiles[device_id]['features'] = features
                self.device_profiles[device_id]['profile_status'] = 'active'
                self.device_profiles[device_id]['anomaly_score'] = self.calculate_anomaly_score(
                    features, self.device_profiles[device_id]['history']
                )
        
        return self.device_profiles[device_id]
    
    def calculate_anomaly_score(self, features, history):
        """Calculate anomaly score using multiple heuristics"""
        score = 0
        
        if 'dominant_hour' in features and features['dominant_hour'] >= 0:
            current_hour = datetime.now().hour
            if abs(current_hour - features['dominant_hour']) > 6:
                score += 15
        
        if 'connections_last_24h' in features and 'avg_interval' in features:
            if features['avg_interval'] > 0:
                expected_per_day = (24 * 3600) / features['avg_interval']
                if features['connections_last_24h'] > expected_per_day * 3:
                    score += 25
        
        if 'unique_hosts' in features and history:
            current_host = history[-1].get('hostname')
            if current_host:
                hosts = set()
                for e in history:
                    if e.get('hostname'):
                        hosts.add(e.get('hostname'))
                if len(hosts) > 1 and current_host not in [h for h in hosts if h != current_host]:
                    score += 20
        
        if 'block_rate' in features and history:
            current_status = history[-1].get('status')
            if current_status == 'blocked' and features['block_rate'] < 0.2:
                score += 20
            elif current_status == 'overridden' and features['override_rate'] < 0.1:
                score += 15
        
        return min(score, 100)
    
    def train_anomaly_model(self, device_events):
        """Save device profiles to JSON"""
        model_file = os.path.join(self.model_path, "device_profiles.json")
        try:
            serializable = {}
            for device_id, profile in self.device_profiles.items():
                serializable[device_id] = {
                    'features': profile.get('features'),
                    'anomaly_score': profile.get('anomaly_score'),
                    'profile_status': profile.get('profile_status')
                }
            with open(model_file, 'w') as f:
                json.dump(serializable, f, indent=2)
            log.info(f"✅ Saved device profiles for {len(serializable)} devices")
        except Exception as e:
            log.error(f"Failed to save profiles: {e}")
        
    def predict_anomaly(self, device_id):
        """Predict if a device is currently behaving anomalously"""
        if device_id not in self.device_profiles:
            return 0, "unknown"
        profile = self.device_profiles[device_id]
        features = profile.get('features')
        if not features:
            return 0, "learning"
        return profile['anomaly_score'], profile['profile_status']


class LoginAnomalyDetector:
    """Detects anomalous login patterns"""
    
    def __init__(self):
        self.login_history = defaultdict(list)
        self.user_profiles = {}
        self.threshold_multiplier = 2.0
        
    def analyze_login(self, username, ip, hostname, browser, timestamp):
        """Analyze a login attempt for anomalies"""
        key = f"{username}|{browser}"
        self.login_history[key].append({
            'timestamp': timestamp,
            'ip': ip,
            'hostname': hostname,
            'browser': browser
        })
        if len(self.login_history[key]) > 50:
            self.login_history[key] = self.login_history[key][-50:]
        
        anomaly_score = 0
        reasons = []
        
        recent_logins = []
        for l in self.login_history[key]:
            try:
                if (datetime.now() - datetime.fromisoformat(l['timestamp'])).total_seconds() < 300:
                    recent_logins.append(l)
            except:
                pass
        if len(recent_logins) > 3:
            anomaly_score += 30
            reasons.append("High login rate")
        
        if len(self.login_history[key]) > 5:
            known_ips = set()
            for l in self.login_history[key][:-5]:
                if l.get('ip'):
                    known_ips.add(l.get('ip'))
            if ip not in known_ips and known_ips:
                anomaly_score += 25
                reasons.append("New IP address")
        
        if len(self.login_history[key]) > 5:
            known_hosts = set()
            for l in self.login_history[key][:-5]:
                if l.get('hostname'):
                    known_hosts.add(l.get('hostname'))
            if hostname not in known_hosts and known_hosts:
                anomaly_score += 20
                reasons.append("New PC")
        
        browser_history = [l.get('browser') for l in self.login_history[key] if l.get('browser')]
        if len(set(browser_history)) > 2 and len(browser_history) > 5:
            anomaly_score += 15
            reasons.append("Multiple browsers used")
        
        return {
            'anomaly_score': min(anomaly_score, 100),
            'is_suspicious': anomaly_score > 50,
            'reasons': reasons,
            'is_new_user': len(self.login_history[key]) <= 2
        }


class NetworkWidePatternAnalyzer:
    """Analyzes patterns across all agents"""
    
    def __init__(self):
        self.global_events = []
        self.patterns = {}
        
    def analyze_events(self, events):
        """Analyze events for coordinated attacks or unusual patterns"""
        insights = []
        
        browser_launches = defaultdict(list)
        for event in events:
            if event.get('event_type') == 'browser_detected':
                hostname = event.get('hostname')
                browser = event.get('browser')
                timestamp = event.get('timestamp')
                if timestamp:
                    try:
                        timestamp = datetime.fromisoformat(timestamp)
                    except:
                        timestamp = datetime.now()
                else:
                    timestamp = datetime.now()
                key = f"{hostname}|{browser}"
                browser_launches[key].append(timestamp)
        
        for key, timestamps in browser_launches.items():
            if len(timestamps) > 1:
                diffs = []
                for i in range(len(timestamps)-1):
                    diff = (timestamps[i+1] - timestamps[i]).total_seconds()
                    diffs.append(diff)
                if diffs and all(d < 2 for d in diffs[:3]):
                    parts = key.split('|')
                    if len(parts) == 2:
                        hostname, browser = parts
                        insights.append({
                            'type': 'coordinated_launch',
                            'severity': 'high',
                            'description': f"Coordinated {browser} launches detected on {hostname}",
                            'count': len(timestamps)
                        })
        
        failed_logins = defaultdict(int)
        for event in events:
            if event.get('action') == 'login_failed':
                username = event.get('username')
                if username:
                    failed_logins[username] += 1
        for username, count in failed_logins.items():
            if count > 5:
                insights.append({
                    'type': 'multiple_failed_logins',
                    'severity': 'medium',
                    'description': f"User {username} had {count} failed login attempts",
                    'count': count
                })
        
        usb_events = [e for e in events if e.get('event_type') == 'usb_event']
        if len(usb_events) > 50:
            insights.append({
                'type': 'usb_activity_spike',
                'severity': 'medium',
                'description': f"High USB activity detected: {len(usb_events)} events",
                'count': len(usb_events)
            })
        
        return insights


# Initialize global AI modules
device_profiler = DeviceBehaviorProfiler()
login_detector = LoginAnomalyDetector()
network_analyzer = NetworkWidePatternAnalyzer()