"""
SentryUSB - Report Generator
Handles PDF and Excel report generation
"""
import io
import logging
import datetime
from datetime import timedelta

# Try importing reportlab
try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.lib.enums import TA_CENTER
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False
    print("WARNING: reportlab not installed. PDF reports disabled.")

# Try importing openpyxl
try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill
    from openpyxl.utils import get_column_letter
    OPENPYXL_AVAILABLE = True
except ImportError:
    OPENPYXL_AVAILABLE = False
    print("WARNING: openpyxl not installed. Excel reports disabled.")

import config
import db

log = logging.getLogger("sentryusb.reports")


# ============================================================
# HELPERS
# ============================================================

def get_date_range(period):
    """Get start and end dates for a given period"""
    end = datetime.datetime.now()
    if period == "today":
        start = end.replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "yesterday":
        start = (end - timedelta(days=1)).replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
    elif period == "week":
        start = (end - timedelta(days=7)).replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "month":
        start = (end - timedelta(days=30)).replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "quarter":
        start = (end - timedelta(days=90)).replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "year":
        start = (end - timedelta(days=365)).replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        start = datetime.datetime(2020, 1, 1)
    return start, end


def get_report_data(period="week"):
    """Collect data for reports"""
    start_date, end_date = get_date_range(period)
    
    # Get all events
    events = db.get_all_events(limit=10000)
    
    # Filter by date range
    filtered = []
    for e in events:
        try:
            ts = datetime.datetime.fromisoformat(e.get("timestamp", ""))
            if start_date <= ts <= end_date:
                filtered.append(e)
        except (ValueError, TypeError):
            continue
    
    # Calculate stats
    total = len(filtered)
    blocked = sum(1 for e in filtered if e.get("status") == "blocked")
    allowed = sum(1 for e in filtered if e.get("status") == "allowed")
    connected = sum(1 for e in filtered if e.get("status") == "connected")
    overridden = sum(1 for e in filtered if e.get("status") == "overridden")
    removed = sum(1 for e in filtered if e.get("status") == "removed")
    
    # Unique devices and PCs
    unique_devices = len({e.get("device_instance_id") for e in filtered if e.get("device_instance_id")})
    active_pcs = len({e.get("hostname") for e in filtered if e.get("hostname")})
    
    # Daily breakdown
    daily = {}
    for e in filtered:
        try:
            day = datetime.datetime.fromisoformat(e.get("timestamp", "")).date().isoformat()
            daily[day] = daily.get(day, 0) + 1
        except (ValueError, TypeError):
            continue
    
    # Top devices
    device_counts = {}
    for e in filtered:
        name = e.get("device_name", "Unknown")
        device_counts[name] = device_counts.get(name, 0) + 1
    top_devices = sorted(device_counts.items(), key=lambda x: x[1], reverse=True)[:10]
    
    # Top PCs
    pc_counts = {}
    for e in filtered:
        host = e.get("hostname", "Unknown")
        pc_counts[host] = pc_counts.get(host, 0) + 1
    top_pcs = sorted(pc_counts.items(), key=lambda x: x[1], reverse=True)[:10]
    
    return {
        "period": period,
        "start_date": start_date,
        "end_date": end_date,
        "total_events": total,
        "blocked": blocked,
        "allowed": allowed,
        "connected": connected,
        "overridden": overridden,
        "removed": removed,
        "unique_devices": unique_devices,
        "active_pcs": active_pcs,
        "daily_data": sorted(daily.items()),
        "top_devices": top_devices,
        "top_pcs": top_pcs,
        "events": filtered[:100],
    }


# ============================================================
# PDF REPORT
# ============================================================

def generate_pdf_report(period="week"):
    """Generate PDF report"""
    if not REPORTLAB_AVAILABLE:
        raise Exception("reportlab is not installed. Run: pip install reportlab")
    
    try:
        data = get_report_data(period)
        buffer = io.BytesIO()
        
        # Create PDF document
        doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=72)
        styles = getSampleStyleSheet()
        
        # Custom styles
        title_style = ParagraphStyle('Title', parent=styles['Heading1'], fontSize=24, textColor=colors.HexColor('#6366f1'), alignment=TA_CENTER, spaceAfter=30)
        heading_style = ParagraphStyle('Heading', parent=styles['Heading2'], fontSize=16, textColor=colors.HexColor('#1a2733'), spaceAfter=12, spaceBefore=20)
        normal_style = ParagraphStyle('Normal', parent=styles['Normal'], fontSize=10, spaceAfter=6)
        
        story = []
        
        # Title
        story.append(Paragraph("SentryUSB Security Report", title_style))
        story.append(Paragraph(f"Period: {data['start_date'].strftime('%Y-%m-%d')} to {data['end_date'].strftime('%Y-%m-%d')}", normal_style))
        story.append(Paragraph(f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", normal_style))
        story.append(Spacer(1, 0.3 * inch))
        
        # Statistics Table
        story.append(Paragraph("Executive Summary", heading_style))
        stats_data = [
            ["Metric", "Value"],
            ["Total Events", str(data["total_events"])],
            ["Blocked Devices", str(data["blocked"])],
            ["Allowed Devices", str(data["allowed"])],
            ["Overridden", str(data["overridden"])],
            ["Connected", str(data["connected"])],
            ["Removed", str(data["removed"])],
            ["Unique Devices", str(data["unique_devices"])],
            ["Active PCs", str(data["active_pcs"])],
        ]
        stats_table = Table(stats_data, colWidths=[2.5 * inch, 2.5 * inch])
        stats_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#6366f1')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f8f9fa')),
            ('BACKGROUND', (0, 2), (-1, -1), colors.HexColor('#ffffff')),
            ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#e5e7eb')),
            ('FONTSIZE', (0, 1), (-1, -1), 10),
        ]))
        story.append(stats_table)
        story.append(Spacer(1, 0.3 * inch))
        
        # Daily Activity
        story.append(Paragraph("Daily Activity", heading_style))
        if data["daily_data"]:
            daily_data = [["Date", "Events"]] + [[d[0], str(d[1])] for d in data["daily_data"]]
            daily_table = Table(daily_data, colWidths=[2.5 * inch, 2.5 * inch])
            daily_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#6366f1')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#e5e7eb')),
            ]))
            story.append(daily_table)
        else:
            story.append(Paragraph("No daily data available", normal_style))
        
        story.append(Spacer(1, 0.3 * inch))
        
        # Top Devices
        if data["top_devices"]:
            story.append(Paragraph("Most Active Devices", heading_style))
            device_data = [["Device", "Connections"]] + [[d[0], str(d[1])] for d in data["top_devices"]]
            device_table = Table(device_data, colWidths=[3 * inch, 2 * inch])
            device_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#6366f1')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 10),
                ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#e5e7eb')),
            ]))
            story.append(device_table)
        
        # Footer
        story.append(Spacer(1, 0.5 * inch))
        story.append(Paragraph(
            "This report was generated automatically by SentryUSB Security System.",
            ParagraphStyle('Footer', parent=styles['Normal'], fontSize=8, textColor=colors.HexColor('#999999'), alignment=TA_CENTER)
        ))
        
        # Build PDF
        doc.build(story)
        buffer.seek(0)
        return buffer.getvalue()
        
    except Exception as e:
        log.error(f"PDF generation error: {e}")
        raise


# ============================================================
# EXCEL REPORT
# ============================================================

def generate_excel_report(period="week"):
    """Generate Excel report"""
    if not OPENPYXL_AVAILABLE:
        raise Exception("openpyxl is not installed. Run: pip install openpyxl")
    
    try:
        data = get_report_data(period)
        wb = openpyxl.Workbook()
        
        # ===== Sheet 1: Summary =====
        ws = wb.active
        ws.title = "Summary"
        
        ws['A1'] = "SentryUSB Security Report"
        ws['A1'].font = Font(size=18, bold=True, color="6366f1")
        ws.merge_cells('A1:D1')
        ws['A2'] = f"Period: {data['start_date'].strftime('%Y-%m-%d')} to {data['end_date'].strftime('%Y-%m-%d')}"
        ws['A3'] = f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        row = 5
        stats = [
            ("Total Events", data["total_events"]),
            ("Blocked Devices", data["blocked"]),
            ("Allowed Devices", data["allowed"]),
            ("Overridden", data["overridden"]),
            ("Connected", data["connected"]),
            ("Removed", data["removed"]),
            ("Unique Devices", data["unique_devices"]),
            ("Active PCs", data["active_pcs"]),
        ]
        for label, value in stats:
            ws[f'A{row}'] = label
            ws[f'B{row}'] = value
            ws[f'A{row}'].font = Font(bold=True)
            row += 1
        
        ws.column_dimensions['A'].width = 20
        ws.column_dimensions['B'].width = 15
        
        # ===== Sheet 2: Daily =====
        ws = wb.create_sheet("Daily Activity")
        ws['A1'] = "Date"
        ws['B1'] = "Events"
        ws['A1'].font = Font(bold=True, color="FFFFFF")
        ws['B1'].font = Font(bold=True, color="FFFFFF")
        ws['A1'].fill = PatternFill(start_color="6366f1", end_color="6366f1", fill_type="solid")
        ws['B1'].fill = PatternFill(start_color="6366f1", end_color="6366f1", fill_type="solid")
        
        for i, (date, count) in enumerate(data["daily_data"], start=2):
            ws[f'A{i}'] = date
            ws[f'B{i}'] = count
        
        ws.column_dimensions['A'].width = 15
        ws.column_dimensions['B'].width = 12
        
        # ===== Sheet 3: Top Devices =====
        ws = wb.create_sheet("Top Devices")
        ws['A1'] = "Device Name"
        ws['B1'] = "Connections"
        ws['A1'].font = Font(bold=True, color="FFFFFF")
        ws['B1'].font = Font(bold=True, color="FFFFFF")
        ws['A1'].fill = PatternFill(start_color="6366f1", end_color="6366f1", fill_type="solid")
        ws['B1'].fill = PatternFill(start_color="6366f1", end_color="6366f1", fill_type="solid")
        
        for i, (name, count) in enumerate(data["top_devices"], start=2):
            ws[f'A{i}'] = name
            ws[f'B{i}'] = count
        
        ws.column_dimensions['A'].width = 30
        ws.column_dimensions['B'].width = 15
        
        # ===== Sheet 4: Top PCs =====
        ws = wb.create_sheet("Active PCs")
        ws['A1'] = "PC Name"
        ws['B1'] = "Connections"
        ws['A1'].font = Font(bold=True, color="FFFFFF")
        ws['B1'].font = Font(bold=True, color="FFFFFF")
        ws['A1'].fill = PatternFill(start_color="6366f1", end_color="6366f1", fill_type="solid")
        ws['B1'].fill = PatternFill(start_color="6366f1", end_color="6366f1", fill_type="solid")
        
        for i, (name, count) in enumerate(data["top_pcs"], start=2):
            ws[f'A{i}'] = name
            ws[f'B{i}'] = count
        
        ws.column_dimensions['A'].width = 30
        ws.column_dimensions['B'].width = 15
        
        # ===== Sheet 5: Events =====
        ws = wb.create_sheet("Recent Events")
        headers = ["Timestamp", "Device", "Host", "User", "Type", "Status"]
        for col, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill(start_color="6366f1", end_color="6366f1", fill_type="solid")
        
        for i, event in enumerate(data["events"], start=2):
            ws.cell(row=i, column=1, value=event.get("timestamp", ""))
            ws.cell(row=i, column=2, value=event.get("device_name", ""))
            ws.cell(row=i, column=3, value=event.get("hostname", ""))
            ws.cell(row=i, column=4, value=event.get("username", ""))
            ws.cell(row=i, column=5, value=event.get("device_type", ""))
            ws.cell(row=i, column=6, value=event.get("status", ""))
        
        for col in range(1, 7):
            ws.column_dimensions[get_column_letter(col)].width = 18
        
        # Save
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        return output.getvalue()
        
    except Exception as e:
        log.error(f"Excel generation error: {e}")
        raise


# ============================================================
# SCHEDULER
# ============================================================

try:
    from apscheduler.schedulers.background import BackgroundScheduler
    from apscheduler.triggers.cron import CronTrigger
    APSCHEDULER_AVAILABLE = True
except ImportError:
    APSCHEDULER_AVAILABLE = False
    print("WARNING: APScheduler not installed. Scheduled reports disabled.")

_scheduler = None


def start_scheduler():
    """Start the report scheduler"""
    global _scheduler
    if not APSCHEDULER_AVAILABLE:
        log.warning("APScheduler not available. Scheduled reports disabled.")
        return
    
    if _scheduler is None:
        try:
            _scheduler = BackgroundScheduler()
            _scheduler.add_job(
                lambda: send_scheduled_report("daily"),
                CronTrigger(hour=8, minute=0),
                id="daily_report",
                replace_existing=True
            )
            _scheduler.add_job(
                lambda: send_scheduled_report("weekly"),
                CronTrigger(day_of_week='mon', hour=9, minute=0),
                id="weekly_report",
                replace_existing=True
            )
            _scheduler.add_job(
                lambda: send_scheduled_report("monthly"),
                CronTrigger(day=1, hour=10, minute=0),
                id="monthly_report",
                replace_existing=True
            )
            _scheduler.start()
            log.info("Report scheduler started")
        except Exception as e:
            log.error(f"Failed to start scheduler: {e}")


def stop_scheduler():
    """Stop the report scheduler"""
    global _scheduler
    if _scheduler:
        _scheduler.shutdown()
        _scheduler = None
        log.info("Report scheduler stopped")


def send_scheduled_report(period):
    """Send a scheduled report via email"""
    if not config.EMAIL_ENABLED or not config.EMAIL_TO:
        log.warning("Email not configured, skipping scheduled report")
        return
    
    try:
        pdf_data = generate_pdf_report(period)
        
        import smtplib
        from email.mime.multipart import MIMEMultipart
        from email.mime.text import MIMEText
        from email.mime.application import MIMEApplication
        
        msg = MIMEMultipart()
        msg['Subject'] = f"SentryUSB {period.capitalize()} Security Report"
        msg['From'] = config.EMAIL_FROM
        msg['To'] = config.EMAIL_TO
        
        body = f"""
        <html>
        <body style="font-family: Arial, sans-serif; padding: 20px;">
            <h2 style="color: #6366f1;">📊 SentryUSB {period.capitalize()} Report</h2>
            <p>Your {period} security report is attached.</p>
            <p><b>Generated:</b> {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <hr>
            <p style="color: #666; font-size: 12px;">This report was automatically generated by SentryUSB.</p>
        </body>
        </html>
        """
        msg.attach(MIMEText(body, 'html'))
        
        attachment = MIMEApplication(pdf_data, _subtype="pdf")
        attachment.add_header('Content-Disposition', 'attachment', filename=f'sentryusb_report_{period}_{datetime.datetime.now().strftime("%Y%m%d")}.pdf')
        msg.attach(attachment)
        
        with smtplib.SMTP(config.EMAIL_HOST, config.EMAIL_PORT) as server:
            if config.EMAIL_USE_TLS:
                server.starttls()
            server.login(config.EMAIL_USERNAME, config.EMAIL_PASSWORD)
            server.send_message(msg)
        
        log.info(f"{period.capitalize()} report sent successfully")
        db.add_audit_log("system", "scheduled_report", f"Sent {period} report")
        
    except Exception as e:
        log.error(f"Failed to send {period} report: {e}")