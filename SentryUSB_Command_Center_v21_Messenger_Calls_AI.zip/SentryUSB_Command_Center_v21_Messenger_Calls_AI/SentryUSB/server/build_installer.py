"""
Build SentryUSB One-Click Installer EXE
"""
import os
import sys
import subprocess

def build_installer():
    print("Building SentryUSB One-Click Installer...")
    print("")
    
    # Check if PyInstaller is installed
    try:
        import PyInstaller.__main__
        print("PyInstaller found")
    except ImportError:
        print("Installing PyInstaller...")
        subprocess.run([sys.executable, "-m", "pip", "install", "pyinstaller"])
        print("PyInstaller installed")
    
    # Build with PyInstaller - REMOVED --windowed flag
    print("Building EXE...")
    PyInstaller.__main__.run([
        "sentryusb_installer.py",
        "--onefile",
        "--name=SentryUSBInstaller",
        "--uac-admin",
        "--distpath=dist",
        "--workpath=build",
        "--specpath=build/spec",
    ])
    
    print("")
    print("="*60)
    print("BUILD COMPLETE!")
    print("="*60)
    print("EXE Location: dist/SentryUSBInstaller.exe")
    print("")
    print("SHARE THIS FILE WITH YOUR FRIEND:")
    print("   1. Upload to Google Drive / WeTransfer")
    print("   2. Send the download link")
    print("="*60)

if __name__ == "__main__":
    build_installer()