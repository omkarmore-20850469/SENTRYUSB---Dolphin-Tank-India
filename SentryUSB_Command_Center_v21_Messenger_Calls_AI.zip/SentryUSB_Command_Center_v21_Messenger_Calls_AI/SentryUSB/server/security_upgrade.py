"""Security v10 primitives: policy evaluation, evidence integrity and risk scoring.

This module is intentionally deterministic and explainable. It does not collect
raw keystrokes, attempt biometric identification, or claim a model accuracy.
"""
import hashlib
import hmac
import json
import math
import os
import re
from datetime import datetime, timezone


VALID_ACTIONS = {"allow", "block", "approval_required", "monitor"}
VALID_MATCH_TYPES = {"device_instance_id", "vid_pid", "device_type", "device_class", "fingerprint"}


def _canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)


def evidence_key():
    """Return a deployment key. Production must set a unique secret in the environment."""
    return os.environ.get("SENTRYUSB_EVIDENCE_HMAC_KEY", os.environ.get("SENTRYUSB_SECRET_KEY", "change-me-secret-key"))


def evidence_key_id():
    return hashlib.sha256(evidence_key().encode("utf-8")).hexdigest()[:16]


def sign_evidence(previous_hash, event_kind, payload):
    material = _canonical({"previous_hash": previous_hash or "", "event_kind": event_kind, "payload": payload})
    return hmac.new(evidence_key().encode("utf-8"), material.encode("utf-8"), hashlib.sha256).hexdigest()


def verify_chain(rows):
    previous = ""
    for row in rows:
        payload = json.loads(row["payload_json"])
        expected = sign_evidence(previous, row["event_kind"], payload)
        if row["previous_hash"] != previous or not hmac.compare_digest(expected, row["entry_hash"]):
            return {"valid": False, "failed_id": row["id"], "checked": row["id"]}
        previous = row["entry_hash"]
    return {"valid": True, "checked": len(rows), "tail_hash": previous}


def normalize_policy(policy):
    match_type = (policy.get("match_type") or "").strip()
    action = (policy.get("action") or "").strip()
    value = (policy.get("match_value") or "").strip()
    if match_type not in VALID_MATCH_TYPES:
        raise ValueError("Unsupported match_type")
    if action not in VALID_ACTIONS:
        raise ValueError("Unsupported action")
    if not value or len(value) > 512:
        raise ValueError("match_value must be 1-512 characters")
    policy_id = (policy.get("policy_id") or "").strip()
    if not policy_id:
        raise ValueError("policy_id is required")
    if not re.fullmatch(r"[A-Za-z0-9_.:-]{3,128}", policy_id):
        raise ValueError("policy_id contains unsupported characters")
    return {
        "policy_id": policy_id,
        "match_type": match_type,
        "match_value": value,
        "action": action,
        "enabled": bool(policy.get("enabled", True)),
        "priority": max(0, min(int(policy.get("priority", 100)), 100000)),
        "reason": (policy.get("reason") or "")[:512],
        "created_by": (policy.get("created_by") or "")[:128],
    }


def evaluate_device_policy(device, policies, default_action="monitor"):
    """Return an explainable policy decision; first enabled priority match wins."""
    candidates = {
        "device_instance_id": str(device.get("device_instance_id") or ""),
        "vid_pid": "%s:%s" % (device.get("vendor_id") or "", device.get("product_id") or ""),
        "device_type": str(device.get("device_type") or ""),
        "device_class": str(device.get("device_class") or ""),
        "fingerprint": str(device.get("device_fingerprint") or ""),
    }
    for policy in sorted((p for p in policies if p.get("enabled")), key=lambda p: (p.get("priority", 100), p.get("id", 0))):
        if candidates.get(policy["match_type"], "").casefold() == str(policy["match_value"]).casefold():
            return {"action": policy["action"], "policy_id": policy["policy_id"], "reason": policy.get("reason") or "Policy match"}
    return {"action": default_action, "policy_id": None, "reason": "No matching policy"}


def behavioral_risk(sample, baseline=None):
    """Score aggregated timing/mouse metrics; input text is neither accepted nor stored.

    A score is a review signal, not an authentication decision. Samples contain
    count and aggregate measurements only: dwell_ms, flight_ms, mouse_speed,
    and optional event_rate_hz.
    """
    dwell = float(sample.get("dwell_ms", 0) or 0)
    flight = float(sample.get("flight_ms", 0) or 0)
    speed = float(sample.get("mouse_speed", 0) or 0)
    rate = float(sample.get("event_rate_hz", 0) or 0)
    score, signals = 0.0, []
    if rate > 20 or (flight > 0 and flight < 12):
        score += 45
        signals.append("superhuman_input_rate")
    if dwell and dwell < 8:
        score += 20
        signals.append("very_short_dwell")
    if baseline and baseline.get("sample_count", 0) >= 20:
        for key, observed, weight in (("dwell_mean", dwell, 15), ("flight_mean", flight, 20), ("mouse_speed_mean", speed, 10)):
            expected = baseline.get(key)
            if expected and observed:
                divergence = abs(observed - float(expected)) / max(float(expected), 1.0)
                if divergence > 1.5:
                    score += weight
                    signals.append("baseline_divergence:" + key)
    return {"risk_score": min(100.0, round(score, 2)), "signals": signals,
            "sample": {"dwell_ms": dwell, "flight_ms": flight, "mouse_speed": speed, "event_rate_hz": rate}}


def update_mean(previous_mean, sample_count, value):
    if value is None or value <= 0:
        return previous_mean
    old = float(previous_mean or 0)
    return ((old * sample_count) + float(value)) / (sample_count + 1)


def utc_now():
    return datetime.now(timezone.utc).isoformat()
