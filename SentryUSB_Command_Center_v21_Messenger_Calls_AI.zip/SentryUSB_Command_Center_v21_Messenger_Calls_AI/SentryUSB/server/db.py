"""
SentryUSB Server - Database layer
SQLite-backed event log for USB detection/block/override/removal events.
"""
import datetime
import sqlite3
import os
import logging
import json

# ===== FIX: Add logging =====
log = logging.getLogger("sentryusb.db")

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sentryusb.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """Initialize database with all tables"""
    conn = get_connection()
    cur = conn.cursor()

    # ========== AI ANALYTICS TABLES ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS ai_analysis (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id TEXT,
            analysis_type TEXT,
            anomaly_score REAL,
            profile_status TEXT,
            features TEXT,
            analyzed_at TEXT NOT NULL
        )
    """)
    
    cur.execute("""
        CREATE TABLE IF NOT EXISTS ai_predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            prediction_type TEXT,
            value REAL,
            confidence REAL,
            predicted_at TEXT NOT NULL
        )
    """)
    
    cur.execute("""
        CREATE TABLE IF NOT EXISTS ai_models (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            model_name TEXT UNIQUE NOT NULL,
            model_version TEXT,
            training_data_count INTEGER,
            accuracy REAL,
            trained_at TEXT NOT NULL,
            model_path TEXT
        )
    """)
    
    # ========== EVENTS TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            hostname TEXT,
            ip_address TEXT,
            username TEXT,
            vendor_id TEXT,
            product_id TEXT,
            serial_number TEXT,
            device_instance_id TEXT,
            device_name TEXT,
            device_type TEXT DEFAULT 'storage',
            status TEXT DEFAULT 'blocked',
            admin_user TEXT,
            timestamp TEXT NOT NULL,
            removed_at TEXT,
            duration_seconds INTEGER,
            override_timestamp TEXT,
            exam_mode INTEGER DEFAULT 0,
            lockdown_mode INTEGER DEFAULT 0,
            critical_action TEXT,
            violation_count INTEGER,
            evidence_path TEXT
        )
    """)

    # Migration: add new columns for pre-existing databases created before
    # auto-shutdown/evidence-capture support (CREATE TABLE IF NOT EXISTS
    # above only affects brand-new DBs, so patch existing ones here too).
    cur.execute("PRAGMA table_info(events)")
    existing_event_cols = {row[1] for row in cur.fetchall()}
    for col_name, col_def in (
        ("critical_action", "TEXT"),
        ("violation_count", "INTEGER"),
        ("evidence_path", "TEXT"),
    ):
        if col_name not in existing_event_cols:
            cur.execute(f"ALTER TABLE events ADD COLUMN {col_name} {col_def}")

    # ========== USERS TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            created_at TEXT NOT NULL
        )
    """)
    
    # ========== ALLOWED DEVICES TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS allowed_devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_instance_id TEXT UNIQUE NOT NULL,
            device_name TEXT,
            added_by TEXT,
            added_at TEXT NOT NULL
        )
    """)
    
    # ========== BLOCKED DEVICES TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS blocked_devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_instance_id TEXT UNIQUE NOT NULL,
            device_name TEXT,
            added_by TEXT,
            added_at TEXT NOT NULL
        )
    """)
    
    # ========== AGENTS TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS agents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hostname TEXT UNIQUE NOT NULL,
            ip_address TEXT,
            username TEXT,
            status TEXT DEFAULT 'offline',
            last_seen TEXT,
            registered_at TEXT NOT NULL,
            lockdown_enabled INTEGER DEFAULT 0,
            lockdown_exempt INTEGER DEFAULT 0,
            exam_active INTEGER DEFAULT 0,
            version TEXT DEFAULT '1.0',
            uptime_seconds INTEGER DEFAULT 0
        )
    """)
    
    # ========== AUDIT LOGS TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            action TEXT,
            details TEXT,
            timestamp TEXT NOT NULL
        )
    """)
    
    # ========== ALERT SETTINGS TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS alert_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            setting_key TEXT UNIQUE NOT NULL,
            setting_value TEXT,
            updated_at TEXT NOT NULL
        )
    """)
    
    # ========== SERVER SETTINGS TABLE ==========
    # Generic key/value override store. Used for the Lab Registration UI so
    # per-lab hub-connection values (lab name, hub URL, registration secret,
    # contact, location, this server's public URL) can be set from the
    # dashboard instead of hand-editing config.py. A value here always wins
    # over the matching default in config.py - see hub_client.get_effective_config().
    cur.execute("""
        CREATE TABLE IF NOT EXISTS server_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            key TEXT UNIQUE NOT NULL,
            value TEXT,
            updated_at TEXT NOT NULL
        )
    """)

    # ========== HUB MESSAGES TABLE ==========
    # Messages pushed down from the Hub admin (read-only monitoring) to this
    # lab server. The hub never acts on this server directly - it can only
    # look (via /api/hub/live-snapshot) and speak (via /api/hub/message).
    # Whoever is at this lab server decides whether/how to act.
    cur.execute("""
        CREATE TABLE IF NOT EXISTS hub_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message TEXT NOT NULL,
            severity TEXT DEFAULT 'info',
            sent_by TEXT,
            received_at TEXT NOT NULL
        )
    """)

    # Durable local cache for the Hub <-> Lab messenger.  The Hub remains
    # the relay of record; this cache lets the Lab UI survive a temporary
    # network interruption and makes conversation history available locally.
    cur.execute("""
        CREATE TABLE IF NOT EXISTS messenger_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message_id TEXT UNIQUE NOT NULL,
            direction TEXT NOT NULL CHECK(direction IN ('hub_to_lab', 'lab_to_hub')),
            sender TEXT NOT NULL,
            body TEXT NOT NULL,
            severity TEXT DEFAULT 'info',
            created_at TEXT NOT NULL,
            delivered_at TEXT,
            read_at TEXT
        )
    """)
    cur.execute("CREATE INDEX IF NOT EXISTS idx_messenger_created ON messenger_messages(created_at)")
    # Messenger v2: rich messages (image / voice / call log)
    _msg_cols = {r[1] for r in cur.execute("PRAGMA table_info(messenger_messages)").fetchall()}
    for _col, _ddl in (("kind", "TEXT DEFAULT 'text'"), ("media_id", "TEXT"), ("media_mime", "TEXT"),
                       ("media_size", "INTEGER"), ("media_duration", "REAL")):
        if _col not in _msg_cols:
            cur.execute(f"ALTER TABLE messenger_messages ADD COLUMN {_col} {_ddl}")

    # ========== ALERT HISTORY TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS alert_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER,
            alert_type TEXT,
            recipient TEXT,
            status TEXT,
            sent_at TEXT NOT NULL
        )
    """)
    
    # ========== DEVICE TAGS TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS device_tags (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_instance_id TEXT NOT NULL,
            tag TEXT NOT NULL,
            added_by TEXT,
            added_at TEXT NOT NULL,
            UNIQUE(device_instance_id, tag)
        )
    """)
    
    # ========== DEVICE NOTES TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS device_notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_instance_id TEXT NOT NULL,
            note TEXT NOT NULL,
            added_by TEXT,
            added_at TEXT NOT NULL
        )
    """)
    
    # ========== ALERT RULES TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS alert_rules (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            event_type TEXT NOT NULL,
            enabled INTEGER DEFAULT 1,
            channels TEXT,
            cooldown_seconds INTEGER DEFAULT 300,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    """)
    
    # ========== 2FA TABLES ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS user_2fa (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            secret TEXT NOT NULL,
            enabled INTEGER DEFAULT 0,
            backup_codes TEXT,
            created_at TEXT NOT NULL
        )
    """)
    
    # ========== SESSIONS TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS user_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL,
            session_id TEXT UNIQUE NOT NULL,
            ip_address TEXT,
            user_agent TEXT,
            created_at TEXT NOT NULL,
            last_active TEXT NOT NULL,
            expires_at TEXT NOT NULL,
            is_active INTEGER DEFAULT 1
        )
    """)
    
    # ========== IP WHITELIST TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS ip_whitelist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ip_address TEXT UNIQUE NOT NULL,
            description TEXT,
            added_by TEXT,
            added_at TEXT NOT NULL,
            is_active INTEGER DEFAULT 1
        )
    """)
    
    # ========== LDAP CONFIG TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS ldap_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            setting_key TEXT UNIQUE NOT NULL,
            setting_value TEXT,
            updated_at TEXT NOT NULL
        )
    """)
    
    # ========== EXAM CONFIG TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS exam_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            config_key TEXT UNIQUE NOT NULL,
            config_value TEXT,
            updated_at TEXT NOT NULL
        )
    """)
    
    # ========== EXAM HISTORY TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS exam_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_url TEXT,
            duration_seconds INTEGER,
            started_by TEXT,
            started_at TEXT NOT NULL,
            ended_at TEXT,
            status TEXT
        )
    """)
    
    # ========== EXAM DEVICE LOGS TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS exam_device_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_id INTEGER,
            device_name TEXT,
            hostname TEXT,
            blocked_at TEXT NOT NULL
        )
    """)
    
    # ========== LOCKDOWN ALLOWED USB TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS lockdown_allowed_usb (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id TEXT UNIQUE NOT NULL,
            device_name TEXT,
            serial_number TEXT,
            added_by TEXT,
            added_at TEXT NOT NULL,
            reason TEXT,
            approved_by TEXT
        )
    """)
    
    # ========== LOCKDOWN ALLOWED WEBSITES TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS lockdown_allowed_websites (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url_pattern TEXT UNIQUE NOT NULL,
            description TEXT,
            added_by TEXT,
            added_at TEXT NOT NULL,
            is_active INTEGER DEFAULT 1
        )
    """)
    
    # ========== LOCKDOWN BLOCK LOGS TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS lockdown_block_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hostname TEXT,
            device_name TEXT,
            browser_name TEXT,
            url TEXT,
            block_reason TEXT,
            blocked_at TEXT NOT NULL
        )
    """)
    
    # ========== DEVICE CACHE TABLE ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS device_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_instance_id TEXT UNIQUE NOT NULL,
            first_seen TEXT NOT NULL,
            last_seen TEXT NOT NULL,
            hostname TEXT,
            event_count INTEGER DEFAULT 1,
            last_status TEXT DEFAULT 'blocked',
            is_active INTEGER DEFAULT 1
        )
    """)

    # Security v10: policy decisions, privacy-safe behavioural summaries and
    # tamper-evident evidence metadata. These tables deliberately store no
    # raw keystrokes, screen contents, or file contents.
    cur.execute("""
        CREATE TABLE IF NOT EXISTS device_policies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            policy_id TEXT UNIQUE NOT NULL,
            match_type TEXT NOT NULL,
            match_value TEXT NOT NULL,
            action TEXT NOT NULL,
            enabled INTEGER DEFAULT 1,
            priority INTEGER DEFAULT 100,
            reason TEXT,
            created_by TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS evidence_chain (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER,
            event_kind TEXT NOT NULL,
            payload_json TEXT NOT NULL,
            previous_hash TEXT,
            entry_hash TEXT NOT NULL UNIQUE,
            key_id TEXT,
            created_at TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS behavioral_profiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject_token TEXT UNIQUE NOT NULL,
            sample_count INTEGER DEFAULT 0,
            dwell_mean REAL,
            flight_mean REAL,
            mouse_speed_mean REAL,
            updated_at TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS behavioral_observations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject_token TEXT NOT NULL,
            hostname TEXT,
            risk_score REAL NOT NULL,
            signals_json TEXT,
            created_at TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS incident_bundles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            incident_id TEXT UNIQUE NOT NULL,
            event_id INTEGER,
            severity TEXT NOT NULL,
            bundle_path TEXT,
            bundle_sha256 TEXT,
            status TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    
    # ========== INSERT DEFAULT ADMIN USER ==========
    from werkzeug.security import generate_password_hash
    import config as _config
    
    now = datetime.datetime.now().isoformat()
    
    cur.execute("SELECT * FROM users WHERE username = ?", (_config.ADMIN_USERNAME,))
    existing_admin = cur.fetchone()
    if not existing_admin:
        cur.execute("""
            INSERT INTO users (username, password, role, created_at)
            VALUES (?, ?, ?, ?)
        """, (_config.ADMIN_USERNAME, generate_password_hash(_config.ADMIN_PASSWORD),
              'admin', now))
    elif existing_admin["password"] and not existing_admin["password"].startswith(("pbkdf2:", "scrypt:")):
        cur.execute("UPDATE users SET password = ? WHERE username = ?",
                    (generate_password_hash(existing_admin["password"]), _config.ADMIN_USERNAME))
    
    # ========== INSERT DEFAULT ALERT SETTINGS ==========
    default_settings = [
        ('email_enabled', 'true'),
        ('email_host', 'smtp.gmail.com'),
        ('email_port', '587'),
        ('email_username', ''),
        ('email_password', ''),
        ('email_to', ''),
        ('telegram_enabled', 'false'),
        ('telegram_token', ''),
        ('telegram_chat_id', ''),
        ('slack_enabled', 'false'),
        ('slack_webhook', ''),
        ('discord_enabled', 'false'),
        ('discord_webhook', ''),
        ('alert_on_blocked', 'true'),
        ('alert_on_allowed', 'true'),
        ('alert_on_connected', 'false'),
        ('alert_on_removed', 'false'),
        ('alert_on_overridden', 'true'),
        ('alert_cooldown', '300'),
    ]
    
    now = datetime.datetime.now().isoformat()
    for key, value in default_settings:
        cur.execute("""
            INSERT OR IGNORE INTO alert_settings (setting_key, setting_value, updated_at)
            VALUES (?, ?, ?)
        """, (key, value, now))
    
    # ========== INSERT DEFAULT EXAM CONFIG ==========
    default_exam_config = [
        ('exam_url', ''),
        ('duration', '3600'),
        ('scheduled_start', ''),  # ISO datetime, e.g. "2026-08-10T09:00:00"; empty = manual start only
        ('block_usb', 'true'),
        ('block_internet', 'true'),
        ('block_browsers', 'true'),
        ('block_copy_paste', 'true'),
        ('block_print_screen', 'true'),
    ]
    
    now = datetime.datetime.now().isoformat()
    for key, value in default_exam_config:
        cur.execute("""
            INSERT OR IGNORE INTO exam_config (config_key, config_value, updated_at)
            VALUES (?, ?, ?)
        """, (key, value, now))
    
    conn.commit()
    conn.close()
    print("✅ Database initialized with all tables")


def insert_event(data: dict) -> int:
    """Insert a new USB event - FIXED VERSION"""
    conn = None
    try:
        conn = get_connection()
        cur = conn.cursor()
        now = datetime.datetime.now().isoformat()
        
        cur.execute("""
            INSERT INTO events (
                session_id, hostname, ip_address, username, vendor_id, product_id,
                serial_number, device_instance_id, device_name, device_type,
                status, timestamp, exam_mode, lockdown_mode,
                critical_action, violation_count, evidence_path
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data.get("session_id"),
            data.get("hostname"),
            data.get("ip_address"),
            data.get("username"),
            data.get("vendor_id"),
            data.get("product_id"),
            data.get("serial_number"),
            data.get("device_instance_id"),
            data.get("device_name"),
            data.get("device_type", "storage"),
            data.get("status", "blocked"),
            now,
            1 if data.get("exam_mode", False) else 0,
            1 if data.get("lockdown_mode", False) else 0,
            data.get("critical_action"),
            data.get("violation_count"),
            data.get("evidence_path"),
        ))
        event_id = cur.lastrowid
        
        # Add to blocked devices if blocked
        if data.get("status") == "blocked":
            _add_to_blocked_devices(cur, data)
        
        conn.commit()
        log.info(f"✅ Event inserted with ID: {event_id}")
        return event_id
        
    except Exception as e:
        log.error(f"Error inserting event: {e}")
        import traceback
        log.error(traceback.format_exc())
        if conn:
            try:
                conn.rollback()
            except:
                pass
        return 0
    finally:
        if conn:
            try:
                conn.close()
            except:
                pass


def _add_to_blocked_devices(cur, data: dict):
    """Add device to blocked devices list"""
    device_id = data.get("device_instance_id")
    if not device_id:
        return
    
    device_name = data.get("device_name", "Unknown Device")
    now = datetime.datetime.now().isoformat()
    
    cur.execute("SELECT * FROM blocked_devices WHERE device_instance_id = ?", (device_id,))
    existing = cur.fetchone()
    
    if not existing:
        cur.execute("""
            INSERT INTO blocked_devices (device_instance_id, device_name, added_by, added_at)
            VALUES (?, ?, ?, ?)
        """, (device_id, device_name, 'system', now))


def mark_removed(session_id: str, hostname: str):
    """Mark a device as removed"""
    if not session_id:
        return None
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM events WHERE session_id = ? AND hostname = ?", (session_id, hostname))
    row = cur.fetchone()
    if not row:
        conn.close()
        return None

    removed_at = datetime.datetime.now()
    connected_at = datetime.datetime.fromisoformat(row["timestamp"])
    duration = int((removed_at - connected_at).total_seconds())

    cur.execute("""
        UPDATE events SET removed_at = ?, duration_seconds = ? WHERE id = ?
    """, (removed_at.isoformat(), duration, row["id"]))
    conn.commit()
    conn.close()
    return duration


def get_event(event_id: int):
    """Get a single event by ID"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM events WHERE id = ?", (event_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_all_events(limit: int = 500):
    """Get all events with limit"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_distinct_devices():
    """Get distinct devices with connection count"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT device_instance_id, device_name, device_type, hostname,
               COUNT(*) as session_count,
               MAX(timestamp) as last_seen,
               status
        FROM events
        WHERE device_instance_id IS NOT NULL
        GROUP BY device_instance_id
        ORDER BY last_seen DESC
    """)
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_device_history(device_instance_id: str):
    """Get history for a specific device"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM events WHERE device_instance_id = ? ORDER BY id DESC
    """, (device_instance_id,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def mark_overridden(event_id: int, admin_user: str):
    """Mark a device as overridden"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        UPDATE events
        SET status = 'overridden', admin_user = ?, override_timestamp = ?
        WHERE id = ?
    """, (admin_user, now, event_id))
    conn.commit()
    conn.close()


def get_blocked_devices():
    """Get blocked devices list"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM blocked_devices ORDER BY added_at DESC")
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def remove_blocked_device(device_id: str):
    """Remove a device from blocked list"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM blocked_devices WHERE device_instance_id = ?", (device_id,))
    conn.commit()
    conn.close()


def get_allowed_devices():
    """Get allowed devices list"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM allowed_devices ORDER BY added_at DESC")
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_allowed_device(device_id: str, device_name: str, added_by: str = None):
    """Add a device to allowed list"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        INSERT OR REPLACE INTO allowed_devices (device_instance_id, device_name, added_by, added_at)
        VALUES (?, ?, ?, ?)
    """, (device_id, device_name, added_by, now))
    conn.commit()
    conn.close()


def remove_allowed_device(device_id: str):
    """Remove a device from allowed list"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM allowed_devices WHERE device_instance_id = ?", (device_id,))
    conn.commit()
    conn.close()


def get_agents():
    """Get all agents"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM agents ORDER BY last_seen DESC")
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def update_agent(hostname: str, ip_address: str, username: str, status: str, version: str = "1.0"):
    """Update or insert agent information"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    
    cur.execute("SELECT * FROM agents WHERE hostname = ?", (hostname,))
    existing = cur.fetchone()
    
    if existing:
        cur.execute("""
            UPDATE agents 
            SET ip_address = COALESCE(?, ip_address),
                username = COALESCE(?, username),
                status = ?,
                last_seen = ?,
                version = ?
            WHERE hostname = ?
        """, (ip_address, username, status, now, version, hostname))
    else:
        cur.execute("""
            INSERT INTO agents (hostname, ip_address, username, status, last_seen, registered_at, version)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (hostname, ip_address, username, status, now, now, version))
    
    conn.commit()
    conn.close()


def remove_agent(hostname: str):
    """Remove an agent"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM agents WHERE hostname = ?", (hostname,))
    conn.commit()
    conn.close()


def add_audit_log(username: str, action: str, details: str = None):
    """Add an audit log entry"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        INSERT INTO audit_logs (username, action, details, timestamp)
        VALUES (?, ?, ?, ?)
    """, (username, action, details, now))
    conn.commit()
    conn.close()


def get_audit_logs(limit: int = 100):
    """Get audit logs"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?", (limit,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ============================================================
# V10 TRUST, EVIDENCE AND BEHAVIOURAL SECURITY
# ============================================================

def list_device_policies():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM device_policies ORDER BY priority ASC, id ASC").fetchall()
    conn.close()
    return [dict(row) for row in rows]


def upsert_device_policy(policy: dict):
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    conn = get_connection()
    conn.execute("""
        INSERT INTO device_policies
        (policy_id, match_type, match_value, action, enabled, priority, reason, created_by, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(policy_id) DO UPDATE SET
          match_type=excluded.match_type, match_value=excluded.match_value,
          action=excluded.action, enabled=excluded.enabled, priority=excluded.priority,
          reason=excluded.reason, created_by=excluded.created_by, updated_at=excluded.updated_at
    """, (
        policy["policy_id"], policy["match_type"], policy["match_value"], policy["action"],
        1 if policy.get("enabled", True) else 0, int(policy.get("priority", 100)),
        policy.get("reason"), policy.get("created_by"), now, now,
    ))
    conn.commit()
    conn.close()


def delete_device_policy(policy_id: str):
    conn = get_connection()
    conn.execute("DELETE FROM device_policies WHERE policy_id = ?", (policy_id,))
    conn.commit()
    conn.close()


def append_evidence_chain(event_id, event_kind: str, payload: dict, previous_hash: str, entry_hash: str, key_id: str):
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    conn = get_connection()
    conn.execute("""
        INSERT INTO evidence_chain (event_id, event_kind, payload_json, previous_hash, entry_hash, key_id, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (event_id, event_kind, json.dumps(payload, sort_keys=True, separators=(",", ":")),
          previous_hash, entry_hash, key_id, now))
    conn.commit()
    conn.close()


def get_evidence_chain(limit=None):
    conn = get_connection()
    if limit is None:
        rows = conn.execute("SELECT * FROM evidence_chain ORDER BY id ASC").fetchall()
    else:
        rows = conn.execute("SELECT * FROM evidence_chain ORDER BY id ASC LIMIT ?", (limit,)).fetchall()
    conn.close()
    return [dict(row) for row in rows]


def get_last_evidence_hash():
    conn = get_connection()
    row = conn.execute("SELECT entry_hash FROM evidence_chain ORDER BY id DESC LIMIT 1").fetchone()
    conn.close()
    return row["entry_hash"] if row else ""


def get_behavioral_profile(subject_token: str):
    conn = get_connection()
    row = conn.execute("SELECT * FROM behavioral_profiles WHERE subject_token = ?", (subject_token,)).fetchone()
    conn.close()
    return dict(row) if row else None


def save_behavioral_profile(subject_token: str, sample_count: int, dwell_mean, flight_mean, mouse_speed_mean):
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    conn = get_connection()
    conn.execute("""
        INSERT INTO behavioral_profiles (subject_token, sample_count, dwell_mean, flight_mean, mouse_speed_mean, updated_at)
        VALUES (?, ?, ?, ?, ?, ?)
        ON CONFLICT(subject_token) DO UPDATE SET sample_count=excluded.sample_count,
          dwell_mean=excluded.dwell_mean, flight_mean=excluded.flight_mean,
          mouse_speed_mean=excluded.mouse_speed_mean, updated_at=excluded.updated_at
    """, (subject_token, sample_count, dwell_mean, flight_mean, mouse_speed_mean, now))
    conn.commit()
    conn.close()


def add_behavioral_observation(subject_token: str, hostname: str, risk_score: float, signals: dict):
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    conn = get_connection()
    conn.execute("""
        INSERT INTO behavioral_observations (subject_token, hostname, risk_score, signals_json, created_at)
        VALUES (?, ?, ?, ?, ?)
    """, (subject_token, hostname, risk_score, json.dumps(signals, sort_keys=True), now))
    conn.commit()
    conn.close()


def add_incident_bundle(incident_id: str, event_id, severity: str, bundle_path: str, bundle_sha256: str, status: str = "captured"):
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    conn = get_connection()
    conn.execute("""
        INSERT INTO incident_bundles (incident_id, event_id, severity, bundle_path, bundle_sha256, status, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (incident_id, event_id, severity, bundle_path, bundle_sha256, status, now))
    conn.commit()
    conn.close()


def clear_all_events():
    """Clear all events"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM events")
    cur.execute("DELETE FROM device_cache")
    conn.commit()
    conn.close()


# ============================================================
# USER FUNCTIONS
# ============================================================

def get_users():
    """Get all users"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, username, role, created_at FROM users ORDER BY created_at DESC")
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_user_by_username(username: str):
    """Get a single user row"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM users WHERE username = ?", (username,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def verify_user_credentials(username: str, password: str) -> bool:
    """Verify user credentials"""
    from werkzeug.security import check_password_hash
    user = get_user_by_username(username)
    if not user:
        return False
    stored = user.get("password", "")
    if stored.startswith(("pbkdf2:", "scrypt:")):
        return check_password_hash(stored, password)
    if stored == password:
        update_user_password(username, password)
        return True
    return False


def add_user(username: str, password: str, role: str = "user"):
    """Add a new user"""
    from werkzeug.security import generate_password_hash
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        INSERT INTO users (username, password, role, created_at)
        VALUES (?, ?, ?, ?)
    """, (username, generate_password_hash(password), role, now))
    conn.commit()
    conn.close()


def update_user_password(username: str, new_password: str):
    """Update user password"""
    from werkzeug.security import generate_password_hash
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE users SET password = ? WHERE username = ?",
                (generate_password_hash(new_password), username))
    conn.commit()
    conn.close()


def delete_user(username: str):
    """Delete a user"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM users WHERE username = ?", (username,))
    conn.commit()
    conn.close()


# ============================================================
# ALERT SETTINGS FUNCTIONS
# ============================================================

def get_alert_setting(key: str):
    """Get a single alert setting value"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT setting_value FROM alert_settings WHERE setting_key = ?", (key,))
    row = cur.fetchone()
    conn.close()
    return row["setting_value"] if row else None


def get_all_alert_settings():
    """Get all alert settings"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT setting_key, setting_value FROM alert_settings")
    rows = cur.fetchall()
    conn.close()
    return {row["setting_key"]: row["setting_value"] for row in rows}


def set_alert_setting(key: str, value: str):
    """Set a single alert setting"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        INSERT OR REPLACE INTO alert_settings (setting_key, setting_value, updated_at)
        VALUES (?, ?, ?)
    """, (key, value, now))
    conn.commit()
    conn.close()


# ============================================================
# EXAM FUNCTIONS
# ============================================================

def get_exam_config():
    """Get exam configuration"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT config_key, config_value FROM exam_config")
    rows = cur.fetchall()
    conn.close()
    config_data = {}
    for row in rows:
        config_data[row["config_key"]] = row["config_value"]
    
    defaults = {
        "exam_url": "",
        "duration": "3600",
        "scheduled_start": "",
        "block_usb": "true",
        "block_internet": "true",
        "block_browsers": "true",
        "block_copy_paste": "true",
        "block_print_screen": "true",
    }
    for key, value in defaults.items():
        if key not in config_data:
            config_data[key] = value
    return config_data


def save_exam_config(data):
    """Save exam configuration"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    for key, value in data.items():
        cur.execute("""
            INSERT OR REPLACE INTO exam_config (config_key, config_value, updated_at)
            VALUES (?, ?, ?)
        """, (key, str(value), now))
    conn.commit()
    conn.close()


def get_exam_history(limit: int = 50):
    """Get exam history"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM exam_history ORDER BY started_at DESC LIMIT ?", (limit,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def start_exam_session(exam_url, duration, started_by):
    """Start an exam session"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        INSERT INTO exam_history (exam_url, duration_seconds, started_by, started_at, status)
        VALUES (?, ?, ?, ?, ?)
    """, (exam_url, duration, started_by, now, "active"))
    conn.commit()
    exam_id = cur.lastrowid
    conn.close()
    return exam_id


def end_exam_session(exam_id):
    """End an exam session"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        UPDATE exam_history SET ended_at = ?, status = 'completed' WHERE id = ?
    """, (now, exam_id))
    conn.commit()
    conn.close()


# ============================================================
# 2FA FUNCTIONS
# ============================================================

def get_2fa_secret(username):
    """Get 2FA secret for user"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT secret FROM user_2fa WHERE username = ?", (username,))
    row = cur.fetchone()
    conn.close()
    return row["secret"] if row else None


def enable_2fa(username, secret):
    """Enable 2FA for user"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        INSERT OR REPLACE INTO user_2fa (username, secret, enabled, created_at)
        VALUES (?, ?, 1, ?)
    """, (username, secret, now))
    conn.commit()
    conn.close()


def disable_2fa(username):
    """Disable 2FA for user"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE user_2fa SET enabled = 0 WHERE username = ?", (username,))
    conn.commit()
    conn.close()


def is_2fa_enabled(username):
    """Check if 2FA is enabled for user"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT enabled FROM user_2fa WHERE username = ?", (username,))
    row = cur.fetchone()
    conn.close()
    return bool(row["enabled"]) if row else False


# ============================================================
# SESSION FUNCTIONS
# ============================================================

def get_active_sessions(username):
    """Get active sessions for user"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM user_sessions 
        WHERE username = ? AND is_active = 1 AND datetime(expires_at) > datetime('now', 'localtime')
        ORDER BY last_active DESC
    """, (username,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def create_session(username, session_id, ip_address, user_agent):
    """Create new session"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    expires_at = (datetime.datetime.now() + datetime.timedelta(hours=8)).isoformat()
    cur.execute("""
        INSERT INTO user_sessions (username, session_id, ip_address, user_agent, created_at, last_active, expires_at, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, 1)
    """, (username, session_id, ip_address, user_agent, now, now, expires_at))
    conn.commit()
    conn.close()


def update_session_activity(session_id):
    """Update session activity"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("UPDATE user_sessions SET last_active = ? WHERE session_id = ?", (now, session_id))
    conn.commit()
    conn.close()


def terminate_session(session_id):
    """Terminate session"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE user_sessions SET is_active = 0 WHERE session_id = ?", (session_id,))
    conn.commit()
    conn.close()


def terminate_all_sessions(username, exclude_session_id=None):
    """Terminate all sessions for user"""
    conn = get_connection()
    cur = conn.cursor()
    if exclude_session_id:
        cur.execute("""
            UPDATE user_sessions SET is_active = 0 
            WHERE username = ? AND session_id != ?
        """, (username, exclude_session_id))
    else:
        cur.execute("UPDATE user_sessions SET is_active = 0 WHERE username = ?", (username,))
    conn.commit()
    conn.close()


# ============================================================
# IP WHITELIST FUNCTIONS
# ============================================================

def get_whitelist():
    """Get IP whitelist"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM ip_whitelist WHERE is_active = 1 ORDER BY added_at DESC")
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_ip_to_whitelist(ip_address, description, added_by):
    """Add IP to whitelist"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        INSERT OR REPLACE INTO ip_whitelist (ip_address, description, added_by, added_at, is_active)
        VALUES (?, ?, ?, ?, 1)
    """, (ip_address, description, added_by, now))
    conn.commit()
    conn.close()


def remove_ip_from_whitelist(ip_address):
    """Remove IP from whitelist"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM ip_whitelist WHERE ip_address = ?", (ip_address,))
    conn.commit()
    conn.close()


def is_ip_whitelisted(ip_address):
    """Check if IP is whitelisted"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM ip_whitelist WHERE ip_address = ? AND is_active = 1", (ip_address,))
    row = cur.fetchone()
    conn.close()
    return bool(row)


# ============================================================
# LOCKDOWN FUNCTIONS
# ============================================================

def get_lockdown_logs(limit=100):
    """Get lockdown block logs"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM lockdown_block_logs ORDER BY blocked_at DESC LIMIT ?", (limit,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_lockdown_log(hostname, device_name, block_reason, browser_name=None, url=None):
    """Add lockdown block log"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        INSERT INTO lockdown_block_logs (hostname, device_name, browser_name, url, block_reason, blocked_at)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (hostname, device_name, browser_name, url, block_reason, now))
    conn.commit()
    conn.close()


def clear_lockdown_logs():
    """Clear lockdown logs"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM lockdown_block_logs")
    conn.commit()
    conn.close()


def get_allowed_usb_devices():
    """Get allowed USB devices"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM lockdown_allowed_usb ORDER BY added_at DESC")
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_allowed_usb_device(device_id, device_name, added_by):
    """Add allowed USB device"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        INSERT OR REPLACE INTO lockdown_allowed_usb (device_id, device_name, added_by, added_at)
        VALUES (?, ?, ?, ?)
    """, (device_id, device_name, added_by, now))
    conn.commit()
    conn.close()


def remove_allowed_usb_device(device_id):
    """Remove allowed USB device"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM lockdown_allowed_usb WHERE device_id = ?", (device_id,))
    conn.commit()
    conn.close()


def get_allowed_websites():
    """Get allowed websites"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM lockdown_allowed_websites WHERE is_active = 1 ORDER BY added_at DESC")
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_allowed_website(url_pattern, description, added_by):
    """Add allowed website"""
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        INSERT OR REPLACE INTO lockdown_allowed_websites (url_pattern, description, added_by, added_at, is_active)
        VALUES (?, ?, ?, ?, 1)
    """, (url_pattern, description, added_by, now))
    conn.commit()
    conn.close()


def remove_allowed_website(url_pattern):
    """Remove allowed website"""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM lockdown_allowed_websites WHERE url_pattern = ?", (url_pattern,))
    conn.commit()
    conn.close()


def get_recent_event(device_instance_id: str, status: str, hostname: str, seconds: int = 5):
    """Check if the same device with the same status and host was recorded recently."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT id FROM events
        WHERE device_instance_id = ?
          AND status = ?
          AND hostname = ?
          AND datetime(timestamp) > datetime('now', 'localtime', ?)
        ORDER BY id DESC LIMIT 1
    """, (device_instance_id, status, hostname, f'-{seconds} seconds'))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None

# ============================================================
# SERVER SETTINGS  (key/value store — lab registration overrides, etc.)
# ============================================================

def get_setting(key: str, default=None):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT value FROM server_settings WHERE key = ?", (key,))
    row = cur.fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key: str, value):
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        INSERT INTO server_settings (key, value, updated_at) VALUES (?, ?, ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at
    """, (key, "" if value is None else str(value), now))
    conn.commit()
    conn.close()


def get_all_settings():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT key, value FROM server_settings")
    rows = {r["key"]: r["value"] for r in cur.fetchall()}
    conn.close()
    return rows


# ============================================================
# HUB MESSAGES  (read-only hub monitoring -> live message to this lab)
# ============================================================

def add_hub_message(message: str, severity: str = "info", sent_by: str = "Hub Admin"):
    conn = get_connection()
    cur = conn.cursor()
    now = datetime.datetime.now().isoformat()
    cur.execute("""
        INSERT INTO hub_messages (message, severity, sent_by, received_at)
        VALUES (?, ?, ?, ?)
    """, (message, severity, sent_by, now))
    conn.commit()
    msg_id = cur.lastrowid
    conn.close()
    return msg_id


def get_recent_hub_messages(limit: int = 20):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM hub_messages ORDER BY id DESC LIMIT ?", (limit,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ============================================================
# SENTRYUSB MESSENGER  (durable Hub <-> Lab conversation cache)
# ============================================================

def upsert_messenger_message(message: dict):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO messenger_messages
        (message_id, direction, sender, body, severity, created_at, delivered_at, read_at,
         kind, media_id, media_mime, media_size, media_duration)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(message_id) DO UPDATE SET
            delivered_at = COALESCE(excluded.delivered_at, messenger_messages.delivered_at),
            read_at = COALESCE(excluded.read_at, messenger_messages.read_at)
    """, (
        message["message_id"], message["direction"], message["sender"], message["body"],
        message.get("severity", "info"), message["created_at"], message.get("delivered_at"),
        message.get("read_at"), message.get("kind") or "text", message.get("media_id"),
        message.get("media_mime"), message.get("media_size"), message.get("media_duration"),
    ))
    conn.commit()
    conn.close()


def get_messenger_messages(limit: int = 100):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM messenger_messages ORDER BY created_at DESC, id DESC LIMIT ?",
                (max(1, min(int(limit), 200)),))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return list(reversed(rows))


def mark_messenger_read(direction: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE messenger_messages SET read_at = COALESCE(read_at, ?) WHERE direction = ?",
                (datetime.datetime.now().isoformat(), direction))
    conn.commit()
    conn.close()


# ============================================================
# POLICY STUDIO (v20): versioned policies + agent consent requests
# ============================================================
def init_policy_tables():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS agent_policies (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            version INTEGER UNIQUE NOT NULL,
            title TEXT NOT NULL,
            body TEXT NOT NULL,
            rules TEXT,
            is_active INTEGER NOT NULL DEFAULT 0,
            created_by TEXT,
            created_at TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS agent_policy_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hostname TEXT UNIQUE NOT NULL,
            ip_address TEXT,
            username TEXT,
            policy_version INTEGER,
            status TEXT NOT NULL DEFAULT 'pending',
            note TEXT,
            requested_at TEXT NOT NULL,
            decided_at TEXT,
            decided_by TEXT
        )
    """)
    cur.execute("SELECT COUNT(*) FROM agent_policies")
    if cur.fetchone()[0] == 0:
        cur.execute(
            "INSERT INTO agent_policies (version,title,body,rules,is_active,created_by,created_at) VALUES (1,?,?,?,1,'system',?)",
            ("SentryUSB Acceptable Use & Monitoring Policy",
             "This computer is monitored by SentryUSB for USB-device activity, browser activity "
             "and remote-access sessions. During an authorised exam the administrator may restrict "
             "USB storage, browsers, internet access, copy/paste, screenshots and task switching. "
             "Restrictions end automatically when the exam time allocated by the server expires, "
             "even if this computer loses its connection. Screen content and keystrokes are never recorded.",
             json.dumps(["USB device monitoring", "Browser activity monitoring", "Remote-access detection",
                         "Exam lockdown (time-limited)"]),
             datetime.datetime.now().isoformat()))
    conn.commit()
    conn.close()


def get_active_policy():
    conn = get_connection()
    row = conn.execute("SELECT * FROM agent_policies WHERE is_active=1 ORDER BY version DESC LIMIT 1").fetchone()
    conn.close()
    return dict(row) if row else None


def list_policies():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM agent_policies ORDER BY version DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def publish_policy(title, body, rules, created_by):
    """Create a new policy version and make it the only active one."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT COALESCE(MAX(version),0)+1 FROM agent_policies")
    version = cur.fetchone()[0]
    cur.execute("UPDATE agent_policies SET is_active=0")
    cur.execute(
        "INSERT INTO agent_policies (version,title,body,rules,is_active,created_by,created_at) VALUES (?,?,?,?,1,?,?)",
        (version, title, body, json.dumps(rules or []), created_by, datetime.datetime.now().isoformat()))
    conn.commit()
    conn.close()
    return version


def upsert_policy_request(hostname, ip_address, username, policy_version):
    """Record an agent's acceptance. Never downgrades an approved agent on same version."""
    now = datetime.datetime.now().isoformat()
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM agent_policy_requests WHERE hostname=?", (hostname,))
    row = cur.fetchone()
    if row is None:
        cur.execute("INSERT INTO agent_policy_requests (hostname,ip_address,username,policy_version,status,requested_at) "
                    "VALUES (?,?,?,?, 'pending', ?)", (hostname, ip_address, username, policy_version, now))
    elif row["policy_version"] != policy_version:
        # New policy version -> agent must be re-approved.
        cur.execute("UPDATE agent_policy_requests SET ip_address=?, username=?, policy_version=?, status='pending', "
                    "requested_at=?, decided_at=NULL, decided_by=NULL WHERE hostname=?",
                    (ip_address, username, policy_version, now, hostname))
    else:
        cur.execute("UPDATE agent_policy_requests SET ip_address=?, username=? WHERE hostname=?",
                    (ip_address, username, hostname))
    conn.commit()
    row = cur.execute("SELECT * FROM agent_policy_requests WHERE hostname=?", (hostname,)).fetchone()
    conn.close()
    return dict(row)


def get_policy_request(hostname):
    conn = get_connection()
    row = conn.execute("SELECT * FROM agent_policy_requests WHERE hostname=?", (hostname,)).fetchone()
    conn.close()
    return dict(row) if row else None


def list_policy_requests():
    conn = get_connection()
    rows = conn.execute("SELECT * FROM agent_policy_requests ORDER BY "
                        "CASE status WHEN 'pending' THEN 0 WHEN 'approved' THEN 1 ELSE 2 END, requested_at DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]


def decide_policy_request(hostname, status, decided_by, note=None):
    conn = get_connection()
    cur = conn.execute("UPDATE agent_policy_requests SET status=?, decided_at=?, decided_by=?, note=? WHERE hostname=?",
                       (status, datetime.datetime.now().isoformat(), decided_by, note, hostname))
    conn.commit()
    changed = cur.rowcount
    conn.close()
    return changed > 0
