"""
SentryUSB - One Click Installer
Installs Server + Agent + All Dependencies
"""
import os
import sys
import subprocess
import urllib.request
import ctypes
import time
import shutil
import tempfile

class SentryUSBInstaller:
    def __init__(self):
        self.install_dir = os.path.join(os.environ['PROGRAMFILES'], 'SentryUSB')
        self.python_installed = False
        self.venv_path = None
        
    def is_admin(self):
        try:
            return ctypes.windll.shell32.IsUserAnAdmin()
        except:
            return False
    
    def print_header(self):
        print("="*70)
        print("SENTRYUSB SECURITY SYSTEM - INSTALLER")
        print("="*70)
        print("Install Location: " + self.install_dir)
        print("="*70)
    
    def check_python(self):
        try:
            result = subprocess.run(["python", "--version"], capture_output=True, text=True)
            if result.returncode == 0:
                print("Python found: " + result.stdout.strip())
                self.python_installed = True
                return True
        except:
            pass
        
        try:
            result = subprocess.run(["py", "-3", "--version"], capture_output=True, text=True)
            if result.returncode == 0:
                print("Python found: " + result.stdout.strip())
                self.python_installed = True
                return True
        except:
            pass
        
        print("Python not found. Installing Python...")
        return False
    
    def download_python(self):
        print("Downloading Python 3.12...")
        python_url = "https://www.python.org/ftp/python/3.12.0/python-3.12.0-amd64.exe"
        installer_path = os.path.join(tempfile.gettempdir(), "python_installer.exe")
        
        try:
            urllib.request.urlretrieve(python_url, installer_path)
            print("Python downloaded")
            
            print("Installing Python (this may take 2-3 minutes)...")
            subprocess.run([
                installer_path,
                "/quiet",
                "InstallAllUsers=1",
                "PrependPath=1",
                "Include_test=0",
                "SimpleInstall=1"
            ], check=True, timeout=300)
            
            print("Python installed successfully!")
            self.python_installed = True
            return True
        except Exception as e:
            print("Failed to install Python: " + str(e))
            return False
    
    def create_virtual_env(self):
        self.venv_path = os.path.join(self.install_dir, "venv")
        
        if os.path.exists(self.venv_path):
            print("Virtual environment already exists")
            return True
        
        print("Creating virtual environment...")
        try:
            python_cmd = "python" if self.python_installed else "py -3"
            subprocess.run([python_cmd, "-m", "venv", self.venv_path], check=True, timeout=60)
            print("Virtual environment created")
            return True
        except Exception as e:
            print("Failed to create virtual environment: " + str(e))
            return False
    
    def install_packages(self):
        print("Installing Python packages (this may take 3-5 minutes)...")
        
        pip_path = os.path.join(self.venv_path, "Scripts", "pip.exe")
        
        packages = [
            "flask==3.0.3",
            "flask-socketio==5.3.6",
            "python-socketio==5.11.2",
            "flask-mail==0.9.1",
            "apscheduler==3.10.4",
            "requests==2.31.0",
            "reportlab==4.0.9",
            "openpyxl==3.1.2",
            "pillow==10.1.0",
            "pyotp==2.9.0",
            "qrcode==7.4.2",
            "psutil==5.9.0",
            "wmi==1.5.1",
            "pywin32"
        ]
        
        for package in packages:
            print("   Installing " + package + "...")
            try:
                subprocess.run([pip_path, "install", package, "--quiet"], check=True, timeout=120)
            except Exception as e:
                print("   Warning: Failed to install " + package + ": " + str(e))
        
        print("All packages installed")
        return True
    
    def copy_files(self):
        print("Copying files...")
        
        os.makedirs(os.path.join(self.install_dir, "server", "templates"), exist_ok=True)
        os.makedirs(os.path.join(self.install_dir, "agent", "logs"), exist_ok=True)
        
        print("Files ready")
        return True
    
    def create_launchers(self):
        print("Creating launchers...")
        
        install_dir = self.install_dir
        
        server_bat = os.path.join(self.install_dir, "Start_Server.bat")
        with open(server_bat, "w") as f:
            f.write('@echo off\n')
            f.write('echo Starting SentryUSB Server...\n')
            f.write('echo.\n')
            f.write('cd /d "' + install_dir + '\\server"\n')
            f.write('"' + install_dir + '\\venv\\Scripts\\python.exe" app.py\n')
            f.write('pause\n')
        
        agent_bat = os.path.join(self.install_dir, "Start_Agent.bat")
        with open(agent_bat, "w") as f:
            f.write('@echo off\n')
            f.write('echo Starting SentryUSB Agent...\n')
            f.write('echo.\n')
            f.write('cd /d "' + install_dir + '\\agent"\n')
            f.write('"' + install_dir + '\\venv\\Scripts\\python.exe" agent.py\n')
            f.write('pause\n')
        
        config_bat = os.path.join(self.install_dir, "Configure.bat")
        with open(config_bat, "w") as f:
            f.write('@echo off\n')
            f.write('echo SentryUSB Configuration\n')
            f.write('echo.\n')
            f.write('echo 1. Edit Server Config\n')
            f.write('echo 2. Edit Agent Config\n')
            f.write('echo.\n')
            f.write('notepad "' + install_dir + '\\server\\config.py"\n')
            f.write('notepad "' + install_dir + '\\agent\\config.py"\n')
            f.write('pause\n')
        
        print("Launchers created")
        return True
    
    def create_shortcuts(self):
        print("Creating desktop shortcuts...")
        try:
            import winshell
            from win32com.client import Dispatch
            
            desktop = winshell.desktop()
            shell = Dispatch('WScript.Shell')
            
            shortcut = shell.CreateShortCut(os.path.join(desktop, 'SentryUSB_Server.lnk'))
            shortcut.Targetpath = os.path.join(self.install_dir, "Start_Server.bat")
            shortcut.WorkingDirectory = self.install_dir
            shortcut.IconLocation = "imageres.dll,3"
            shortcut.save()
            
            shortcut = shell.CreateShortCut(os.path.join(desktop, 'SentryUSB_Agent.lnk'))
            shortcut.Targetpath = os.path.join(self.install_dir, "Start_Agent.bat")
            shortcut.WorkingDirectory = self.install_dir
            shortcut.IconLocation = "imageres.dll,3"
            shortcut.save()
            
            shortcut = shell.CreateShortCut(os.path.join(desktop, 'SentryUSB_Configure.lnk'))
            shortcut.Targetpath = os.path.join(self.install_dir, "Configure.bat")
            shortcut.WorkingDirectory = self.install_dir
            shortcut.save()
            
            print("Desktop shortcuts created")
            return True
        except Exception as e:
            print("Warning: Could not create shortcuts: " + str(e))
            return True
    
    def create_startmenu(self):
        try:
            startmenu = os.path.join(os.environ['PROGRAMDATA'], 
                                    'Microsoft\\Windows\\Start Menu\\Programs\\SentryUSB')
            os.makedirs(startmenu, exist_ok=True)
            
            for name in ['SentryUSB_Server', 'SentryUSB_Agent', 'SentryUSB_Configure']:
                src = os.path.join(os.environ['USERPROFILE'], 'Desktop', name + '.lnk')
                dst = os.path.join(startmenu, name + '.lnk')
                if os.path.exists(src):
                    shutil.copy2(src, dst)
            
            print("Start Menu entries created")
            return True
        except:
            return True
    
    def create_uninstaller(self):
        print("Creating uninstaller...")
        uninstall = os.path.join(self.install_dir, "Uninstall.bat")
        with open(uninstall, "w") as f:
            f.write('@echo off\n')
            f.write('echo Uninstalling SentryUSB...\n')
            f.write('echo.\n')
            f.write('echo WARNING: This will delete ALL SentryUSB files!\n')
            f.write('echo.\n')
            f.write('choice /C YN /M "Are you sure you want to uninstall"\n')
            f.write('if errorlevel 2 exit\n')
            f.write('echo.\n')
            f.write('echo Removing files...\n')
            f.write('cd /d "C:\\"\n')
            f.write('rmdir /s /q "' + self.install_dir + '"\n')
            f.write('echo.\n')
            f.write('echo Removing Start Menu entries...\n')
            f.write('rmdir /s /q "' + os.environ['PROGRAMDATA'] + '\\Microsoft\\Windows\\Start Menu\\Programs\\SentryUSB"\n')
            f.write('echo.\n')
            f.write('echo Removing desktop shortcuts...\n')
            f.write('del "' + os.environ['USERPROFILE'] + '\\Desktop\\SentryUSB_Server.lnk"\n')
            f.write('del "' + os.environ['USERPROFILE'] + '\\Desktop\\SentryUSB_Agent.lnk"\n')
            f.write('del "' + os.environ['USERPROFILE'] + '\\Desktop\\SentryUSB_Configure.lnk"\n')
            f.write('echo.\n')
            f.write('echo SentryUSB Uninstalled!\n')
            f.write('pause\n')
        print("Uninstaller created")
        return True
    
    def install(self):
        self.print_header()
        
        if not self.is_admin():
            print("ERROR: This installer requires Administrator privileges!")
            print("Please right-click and select 'Run as Administrator'")
            input("Press Enter to exit...")
            return False
        
        print("")
        print("Step 1: Checking Python...")
        if not self.check_python():
            if not self.download_python():
                print("ERROR: Failed to install Python.")
                input("Press Enter to exit...")
                return False
        
        print("")
        print("Step 2: Creating virtual environment...")
        if not self.create_virtual_env():
            input("Press Enter to exit...")
            return False
        
        print("")
        print("Step 3: Installing packages...")
        self.install_packages()
        
        print("")
        print("Step 4: Creating launchers...")
        self.create_launchers()
        
        print("")
        print("Step 5: Creating shortcuts...")
        self.create_shortcuts()
        
        print("")
        print("Step 6: Creating Start Menu entries...")
        self.create_startmenu()
        
        print("")
        print("Step 7: Creating uninstaller...")
        self.create_uninstaller()
        
        print("")
        print("="*70)
        print("INSTALLATION COMPLETE!")
        print("="*70)
        print("")
        print("Installed to: " + self.install_dir)
        print("")
        print("Desktop shortcuts created:")
        print("   SentryUSB_Server  - Start the Server")
        print("   SentryUSB_Agent   - Start the Agent")
        print("   SentryUSB_Configure - Edit Settings")
        print("")
        print("NEXT STEPS:")
        print("   1. Configure: Double-click 'SentryUSB_Configure'")
        print("   2. Run Server: Right-click 'SentryUSB_Server' -> Run as Admin")
        print("   3. Run Agent: Right-click 'SentryUSB_Agent' -> Run as Admin")
        print("   4. Open browser: http://localhost:5000")
        print("   5. Login: admin / change-me-admin-pass")
        print("")
        print("="*70)
        input("Press Enter to exit...")
        return True

if __name__ == "__main__":
    installer = SentryUSBInstaller()
    installer.install()