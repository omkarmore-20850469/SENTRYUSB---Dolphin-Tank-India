"""
SentryUSB Server - AI Security Assistant (v2)
---------------------------------------------
* Understands plain-English questions about agents, devices, events, logins,
  exams, audit trail and the Hub messenger - including specific hostnames,
  time windows ("last 6 hours") and follow-ups ("what about LAB-PC-3?").
* Answers with structured replies: text, metric cards, follow-up suggestions
  and *confirmable* actions. The assistant never executes anything by itself:
  every action is a button the admin must confirm.
* Proactive "autopilot": a background watcher turns the live snapshot into
  insights (offline agents, blocked-USB bursts, risky devices, unread Hub
  messages...) and pushes new ones to the chat widget.
* Works fully offline with the local engine. If AI_CHAT_USE_ANTHROPIC is set,
  open-ended questions go to Claude with read-only tools + a propose_action
  tool (still confirm-only).
"""
import difflib
import json
import logging
import re
import threading
import time
import urllib.error
import urllib.request
from collections import Counter
from datetime import datetime, timedelta

import config
import db

log = logging.getLogger("sentryusb.ai_chat")

try:
    from ai_anomaly import device_profiler, login_detector, network_analyzer  # noqa: F401
    AI_ANOMALY_AVAILABLE = True
except ImportError:
    AI_ANOMALY_AVAILABLE = False

try:
    from ai_enhanced import ThreatIntelligence  # noqa: F401
    AI_ENHANCED_AVAILABLE = True
except ImportError:
    AI_ENHANCED_AVAILABLE = False

# Actions the assistant may *propose*. Risk drives the confirmation wording.
ACTION_CATALOG = {
    "override_device": {"label": "Override blocked device", "risk": "high"},
    "allow_device": {"label": "Add device to allow-list", "risk": "high"},
    "unblock_device": {"label": "Remove from block-list", "risk": "high"},
    "start_exam": {"label": "Start exam mode", "risk": "high"},
    "stop_exam": {"label": "Stop exam mode", "risk": "medium"},
    "train_ai": {"label": "Retrain anomaly model", "risk": "low"},
    "generate_report": {"label": "Generate AI report", "risk": "low"},
    "message_hub": {"label": "Send message to Hub", "risk": "low"},
    "call_hub": {"label": "Start voice call with Hub", "risk": "low"},
}

_history = {}     # admin -> [{"role","content"}]
_context = {}     # admin -> {"intent","agent","hours"} for follow-ups


# ---------------------------------------------------------------------------
# Conversation memory
# ---------------------------------------------------------------------------
def _remember(admin_user, role, text):
    hist = _history.setdefault(admin_user, [])
    hist.append({"role": role, "content": text})
    max_len = getattr(config, "AI_CHAT_MAX_HISTORY", 12)
    if len(hist) > max_len:
        del hist[: len(hist) - max_len]


def reset_conversation(admin_user):
    _history.pop(admin_user, None)
    _context.pop(admin_user, None)


# ---------------------------------------------------------------------------
# Live snapshot (single source of truth for the local engine, insights and LLM)
# ---------------------------------------------------------------------------
def _parse_ts(value):
    try:
        return datetime.fromisoformat(value) if value else None
    except (TypeError, ValueError):
        return None


def get_system_snapshot():
    now = datetime.now()
    snap = {"generated_at": now.isoformat()}

    try:
        agents = db.get_agents()
    except Exception as e:
        log.error("snapshot: get_agents failed: %s", e)
        agents = []
    online = [a for a in agents if (a.get("status") or "").lower() == "online"]
    snap["agents_total"], snap["agents_online"] = len(agents), len(online)
    snap["agents_offline"] = len(agents) - len(online)
    snap["online_hostnames"] = [a.get("hostname") for a in online]
    snap["agents"] = [{
        "hostname": a.get("hostname"), "ip": a.get("ip_address"), "user": a.get("username"),
        "status": (a.get("status") or "unknown").lower(), "last_seen": a.get("last_seen"),
    } for a in agents]

    try:
        events = db.get_all_events(limit=500)
    except Exception as e:
        log.error("snapshot: get_all_events failed: %s", e)
        events = []
    recent = []
    for e in events:
        ts = _parse_ts(e.get("timestamp"))
        if ts:
            recent.append((ts, e))
    snap["events"] = [{
        "id": e.get("id"), "ts": ts.isoformat(), "host": e.get("hostname"), "user": e.get("username"),
        "device": e.get("device_name"), "device_id": e.get("device_instance_id"),
        "type": e.get("device_type"), "status": (e.get("status") or "").lower(),
    } for ts, e in recent[:300]]

    def within(hours):
        cut = now - timedelta(hours=hours)
        return [x for x in snap["events"] if _parse_ts(x["ts"]) >= cut]

    last_24h, last_1h = within(24), within(1)
    cnt = lambda lst, st: sum(1 for x in lst if x["status"] == st)  # noqa: E731
    snap.update(events_last_24h=len(last_24h), blocked_last_24h=cnt(last_24h, "blocked"),
                allowed_last_24h=cnt(last_24h, "allowed"), overridden_last_24h=cnt(last_24h, "overridden"),
                blocked_last_hour=cnt(last_1h, "blocked"))
    snap["top_blocked_devices"] = Counter(
        x["device"] or "Unknown device" for x in last_24h if x["status"] == "blocked").most_common(5)
    snap["top_blocked_hosts"] = Counter(
        x["host"] or "?" for x in last_24h if x["status"] == "blocked").most_common(5)

    for key, fn in (("blocked_devices", db.get_blocked_devices), ("allowed_devices", db.get_allowed_devices)):
        try:
            snap[key] = len(fn())
        except Exception:
            snap[key] = 0

    snap["exam_active"] = False         # merged in by app.py via injected_context
    snap["lockdown_active"] = False

    try:
        audit = db.get_audit_logs(limit=20)
    except Exception:
        audit = []
    snap["recent_audit"] = [f"{a.get('username', '?')}: {a.get('action', '?')} ({a.get('timestamp', '')})"
                            for a in audit[:6]]

    # Hub messenger state (cache kept on this server)
    try:
        msgs = db.get_messenger_messages(40)
    except Exception:
        msgs = []
    unread = [m for m in msgs if m.get("direction") == "hub_to_lab" and not m.get("read_at")
              and (m.get("kind") or "text") != "call"]
    snap["hub_unread"] = len(unread)
    snap["hub_last_message"] = (unread[-1] if unread else (msgs[-1] if msgs else None))
    if snap["hub_last_message"]:
        lm = snap["hub_last_message"]
        snap["hub_last_message"] = {"from": lm.get("sender"), "kind": lm.get("kind") or "text",
                                    "text": (lm.get("body") or "")[:160], "at": lm.get("created_at"),
                                    "severity": lm.get("severity")}

    risky = []
    if AI_ANOMALY_AVAILABLE:
        for device_id in list(getattr(device_profiler, "device_profiles", {}).keys()):
            try:
                score, status = device_profiler.predict_anomaly(device_id)
            except Exception:
                continue
            if score and score >= getattr(config, "AI_LIVE_ALERT_THRESHOLD", 50):
                risky.append({"device_id": device_id, "score": score, "status": status})
    risky.sort(key=lambda d: d["score"], reverse=True)
    snap["high_risk_devices"] = risky

    score = 100
    score -= min(30, snap["blocked_last_24h"] * 3)
    score -= min(30, len(risky) * 10)
    if snap["agents_total"]:
        score -= int(snap["agents_offline"] / snap["agents_total"] * 15)
    snap["security_score"] = max(0, min(100, score))
    return snap


def _tier(score):
    return "excellent" if score >= 85 else "good" if score >= 65 else "needs attention" if score >= 40 else "critical"


def _tone(score):
    return "good" if score >= 85 else "ok" if score >= 65 else "warn" if score >= 40 else "bad"


# ---------------------------------------------------------------------------
# Insights (used by the autopilot, the recommendations intent and the briefing)
# ---------------------------------------------------------------------------
def generate_insights(snap):
    out = []

    def add(iid, sev, title, detail, action=None):
        out.append({"id": iid, "severity": sev, "title": title, "detail": detail, "action": action})

    if snap["exam_active"] and snap["agents_online"] == 0:
        add("exam_no_agents", "critical", "Exam is active but no agents are online",
            "No lab PC is currently enforcing exam restrictions. Check the agents / network first.")
    for d in snap["high_risk_devices"][:3]:
        add("risk_" + str(d["device_id"]), "critical" if d["score"] >= 80 else "warning",
            f"High-risk device {d['device_id']}", f"Anomaly score {d['score']} ({d['status']}). Review it in AI Security.")
    if snap["blocked_last_hour"] >= 5:
        top = snap["top_blocked_hosts"][0][0] if snap["top_blocked_hosts"] else "?"
        add("blocked_burst", "warning", f"{snap['blocked_last_hour']} USB devices blocked in the last hour",
            f"Most blocks came from {top}. This could be a lab-wide attempt or a mis-configured allow-list.")
    if snap["agents_total"] and snap["agents_offline"]:
        ratio = snap["agents_offline"] / snap["agents_total"]
        offline = [a["hostname"] for a in snap["agents"] if a["status"] != "online"][:4]
        add("agents_offline", "warning" if ratio >= 0.3 else "info",
            f"{snap['agents_offline']} of {snap['agents_total']} agents offline", ", ".join(h for h in offline if h) or "")
    if snap["hub_unread"]:
        lm = snap.get("hub_last_message") or {}
        sev = "warning" if lm.get("severity") in ("warning", "critical") else "info"
        add("hub_unread", sev, f"{snap['hub_unread']} unread Hub message(s)",
            (lm.get("text") or "")[:100], {"type": "open_messenger", "label": "Open Messenger"})
    if snap["security_score"] < 65:
        add("score_low", "warning", f"Security score is {snap['security_score']}/100", "Ask me \"what should I do?\" for next steps.")
    return out


# ---------------------------------------------------------------------------
# Entity helpers
# ---------------------------------------------------------------------------
def _find_agent(question, snap):
    q = question.lower()
    names = [a["hostname"] for a in snap["agents"] if a.get("hostname")]
    for n in sorted(names, key=len, reverse=True):
        if n.lower() in q:
            return n
    tokens = re.findall(r"[a-z0-9][\w\-\.]{2,}", q)
    for t in tokens:
        m = difflib.get_close_matches(t, [n.lower() for n in names], n=1, cutoff=0.82)
        if m:
            return next(n for n in names if n.lower() == m[0])
    return None


def _hours_from(question, default=24):
    q = question.lower()
    m = re.search(r"(?:last|past)\s+(\d+)\s*(minute|min|hour|hr|h|day|d)s?\b", q)
    if m:
        n, unit = int(m.group(1)), m.group(2)
        return max(1, int(n / 60) if unit.startswith("min") else n * 24 if unit.startswith("d") else n)
    if "yesterday" in q or "last day" in q:
        return 48
    if "today" in q:
        return 24
    if re.search(r"last hour|past hour", q):
        return 1
    if "this week" in q or "last week" in q:
        return 24 * 7
    return default


def _ago(iso):
    ts = _parse_ts(iso)
    if not ts:
        return "unknown"
    s = (datetime.now() - ts).total_seconds()
    if s < 90:
        return "just now"
    if s < 5400:
        return f"{int(s // 60)} min ago"
    if s < 172800:
        return f"{int(s // 3600)} h ago"
    return f"{int(s // 86400)} d ago"


# ---------------------------------------------------------------------------
# Local intent engine
# ---------------------------------------------------------------------------
_INTENTS = [
    ("help", [r"\bhelp\b", r"what can you do", r"\bcommands?\b", r"\bcapabilit"]),
    ("briefing", [r"\bbrief(ing)?\b", r"\bdigest\b", r"catch me up", r"daily (report|summary)", r"morning"]),
    ("recommend", [r"what should i do", r"next steps?", r"recommend", r"\badvice\b", r"what do you suggest", r"priorit"]),
    ("score", [r"security score", r"how (are|is) (we|it) doing", r"\bposture\b", r"\bhealth\b"]),
    ("hub", [r"\bhub\b", r"messenger", r"unread", r"\bmessages?\b"]),
    ("offline", [r"\boffline\b", r"not connected", r"disconnected", r"\bdown\b"]),
    ("agent_detail", [r"\b(tell me about|details? (on|about|for)|status of)\b", r"\b(pc|host|computer)\b"]),
    ("agents", [r"\bagents?\b", r"who'?s (connected|online)", r"\bonline\b", r"\blab pcs?\b", r"\bcomputers?\b"]),
    ("blocked", [r"\bblock(ed|s)?\b", r"\bdenied\b", r"\brejected\b"]),
    ("events", [r"\bevents?\b", r"\busb\b", r"\bactivity\b", r"recent", r"timeline", r"what happened", r"\blog\b"]),
    ("anomalies", [r"suspicious", r"anomal", r"\brisk(y)?\b", r"threat", r"malicious", r"\bunusual\b"]),
    ("logins", [r"\blogins?\b", r"sign[- ]?in", r"credential"]),
    ("exam", [r"\bexam\b", r"lockdown"]),
    ("audit", [r"\baudit\b", r"admin activity", r"who did"]),
    ("summary", [r"\bsummary\b", r"\boverview\b", r"\bstatus\b", r"\breport\b"]),
]
_COMPILED = [(i, [re.compile(p, re.I) for p in ps]) for i, ps in _INTENTS]


def _classify(question):
    scores = {}
    for intent, pats in _COMPILED:
        s = sum(1 for p in pats if p.search(question))
        if s:
            scores[intent] = s
    if not scores:
        return None
    # specific beats generic when they tie
    order = [i for i, _ in _INTENTS]
    return sorted(scores, key=lambda i: (-scores[i], order.index(i)))[0]


def _reply(text, cards=None, suggestions=None, actions=None):
    return {"text": text, "cards": cards or [], "suggestions": suggestions or [], "actions": actions or []}


def _card(label, value, tone="ok"):
    return {"label": label, "value": str(value), "tone": tone}


def _handler(intent, q, snap, ctx):
    agent = _find_agent(q, snap) or (ctx.get("agent") if intent in ("agent_detail", "events") and re.search(r"\b(it|that|there|same|this one)\b", q, re.I) else None)
    hours = _hours_from(q, ctx.get("hours", 24))
    s = snap

    if intent == "help":
        return _reply(
            "Here is what I can do:\n"
            "• **Ask** – “brief me”, “security score”, “which agents are offline?”, “blocked devices in the last 6 hours”, “tell me about LAB-PC-3”\n"
            "• **Advise** – “what should I do?” gives prioritised next steps\n"
            "• **Act (with your confirmation)** – “start exam”, “override 123”, “allow device USB\\\\VID_…”, “message hub: need help in Lab 2”, “call hub”\n"
            "• **Slash commands** – /brief /risky /agents /hub /clear\n\n"
            "I also watch the system in the background and warn you about problems.",
            suggestions=["Brief me", "What should I do?", "Which agents are offline?", "Any hub messages?"])

    if intent == "briefing" or intent == "summary" and re.search(r"report|brief", q, re.I):
        parts = [f"**Security briefing** – score **{s['security_score']}/100** ({_tier(s['security_score'])})."]
        parts.append(f"• Agents: {s['agents_online']}/{s['agents_total']} online")
        parts.append(f"• USB (24 h): {s['blocked_last_24h']} blocked · {s['allowed_last_24h']} allowed · {s['overridden_last_24h']} overridden")
        parts.append(f"• Flagged devices: {len(s['high_risk_devices'])} · Exam: {'ACTIVE' if s['exam_active'] else 'idle'}")
        if s["hub_unread"]:
            parts.append(f"• Hub: {s['hub_unread']} unread message(s)")
        ins = generate_insights(s)
        if ins:
            parts.append("\n**Needs attention**")
            parts += [f"• {i['title']}" for i in ins[:4]]
        else:
            parts.append("\nNothing needs attention right now.")
        return _reply("\n".join(parts), cards=_overview_cards(s),
                      suggestions=["What should I do?", "Show risky devices", "Recent events"])

    if intent == "recommend":
        ins = generate_insights(s)
        if not ins:
            return _reply("All clear – nothing urgent. A good use of quiet time: retrain the anomaly model so it learns recent behaviour.",
                          actions=[_action("train_ai")], suggestions=["Brief me", "Security score"])
        ordered = sorted(ins, key=lambda i: {"critical": 0, "warning": 1, "info": 2}[i["severity"]])
        lines = ["Here is what I would do, in order:"]
        for n, i in enumerate(ordered[:5], 1):
            lines.append(f"{n}. **{i['title']}** – {i['detail']}")
        acts = []
        if any(i["id"] == "hub_unread" for i in ordered):
            acts.append({"id": "open_messenger", "type": "open_messenger", "label": "Open Messenger", "risk": "low"})
        return _reply("\n".join(lines), actions=acts, suggestions=["Show risky devices", "Which agents are offline?"])

    if intent == "score":
        sc = s["security_score"]
        return _reply(f"Security score is **{sc}/100** ({_tier(sc)}). It reflects blocked-USB activity in 24 h, anomaly flags and offline agents.",
                      cards=[_card("Score", f"{sc}/100", _tone(sc)), _card("Blocked 24h", s["blocked_last_24h"], "warn" if s["blocked_last_24h"] else "good"),
                             _card("Flagged", len(s["high_risk_devices"]), "bad" if s["high_risk_devices"] else "good"),
                             _card("Offline", s["agents_offline"], "warn" if s["agents_offline"] else "good")],
                      suggestions=["What should I do?", "Brief me"])

    if intent == "hub":
        lm = s.get("hub_last_message")
        if not lm:
            return _reply("No Hub messages yet. I can send one for you – say “message hub: …”.", suggestions=["Call hub"])
        txt = f"{'**' + str(s['hub_unread']) + ' unread**' if s['hub_unread'] else 'No unread'} Hub message(s). Latest from **{lm['from']}** ({_ago(lm['at'])}): “{lm['text'] or '[' + lm['kind'] + ']'}”"
        return _reply(txt, cards=[_card("Unread", s["hub_unread"], "warn" if s["hub_unread"] else "good")],
                      actions=[{"id": "open_messenger", "type": "open_messenger", "label": "Open Messenger", "risk": "low"}, _action("call_hub")])

    if intent == "offline":
        off = [a for a in s["agents"] if a["status"] != "online"]
        if not off:
            return _reply("Every registered agent is online.", suggestions=["Brief me"])
        lines = [f"• **{a['hostname']}** – last seen {_ago(a['last_seen'])}" + (f" · {a['user']}" if a.get("user") else "") for a in off[:10]]
        return _reply(f"{len(off)} agent(s) offline:\n" + "\n".join(lines), suggestions=[f"Tell me about {off[0]['hostname']}"])

    if intent == "agent_detail" and agent:
        a = next(x for x in s["agents"] if x["hostname"] == agent)
        ev = [e for e in s["events"] if e["host"] == agent and _parse_ts(e["ts"]) >= datetime.now() - timedelta(hours=hours)]
        blocked = [e for e in ev if e["status"] == "blocked"]
        lines = [f"**{agent}** is **{a['status']}** · user {a.get('user') or '—'} · IP {a.get('ip') or '—'} · last seen {_ago(a['last_seen'])}.",
                 f"In the last {hours} h: {len(ev)} USB event(s), {len(blocked)} blocked."]
        if ev:
            lines.append("Latest: " + ", ".join(f"{e['device'] or 'device'} ({e['status']})" for e in ev[:3]))
        _context_set(ctx, agent=agent, hours=hours)
        return _reply("\n".join(lines), suggestions=[f"Events for {agent}", "Which agents are offline?"])

    if intent == "agents" or (intent == "agent_detail" and re.search(r"\b(pc|host|computer)s?\b", q, re.I)):
        if agent:
            return _handler("agent_detail", q, s, ctx)
        lines = [f"• **{a['hostname']}** – {a['status']}" + (f" ({a['user']})" if a.get("user") else "") for a in s["agents"][:12]]
        return _reply(f"**{s['agents_online']} of {s['agents_total']}** agents online.\n" + "\n".join(lines),
                      cards=[_card("Online", s["agents_online"], "good"), _card("Offline", s["agents_offline"], "warn" if s["agents_offline"] else "good")],
                      suggestions=["Which agents are offline?", "Brief me"])

    if intent == "blocked":
        evs = [e for e in s["events"] if e["status"] == "blocked" and _parse_ts(e["ts"]) >= datetime.now() - timedelta(hours=hours)]
        if agent:
            evs = [e for e in evs if e["host"] == agent]
        if not evs:
            return _reply(f"No blocked USB events in the last {hours} h" + (f" on {agent}" if agent else "") + ". Clean.")
        top = Counter(e["device"] or "Unknown" for e in evs).most_common(3)
        txt = (f"**{len(evs)} blocked** USB event(s) in the last {hours} h" + (f" on {agent}" if agent else "") +
               f". {s['blocked_devices']} device(s) are on the block-list.\nTop: " + ", ".join(f"{n} ×{c}" for n, c in top))
        _context_set(ctx, hours=hours, agent=agent)
        return _reply(txt, cards=[_card("Blocked", len(evs), "warn"), _card("Block-list", s["blocked_devices"], "ok")],
                      suggestions=["Show risky devices", "What should I do?"])

    if intent == "events":
        evs = [e for e in s["events"] if _parse_ts(e["ts"]) >= datetime.now() - timedelta(hours=hours)]
        if agent:
            evs = [e for e in evs if e["host"] == agent]
        if not evs:
            return _reply(f"No USB events in the last {hours} h" + (f" for {agent}" if agent else "") + ".")
        lines = [f"• {_ago(e['ts'])} – **{e['device'] or 'device'}** on {e['host']} → {e['status']} (id {e['id']})" for e in evs[:8]]
        _context_set(ctx, hours=hours, agent=agent)
        return _reply(f"{len(evs)} event(s) in the last {hours} h" + (f" for {agent}" if agent else "") + ":\n" + "\n".join(lines),
                      suggestions=["Only blocked", "Last 1 hour"])

    if intent == "anomalies":
        risky = s["high_risk_devices"]
        if not risky:
            return _reply("No devices are currently flagged as anomalous.", suggestions=["Brief me"])
        lines = [f"• **{d['device_id']}** – score {d['score']} ({d['status']})" for d in risky[:6]]
        return _reply("Flagged devices:\n" + "\n".join(lines), cards=[_card("Flagged", len(risky), "bad")],
                      actions=[_action("train_ai")], suggestions=["What should I do?"])

    if intent == "logins":
        return _reply("I track login anomalies (new IP, new PC, high login rate, browser switching) as agents report them. "
                      "Ask about a hostname for its recent activity." if AI_ANOMALY_AVAILABLE else "The login anomaly detector isn't loaded on this server.",
                      suggestions=["Brief me"])

    if intent == "exam":
        return _reply("An exam session is **active**." if s["exam_active"] else "No exam session is active.",
                      actions=[_action("stop_exam")] if s["exam_active"] else [_action("start_exam")])

    if intent == "audit":
        return _reply("Recent admin activity:\n" + "\n".join(f"• {a}" for a in s["recent_audit"]) if s["recent_audit"] else "No recent admin actions logged.")

    if intent == "summary":
        return _handler("briefing", q, s, ctx)
    return None


def _context_set(ctx, **kw):
    ctx.update({k: v for k, v in kw.items() if v})


def _overview_cards(s):
    sc = s["security_score"]
    return [_card("Score", f"{sc}/100", _tone(sc)), _card("Agents", f"{s['agents_online']}/{s['agents_total']}", "ok"),
            _card("Blocked 24h", s["blocked_last_24h"], "warn" if s["blocked_last_24h"] else "good"),
            _card("Flagged", len(s["high_risk_devices"]), "bad" if s["high_risk_devices"] else "good")]


# ---------------------------------------------------------------------------
# Actions (propose only - the widget asks the admin to confirm)
# ---------------------------------------------------------------------------
def _action(kind, **params):
    meta = ACTION_CATALOG[kind]
    label = meta["label"] + (f" {params['event_id']}" if "event_id" in params else f" ({params['device_id']})" if "device_id" in params else "")
    return {"id": kind, "type": kind, "label": label, "risk": meta["risk"], "params": params,
            "action": f"{kind} {params.get('event_id', params.get('device_id', ''))}".strip()}   # legacy field


def _detect_action(question):
    q = question.strip()
    ql = q.lower()
    m = re.match(r"(?:/hub|(?:please )?(?:message|tell|send|notify|ping)(?: the)? hub)\s*[:,\-]?\s*(.+)", q, re.I)
    if m and len(m.group(1).strip()) > 1:
        return "message_hub", {"text": m.group(1).strip()[:500]}
    if re.search(r"\b(call|ring|phone|video call)\b.*\bhub\b|\bhub\b.*\b(call|ring)\b", ql) and "?" not in ql:
        return "call_hub", {}
    m = re.search(r"override\s+(?:device\s+|event\s+)?#?(\d+)", ql)
    if m:
        return "override_device", {"event_id": int(m.group(1))}
    m = re.search(r"(?:allow|whitelist|trust)\s+device\s+(\S+)|whitelist\s+(\S+)", q, re.I)
    if m:
        return "allow_device", {"device_id": m.group(1) or m.group(2)}
    m = re.search(r"unblock\s+(?:device\s+)?(\S+)", q, re.I)
    if m:
        return "unblock_device", {"device_id": m.group(1)}
    if re.search(r"\b(start|begin|enable)\s+(the\s+)?(exam|lockdown)\b", ql):
        return "start_exam", {}
    if re.search(r"\b(stop|end|finish|disable)\s+(the\s+)?(exam|lockdown)\b", ql):
        return "stop_exam", {}
    if re.search(r"\btrain\s+(the\s+)?(ai|model|anomaly)", ql):
        return "train_ai", {}
    if re.search(r"\b(generate|create|make)\s+(an?\s+)?(ai\s+)?report\b", ql):
        return "generate_report", {}
    return None


# ---------------------------------------------------------------------------
# Optional Claude path (read-only tools + propose_action)
# ---------------------------------------------------------------------------
_TOOLS = [
    {"name": "get_snapshot", "description": "Current SentryUSB system snapshot (agents, 24h USB stats, flagged devices, exam state, Hub unread count, security score).",
     "input_schema": {"type": "object", "properties": {}}},
    {"name": "recent_events", "description": "Recent USB events, optionally filtered.",
     "input_schema": {"type": "object", "properties": {"hours": {"type": "integer"}, "hostname": {"type": "string"},
                                                       "status": {"type": "string", "enum": ["blocked", "allowed", "overridden"]}}}},
    {"name": "propose_action", "description": "Offer the admin a button for an action. This NEVER executes anything; the admin must confirm.",
     "input_schema": {"type": "object", "properties": {"type": {"type": "string", "enum": sorted(ACTION_CATALOG)},
                                                       "params": {"type": "object"}, "reason": {"type": "string"}}, "required": ["type"]}},
]


def _anthropic_answer(question, snap, history):
    if not getattr(config, "AI_CHAT_USE_ANTHROPIC", False):
        return None
    api_key = getattr(config, "AI_CHAT_ANTHROPIC_API_KEY", "")
    if not api_key:
        return None
    system = ("You are the AI security assistant inside SentryUSB, a USB / lab-endpoint security console. "
              "Use the tools to read live data; never invent figures. Be concise and operational (max ~120 words), "
              "use short bullets and **bold** sparingly. You cannot execute actions - use propose_action to offer a button. "
              "If data is missing, say so.")
    messages = list(history) + [{"role": "user", "content": question}]
    proposed = []

    def call(msgs):
        body = json.dumps({"model": getattr(config, "AI_CHAT_ANTHROPIC_MODEL", "claude-sonnet-4-6"), "max_tokens": 700,
                           "system": system, "tools": _TOOLS, "messages": msgs}).encode()
        req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=body, method="POST",
                                     headers={"Content-Type": "application/json", "x-api-key": api_key,
                                              "anthropic-version": "2023-06-01"})
        with urllib.request.urlopen(req, timeout=25) as resp:
            return json.loads(resp.read().decode())

    try:
        for _ in range(4):
            data = call(messages)
            blocks = data.get("content", [])
            if data.get("stop_reason") != "tool_use":
                text = "\n".join(b.get("text", "") for b in blocks if b.get("type") == "text").strip()
                return (text, proposed) if text else None
            messages.append({"role": "assistant", "content": blocks})
            results = []
            for b in blocks:
                if b.get("type") != "tool_use":
                    continue
                name, inp = b["name"], b.get("input") or {}
                if name == "get_snapshot":
                    out = {k: v for k, v in snap.items() if k not in ("events", "agents")}
                    out["agents"] = snap["agents"][:40]
                elif name == "recent_events":
                    cut = datetime.now() - timedelta(hours=int(inp.get("hours") or 24))
                    out = [e for e in snap["events"] if _parse_ts(e["ts"]) >= cut
                           and (not inp.get("hostname") or e["host"] == inp["hostname"])
                           and (not inp.get("status") or e["status"] == inp["status"])][:40]
                elif name == "propose_action" and inp.get("type") in ACTION_CATALOG:
                    proposed.append(_action(inp["type"], **(inp.get("params") or {})))
                    out = {"ok": True, "note": "Shown to the admin as a confirm button."}
                else:
                    out = {"error": "unknown tool"}
                results.append({"type": "tool_result", "tool_use_id": b["id"], "content": json.dumps(out, default=str)})
            messages.append({"role": "user", "content": results})
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, ValueError, KeyError) as e:
        log.warning("Anthropic chat failed, using local engine: %s", e)
    return None


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def answer(question, admin_user="admin", injected_context=None):
    question = (question or "").strip()
    snap = get_system_snapshot()
    if injected_context:
        snap.update(injected_context)
    ctx = _context.setdefault(admin_user, {})

    if not question:
        r = _handler("briefing", "brief", snap, ctx)
        return _finish(admin_user, "(opened)", r, "local", snap)
    _remember(admin_user, "user", question)

    act = _detect_action(question)
    if act:
        kind, params = act
        if kind == "message_hub":
            text = f"Ready to send this to the Hub: “{params['text']}”"
        elif kind == "call_hub":
            text = "Ready to start a voice call with the Hub."
        elif kind in ("start_exam", "stop_exam", "train_ai", "generate_report"):
            text = f"{ACTION_CATALOG[kind]['label']} – confirm below."
        else:
            text = f"{ACTION_CATALOG[kind]['label']}: " + ", ".join(f"{k} {v}" for k, v in params.items()) + " – confirm below."
        return _finish(admin_user, question, _reply(text, actions=[_action(kind, **params)]), "local", snap)

    if re.match(r"^\s*(block|ban)\s+\S+", question, re.I):
        return _finish(admin_user, question, _reply(
            "Manual blocking isn't wired into the console yet – devices are blocked automatically by policy and the block-list. "
            "I can allow-list a device, override a blocked one, or review risky devices instead.",
            suggestions=["Show risky devices", "Recent blocked events"]), "local", snap)

    intent = _classify(question)
    # follow-ups: bare entity / modifier with no intent -> reuse last intent
    if not intent and (_find_agent(question, snap) or re.search(r"\b(only|just|also|and|what about|how about|more)\b|last \d+", question, re.I)):
        intent = ctx.get("intent")
    if intent:
        r = _handler(intent, question, snap, ctx)
        if r:
            ctx["intent"] = intent
            return _finish(admin_user, question, r, "local", snap)

    remote = _anthropic_answer(question, snap, _history.get(admin_user, [])[:-1])
    if remote:
        text, proposed = remote
        return _finish(admin_user, question, _reply(text, actions=proposed, suggestions=["Brief me", "What should I do?"]), "anthropic", snap)

    r = _handler("briefing", "brief", snap, ctx)
    r["text"] = "I'm not sure I understood that, but here's where things stand:\n\n" + r["text"]
    r["suggestions"] = ["Help", "What should I do?", "Which agents are offline?"]
    return _finish(admin_user, question, r, "local", snap)


def _finish(admin_user, question, r, source, snap):
    _remember(admin_user, "assistant", r["text"])
    return {"answer": r["text"], "source": source, "cards": r["cards"], "suggestions": r["suggestions"],
            "actions": r["actions"], "insight_count": len(generate_insights(snap))}


# ---------------------------------------------------------------------------
# Autopilot: background watcher that pushes new insights to the widget
# ---------------------------------------------------------------------------
_autopilot = {"thread": None, "announced": {}, "latest": []}


def current_insights(injected_context=None):
    snap = get_system_snapshot()
    if injected_context:
        snap.update(injected_context)
    ins = generate_insights(snap)
    _autopilot["latest"] = ins
    return ins


def start_autopilot(socketio, context_fn=None, interval=60, cooldown=1800):
    """Start once. Emits 'ai_insight' for each *new* insight (re-announced after `cooldown`)."""
    if _autopilot["thread"]:
        return

    def loop():
        time.sleep(15)
        while True:
            try:
                ins = current_insights(context_fn() if context_fn else None)
                now = time.time()
                for i in ins:
                    if i["severity"] == "info":
                        continue                       # info stays in the panel; only warn/critical push
                    if now - _autopilot["announced"].get(i["id"], 0) > cooldown:
                        _autopilot["announced"][i["id"]] = now
                        socketio.emit("ai_insight", i)
                live = {i["id"] for i in ins}
                for k in list(_autopilot["announced"]):
                    if k not in live:
                        _autopilot["announced"].pop(k, None)   # resolved -> may fire again if it recurs
            except Exception as e:
                log.debug("autopilot tick failed: %s", e)
            time.sleep(interval)

    t = threading.Thread(target=loop, daemon=True, name="ai-autopilot")
    t.start()
    _autopilot["thread"] = t
