# server/ai_enhanced/ml_anomaly.py
"""
Machine Learning Anomaly Detection using Isolation Forest
"""
import logging
import pickle
import os
import numpy as np
from datetime import datetime, timedelta
from collections import defaultdict

# Try importing sklearn – we know it's installed from requirements.txt
try:
    from sklearn.ensemble import IsolationForest
    from sklearn.preprocessing import StandardScaler
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    print("⚠️ scikit-learn not available. Using fallback heuristics.")

log = logging.getLogger("sentryusb.ml_anomaly")

class MLAnomalyDetector:
    def __init__(self, model_path="ai_models/anomaly_model.pkl"):
        self.model_path = model_path
        self.model = None
        self.scaler = None
        self.device_profiles = {}  # Store historical features for each device
        self._load_model()
    
    def _load_model(self):
        """Load trained model from disk if exists"""
        if not SKLEARN_AVAILABLE:
            return
        try:
            if os.path.exists(self.model_path):
                with open(self.model_path, 'rb') as f:
                    data = pickle.load(f)
                    self.model = data.get('model')
                    self.scaler = data.get('scaler')
                log.info("✅ Loaded ML anomaly model")
            else:
                log.info("No existing ML model found. Will train on first data.")
        except Exception as e:
            log.error(f"Failed to load model: {e}")
    
    def _save_model(self):
        """Save trained model to disk"""
        if not SKLEARN_AVAILABLE or self.model is None:
            return
        try:
            os.makedirs(os.path.dirname(self.model_path), exist_ok=True)
            with open(self.model_path, 'wb') as f:
                pickle.dump({
                    'model': self.model,
                    'scaler': self.scaler,
                    'trained_at': datetime.now().isoformat()
                }, f)
            log.info("✅ ML anomaly model saved")
        except Exception as e:
            log.error(f"Failed to save model: {e}")
    
    def extract_features(self, device_events):
        """
        Extract numerical features from a device's event history.
        Returns a feature vector suitable for ML.
        """
        if not device_events:
            return None
        
        # We'll compute various statistics
        total = len(device_events)
        
        # Connection frequency (events per day)
        timestamps = [e.get('timestamp') for e in device_events if e.get('timestamp')]
        if timestamps:
            try:
                first = datetime.fromisoformat(timestamps[0])
                last = datetime.fromisoformat(timestamps[-1])
                days = max(1, (last - first).days)
                freq = total / days
            except:
                freq = 0
        else:
            freq = 0
        
        # Unique hosts
        hosts = set(e.get('hostname') for e in device_events if e.get('hostname'))
        unique_hosts = len(hosts)
        
        # Status distribution
        blocked = sum(1 for e in device_events if e.get('status') == 'blocked')
        overridden = sum(1 for e in device_events if e.get('status') == 'overridden')
        allowed = sum(1 for e in device_events if e.get('status') == 'allowed')
        connected = sum(1 for e in device_events if e.get('status') == 'connected')
        
        block_rate = blocked / total if total else 0
        override_rate = overridden / total if total else 0
        allowed_rate = allowed / total if total else 0
        
        # Duration statistics
        durations = [e.get('duration_seconds', 0) for e in device_events if e.get('duration_seconds')]
        avg_duration = sum(durations) / len(durations) if durations else 0
        max_duration = max(durations) if durations else 0
        
        # Connection interval (time between events)
        intervals = []
        for i in range(1, len(timestamps)):
            try:
                t1 = datetime.fromisoformat(timestamps[i-1])
                t2 = datetime.fromisoformat(timestamps[i])
                intervals.append((t2 - t1).total_seconds())
            except:
                pass
        avg_interval = sum(intervals) / len(intervals) if intervals else 0
        std_interval = np.std(intervals) if intervals else 0
        
        # Hour of day distribution (peak hour score)
        hours = []
        for ts in timestamps:
            try:
                hour = datetime.fromisoformat(ts).hour
                hours.append(hour)
            except:
                pass
        if hours:
            hour_counts = defaultdict(int)
            for h in hours:
                hour_counts[h] += 1
            # Check if events are concentrated in few hours (low entropy = suspicious)
            probs = [c / len(hours) for c in hour_counts.values()]
            entropy = -sum(p * np.log(p) for p in probs) if probs else 0
        else:
            entropy = 0
        
        # Feature vector
        features = [
            freq,                      # 0
            unique_hosts,              # 1
            block_rate,                # 2
            override_rate,             # 3
            allowed_rate,              # 4
            avg_duration / 3600,       # 5 (hours)
            max_duration / 3600,       # 6 (hours)
            avg_interval / 3600,       # 7 (hours)
            std_interval / 3600,       # 8 (hours)
            entropy,                   # 9
            total / 100,               # 10 (normalized count)
        ]
        return np.array(features).reshape(1, -1)
    
    def train(self, all_events_by_device):
        """
        Train the Isolation Forest model on historical device events.
        all_events_by_device: dict {device_id: [list_of_events]}
        """
        if not SKLEARN_AVAILABLE:
            log.warning("sklearn not available, cannot train ML model")
            return False
        
        feature_vectors = []
        device_ids = []
        
        for device_id, events in all_events_by_device.items():
            if len(events) < 10:  # Need enough data
                continue
            features = self.extract_features(events)
            if features is not None:
                feature_vectors.append(features.flatten())
                device_ids.append(device_id)
                # Store the features for later prediction
                self.device_profiles[device_id] = {
                    'features': features.flatten(),
                    'events': events
                }
        
        if len(feature_vectors) < 10:
            log.warning(f"Only {len(feature_vectors)} devices with enough data. Need at least 10 to train.")
            return False
        
        X = np.array(feature_vectors)
        
        # Scale features
        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X)
        
        # Train Isolation Forest
        self.model = IsolationForest(
            contamination=0.05,  # Expect ~5% anomalies
            random_state=42,
            n_estimators=100,
            max_samples='auto'
        )
        self.model.fit(X_scaled)
        
        self._save_model()
        log.info(f"✅ Trained ML anomaly model on {len(feature_vectors)} devices")
        return True
    
    def predict_anomaly(self, device_id, recent_events):
        """
        Predict if a device is anomalous based on recent events.
        Returns (score, status, details)
        """
        if not SKLEARN_AVAILABLE or self.model is None or self.scaler is None:
            # Fallback to heuristic if ML not available
            return self._fallback_heuristic(device_id, recent_events)
        
        # Extract features from recent events
        features = self.extract_features(recent_events)
        if features is None:
            return 0, "unknown", {"reason": "Insufficient data"}
        
        # Scale
        features_scaled = self.scaler.transform(features)
        
        # Predict: -1 = anomaly, 1 = normal
        pred = self.model.predict(features_scaled)
        # Get anomaly score (decision function)
        score_raw = self.model.decision_function(features_scaled)
        # Convert to 0-100 (higher = more anomalous)
        # decision_function gives negative for anomalies, positive for normal
        # We'll map to 0-100 where 100 is highly anomalous
        score = max(0, min(100, 50 - score_raw[0] * 20))
        
        status = "anomaly" if pred[0] == -1 else "normal"
        
        # Add explanation
        reasons = []
        if pred[0] == -1:
            # Find which features contributed most (simple approach)
            # In real implementation, we'd use SHAP or feature importance
            reasons.append("Device behavior deviates from normal patterns")
        
        # Compare with historical profile if exists
        if device_id in self.device_profiles:
            hist_features = self.device_profiles[device_id]['features']
            # Simple distance measure (could be improved)
            dist = np.linalg.norm(features.flatten() - hist_features)
            if dist > 2.0:
                reasons.append("Significant change from historical behavior")
        
        return {
            'anomaly_score': int(score),
            'status': status,
            'reasons': reasons,
            'raw_prediction': int(pred[0])
        }
    
    def _fallback_heuristic(self, device_id, recent_events):
        """Fallback heuristic when ML unavailable"""
        # Simple heuristic based on block rate and host diversity
        if not recent_events:
            return {'anomaly_score': 0, 'status': 'unknown', 'reasons': []}
        
        total = len(recent_events)
        blocked = sum(1 for e in recent_events if e.get('status') == 'blocked')
        hosts = set(e.get('hostname') for e in recent_events if e.get('hostname'))
        
        score = 0
        reasons = []
        
        if blocked / total > 0.8:
            score += 40
            reasons.append("Very high block rate")
        
        if len(hosts) > 3:
            score += 30
            reasons.append("Device used on many PCs")
        
        if total > 20 and len(hosts) == 1 and blocked / total > 0.5:
            score += 20
            reasons.append("Persistent blocking on single PC")
        
        return {
            'anomaly_score': min(score, 100),
            'status': 'suspicious' if score > 50 else 'normal',
            'reasons': reasons
        }