# server/ai_enhanced/integrity_checker.py
"""
System Integrity and Security Verification
"""
import logging
import hashlib
import os
import subprocess
from datetime import datetime
from typing import Dict, List, Optional
import json

log = logging.getLogger("sentryusb.integrity_checker")


class IntegrityChecker:
    """
    System integrity checker for detecting tampering
    
    Features:
    - File integrity monitoring
    - Process integrity verification
    - System state verification
    - Anti-tampering detection
    """
    
    def __init__(self):
        self.baseline = {}
        self.integrity_log = []
        self._max_log = 500
        self._load_baseline()
        
        log.info("IntegrityChecker initialized")
    
    def _load_baseline(self):
        """Load integrity baseline"""
        baseline_path = os.path.join(
            os.path.dirname(__file__), 
            "ai_models", 
            "integrity_baseline.json"
        )
        if os.path.exists(baseline_path):
            try:
                with open(baseline_path, 'r') as f:
                    self.baseline = json.load(f)
                log.info(f"Integrity baseline loaded ({len(self.baseline)} files)")
            except Exception as e:
                log.error(f"Failed to load baseline: {e}")
        else:
            log.warning("No integrity baseline found. Run create_baseline() first.")
    
    def create_baseline(self, files: List[str] = None):
        """
        Create an integrity baseline for specified files
        
        Args:
            files: List of file paths to include in baseline
        """
        if files is None:
            # Default critical files
            files = [
                # System files
                r"C:\Windows\System32\ntoskrnl.exe",
                r"C:\Windows\System32\winlogon.exe",
                r"C:\Windows\System32\services.exe",
                r"C:\Windows\System32\lsass.exe",
                r"C:\Windows\System32\svchost.exe",
                # SentryUSB files
                os.path.join(os.path.dirname(__file__), "..", "agent.py"),
                os.path.join(os.path.dirname(__file__), "..", "device_utils.py"),
                os.path.join(os.path.dirname(__file__), "..", "config.py"),
            ]
        
        baseline = {}
        for file_path in files:
            if os.path.exists(file_path):
                try:
                    with open(file_path, 'rb') as f:
                        file_hash = hashlib.sha256(f.read()).hexdigest()
                    baseline[file_path] = {
                        'hash': file_hash,
                        'size': os.path.getsize(file_path),
                        'modified': datetime.fromtimestamp(os.path.getmtime(file_path)).isoformat(),
                        'created_at': datetime.now().isoformat()
                    }
                except Exception as e:
                    log.error(f"Failed to hash {file_path}: {e}")
        
        self.baseline = baseline
        self._save_baseline()
        log.info(f"Created integrity baseline for {len(baseline)} files")
    
    def _save_baseline(self):
        """Save integrity baseline to disk"""
        baseline_path = os.path.join(
            os.path.dirname(__file__), 
            "ai_models", 
            "integrity_baseline.json"
        )
        try:
            os.makedirs(os.path.dirname(baseline_path), exist_ok=True)
            with open(baseline_path, 'w') as f:
                json.dump(self.baseline, f, indent=2)
            log.info("Integrity baseline saved")
        except Exception as e:
            log.error(f"Failed to save baseline: {e}")
    
    def check_file_integrity(self, file_path: str) -> Dict:
        """
        Check if a file has been tampered with
        
        Returns:
            Dict with integrity status
        """
        result = {
            'file': file_path,
            'status': 'unknown',
            'timestamp': datetime.now().isoformat()
        }
        
        if not os.path.exists(file_path):
            result['status'] = 'missing'
            return result
        
        try:
            # Calculate current hash
            with open(file_path, 'rb') as f:
                current_hash = hashlib.sha256(f.read()).hexdigest()
            
            result['current_hash'] = current_hash
            result['size'] = os.path.getsize(file_path)
            
            # Check against baseline
            if file_path in self.baseline:
                expected = self.baseline[file_path]
                if current_hash != expected.get('hash'):
                    result['status'] = 'modified'
                    result['expected_hash'] = expected.get('hash')
                    result['expected_size'] = expected.get('size')
                    result['severity'] = self._classify_severity(file_path)

                    # Size-delta as an extra tamper signal: a small size delta
                    # on a large binary is consistent with a targeted patch
                    # (e.g. a single-byte jump-instruction patch or injected
                    # shellcode stub) rather than a full legitimate rebuild,
                    # which is worth flagging distinctly for triage.
                    expected_size = expected.get('size')
                    if expected_size:
                        delta = abs(result['size'] - expected_size)
                        result['size_delta_bytes'] = delta
                        if expected_size > 100_000 and delta < 4096:
                            result['tamper_pattern'] = 'small_targeted_patch'
                else:
                    result['status'] = 'ok'
            else:
                result['status'] = 'unverified'
                
        except Exception as e:
            log.error(f"Failed to check integrity of {file_path}: {e}")
            result['status'] = 'error'
            result['error'] = str(e)
        
        return result
    
    # Files whose tampering has outsized security impact - core OS trust
    # boundary, credential surfaces, or the agent's own binaries (an attacker
    # disabling the monitor itself is a critical event, not a routine one).
    _CRITICAL_NAME_MARKERS = ('ntoskrnl', 'winlogon', 'lsass', 'services.exe',
                               'sentryusb', 'agent.exe', 'agent.py')

    def _classify_severity(self, file_path: str) -> str:
        """Classify how severe a detected modification is, based on what
        kind of file was altered."""
        lower = file_path.lower()
        if any(marker in lower for marker in self._CRITICAL_NAME_MARKERS):
            return 'critical'
        if 'system32' in lower or 'syswow64' in lower:
            return 'high'
        return 'medium'

    def verify_critical_files(self) -> Dict:
        """
        Verify integrity of critical system files
        
        Returns:
            Dict with verification results
        """
        results = {
            'verified': 0,
            'modified': 0,
            'missing': 0,
            'unverified': 0,
            'error': 0,
            'details': [],
            'timestamp': datetime.now().isoformat()
        }
        
        # Use all files in baseline or default critical files
        files_to_check = list(self.baseline.keys()) if self.baseline else []
        
        # If no baseline, check default critical files
        if not files_to_check:
            default_files = [
                r"C:\Windows\System32\ntoskrnl.exe",
                r"C:\Windows\System32\winlogon.exe",
                r"C:\Windows\System32\services.exe",
            ]
            files_to_check = [f for f in default_files if os.path.exists(f)]
        
        for file_path in files_to_check:
            result = self.check_file_integrity(file_path)
            results['details'].append(result)
            
            if result['status'] == 'ok':
                results['verified'] += 1
            elif result['status'] == 'modified':
                results['modified'] += 1
                log.warning(f"⚠️ File modified: {file_path}")
            elif result['status'] == 'missing':
                results['missing'] += 1
                log.warning(f"⚠️ File missing: {file_path}")
            elif result['status'] == 'unverified':
                results['unverified'] += 1
            else:
                results['error'] += 1
        
        # Aggregate risk score, weighted by severity of each modified file,
        # combined via noisy-OR for consistency with the other AI modules
        severity_weights = {'critical': 0.9, 'high': 0.6, 'medium': 0.35}
        p_benign = 1.0
        for detail in results['details']:
            if detail.get('status') == 'modified':
                w = severity_weights.get(detail.get('severity', 'medium'), 0.35)
                p_benign *= (1 - w)
            elif detail.get('status') == 'missing':
                p_benign *= (1 - 0.5)
        results['risk_score'] = round(min(1 - p_benign, 1.0), 3)

        # Log to integrity log
        self.integrity_log.append(results)
        if len(self.integrity_log) > self._max_log:
            self.integrity_log = self.integrity_log[-self._max_log:]
        
        return results
    
    def check_process_integrity(self, process_name: str) -> Dict:
        """
        Check if a process is running and verify its integrity
        
        Returns:
            Dict with process status
        """
        result = {
            'process': process_name,
            'running': False,
            'integrity': 'unknown',
            'timestamp': datetime.now().isoformat()
        }
        
        try:
            import psutil
            for proc in psutil.process_iter(['pid', 'name', 'exe']):
                try:
                    if proc.info['name'].lower() == process_name.lower():
                        result['running'] = True
                        result['pid'] = proc.info['pid']
                        result['exe'] = proc.info['exe']
                        
                        # Check executable integrity
                        if proc.info['exe'] and os.path.exists(proc.info['exe']):
                            integrity_result = self.check_file_integrity(proc.info['exe'])
                            result['integrity'] = integrity_result['status']
                        
                        break
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        except Exception as e:
            log.error(f"Failed to check process {process_name}: {e}")
            result['error'] = str(e)
        
        return result
    
    def get_integrity_report(self) -> Dict:
        """Generate integrity report"""
        return {
            'status': 'active' if self.baseline else 'inactive',
            'baseline_exists': bool(self.baseline),
            'baseline_entries': len(self.baseline),
            'last_check': self.integrity_log[-1]['timestamp'] if self.integrity_log else None,
            'integrity_log': self.integrity_log[-20:],
            'issues_found': sum(1 for log in self.integrity_log[-20:] if log.get('modified', 0) > 0)
        }