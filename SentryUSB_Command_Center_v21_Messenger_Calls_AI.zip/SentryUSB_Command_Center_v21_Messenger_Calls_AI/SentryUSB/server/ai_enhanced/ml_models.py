# server/ai_enhanced/ml_models.py
"""
Enhanced Machine Learning Models for SentryUSB
"""
import json
import logging
import pickle
import os
from datetime import datetime
from typing import Dict, List, Optional, Tuple
import numpy as np
from collections import defaultdict

log = logging.getLogger("sentryusb.ml_models")

try:
    from sklearn.ensemble import IsolationForest, RandomForestClassifier
    from sklearn.preprocessing import StandardScaler
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import accuracy_score, precision_score, recall_score
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False
    log.warning("scikit-learn not available. ML features will be limited.")


class MLModelManager:
    """
    Manages machine learning models for anomaly detection
    
    Models supported:
    - Isolation Forest for anomaly detection
    - Random Forest for classification
    - LSTM for sequence prediction (if TensorFlow available)
    """
    
    def __init__(self, model_path: str = "ai_models/ml"):
        self.model_path = model_path
        os.makedirs(model_path, exist_ok=True)
        
        self.models = {}
        self.scalers = {}
        self.feature_importance = {}
        self.training_history = []
        self.model_metadata = {}
        
        # Load existing models
        self._load_models()
        
        log.info(f"MLModelManager initialized with {len(self.models)} models")
    
    def _load_models(self):
        """Load trained models from disk"""
        model_files = [f for f in os.listdir(self.model_path) if f.endswith('.pkl')]
        for model_file in model_files:
            try:
                model_name = model_file.replace('.pkl', '')
                with open(os.path.join(self.model_path, model_file), 'rb') as f:
                    self.models[model_name] = pickle.load(f)
                
                # Load scaler if exists
                scaler_file = model_file.replace('.pkl', '_scaler.pkl')
                if os.path.exists(os.path.join(self.model_path, scaler_file)):
                    with open(os.path.join(self.model_path, scaler_file), 'rb') as f:
                        self.scalers[model_name] = pickle.load(f)
                
                # Load metadata if exists
                meta_file = model_file.replace('.pkl', '_meta.json')
                if os.path.exists(os.path.join(self.model_path, meta_file)):
                    with open(os.path.join(self.model_path, meta_file), 'r') as f:
                        self.model_metadata[model_name] = json.load(f)
                
                log.info(f"Loaded model: {model_name}")
            except Exception as e:
                log.error(f"Failed to load model {model_file}: {e}")
    
    def _save_model(self, model, model_name: str, scaler=None, metadata: Dict = None):
        """Save model and associated files"""
        try:
            # Save model
            with open(os.path.join(self.model_path, f"{model_name}.pkl"), 'wb') as f:
                pickle.dump(model, f)
            
            # Save scaler
            if scaler:
                with open(os.path.join(self.model_path, f"{model_name}_scaler.pkl"), 'wb') as f:
                    pickle.dump(scaler, f)
            
            # Save metadata
            if metadata:
                with open(os.path.join(self.model_path, f"{model_name}_meta.json"), 'w') as f:
                    json.dump(metadata, f, indent=2)
            
            log.info(f"Saved model: {model_name}")
            return True
        except Exception as e:
            log.error(f"Failed to save model {model_name}: {e}")
            return False
    
    def train_anomaly_model(self, data: List[Dict]) -> Dict:
        """
        Train anomaly detection model using Isolation Forest
        
        Args:
            data: List of feature vectors
            
        Returns:
            Dict with training results
        """
        if not SKLEARN_AVAILABLE:
            return {'error': 'scikit-learn not available'}
        
        if len(data) < 10:
            return {'error': 'Insufficient data for training (need at least 10 samples)'}
        
        try:
            # Extract features
            features = self._extract_features(data)
            
            # Scale features
            scaler = StandardScaler()
            features_scaled = scaler.fit_transform(features)
            
            # Train Isolation Forest
            model = IsolationForest(
                contamination=0.1,
                random_state=42,
                n_estimators=100,
                max_samples='auto'
            )
            model.fit(features_scaled)
            
            # Generate model name
            model_name = f"isolation_forest_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            # Prepare metadata
            metadata = {
                'type': 'isolation_forest',
                'contamination': 0.1,
                'n_estimators': 100,
                'samples': len(data),
                'features': features.shape[1] if features.shape[0] > 0 else 0,
                'trained_at': datetime.now().isoformat(),
                'version': '2.0.0'
            }
            
            # Save model
            self._save_model(model, model_name, scaler, metadata)
            
            # Store in memory
            self.models[model_name] = model
            self.scalers[model_name] = scaler
            self.model_metadata[model_name] = metadata
            self.training_history.append({
                'model': model_name,
                'type': 'anomaly',
                'samples': len(data),
                'timestamp': datetime.now().isoformat()
            })
            
            return {
                'success': True,
                'model_name': model_name,
                'samples': len(data),
                'features': features.shape[1] if features.shape[0] > 0 else 0,
                'contamination': 0.1,
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            log.error(f"Failed to train anomaly model: {e}")
            return {'error': str(e)}
    
    def train_classification_model(self, data: List[Dict], labels: List[int]) -> Dict:
        """
        Train a classification model for threat detection
        
        Args:
            data: List of feature vectors
            labels: List of labels (0 = benign, 1 = malicious)
            
        Returns:
            Dict with training results
        """
        if not SKLEARN_AVAILABLE:
            return {'error': 'scikit-learn not available'}
        
        if len(data) < 20:
            return {'error': 'Insufficient data for training (need at least 20 samples)'}
        
        try:
            features = self._extract_features(data)
            
            # Split data
            X_train, X_test, y_train, y_test = train_test_split(
                features, labels, test_size=0.2, random_state=42
            )
            
            # Train classifier
            model = RandomForestClassifier(
                n_estimators=100,
                random_state=42,
                max_depth=10,
                min_samples_split=5,
                n_jobs=-1
            )
            model.fit(X_train, y_train)
            
            # Evaluate
            y_pred = model.predict(X_test)
            accuracy = accuracy_score(y_test, y_pred)
            precision = precision_score(y_test, y_pred, average='weighted', zero_division=0)
            recall = recall_score(y_test, y_pred, average='weighted', zero_division=0)
            
            # Generate model name
            model_name = f"classifier_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            
            # Prepare metadata
            metadata = {
                'type': 'random_forest',
                'n_estimators': 100,
                'max_depth': 10,
                'samples': len(data),
                'features': features.shape[1] if features.shape[0] > 0 else 0,
                'accuracy': float(accuracy),
                'precision': float(precision),
                'recall': float(recall),
                'trained_at': datetime.now().isoformat(),
                'version': '2.0.0'
            }
            
            # Save model
            self._save_model(model, model_name, None, metadata)
            
            # Store in memory
            self.models[model_name] = model
            self.model_metadata[model_name] = metadata
            self.training_history.append({
                'model': model_name,
                'type': 'classification',
                'samples': len(data),
                'accuracy': float(accuracy),
                'timestamp': datetime.now().isoformat()
            })
            
            return {
                'success': True,
                'model_name': model_name,
                'samples': len(data),
                'features': features.shape[1] if features.shape[0] > 0 else 0,
                'accuracy': float(accuracy),
                'precision': float(precision),
                'recall': float(recall),
                'timestamp': datetime.now().isoformat()
            }
            
        except Exception as e:
            log.error(f"Failed to train classification model: {e}")
            return {'error': str(e)}
    
    def _extract_features(self, data: List[Dict]) -> np.ndarray:
        """
        Extract feature vectors from data
        
        Features extracted:
        - Connection frequency
        - Time-based features
        - Device diversity
        - Status distribution
        - Behavioral patterns
        """
        features = []
        
        for item in data:
            feature_vector = []
            
            # 1. Connection count (normalized)
            conn_count = item.get('connection_count', 0)
            feature_vector.append(min(conn_count / 100, 1.0))
            
            # 2. Unique hosts (normalized)
            unique_hosts = item.get('unique_hosts', 0)
            feature_vector.append(min(unique_hosts / 10, 1.0))
            
            # 3. Block rate
            feature_vector.append(item.get('block_rate', 0.0))
            
            # 4. Override rate
            feature_vector.append(item.get('override_rate', 0.0))
            
            # 5. Average duration (normalized to 1 hour)
            avg_duration = item.get('avg_duration', 0)
            feature_vector.append(min(avg_duration / 3600, 1.0))
            
            # 6. Hours since last seen (normalized to 24 hours)
            hours_since = item.get('hours_since_last', 24)
            feature_vector.append(min(hours_since / 24, 1.0))
            
            # 7. Device age (normalized to 30 days)
            age_days = item.get('device_age_days', 0)
            feature_vector.append(min(age_days / 30, 1.0))
            
            # 8. Activity variance (normalized)
            variance = item.get('activity_variance', 0)
            feature_vector.append(min(variance / 100, 1.0))
            
            # 9. Connection frequency (connections per hour)
            if age_days > 0:
                conn_per_hour = conn_count / (age_days * 24)
                feature_vector.append(min(conn_per_hour / 10, 1.0))
            else:
                feature_vector.append(0.0)
            
            # 10. Host diversity ratio
            if conn_count > 0:
                host_ratio = unique_hosts / conn_count
                feature_vector.append(min(host_ratio, 1.0))
            else:
                feature_vector.append(0.0)
            
            features.append(feature_vector)
        
        return np.array(features)
    
    def predict_anomaly(self, features: Dict, model_name: str = None) -> Tuple[int, float]:
        """
        Predict if a device is anomalous
        
        Returns:
            Tuple of (is_anomaly, confidence)
        """
        if not SKLEARN_AVAILABLE or not self.models:
            return (0, 0.0)
        
        # Use latest model if none specified
        if model_name is None and self.models:
            # Prefer isolation forest models
            for name in self.models:
                if 'isolation_forest' in name:
                    model_name = name
                    break
            if model_name is None:
                model_name = list(self.models.keys())[0]
        
        if model_name not in self.models:
            return (0, 0.0)
        
        try:
            model = self.models[model_name]
            scaler = self.scalers.get(model_name)
            
            # Extract features
            feature_vector = self._extract_features([features])
            
            # Scale if scaler available
            if scaler is not None:
                feature_vector = scaler.transform(feature_vector)
            
            # Predict
            prediction = model.predict(feature_vector)
            
            # Isolation Forest: 1 = normal, -1 = anomaly
            is_anomaly = 1 if prediction[0] == -1 else 0
            
            # Calculate confidence based on decision function if available
            confidence = 0.5
            if hasattr(model, 'decision_function'):
                try:
                    score = model.decision_function(feature_vector)
                    # Normalize to 0-1 range
                    confidence = min(abs(score[0]) / 2, 1.0)
                except:
                    pass
            
            return (is_anomaly, confidence)
            
        except Exception as e:
            log.error(f"Prediction failed: {e}")
            return (0, 0.0)
    
    def get_model_status(self) -> Dict:
        """Get status of all models"""
        return {
            'models': list(self.models.keys()),
            'total_models': len(self.models),
            'scalers_available': len(self.scalers),
            'model_metadata': self.model_metadata,
            'training_history': self.training_history[-20:],
            'timestamp': datetime.now().isoformat()
        }
    
    def delete_model(self, model_name: str) -> bool:
        """Delete a model and its associated files"""
        if model_name not in self.models:
            return False
        
        try:
            # Delete from memory
            del self.models[model_name]
            if model_name in self.scalers:
                del self.scalers[model_name]
            if model_name in self.model_metadata:
                del self.model_metadata[model_name]
            
            # Delete files
            base_path = os.path.join(self.model_path, model_name)
            for ext in ['.pkl', '_scaler.pkl', '_meta.json']:
                file_path = base_path + ext
                if os.path.exists(file_path):
                    os.remove(file_path)
            
            log.info(f"Deleted model: {model_name}")
            return True
        except Exception as e:
            log.error(f"Failed to delete model {model_name}: {e}")
            return False