# server/ai_enhanced/ml_simple.py
"""
Simple ML Model - Pure Python, NO external dependencies!
No numpy, no scikit-learn required.
"""
import json
import os
import logging
from datetime import datetime
import math

log = logging.getLogger("sentryusb.ml_simple")


class SimpleMLManager:
    """
    Simple ML Manager - Pure Python implementation
    Uses statistical analysis without any external libraries
    """
    
    def __init__(self, model_path="ai_models"):
        self.model_path = model_path
        os.makedirs(model_path, exist_ok=True)
        self.models = {}
        self.training_history = []
        self.device_profiles = {}
        self._load_profiles()
        self.feature_baseline = self._load_baseline()
        
    def _load_profiles(self):
        """Load saved profiles from disk"""
        stats_path = os.path.join(self.model_path, 'device_profiles.json')
        if os.path.exists(stats_path):
            try:
                with open(stats_path, 'r') as f:
                    data = json.load(f)
                    self.device_profiles = data.get('devices', {})
                    log.info(f"Loaded {len(self.device_profiles)} device profiles")
            except Exception as e:
                log.error(f"Failed to load profiles: {e}")
    
    def _save_profiles(self):
        """Save profiles to disk"""
        stats_path = os.path.join(self.model_path, 'device_profiles.json')
        try:
            with open(stats_path, 'w') as f:
                json.dump({
                    'devices': self.device_profiles,
                    'total_devices': len(self.device_profiles),
                    'trained_at': datetime.now().isoformat()
                }, f, indent=2)
            log.info(f"Saved {len(self.device_profiles)} device profiles")
        except Exception as e:
            log.error(f"Failed to save profiles: {e}")
    
    def train_anomaly_model(self, data):
        """Train a simple anomaly detection model"""
        try:
            # Build device profiles from data
            device_stats = {}
            
            for item in data:
                device_id = item.get('device_id') or item.get('device_instance_id') or 'unknown'
                
                if device_id not in device_stats:
                    device_stats[device_id] = {
                        'count': 0,
                        'blocked': 0,
                        'allowed': 0,
                        'overridden': 0,
                        'hosts': [],
                        'first_seen': datetime.now().isoformat(),
                        'last_seen': datetime.now().isoformat()
                    }
                
                stats = device_stats[device_id]
                stats['count'] += 1
                
                status = item.get('status', '')
                if status == 'blocked':
                    stats['blocked'] += 1
                elif status == 'allowed':
                    stats['allowed'] += 1
                elif status == 'overridden':
                    stats['overridden'] += 1
                
                host = item.get('hostname')
                if host and host not in stats['hosts']:
                    stats['hosts'].append(host)
                
                timestamp = item.get('timestamp')
                if timestamp:
                    stats['last_seen'] = timestamp
                    if not stats['first_seen'] or timestamp < stats['first_seen']:
                        stats['first_seen'] = timestamp
            
            self.device_profiles = device_stats
            self._save_profiles()

            # ---- Learn a real statistical baseline from the training data ----
            # Rather than hard-coded thresholds, compute the population mean/std
            # of each *device's* aggregate behavior, so predictions are
            # standardized (z-scores) against what this deployment's actual
            # device population looks like (per-event rows aren't independent
            # observations here - each device's overall profile is).
            feature_rows = [{
                'block_rate': (s['blocked'] / s['count']) if s['count'] else 0.0,
                'override_rate': (s['overridden'] / s['count']) if s['count'] else 0.0,
                'connection_count': s['count'],
                'unique_hosts': len(s['hosts']),
            } for s in device_stats.values()]

            self.feature_baseline = self._compute_baseline(feature_rows)

            # Record training
            self.training_history.append({
                'model': 'simple_anomaly',
                'type': 'anomaly',
                'samples': len(data),
                'devices': len(device_stats),
                'timestamp': datetime.now().isoformat()
            })

            self._save_baseline()

            return {
                'success': True,
                'model_name': 'simple_anomaly',
                'samples': len(data),
                'devices': len(device_stats),
                'features': 4,
                'baseline': self.feature_baseline
            }
            
        except Exception as e:
            log.error(f"Training failed: {e}")
            return {
                'success': False,
                'error': str(e)
            }

    @staticmethod
    def _mean_std(values):
        n = len(values)
        if n == 0:
            return 0.0, 1.0
        mean = sum(values) / n
        if n < 2:
            return mean, max(mean * 0.5, 1e-6) or 1.0
        variance = sum((v - mean) ** 2 for v in values) / (n - 1)
        std = math.sqrt(variance)
        return mean, std if std > 1e-6 else max(abs(mean) * 0.25, 1e-6)

    def _compute_baseline(self, feature_rows):
        baseline = {}
        for key in ('block_rate', 'override_rate', 'connection_count', 'unique_hosts'):
            values = [row[key] for row in feature_rows]
            mean, std = self._mean_std(values)
            baseline[key] = {'mean': mean, 'std': std}
        return baseline

    def _baseline_path(self):
        return os.path.join(self.model_path, 'anomaly_baseline.json')

    def _save_baseline(self):
        try:
            with open(self._baseline_path(), 'w') as f:
                json.dump(self.feature_baseline, f, indent=2)
        except Exception as e:
            log.error(f"Failed to save anomaly baseline: {e}")

    def _load_baseline(self):
        path = self._baseline_path()
        if os.path.exists(path):
            try:
                with open(path, 'r') as f:
                    return json.load(f)
            except Exception as e:
                log.error(f"Failed to load anomaly baseline: {e}")
        return {}

    # Feature weights: block_rate and connection/host fan-out are the
    # strongest indicators of anomalous USB/device behavior in a lab context;
    # override_rate matters but is noisier (legitimate teacher overrides happen).
    _FEATURE_WEIGHTS = {
        'block_rate': 1.2,
        'unique_hosts': 1.0,
        'connection_count': 0.8,
        'override_rate': 0.9,
    }

    def predict_anomaly(self, features):
        """
        Predict anomaly using a weighted multivariate z-score ensemble against
        the learned baseline, falling back to sane defaults (population
        assumed centered at 0 with unit spread) when no baseline has been
        trained yet. This replaces fixed magic-number thresholds with a model
        that adapts to each deployment's actual traffic patterns.
        """
        try:
            baseline = getattr(self, 'feature_baseline', None) or self._load_baseline()

            observed = {
                'block_rate': features.get('block_rate', 0),
                'unique_hosts': features.get('unique_hosts', 0),
                'connection_count': features.get('connection_count', 0),
                'override_rate': features.get('override_rate', 0),
            }

            z_scores = {}
            for key, value in observed.items():
                stats = baseline.get(key) if baseline else None
                if stats:
                    mean, std = stats['mean'], stats['std'] or 1.0
                else:
                    # Reasonable priors when nothing has been trained yet,
                    # roughly matching a well-behaved lab environment
                    defaults = {
                        'block_rate': (0.05, 0.15),
                        'unique_hosts': (1.5, 1.5),
                        'connection_count': (3.0, 4.0),
                        'override_rate': (0.02, 0.08),
                    }
                    mean, std = defaults[key]
                z = (value - mean) / (std if std > 1e-6 else 1.0)
                z_scores[key] = z

            # Weighted combination -- only positive deviations count as
            # "anomalous" (e.g. unusually LOW block rate isn't a threat)
            weighted_sum = sum(
                max(z, 0) * self._FEATURE_WEIGHTS[key] for key, z in z_scores.items()
            )
            weight_total = sum(self._FEATURE_WEIGHTS.values())
            normalized = weighted_sum / weight_total if weight_total else 0.0

            # Convert to a 0-1 confidence via a logistic squashing function
            # centered so ~2 standard deviations of combined deviation -> ~0.73
            confidence = 1 / (1 + math.exp(-1.1 * (normalized - 1.5)))
            confidence = round(min(max(confidence, 0.0), 0.99), 3)
            is_anomaly = 1 if confidence >= 0.5 else 0

            return is_anomaly, confidence

        except Exception as e:
            log.error(f"Prediction failed: {e}")
            return 0, 0.0
    
    def get_model_status(self):
        """Get model status"""
        return {
            'models': ['simple_anomaly'] if self.device_profiles else [],
            'total_models': 1 if self.device_profiles else 0,
            'scalers_available': 0,
            'model_metadata': {
                'simple_anomaly': {
                    'type': 'simple',
                    'devices': len(self.device_profiles),
                    'trained_at': self.training_history[-1]['timestamp'] if self.training_history else None
                }
            },
            'training_history': self.training_history[-10:],
            'timestamp': datetime.now().isoformat()
        }
    
    def get_device_profile(self, device_id):
        """Get profile for a specific device"""
        return self.device_profiles.get(device_id, {})