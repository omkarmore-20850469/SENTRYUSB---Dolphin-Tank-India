# server/ai_enhanced/rdp_detector.py
"""
AI-Powered RDP / Remote-Access Detection - server-side aggregator

IMPORTANT: This module does NOT scan the machine it runs on. The server
process runs on the lab server (tier 2), not on the student exam PCs
(tier 3) - so scanning its own OS for RDP sessions was always checking
the wrong machine. Detection now happens on each agent (see
agent/rdp_monitor.py), which reports what it sees over the existing
socketio channel (rdp_status_response / rdp_event). This class just
stores and analyzes what agents report.
"""
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import json
import os

log = logging.getLogger("sentryusb.rdp_detector")


class RDPDetector:
    """
    Aggregates agent-reported RDP / remote-access telemetry and flags
    anomalous patterns.

    Data flow:
        agent/rdp_monitor.py detects locally  ->  socketio 'rdp_status_response' / 'rdp_event'
        ->  app.py handlers call ingest_status() / ingest_event()  ->  this class
    """

    def __init__(self):
        # Latest reported status per hostname: {hostname: {..., 'last_seen': iso}}
        self.host_status: Dict[str, dict] = {}

        # Flat history of ingested events (session start/end, tool detected/closed)
        self.rdp_history: List[dict] = []
        self._max_history = 2000

        self._load_history()

        log.info("RDPDetector (aggregator) initialized")

    # ============================================================
    # PERSISTENCE
    # ============================================================

    def _history_path(self):
        return os.path.join(os.path.dirname(__file__), "ai_models", "rdp_history.json")

    def _load_history(self):
        path = self._history_path()
        if os.path.exists(path):
            try:
                with open(path, 'r') as f:
                    data = json.load(f)
                    self.rdp_history = data.get('history', [])
                log.info(f"Loaded {len(self.rdp_history)} RDP history entries")
            except Exception as e:
                log.error(f"Failed to load RDP history: {e}")

    def _save_history(self):
        path = self._history_path()
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, 'w') as f:
                json.dump({'history': self.rdp_history[-self._max_history:]}, f, indent=2)
        except Exception as e:
            log.error(f"Failed to save RDP history: {e}")

    # ============================================================
    # INGESTION (called from app.py socketio handlers)
    # ============================================================

    def ingest_status(self, hostname: str, status: dict) -> Dict:
        """
        Store the latest status snapshot reported by an agent, and return
        a fresh anomaly analysis for that host.
        """
        entry = dict(status)
        entry['hostname'] = hostname
        entry['last_seen'] = datetime.now().isoformat()
        self.host_status[hostname] = entry
        return self.analyze_rdp_connections(hostname)

    def ingest_event(self, hostname: str, event: dict) -> Dict:
        """Store a single agent-reported event (session start/end, tool detected/closed)."""
        entry = dict(event)
        entry['hostname'] = hostname
        entry.setdefault('timestamp', datetime.now().isoformat())

        self.rdp_history.append(entry)
        if len(self.rdp_history) > self._max_history:
            self.rdp_history = self.rdp_history[-self._max_history:]
        self._save_history()

        return entry

    # ============================================================
    # QUERIES
    # ============================================================

    def get_active_rdp_sessions(self, hostname: Optional[str] = None) -> List[Dict]:
        """
        Get currently active RDP sessions / third-party remote-access tools,
        as last reported by agent(s). If hostname is given, scope to that
        machine only - otherwise return across every agent that has reported.
        """
        sessions = []
        hosts = [hostname] if hostname else list(self.host_status.keys())

        for h in hosts:
            status = self.host_status.get(h)
            if not status:
                continue
            for s in status.get('active_sessions', []):
                sessions.append({**s, 'hostname': h})
            for t in status.get('active_remote_tools', []):
                sessions.append({**t, 'hostname': h})

        return sessions

    def get_history(self, hostname: Optional[str] = None, limit: int = 50) -> List[Dict]:
        history = self.rdp_history
        if hostname:
            history = [e for e in history if e.get('hostname') == hostname]
        return history[-limit:]

    def get_known_hosts(self) -> List[str]:
        return list(self.host_status.keys())

    # ============================================================
    # ANALYSIS
    # ============================================================

    def analyze_rdp_connections(self, hostname: Optional[str] = None) -> Dict:
        """
        Analyze RDP / remote-access patterns for anomalies.

        If hostname is provided, this actually scopes to that specific
        agent's reported data (previously the hostname parameter was
        accepted but ignored, since detection ran locally on the server
        regardless of which hostname was asked about).
        """
        active_sessions = self.get_active_rdp_sessions(hostname)
        status = self.host_status.get(hostname, {}) if hostname else {}

        anomalies = []

        # 1. Multiple concurrent RDP sessions / remote tools active at once
        active_count = len(active_sessions)
        if active_count > 2:
            anomalies.append({
                'type': 'multiple_rdp_sessions',
                'severity': 'medium',
                'description': f'Multiple RDP/remote-access sessions active ({active_count})',
                'count': active_count
            })

        # 2. Third-party remote-access tools are a strong signal on their own -
        #    these previously weren't detected at all.
        tools_seen = sorted({s.get('tool') for s in active_sessions if s.get('type') == 'third_party_remote_tool' and s.get('tool')})
        if tools_seen:
            anomalies.append({
                'type': 'third_party_remote_tool',
                'severity': 'high',
                'description': f"Third-party remote-access tool(s) detected: {', '.join(tools_seen)}",
                'tools': tools_seen
            })

        # 2b. Risk-tier known remote-access tools - some (screen-share/support
        # tools) are far more commonly abused for exam cheating / unauthorized
        # remote control than others, so weight them accordingly rather than
        # treating every third-party tool identically.
        if tools_seen:
            high_risk_tools = {'anydesk', 'teamviewer', 'chrome remote desktop',
                                'ultraviewer', 'ammyy admin', 'supremo', 'remotepc'}
            matched_high_risk = sorted({t for t in tools_seen if t.lower() in high_risk_tools})
            if matched_high_risk:
                anomalies.append({
                    'type': 'high_risk_remote_tool',
                    'severity': 'critical',
                    'description': f"High-risk remote-control tool(s) active, commonly used to bypass exam lockdown: {', '.join(matched_high_risk)}",
                    'tools': matched_high_risk
                })

        # 3. Excessive failed/remote login attempts, from the agent's real
        #    Windows Security Event Log counters (when available), rather
        #    than a self-referential history counter that could never fire.
        recent_failed = status.get('recent_failed_logons', 0) if hostname else self._max_field_across_hosts('recent_failed_logons')
        if recent_failed and recent_failed > 5:
            anomalies.append({
                'type': 'excessive_login_attempts',
                'severity': 'high',
                'description': f'Excessive failed logon attempts detected: {recent_failed} recently',
                'count': recent_failed
            })

        # 4. Anomalous time of day, only meaningful if something is actually active
        anomalous_time = self._check_anomalous_time()
        if anomalous_time and active_count:
            anomalies.append({
                'type': 'anomalous_login_time',
                'severity': 'medium',
                'description': f'RDP/remote-access activity at unusual hour: {anomalous_time}',
            })

        # 5. Rapid session creation (possible brute-force / reconnect-storm pattern)
        rapid_sessions = self._check_rapid_sessions(hostname)
        if rapid_sessions:
            anomalies.append(rapid_sessions)

        return {
            'active_sessions': active_sessions,
            'session_count': active_count,
            'anomalies': anomalies,
            'anomaly_count': len(anomalies),
            'risk_score': self._calculate_risk_score(anomalies),
            'timestamp': datetime.now().isoformat(),
            'hostname': hostname or 'all',
            'hosts_reporting': len(self.host_status) if not hostname else (1 if hostname in self.host_status else 0),
        }

    def _max_field_across_hosts(self, field: str) -> int:
        values = [s.get(field, 0) or 0 for s in self.host_status.values()]
        return max(values) if values else 0

    def _check_anomalous_time(self) -> Optional[str]:
        """Check if current time is outside normal exam-lab operating hours"""
        current_hour = datetime.now().hour
        if current_hour < 6 or current_hour > 22:
            return f"{current_hour}:00 - outside normal operating hours (6 AM - 10 PM)"
        return None

    def _check_rapid_sessions(self, hostname: Optional[str] = None) -> Optional[Dict]:
        """Check for rapid session/tool-detection creation pattern from real event timestamps"""
        history = self.rdp_history
        if hostname:
            history = [e for e in history if e.get('hostname') == hostname]

        recent = [e for e in history[-30:]
                  if e.get('event') in ('rdp_session_started', 'remote_tool_detected')]

        if len(recent) > 6:
            timestamps = []
            for e in recent:
                try:
                    timestamps.append(datetime.fromisoformat(e.get('timestamp', '')))
                except Exception:
                    pass

            if len(timestamps) > 3:
                timestamps.sort()
                intervals = [
                    (timestamps[i + 1] - timestamps[i]).total_seconds()
                    for i in range(len(timestamps) - 1)
                ]
                if intervals and (sum(intervals) / len(intervals)) < 30:
                    return {
                        'type': 'rapid_session_creation',
                        'severity': 'high',
                        'description': f'Rapid RDP/remote-access session creation detected: {len(recent)} events in a short period',
                        'count': len(recent)
                    }

        return None

    def _calculate_risk_score(self, anomalies: List[Dict]) -> float:
        """
        Calculate overall risk score by combining anomaly severities as
        independent probabilistic evidence (noisy-OR) rather than plain
        addition. Plain addition lets four "low" anomalies (0.4) understate
        risk relative to two "medium" ones (0.6) even when the low-severity
        set represents a broader, more corroborated pattern; noisy-OR combines
        evidence the way a human analyst reasons about "how likely is this
        genuinely risky given everything observed", and saturates smoothly
        toward 1.0 instead of a hard clip.
        """
        if not anomalies:
            return 0.0

        severity_weights = {
            'low': 0.15,
            'medium': 0.35,
            'high': 0.55,
            'critical': 0.8
        }

        p_benign = 1.0
        for anomaly in anomalies:
            severity = anomaly.get('severity', 'low')
            p_benign *= (1 - severity_weights.get(severity, 0.15))

        return round(min(1 - p_benign, 1.0), 3)

    def get_rdp_security_score(self, hostname: Optional[str] = None) -> float:
        """
        Calculate RDP/remote-access security score based on the most
        recently reported agent state.

        Returns:
            Score from 0 (risky) to 1 (secure). With no hostname given,
            returns the worst (lowest) score across all reporting hosts,
            so a single compromised lab PC pulls the lab-wide indicator down.
        """
        if hostname:
            return self._score_for_host(hostname)

        if not self.host_status:
            return 1.0

        return min(self._score_for_host(h) for h in self.host_status)

    def _score_for_host(self, hostname: str) -> float:
        score = 1.0
        sessions = self.get_active_rdp_sessions(hostname)

        if sessions:
            score -= min(0.2 * len(sessions), 0.5)

        if any(s.get('type') == 'third_party_remote_tool' for s in sessions):
            score -= 0.3

        if len(sessions) > 2:
            score -= 0.2

        if self._check_anomalous_time() and sessions:
            score -= 0.1

        return max(0.0, round(score, 2))

    def clear_history(self):
        """Clear RDP history (does not clear last-known live status)"""
        self.rdp_history = []
        self._save_history()
        log.info("RDP history cleared")
