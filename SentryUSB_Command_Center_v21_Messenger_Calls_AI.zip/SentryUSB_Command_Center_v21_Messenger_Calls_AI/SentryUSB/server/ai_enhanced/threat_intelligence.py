# server/ai_enhanced/threat_intelligence.py
"""
AI-Powered Threat Intelligence Integration
"""
import json
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import threading
import hashlib
import re
import os
import math
import requests

log = logging.getLogger("sentryusb.threat_intelligence")


class ThreatIntelligence:
    """
    Threat intelligence integration for enhanced security
    
    Features:
    - IOC matching (IP, domain, hash, URL)
    - Threat feed integration
    - Automated threat updates
    - Confidence scoring
    - Alert correlation
    """
    
    def __init__(self, model_path: str = "ai_models/threat_intel"):
        self.model_path = model_path
        os.makedirs(model_path, exist_ok=True)
        
        # IOC databases
        self.ioc_database = {
            'ip': {},
            'domain': {},
            'hash': {},
            'url': {},
        }
        
        # Threat feeds
        self.active_feeds = []
        self.feed_update_time = None
        
        # Confidence scores
        self.confidence_cache = {}
        
        # Statistics
        self.stats = {
            'ioc_count': 0,
            'feed_updates': 0,
            'last_update': None,
            'threats_detected': 0
        }
        
        # Load threat intelligence
        self._load_ioc_database()
        
        # Start background updater
        self._start_background_updater()
        
        log.info("ThreatIntelligence initialized")
    
    def _load_ioc_database(self):
        """Load IOC database from persistent storage"""
        ioc_path = os.path.join(self.model_path, "ioc_database.json")
        if os.path.exists(ioc_path):
            try:
                with open(ioc_path, 'r') as f:
                    data = json.load(f)
                    self.ioc_database = data.get('iocs', self.ioc_database)
                    self.stats['ioc_count'] = self._count_iocs()
                    log.info(f"Loaded {self.stats['ioc_count']} IOCs from database")
            except Exception as e:
                log.error(f"Failed to load IOC database: {e}")
        else:
            # Create default database
            self._create_default_ioc_database()
    
    def _create_default_ioc_database(self):
        """Create default IOC database with known threats"""
        # Known malicious IPs (example data)
        self.ioc_database['ip'] = {
            # These are well-known malicious IPs (placeholders)
        }
        
        # Known malicious domains
        self.ioc_database['domain'] = {
            # These are known malicious domains (placeholders)
            "malware.test": {
                "malicious": True,
                "confidence": 0.9,
                "threat_type": "malware_c2",
                "details": {"source": "default"}
            },
        }
        
        self._save_ioc_database()
        log.info("Created default IOC database")
    
    def _save_ioc_database(self):
        """Save IOC database to persistent storage"""
        ioc_path = os.path.join(self.model_path, "ioc_database.json")
        try:
            with open(ioc_path, 'w') as f:
                json.dump({
                    'iocs': self.ioc_database,
                    'metadata': {
                        'created': datetime.now().isoformat(),
                        'version': '2.0.0',
                        'ioc_count': self._count_iocs()
                    }
                }, f, indent=2)
            log.info(f"Saved {self._count_iocs()} IOCs to database")
        except Exception as e:
            log.error(f"Failed to save IOC database: {e}")
    
    def _count_iocs(self) -> int:
        """Count total IOCs in database"""
        return sum(len(iocs) for iocs in self.ioc_database.values())
    
    def _start_background_updater(self):
        """Start background thread for updating threat feeds"""
        def updater():
            while True:
                try:
                    # Update feeds every 6 hours
                    import time
                    time.sleep(21600)  # 6 hours
                    self.update_threat_feeds()
                except Exception as e:
                    log.error(f"Background feed update failed: {e}")
        
        thread = threading.Thread(target=updater, daemon=True)
        thread.start()
        log.info("Background threat feed updater started")
    
    def check_ip(self, ip_address: str) -> Dict:
        """
        Check if IP is known malicious
        
        Returns:
            Dict with threat level and details
        """
        result = {'malicious': False, 'confidence': 0.0, 'details': {}}
        
        # Check in database
        if ip_address in self.ioc_database['ip']:
            entry = self.ioc_database['ip'][ip_address]
            result['malicious'] = True
            result['confidence'] = entry.get('confidence', 0.7)
            result['details'] = entry.get('details', {})
            result['threat_type'] = entry.get('threat_type', 'unknown')
        
        # Check for suspicious patterns
        if self._is_suspicious_ip(ip_address):
            result['malicious'] = True
            result['confidence'] = max(result['confidence'], 0.5)
            result['details']['pattern'] = 'suspicious_ip_pattern'
        
        return result
    
    def check_domain(self, domain: str) -> Dict:
        """
        Check if domain is known malicious
        
        Returns:
            Dict with threat level and details
        """
        result = {'malicious': False, 'confidence': 0.0, 'details': {}}
        
        # Clean domain
        domain = domain.lower().strip()
        
        # Check in database
        if domain in self.ioc_database['domain']:
            entry = self.ioc_database['domain'][domain]
            result['malicious'] = True
            result['confidence'] = entry.get('confidence', 0.7)
            result['details'] = entry.get('details', {})
            result['threat_type'] = entry.get('threat_type', 'unknown')
        
        # Check for suspicious patterns
        if self._is_suspicious_domain(domain):
            result['malicious'] = True
            typosquat_brand = self._is_typosquat(domain)
            if typosquat_brand:
                result['confidence'] = max(result['confidence'], 0.8)
                result['details']['pattern'] = 'typosquat'
                result['details']['impersonated_brand'] = typosquat_brand
                result['threat_type'] = result.get('threat_type', 'phishing_typosquat')
            else:
                result['confidence'] = max(result['confidence'], 0.6)
                result['details']['pattern'] = 'suspicious_domain_pattern'
            result['details']['entropy'] = round(self._domain_entropy(domain.split('.')[0]), 3)
        
        return result

    def correlate_iocs(self, event: Dict) -> Dict:
        """
        Multi-IOC correlation: a single weak indicator (e.g. one suspicious
        domain visit) is low-signal, but several independent indicators
        co-occurring in the same event (suspicious IP + suspicious domain +
        known-bad hash) sharply raises confidence that this is a genuine
        incident rather than noise. Returns an aggregate risk assessment
        with a lightweight MITRE ATT&CK-style tag for triage.

        `event` may contain any of: ip, domain, url, file_hash
        """
        findings = []
        risk = 0.0

        if event.get('ip'):
            r = self.check_ip(event['ip'])
            if r['malicious']:
                findings.append({'type': 'ip', 'value': event['ip'], **r})
                risk = 1 - (1 - risk) * (1 - r['confidence'])

        if event.get('domain'):
            r = self.check_domain(event['domain'])
            if r['malicious']:
                findings.append({'type': 'domain', 'value': event['domain'], **r})
                risk = 1 - (1 - risk) * (1 - r['confidence'])

        if event.get('url'):
            r = self.check_url(event['url'])
            if r['malicious']:
                findings.append({'type': 'url', 'value': event['url'], **r})
                risk = 1 - (1 - risk) * (1 - r['confidence'])

        if event.get('file_hash'):
            r = self.check_hash(event['file_hash'])
            if r['malicious']:
                findings.append({'type': 'hash', 'value': event['file_hash'], **r})
                risk = 1 - (1 - risk) * (1 - r['confidence'])

        # Correlation bonus: independent corroborating indicators are much
        # stronger evidence together than any one alone
        if len(findings) >= 2:
            risk = min(risk * 1.15, 0.99)

        mitre_tag = None
        if any(f['type'] == 'hash' for f in findings):
            mitre_tag = "T1204 - User Execution (malicious file)"
        elif any(f.get('details', {}).get('pattern') == 'typosquat' for f in findings):
            mitre_tag = "T1566 - Phishing"
        elif any(f['type'] in ('ip', 'domain') for f in findings):
            mitre_tag = "T1071 - Application Layer Protocol (C2)"

        return {
            'risk_score': round(risk, 3),
            'severity': 'critical' if risk >= 0.85 else 'high' if risk >= 0.6 else 'medium' if risk >= 0.3 else 'low',
            'findings': findings,
            'correlated': len(findings) >= 2,
            'mitre_attack': mitre_tag,
        }
    
    def check_hash(self, file_hash: str, hash_type: str = 'sha256') -> Dict:
        """
        Check if file hash is known malicious
        
        Returns:
            Dict with threat level and details
        """
        result = {'malicious': False, 'confidence': 0.0, 'details': {}}
        
        # Check in database
        if file_hash in self.ioc_database['hash']:
            entry = self.ioc_database['hash'][file_hash]
            result['malicious'] = True
            result['confidence'] = entry.get('confidence', 0.8)
            result['details'] = entry.get('details', {})
            result['threat_type'] = entry.get('threat_type', 'unknown')
            result['threat_name'] = entry.get('threat_name', 'Known Malware')
        
        return result
    
    def check_url(self, url: str) -> Dict:
        """
        Check if URL is known malicious
        
        Returns:
            Dict with threat level and details
        """
        result = {'malicious': False, 'confidence': 0.0, 'details': {}}
        
        # Check in database
        if url in self.ioc_database['url']:
            entry = self.ioc_database['url'][url]
            result['malicious'] = True
            result['confidence'] = entry.get('confidence', 0.7)
            result['details'] = entry.get('details', {})
        
        # Extract domain and check it
        import urllib.parse
        try:
            parsed = urllib.parse.urlparse(url)
            domain = parsed.netloc
            if domain:
                domain_check = self.check_domain(domain)
                if domain_check['malicious']:
                    result['malicious'] = True
                    result['confidence'] = max(result['confidence'], domain_check['confidence'])
                    result['details']['domain_check'] = domain_check
        except:
            pass
        
        return result
    
    # Known-abused free/anonymous dynamic-DNS and URL-shortener domains often
    # used in phishing / C2 redirection chains
    _ABUSED_INFRA_SUFFIXES = (
        '.tk', '.ml', '.ga', '.cf', '.gq',            # free ccTLD registrars, heavily abused
        '.duckdns.org', '.no-ip.org', '.ddns.net',    # dynamic DNS often used for C2
    )

    # A short list of high-value brands commonly impersonated in typosquatting/phishing
    _PROTECTED_BRANDS = (
        'google', 'microsoft', 'apple', 'amazon', 'paypal', 'facebook', 'instagram',
        'office365', 'outlook', 'onedrive', 'dropbox', 'bankofamerica', 'chase', 'wellsfargo',
    )

    def _cidr_contains(self, ip_int: int, cidr: str) -> bool:
        """Pure-Python CIDR membership test (no dependency on ipaddress edge cases needed)"""
        try:
            net, prefix = cidr.split('/')
            prefix = int(prefix)
            net_int = self._ip_to_int(net)
            mask = (0xFFFFFFFF << (32 - prefix)) & 0xFFFFFFFF
            return (ip_int & mask) == (net_int & mask)
        except Exception:
            return False

    @staticmethod
    def _ip_to_int(ip_address: str) -> int:
        parts = [int(p) for p in ip_address.split('.')]
        if len(parts) != 4 or any(p < 0 or p > 255 for p in parts):
            raise ValueError("invalid IPv4")
        return (parts[0] << 24) + (parts[1] << 16) + (parts[2] << 8) + parts[3]

    def _is_suspicious_ip(self, ip_address: str) -> bool:
        """
        Heuristic IP reputation check:
        - Flags bogon/reserved ranges that should never appear as a real
          external endpoint (0.0.0.0/8, 169.254.0.0/16 link-local, 100.64.0.0/10
          CGNAT, 224.0.0.0/4 multicast, 240.0.0.0/4 reserved) - traffic to/from
          these is almost always spoofed, misconfigured, or malformed.
        - Flags TEST-NET ranges used in documentation/PoCs, sometimes reused by
          malware authors as placeholder C2 addresses.
        """
        try:
            ip_int = self._ip_to_int(ip_address)
        except Exception:
            return False

        bogon_ranges = [
            '0.0.0.0/8', '169.254.0.0/16', '100.64.0.0/10', '224.0.0.0/4',
            '240.0.0.0/4', '192.0.2.0/24', '198.51.100.0/24', '203.0.113.0/24',
            '127.0.0.0/8',
        ]
        for cidr in bogon_ranges:
            if self._cidr_contains(ip_int, cidr):
                return True
        return False

    def _domain_entropy(self, label: str) -> float:
        """Shannon entropy of a domain label - used as a DGA (domain generation
        algorithm) indicator. Human-chosen names cluster low (~2.5-3.5);
        algorithmically-generated ones trend higher (>3.8) for their length."""
        if not label:
            return 0.0
        counts = {}
        for ch in label:
            counts[ch] = counts.get(ch, 0) + 1
        length = len(label)
        entropy = 0.0
        for c in counts.values():
            p = c / length
            entropy -= p * math.log2(p)
        return entropy

    def _is_typosquat(self, domain: str) -> Optional[str]:
        """Detect likely typosquatting against protected brand names using
        Levenshtein edit distance (catches googIe.com, paypa1.com,
        micros0ft-support.net, paypal-secure-login.net, etc.). Checks the
        full second-level label as well as each hyphen/dot-separated token,
        since typosquats commonly pad the brand with extra words."""
        sld = domain.lower().split('.')[0]
        tokens = set(re.split(r'[-_.]', sld)) | {sld}

        for brand in self._PROTECTED_BRANDS:
            if brand in sld:
                # exact brand substring with extra padding words is itself a
                # classic combosquat pattern (e.g. "paypal-secure-login")
                if sld != brand:
                    return brand
                continue
            for token in tokens:
                if not token or token == brand:
                    continue
                if abs(len(token) - len(brand)) > 2:
                    continue
                distance = self._levenshtein(token, brand)
                if 0 < distance <= 2:
                    return brand
        return None

    @staticmethod
    def _levenshtein(a: str, b: str) -> int:
        if a == b:
            return 0
        prev = list(range(len(b) + 1))
        for i, ca in enumerate(a, 1):
            cur = [i] + [0] * len(b)
            for j, cb in enumerate(b, 1):
                cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (ca != cb))
            prev = cur
        return prev[-1]

    def _is_suspicious_domain(self, domain: str) -> bool:
        """Multi-signal domain reputation check combining known-abused
        infrastructure, DGA-style entropy, structural patterns, and
        typosquat detection against protected brands."""
        suspicious_patterns = [
            r'[0-9]+\.(com|org|net)$',        # number-only second-level domain
            r'^[a-z0-9]{16,}\.(com|net|info|xyz|top)$',  # long random label
            r'^[0-9a-f]{8,}\.',                # hex-looking subdomain (common in DGA/C2)
            r'xn--',                           # punycode / IDN homograph indicator
        ]

        for pattern in suspicious_patterns:
            if re.search(pattern, domain, re.IGNORECASE):
                return True

        if domain.endswith(self._ABUSED_INFRA_SUFFIXES):
            return True

        label = domain.split('.')[0]
        if len(label) >= 8 and self._domain_entropy(label) >= 3.8:
            return True

        if self._is_typosquat(domain):
            return True

        return False
    
    def update_threat_feeds(self, feed_urls: List[str] = None) -> Dict:
        """
        Update threat feeds from external sources
        
        Returns:
            Dict with update results
        """
        results = {
            'updated': 0,
            'failed': 0,
            'total_iocs': 0,
            'timestamp': datetime.now().isoformat()
        }
        
        # Default feeds
        if feed_urls is None:
            feed_urls = [
                # "https://feeds.talosintelligence.com/v2/threat_intel.json",
                # "https://www.abuse.ch/feeds/",
                # Add more feeds here
            ]
        
        for feed_url in feed_urls:
            try:
                # In production, fetch and parse the feed
                # response = requests.get(feed_url, timeout=30)
                # if response.status_code == 200:
                #     data = response.json()
                #     # Parse and update database
                #     self._parse_feed(data)
                #     results['updated'] += 1
            
                # For now, just log
                log.info(f"Would update from feed: {feed_url}")
                results['updated'] += 1
                
            except Exception as e:
                log.error(f"Failed to update feed {feed_url}: {e}")
                results['failed'] += 1
        
        self.stats['feed_updates'] += 1
        self.stats['last_update'] = datetime.now().isoformat()
        results['total_iocs'] = self._count_iocs()
        
        return results
    
    def add_ioc(self, ioc_type: str, value: str, metadata: Dict = None):
        """
        Add an IOC to the database
        
        Args:
            ioc_type: 'ip', 'domain', 'hash', or 'url'
            value: The IOC value
            metadata: Additional information
        """
        if ioc_type not in self.ioc_database:
            raise ValueError(f"Invalid IOC type: {ioc_type}")
        
        self.ioc_database[ioc_type][value] = metadata or {
            'malicious': True,
            'confidence': 0.8,
            'added_at': datetime.now().isoformat(),
            'source': 'manual'
        }
        
        self._save_ioc_database()
        self.stats['ioc_count'] = self._count_iocs()
        log.info(f"Added IOC: {ioc_type}:{value}")
    
    def get_threat_intelligence_report(self) -> Dict:
        """Generate threat intelligence report"""
        return {
            'total_iocs': self._count_iocs(),
            'ip_iocs': len(self.ioc_database['ip']),
            'domain_iocs': len(self.ioc_database['domain']),
            'hash_iocs': len(self.ioc_database['hash']),
            'url_iocs': len(self.ioc_database['url']),
            'feed_updates': self.stats['feed_updates'],
            'last_updated': self.stats['last_update'] or datetime.now().isoformat(),
            'status': 'active',
            'threats_detected': self.stats['threats_detected']
        }