# server/ai_enhanced/__init__.py
"""
Enhanced AI Modules for SentryUSB - Pure Python Version
NO external dependencies required!
"""

from .malware_detector import MalwareDetector, ScanResult
from .rdp_detector import RDPDetector
from .browser_analyzer import BrowserAnalyzer
from .threat_intelligence import ThreatIntelligence
from .integrity_checker import IntegrityChecker

# Use pure Python ML manager (NO numpy/scikit-learn required)
try:
    from .ml_simple import SimpleMLManager as MLModelManager
    print("✅ Using Pure Python ML Manager (no external dependencies)")
except ImportError as e:
    print(f"⚠️ ML Manager not available: {e}")
    # Create a minimal fallback
    class MLModelManager:
        def __init__(self, *args, **kwargs):
            self.device_profiles = {}
        def train_anomaly_model(self, data):
            return {'success': True, 'devices': len(data)}
        def predict_anomaly(self, features):
            return 0, 0.0
        def get_model_status(self):
            return {'models': [], 'total_models': 0}

__all__ = [
    'MalwareDetector',
    'ScanResult', 
    'RDPDetector',
    'BrowserAnalyzer',
    'ThreatIntelligence',
    'MLModelManager',
    'IntegrityChecker'
]

__version__ = '2.0.0'