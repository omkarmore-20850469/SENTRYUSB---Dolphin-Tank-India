# server/ai_enhanced/browser_analyzer.py
"""
AI-Powered Browser Activity Analyzer
"""
import logging
import re
from datetime import datetime, timedelta
from typing import List, Dict, Optional
from collections import defaultdict
import json
import os

log = logging.getLogger("sentryusb.browser_analyzer")


class BrowserAnalyzer:
    """
    Advanced browser activity analysis with AI
    
    Features:
    - Browser process anomaly detection
    - Suspicious extension detection
    - Login page analysis
    - Browser memory analysis
    - User behavior profiling
    """
    
    def __init__(self):
        self.browser_profiles = {}
        self.suspicious_patterns = self._load_suspicious_patterns()
        self.known_extensions = self._load_known_extensions()
        self.login_history = defaultdict(list)
        self.browser_history = []
        self._max_history = 1000
        
        # Load history
        self._load_history()
        
        log.info("BrowserAnalyzer initialized")
    
    def _load_suspicious_patterns(self) -> Dict:
        """Load suspicious browser patterns"""
        return {
            'login_urls': [
                r'https?://[^/]+/login',
                r'https?://[^/]+/signin',
                r'https?://[^/]+/sign-in',
                r'https?://[^/]+/auth',
                r'https?://[^/]+/oauth',
                r'https?://[^/]+/accounts\.google\.com',
                r'https?://[^/]+/login\.microsoftonline\.com',
                r'https?://[^/]+/facebook\.com/login',
                r'https?://[^/]+/twitter\.com/login',
                r'https?://[^/]+/instagram\.com/accounts/login',
                r'https?://[^/]+/linkedin\.com/login',
                r'https?://[^/]+/amazon\.com/ap/signin',
                r'https?://[^/]+/appleid\.apple\.com',
                r'https?://[^/]+/github\.com/login',
                r'https?://[^/]+/stackoverflow\.com/users/login',
                r'https?://[^/]+/reddit\.com/login',
            ],
            'suspicious_domains': [
                'free-exam-answers',
                'cheatsheet',
                'exam-pdf',
                'test-bank',
                'cram',
                'studocu',
                'coursehero',
                'chegg',
                'quizlet',
                'test-answers',
                'exam-dump',
                'brainly',
                'bartleby',
                'transparent',
                'slader',
                'answers.com',
                'numerade',
                'gauthmath',
                'photomath',
                'symbolab',
                'wolframalpha',
                'examtopics',
                'coursesidekick',
                'studypool',
                'homeworkmarket',
                'assignmentexpert',
                'geeksforgeeks/practice',
            ],
            # Domains for general-purpose generative-AI assistants - not
            # inherently malicious, but a strong exam-integrity signal when
            # visited during an active lockdown window, so tracked separately
            # from the higher-confidence cheat-site list above.
            'ai_assistant_domains': [
                'chat.openai.com', 'chatgpt.com', 'claude.ai', 'gemini.google.com',
                'bard.google.com', 'copilot.microsoft.com', 'perplexity.ai',
                'poe.com', 'character.ai', 'huggingface.co/chat',
            ],
            'suspicious_keywords': [
                'inject',
                'hack',
                'bypass',
                'unlock',
                'crack',
                'keygen',
                'exploit',
                'cheat',
                'bypass',
                'injector',
                'proxy',
                'vpn',
                'tor',
                'anonymous',
            ],
            'suspicious_titles': [
                'sign in',
                'login',
                'log in',
                'sign-in',
                'log-in',
                'authentication',
                'access',
                'verify',
                'password',
                'credential',
                'session',
                'secure',
                'account',
                'profile',
                'settings',
                '2fa',
                'two-factor',
                'mfa',
                'otp',
                'verification',
            ]
        }
    
    def _load_known_extensions(self) -> Dict:
        """Load known browser extensions"""
        return {
            'suspicious': [
                'hack', 'crack', 'bypass', 'inject', 'exploit',
                'cheat', 'unlock', 'keygen', 'crypto', 'miner',
                'proxify', 'unblock', 'freevpn', 'anonymous',
            ],
            'benign': [
                'adblock', 'privacy', 'security', 'password', 
                'google', 'microsoft', 'apple', 'firefox',
                'chrome', 'edge', 'brave', 'opera',
                'grammarly', 'dark', 'reader', 'translate',
            ]
        }
    
    def _load_history(self):
        """Load browser history from disk"""
        history_path = os.path.join(
            os.path.dirname(__file__), 
            "ai_models", 
            "browser_history.json"
        )
        if os.path.exists(history_path):
            try:
                with open(history_path, 'r') as f:
                    data = json.load(f)
                    self.browser_history = data.get('history', [])
                log.info(f"Loaded {len(self.browser_history)} browser history entries")
            except Exception as e:
                log.error(f"Failed to load browser history: {e}")
    
    def _save_history(self):
        """Save browser history to disk"""
        history_path = os.path.join(
            os.path.dirname(__file__), 
            "ai_models", 
            "browser_history.json"
        )
        try:
            os.makedirs(os.path.dirname(history_path), exist_ok=True)
            with open(history_path, 'w') as f:
                json.dump({'history': self.browser_history[-self._max_history:]}, f, indent=2)
        except Exception as e:
            log.error(f"Failed to save browser history: {e}")
    
    def analyze_browser_activity(self, browser_data: List[Dict]) -> Dict:
        """
        Analyze browser activity for suspicious patterns
        
        Args:
            browser_data: List of browser events
            
        Returns:
            Dict with analysis results
        """
        # Add to history
        for event in browser_data:
            if event.get('timestamp'):
                self.browser_history.append(event)
        
        if len(self.browser_history) > self._max_history:
            self.browser_history = self.browser_history[-self._max_history:]
        
        self._save_history()
        
        analysis = {
            'suspicious_events': [],
            'login_detections': [],
            'anomalies': [],
            'risk_score': 0.0,
            'patterns': [],
            'timestamp': datetime.now().isoformat()
        }
        
        for event in browser_data:
            # Check for login attempts
            if self._is_login_attempt(event):
                analysis['login_detections'].append({
                    'timestamp': event.get('timestamp'),
                    'url': event.get('url'),
                    'hostname': event.get('hostname'),
                    'browser': event.get('browser'),
                    'title': event.get('title', '')
                })
            
            # Check for suspicious domains
            if self._check_suspicious_domain(event):
                analysis['suspicious_events'].append({
                    'type': 'suspicious_domain',
                    'timestamp': event.get('timestamp'),
                    'url': event.get('url'),
                    'hostname': event.get('hostname'),
                    'domain': self._extract_domain(event.get('url', ''))
                })
            
            # Check for suspicious keywords
            if self._check_suspicious_keywords(event):
                analysis['suspicious_events'].append({
                    'type': 'suspicious_keyword',
                    'timestamp': event.get('timestamp'),
                    'url': event.get('url'),
                    'keyword': self._extract_suspicious_keyword(event.get('url', ''))
                })

            # Check for generative-AI assistant use during monitoring
            ai_domain = self._check_ai_assistant_domain(event)
            if ai_domain:
                analysis['suspicious_events'].append({
                    'type': 'ai_assistant_use',
                    'timestamp': event.get('timestamp'),
                    'url': event.get('url'),
                    'hostname': event.get('hostname'),
                    'domain': ai_domain
                })
            
            # Check for suspicious window titles
            title = event.get('title', '')
            if title and self._check_suspicious_title(title):
                analysis['suspicious_events'].append({
                    'type': 'suspicious_title',
                    'timestamp': event.get('timestamp'),
                    'title': title,
                    'browser': event.get('browser')
                })
        
        # Detect patterns
        analysis['patterns'] = self._detect_patterns(browser_data)
        
        # Calculate risk score
        analysis['risk_score'] = self._calculate_risk_score(analysis)
        
        # Detect anomalies
        analysis['anomalies'] = self._detect_anomalies(browser_data)
        
        return analysis
    
    def _is_login_attempt(self, event: Dict) -> bool:
        """Check if event indicates a login attempt"""
        url = event.get('url', '')
        title = event.get('title', '')
        combined = f"{url} {title}".lower()
        
        # Check login URL patterns
        for pattern in self.suspicious_patterns['login_urls']:
            if re.search(pattern, combined, re.IGNORECASE):
                return True
        
        # Check login indicators
        login_indicators = ['login', 'signin', 'sign-in', 'log-in', 'auth', 'oauth', 'authentication', 'verify']
        return any(indicator in combined for indicator in login_indicators)
    
    def _check_suspicious_domain(self, event: Dict) -> bool:
        """Check if URL contains suspicious domain"""
        url = event.get('url', '').lower()
        for domain in self.suspicious_patterns['suspicious_domains']:
            if domain in url:
                return True
        return False

    def _check_ai_assistant_domain(self, event: Dict) -> Optional[str]:
        """Check if URL is a general-purpose generative-AI assistant"""
        url = event.get('url', '').lower()
        for domain in self.suspicious_patterns.get('ai_assistant_domains', []):
            if domain in url:
                return domain
        return None
    
    def _check_suspicious_keywords(self, event: Dict) -> bool:
        """Check if URL contains suspicious keywords"""
        url = event.get('url', '').lower()
        for keyword in self.suspicious_patterns['suspicious_keywords']:
            if keyword in url:
                return True
        return False
    
    def _check_suspicious_title(self, title: str) -> bool:
        """Check if window title is suspicious"""
        title_lower = title.lower()
        for pattern in self.suspicious_patterns['suspicious_titles']:
            if pattern in title_lower:
                return True
        return False
    
    def _extract_domain(self, url: str) -> Optional[str]:
        """Extract domain from URL"""
        try:
            import urllib.parse
            parsed = urllib.parse.urlparse(url)
            return parsed.netloc or None
        except:
            return None
    
    def _extract_suspicious_keyword(self, text: str) -> Optional[str]:
        """Extract suspicious keyword from text"""
        text_lower = text.lower()
        for keyword in self.suspicious_patterns['suspicious_keywords']:
            if keyword in text_lower:
                return keyword
        return None
    
    def _calculate_risk_score(self, analysis: Dict) -> float:
        """
        Calculate overall risk score. Uses a noisy-OR combination (like the
        RDP and malware ensembles) so multiple independent weak signals
        compound realistically instead of a flat linear sum, and weights
        event *types* rather than just counting them - e.g. a single hit on
        a known cheat-site (chegg/coursehero) is far more diagnostic of exam
        misconduct than five generic "sign in" detections.
        """
        event_type_weight = {
            'suspicious_domain': 0.55,
            'ai_assistant_use': 0.4,
            'suspicious_keyword': 0.3,
        }

        p_benign = 1.0
        for evt in analysis.get('suspicious_events', []):
            w = event_type_weight.get(evt.get('type'), 0.25)
            p_benign *= (1 - w)

        # Login detections are weaker/noisier signal (normal browsing includes
        # logins) - contribute a small amount each, capped
        login_count = len(analysis.get('login_detections', []))
        if login_count:
            p_benign *= (1 - min(login_count * 0.05, 0.25))

        # Behavioral patterns (e.g. rapid restarts, incognito bursts) add risk
        pattern_count = len(analysis.get('patterns', []))
        if pattern_count:
            p_benign *= (1 - min(pattern_count * 0.12, 0.4))

        return round(min(1 - p_benign, 1.0), 3)
    
    def _detect_patterns(self, browser_data: List[Dict]) -> List[Dict]:
        """Detect patterns in browser activity"""
        patterns = []
        
        # Check for pattern of rapid browser restarts
        process_starts = [e for e in browser_data if e.get('event') == 'opened']
        if len(process_starts) > 3:
            timestamps = [e.get('timestamp') for e in process_starts if e.get('timestamp')]
            if len(timestamps) > 2:
                try:
                    times = [datetime.fromisoformat(t) for t in timestamps[:10]]
                    if len(times) > 1:
                        intervals = [(times[i+1] - times[i]).total_seconds() 
                                   for i in range(len(times)-1)]
                        if intervals:
                            avg_interval = sum(intervals) / len(intervals)
                            if avg_interval < 30:
                                patterns.append({
                                    'type': 'rapid_browser_restarts',
                                    'severity': 'medium',
                                    'description': f'Browser restarted {len(process_starts)} times in quick succession',
                                    'count': len(process_starts)
                                })
                except:
                    pass
        
        # Check for unusual browser combinations
        browsers = set(e.get('browser') for e in browser_data if e.get('browser'))
        if len(browsers) > 2:
            patterns.append({
                'type': 'multiple_browsers',
                'severity': 'low',
                'description': f'Multiple browsers used: {", ".join(browsers)}',
                'count': len(browsers)
            })
        
        # Check for many login attempts in short time
        login_events = [e for e in browser_data if self._is_login_attempt(e)]
        if len(login_events) > 5:
            patterns.append({
                'type': 'multiple_login_attempts',
                'severity': 'high',
                'description': f'Multiple login attempts detected: {len(login_events)}',
                'count': len(login_events)
            })
        
        return patterns
    
    def _detect_anomalies(self, browser_data: List[Dict]) -> List[Dict]:
        """Detect anomalies in browser activity"""
        anomalies = []
        
        # Check for long-running browser sessions (could indicate automation)
        for event in browser_data:
            if event.get('event') == 'opened':
                # Check if we have a corresponding close event
                pid = event.get('pid')
                if pid:
                    close_events = [e for e in browser_data if e.get('pid') == pid and e.get('event') == 'closed']
                    if not close_events:
                        # Browser still running, check runtime
                        try:
                            start_time = datetime.fromisoformat(event.get('timestamp', ''))
                            runtime = (datetime.now() - start_time).total_seconds()
                            if runtime > 14400:  # 4 hours
                                anomalies.append({
                                    'type': 'long_running_browser',
                                    'severity': 'medium',
                                    'description': f'Browser running for {runtime/3600:.1f} hours',
                                    'browser': event.get('browser'),
                                    'pid': pid
                                })
                        except:
                            pass
        
        return anomalies
    
    def get_login_history(self, limit: int = 50) -> List[Dict]:
        """Get recent login history"""
        logins = [e for e in self.browser_history if self._is_login_attempt(e)]
        return logins[-limit:]
    
    def clear_history(self):
        """Clear browser history"""
        self.browser_history = []
        self._save_history()
        log.info("Browser history cleared")