"""
SentryUSB Server
-----------------
Flask + Flask-SocketIO server that receives USB device events from lab
agents, logs them to SQLite, and serves a live admin dashboard.
"""
import config
import functools
from datetime import datetime, timedelta
import hmac
import io
import csv
import time
import os
import logging
import json
import socket
import uuid
from ai_anomaly import device_profiler, network_analyzer, login_detector

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, Response, send_file
from flask_socketio import SocketIO
from urllib.parse import urlparse
from werkzeug.utils import secure_filename

import config
import db
from security_upgrade import (behavioral_risk, evaluate_device_policy, evidence_key_id,
                              normalize_policy, sign_evidence, update_mean, verify_chain)
import content_security
import forensics
import peer_sync

try:
    import notifications
    NOTIFICATIONS_AVAILABLE = True
except ImportError:
    NOTIFICATIONS_AVAILABLE = False
    print("⚠️ notifications module not found. Alerts disabled.")

try:
    from reports import generate_pdf_report, generate_excel_report, start_scheduler
    REPORTS_AVAILABLE = True
except ImportError:
    REPORTS_AVAILABLE = False
    print("⚠️ reports module not found. Reports disabled.")

try:
    import exam_scheduler
    EXAM_SCHEDULER_AVAILABLE = True
except ImportError:
    EXAM_SCHEDULER_AVAILABLE = False
    print("⚠️ exam_scheduler module not found. Scheduled exam start/stop disabled.")

try:
    from security import (
        generate_2fa_secret, enable_2fa, disable_2fa,
        is_2fa_enabled, verify_2fa_code, get_2fa_qr_code,
        create_session, update_session_activity, get_active_sessions,
        terminate_session, terminate_all_sessions,
        add_ip_to_whitelist, remove_ip_from_whitelist, get_whitelist,
        ldap_authenticate
    )
    SECURITY_AVAILABLE = True
except ImportError:
    SECURITY_AVAILABLE = False
    print("⚠️ security module not found. Security features disabled.")

# ========== AI IMPORTS ==========
try:
    from ai_anomaly import device_profiler, network_analyzer
    from ai_reports import AIReportGenerator
    AI_AVAILABLE = True
    print("✅ AI modules loaded successfully")
except ImportError as e:
    AI_AVAILABLE = False
    print(f"⚠️ AI modules not available: {e}")

# ========== AI CHAT ASSISTANT ==========
try:
    import ai_chat
    AI_CHAT_AVAILABLE = True
    print("✅ AI chat assistant loaded")
except ImportError as e:
    AI_CHAT_AVAILABLE = False
    print(f"⚠️ AI chat assistant not available: {e}")

# ========== ENHANCED AI IMPORTS ==========
AI_ENHANCED_AVAILABLE = False
try:
    from ai_enhanced import (
        MalwareDetector, RDPDetector, BrowserAnalyzer,
        ThreatIntelligence, MLModelManager, IntegrityChecker, __version__
    )
    AI_ENHANCED_AVAILABLE = True
    print("✅ Enhanced AI modules loaded")
except ImportError as e:
    print(f"⚠️ Enhanced AI modules not available: {e}")
    print("   Run: pip install scikit-learn python-magic yara-python psutil")

# ========== ML ANOMALY DETECTOR (NEW) ==========
ML_ANOMALY_AVAILABLE = False
try:
    from ai_enhanced.ml_anomaly import MLAnomalyDetector
    ML_ANOMALY_AVAILABLE = True
    ml_anomaly_detector = MLAnomalyDetector()
    print("✅ ML Anomaly Detector loaded")
except Exception as e:
    print(f"⚠️ ML Anomaly Detector not available: {e}")

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
log = logging.getLogger("sentryusb.server")

# Resolve templates/static assets relative to this file so the server works
# regardless of the directory from which `python app.py` is launched.
_BASE_DIR = os.path.dirname(os.path.abspath(__file__))
_TEMPLATE_DIR = os.path.join(_BASE_DIR, "templates")
_STATIC_DIR = os.path.join(_BASE_DIR, "static")
app = Flask(__name__, template_folder=_TEMPLATE_DIR, static_folder=_STATIC_DIR)
app.config["SECRET_KEY"] = config.SECRET_KEY
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=8)
app.config["MAX_CONTENT_LENGTH"] = max(1, getattr(config, "CONTENT_UPLOAD_MAX_MB", 50)) * 1024 * 1024

app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = os.environ.get("SENTRYUSB_FORCE_HTTPS", "false").lower() == "true"

if config.SECRET_KEY == "change-me-secret-key":
    print("⚠️  SECRET_KEY is still the default.")
if config.ADMIN_PASSWORD == "change-me-admin-pass":
    print("⚠️  Default admin password is still active.")

socketio = SocketIO(app, async_mode="threading", cors_allowed_origins="*")

# Enterprise command-center extensions (topology, proactive AI, readiness, workflow).
try:
    import enterprise_command_center as enterprise_cc
    ENTERPRISE_CC_AVAILABLE = True
except Exception as _enterprise_exc:
    enterprise_cc = None
    ENTERPRISE_CC_AVAILABLE = False
    logging.getLogger("sentryusb").warning("Enterprise extensions unavailable: %s", _enterprise_exc)

db.init_db()
db.init_policy_tables()

connected_agents = {}
exam_active = False
lockdown_active = False

LOGIN_MAX_ATTEMPTS = getattr(config, 'LOGIN_MAX_ATTEMPTS', 5)
LOGIN_LOCKOUT_SECONDS = getattr(config, 'LOGIN_LOCKOUT_SECONDS', 300)
_failed_logins = {}

# Initialize Enhanced AI components if available
if AI_ENHANCED_AVAILABLE:
    try:
        malware_detector = MalwareDetector()
        rdp_detector = RDPDetector()
        browser_analyzer = BrowserAnalyzer()
        threat_intel = ThreatIntelligence()
        ml_manager = MLModelManager()
        integrity_checker = IntegrityChecker()
        print("✅ Enhanced AI components initialized")
    except Exception as e:
        print(f"⚠️ Enhanced AI initialization error: {e}")
        AI_ENHANCED_AVAILABLE = False


def _login_key():
    return f"{request.form.get('username', '')}|{request.remote_addr}"


def _is_locked_out(key):
    entry = _failed_logins.get(key)
    if not entry or not entry.get("locked_until"):
        return 0
    remaining = entry["locked_until"] - time.time()
    return max(0, int(remaining))


def _record_failed_login(key, username):
    entry = _failed_logins.setdefault(key, {"count": 0, "locked_until": None})
    entry["count"] += 1
    if entry["count"] >= LOGIN_MAX_ATTEMPTS:
        entry["locked_until"] = time.time() + LOGIN_LOCKOUT_SECONDS
        db.add_audit_log(username or "unknown", "login_locked",
                          f"Locked out after {entry['count']} failed attempts from {request.remote_addr}")
    else:
        db.add_audit_log(username or "unknown", "login_failed",
                          f"Failed login attempt from {request.remote_addr}")


def _clear_failed_logins(key):
    _failed_logins.pop(key, None)


@app.after_request
def after_request(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["X-XSS-Protection"] = "1; mode=block"
    # Remove ngrok warning for all visitors
    response.headers["ngrok-skip-browser-warning"] = "true"
    return response


@app.before_request
def _csrf_origin_check():
    if request.method not in ("POST", "PUT", "DELETE", "PATCH"):
        return None
    if not request.path.startswith("/api/"):
        return None
    origin = request.headers.get("Origin") or request.headers.get("Referer")
    if not origin:
        return None
    try:
        origin_host = urlparse(origin).netloc
    except Exception:
        origin_host = ""
    if origin_host and origin_host != request.host:
        log.warning("Blocked cross-origin API request: origin=%s host=%s path=%s",
                    origin_host, request.host, request.path)
        return jsonify({"error": "Cross-origin request rejected"}), 403
    return None


_agent_registration_cache = {}


def _check_agent_rate_limit(ip):
    now = time.time()
    if ip in _agent_registration_cache:
        count, first_time = _agent_registration_cache[ip]
        if now - first_time < 60:
            if count >= 20:
                return False
            _agent_registration_cache[ip] = (count + 1, first_time)
        else:
            _agent_registration_cache[ip] = (1, now)
    else:
        _agent_registration_cache[ip] = (1, now)
    return True


def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


# ============================================================
# V10 TRUST, CONTENT AND FORENSICS HELPERS
# ============================================================

def _append_evidence(event_id, event_kind, payload):
    """Append a HMAC-linked event. The key id permits safe key rotation audits."""
    previous_hash = db.get_last_evidence_hash()
    entry_hash = sign_evidence(previous_hash, event_kind, payload)
    db.append_evidence_chain(event_id, event_kind, payload, previous_hash, entry_hash, evidence_key_id())
    return entry_hash


def _device_risk(data, decision):
    score, signals = 0, []
    if data.get("device_type") == "hid" and not data.get("trusted"):
        score += 35
        signals.append("untrusted_hid")
    if data.get("firmware_fingerprint_changed"):
        score += 40
        signals.append("device_fingerprint_changed")
    if decision.get("action") == "block":
        score += 40
        signals.append("block_policy_match")
    elif decision.get("action") == "approval_required":
        score += 20
        signals.append("approval_required")
    if data.get("status") == "blocked":
        score += 10
    return min(score, 100), signals


def _send_siem(event):
    """Best-effort RFC5424-style UDP syslog forwarding; event persistence never depends on it."""
    host = getattr(config, "SIEM_SYSLOG_HOST", "")
    if not host:
        return
    try:
        message = "<134>1 - SentryUSB - - - " + json.dumps(event, sort_keys=True, separators=(",", ":"))
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
            sock.sendto(message.encode("utf-8")[:8192], (host, int(getattr(config, "SIEM_SYSLOG_PORT", 514))))
    except Exception as exc:
        log.warning("SIEM syslog forwarding failed: %s", exc)


def _incident_capture(event_id, data, severity):
    if not getattr(config, "AUTO_INCIDENT_CAPTURE", False):
        return None
    if int(data.get("risk_score", 0)) < getattr(config, "INCIDENT_CAPTURE_MIN_RISK", 80):
        return None
    try:
        verification = verify_chain(db.get_evidence_chain())
        output_dir = os.path.join(os.path.dirname(__file__), "evidence", "incidents")
        bundle = forensics.create_incident_bundle(output_dir, data, db.get_evidence_chain(), verification)
        db.add_incident_bundle(bundle["incident_id"], event_id, severity, bundle["folder"], bundle["sha256"])
        return bundle
    except Exception as exc:
        log.error("Incident bundle creation failed: %s", exc)
        return None


def _save_uploaded_file(file_storage):
    filename = secure_filename(file_storage.filename or "")
    if not filename:
        raise ValueError("A filename is required")
    upload_dir = os.path.join(os.path.dirname(__file__), "uploads")
    os.makedirs(upload_dir, exist_ok=True)
    path = os.path.join(upload_dir, "%s_%s" % (uuid.uuid4().hex, filename))
    file_storage.save(path)
    if os.path.getsize(path) > app.config["MAX_CONTENT_LENGTH"]:
        os.remove(path)
        raise ValueError("File exceeds configured upload limit")
    return path


# ============================================================
# V10 API: POLICY, EVIDENCE, CONTENT SECURITY, SIEM AND PEERS
# ============================================================

@app.route("/api/v10/policies", methods=["GET", "POST"])
@login_required
def api_v10_policies():
    if request.method == "GET":
        return jsonify({"policies": db.list_device_policies(), "default_action": getattr(config, "DEVICE_POLICY_DEFAULT_ACTION", "monitor")})
    try:
        raw = request.get_json(silent=True) or {}
        raw["created_by"] = session.get("username") or session.get("admin_user") or "admin"
        policy = normalize_policy(raw)
        db.upsert_device_policy(policy)
        db.add_audit_log(policy["created_by"], "device_policy_upsert", policy["policy_id"])
        _append_evidence(None, "device_policy_upsert", policy)
        return jsonify({"success": True, "policy": policy}), 201
    except (ValueError, TypeError) as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/v10/policies/<policy_id>", methods=["DELETE"])
@login_required
def api_v10_delete_policy(policy_id):
    db.delete_device_policy(policy_id)
    actor = session.get("username") or session.get("admin_user") or "admin"
    db.add_audit_log(actor, "device_policy_deleted", policy_id)
    _append_evidence(None, "device_policy_deleted", {"policy_id": policy_id, "actor": actor})
    return jsonify({"success": True})


@app.route("/api/v10/evidence/verify")
@login_required
def api_v10_verify_evidence():
    rows = db.get_evidence_chain()
    return jsonify({"verification": verify_chain(rows), "entries": len(rows), "key_id": evidence_key_id()})


@app.route("/api/v10/siem/events")
@login_required
def api_v10_siem_events():
    limit = max(1, min(request.args.get("limit", 200, type=int), 2000))
    return jsonify({"schema": "sentryusb-siem/v1", "events": db.get_all_events(limit=limit)})


@app.route("/api/v10/content/inspect", methods=["POST"])
@login_required
def api_v10_content_inspect():
    file_storage = request.files.get("file")
    if not file_storage:
        return jsonify({"error": "multipart file field is required"}), 400
    try:
        path = _save_uploaded_file(file_storage)
        result = content_security.inspect_file(path)
        result["stored_for_review"] = os.path.basename(path)
        _append_evidence(None, "content_inspection", result)
        return jsonify(result)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/v10/content/cdr", methods=["POST"])
@login_required
def api_v10_content_cdr():
    file_storage = request.files.get("file")
    if not file_storage:
        return jsonify({"error": "multipart file field is required"}), 400
    try:
        path = _save_uploaded_file(file_storage)
        inspection = content_security.inspect_file(path)
        result = content_security.cdr_reconstruct(path, os.path.join(os.path.dirname(__file__), "cdr_output"))
        _append_evidence(None, "cdr_reconstruction", {"input": inspection, "removed": result["removed"], "modified": result["modified"]})
        return send_file(result["path"], as_attachment=True, download_name=os.path.basename(result["path"]),
                         mimetype="application/octet-stream", max_age=0)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400


@app.route("/api/v10/peer/events", methods=["POST"])
def api_v10_peer_events():
    envelope = request.get_json(silent=True) or {}
    signature = request.headers.get("X-SentryUSB-Peer-Signature", "")
    if not peer_sync.verify(envelope, signature):
        return jsonify({"error": "invalid or disabled peer envelope"}), 403
    event = envelope.get("event") or {}
    if event.get("type") not in {"threat_indicator", "health_notice", "policy_notice"}:
        return jsonify({"error": "unsupported peer event type"}), 400
    _append_evidence(None, "peer_event", {"peer": envelope.get("peer_id"), "event": event})
    db.add_audit_log("peer:" + str(envelope.get("peer_id", "unknown"))[:64], "peer_event_received", event.get("type"))
    return jsonify({"success": True})


# ============================================================
# SYSTEM METRICS API
# ============================================================

@app.route("/api/system/metrics")
@login_required
def api_system_metrics():
    """Get comprehensive system metrics for the System Details panel."""
    import psutil
    import platform
    import socket
    import time

    agents = db.get_agents()
    active_agents = sum(1 for a in agents if a.get('status') == 'online')
    events = db.get_all_events(limit=10000)
    total_events = len(events)
    blocked_events = sum(1 for e in events if e.get('status') == 'blocked')
    cache_rate = 0
    if total_events > 0:
        cache_rate = min(round((total_events - blocked_events) / total_events * 100), 100)

    system_info = {
        "cpu": psutil.cpu_percent(interval=0.5),
        "memory": psutil.virtual_memory().percent,
        "disk": psutil.disk_usage('/').percent,
        "load": psutil.getloadavg()[0] if hasattr(psutil, 'getloadavg') else psutil.cpu_percent() / 100,
        "hostname": socket.gethostname(),
        "os": platform.system(),
        "kernel": platform.release(),
        "arch": platform.machine(),
        "python": platform.python_version(),
        "uptime": time.time() - psutil.boot_time(),
        "cpu_cores": psutil.cpu_count(logical=True),
        "total_memory": f"{psutil.virtual_memory().total / (1024**3):.1f} GB",
        "free_disk": f"{psutil.disk_usage('/').free / (1024**3):.1f} GB",
        "net_io": f"{(psutil.net_io_counters().bytes_sent + psutil.net_io_counters().bytes_recv) / (1024**2):.0f} MB",
        "processes": len(psutil.pids()),
    }

    return jsonify({
        "active_agents": active_agents,
        "total_events": total_events,
        "blocked_devices": blocked_events,
        "cache_rate": cache_rate,
        "exam_active": exam_active,
        "lockdown_active": lockdown_active,
        "system": system_info
    })


# ============================================================
# AGENT TERMINATION ENDPOINT
# ============================================================

@app.route("/api/admin/agents/terminate/<hostname>", methods=["POST"])
@login_required
def api_terminate_agent(hostname):
    """Send termination command to a specific agent."""
    sid = connected_agents.get(hostname)
    if not sid:
        return jsonify({"error": "Agent not currently connected"}), 404

    socketio.emit("terminate_agent", {"hostname": hostname}, room=sid)
    db.add_audit_log(session.get("admin_user"), "terminate_agent", f"Terminated agent: {hostname}")
    log.info(f"Termination command sent to agent {hostname}")
    return jsonify({"status": "ok", "message": f"Termination command sent to {hostname}"})


# ============================================================
# ML ANOMALY DETECTION ENDPOINTS (NEW)
# ============================================================

@app.route("/api/ai/ml/train", methods=["POST"])
@login_required
def api_ml_train():
    """Train the ML anomaly detection model on all device history"""
    if not ML_ANOMALY_AVAILABLE:
        return jsonify({"error": "ML anomaly detector not available"}), 503
    
    # Get all events grouped by device
    all_events = db.get_all_events(limit=10000)
    device_events = {}
    for ev in all_events:
        device_id = ev.get('device_instance_id')
        if device_id:
            device_events.setdefault(device_id, []).append(ev)
    
    if len(device_events) < 10:
        return jsonify({
            "success": False,
            "message": "Need at least 10 devices with history to train ML model"
        })
    
    success = ml_anomaly_detector.train(device_events)
    return jsonify({
        "success": success,
        "devices_trained": len(ml_anomaly_detector.device_profiles),
        "message": "ML model trained successfully" if success else "Training failed"
    })


@app.route("/api/ai/risk-devices")
@login_required
def api_risk_devices():
    """Get list of devices with high anomaly scores"""
    devices = db.get_distinct_devices()
    result = []
    
    for dev in devices:
        device_id = dev.get('device_instance_id')
        if not device_id:
            continue
        
        # Use ML if available and we have enough history
        if ML_ANOMALY_AVAILABLE:
            history = db.get_device_history(device_id)
            if len(history) >= 10:
                try:
                    ml_result = ml_anomaly_detector.predict_anomaly(device_id, history)
                    score = ml_result.get('anomaly_score', 0)
                    status = ml_result.get('status', 'unknown')
                    reasons = ml_result.get('reasons', [])
                    if score >= 30:
                        result.append({
                            'device_id': device_id,
                            'device_name': dev.get('device_name', 'Unknown'),
                            'hostname': dev.get('hostname', 'Unknown'),
                            'score': score,
                            'status': status,
                            'reasons': reasons
                        })
                except Exception as e:
                    log.error(f"ML prediction failed for {device_id}: {e}")
            else:
                # Not enough history, check heuristic profile
                if AI_AVAILABLE:
                    profile = device_profiler.device_profiles.get(device_id, {})
                    score = profile.get('anomaly_score', 0)
                    if score >= 30:
                        result.append({
                            'device_id': device_id,
                            'device_name': dev.get('device_name', 'Unknown'),
                            'hostname': dev.get('hostname', 'Unknown'),
                            'score': score,
                            'status': profile.get('profile_status', 'unknown'),
                            'reasons': ['Heuristic analysis (insufficient data for ML)']
                        })
        elif AI_AVAILABLE:
            profile = device_profiler.device_profiles.get(device_id, {})
            score = profile.get('anomaly_score', 0)
            if score >= 30:
                result.append({
                    'device_id': device_id,
                    'device_name': dev.get('device_name', 'Unknown'),
                    'hostname': dev.get('hostname', 'Unknown'),
                    'score': score,
                    'status': profile.get('profile_status', 'unknown'),
                    'reasons': []
                })
    
    # Sort by score descending and limit to top 10
    result.sort(key=lambda x: x['score'], reverse=True)
    return jsonify(result[:10])


# ============================================================
# AUTHENTICATION ROUTES
# ============================================================

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "")
        password = request.form.get("password", "")
        code = request.form.get("code", "")

        key = _login_key()
        locked_seconds = _is_locked_out(key)
        if locked_seconds:
            minutes = max(1, locked_seconds // 60)
            return render_template("login.html",
                                 error=f"Too many failed attempts. Try again in ~{minutes} min.",
                                 show_2fa=False)

        if db.verify_user_credentials(username, password):
            if SECURITY_AVAILABLE and is_2fa_enabled(username):
                if not code:
                    return render_template("login.html", 
                                         error="2FA code required", 
                                         show_2fa=True, 
                                         username=username)
                if not verify_2fa_code(username, code):
                    _record_failed_login(key, username)
                    return render_template("login.html", 
                                         error="Invalid 2FA code", 
                                         show_2fa=True, 
                                         username=username)
            
            session["logged_in"] = True
            session["admin_user"] = username
            session.permanent = True
            
            if SECURITY_AVAILABLE:
                session_id = create_session(username)
                session["session_id"] = session_id

            _clear_failed_logins(key)
            db.add_audit_log(username, "login", f"Logged in from {request.remote_addr}")
            return redirect(url_for("dashboard"))
        
        if config.LDAP_ENABLED and SECURITY_AVAILABLE:
            if ldap_authenticate(username, password):
                session["logged_in"] = True
                session["admin_user"] = username
                session.permanent = True
                
                if SECURITY_AVAILABLE:
                    session_id = create_session(username)
                    session["session_id"] = session_id

                _clear_failed_logins(key)
                db.add_audit_log(username, "login", f"Logged in via LDAP from {request.remote_addr}")
                return redirect(url_for("dashboard"))

        _record_failed_login(key, username)
        return render_template("login.html", error="Invalid credentials", show_2fa=False)
    
    return render_template("login.html", error=None, show_2fa=False)


@app.route("/logout")
def logout():
    if SECURITY_AVAILABLE and session.get("session_id"):
        terminate_session(session.get("session_id"))
    session.clear()
    return redirect(url_for("login"))


# ============================================================
# PAGE ROUTES
# ============================================================

@app.route("/")
@login_required
def dashboard():
    return render_template("dashboard.html")


@app.route("/devices")
@login_required
def devices():
    device_list = db.get_distinct_devices()
    return render_template("devices.html", devices=device_list)


@app.route("/devices/<path:device_instance_id>")
@login_required
def device_report(device_instance_id):
    history = db.get_device_history(device_instance_id)
    return render_template("device_report.html", history=history, device_instance_id=device_instance_id)


@app.route("/history")
@login_required
def history_page():
    return render_template("history.html")


@app.route("/analytics")
@login_required
def analytics_page():
    return render_template("analytics.html")


@app.route("/admin")
@login_required
def admin_page():
    users = db.get_users()
    allowed_devices = db.get_allowed_devices()
    blocked_devices = db.get_blocked_devices()
    agents = db.get_agents()
    return render_template("admin.html", 
                         users=users, 
                         allowed_devices=allowed_devices,
                         blocked_devices=blocked_devices,
                         agents=agents)


@app.route("/settings")
@login_required
def settings_page():
    return render_template("settings.html")


@app.route("/alerts")
@login_required
def alert_settings():
    return render_template("alert_settings.html")


@app.route("/reports")
@login_required
def reports_page():
    return render_template("reports.html", reports_available=REPORTS_AVAILABLE)


@app.route("/security")
@login_required
def security_page():
    if not SECURITY_AVAILABLE:
        return render_template("security.html", 
                             has_2fa=False, 
                             active_sessions=[], 
                             whitelist=[],
                             security_available=False)
    
    username = session.get("admin_user")
    has_2fa = is_2fa_enabled(username)
    active_sessions = get_active_sessions(username)
    whitelist = get_whitelist()
    
    return render_template("security.html", 
                         has_2fa=has_2fa,
                         active_sessions=active_sessions,
                         whitelist=whitelist,
                         security_available=True)


@app.route("/exam")
@login_required
def exam_control():
    return render_template("exam_control.html")


@app.route("/browser-control")
@login_required
def browser_control():
    return render_template("browser_control.html")


@app.route("/ai-enhanced")
@login_required
def ai_enhanced_dashboard():
    """AI Enhanced Security Dashboard"""
    return render_template("ai_enhanced_dashboard.html")

@app.route("/live-map")
@login_required
def live_map():
    """Real-time floor map of all lab PCs and their current status."""
    return render_template("live_map.html")


@app.route("/api/live-map/state")
@login_required
def api_live_map_state():
    """Snapshot used to populate the live map on page load."""
    try:
        agents = db.get_agents()
    except Exception as e:
        log.error(f"live-map state: get_agents failed: {e}")
        agents = []

    try:
        recent_events = db.get_all_events(limit=50)
    except Exception:
        recent_events = []

    anomaly_by_device = {}
    if AI_AVAILABLE:
        for device_id in list(getattr(device_profiler, "device_profiles", {}).keys()):
            score, status = device_profiler.predict_anomaly(device_id)
            anomaly_by_device[device_id] = {"score": score, "status": status}

    nodes = []
    for a in agents:
        nodes.append({
            "hostname": a.get("hostname"),
            "ip_address": a.get("ip_address"),
            "username": a.get("username"),
            "status": a.get("status"),
            "version": a.get("version"),
            "last_seen": a.get("last_seen"),
        })

    recent_alerts = []
    for e in recent_events[:15]:
        if e.get("status") in ("blocked", "overridden"):
            recent_alerts.append({
                "type": "usb",
                "hostname": e.get("hostname"),
                "device_name": e.get("device_name"),
                "status": e.get("status"),
                "timestamp": e.get("timestamp"),
            })

    return jsonify({
        "nodes": nodes,
        "recent_alerts": recent_alerts,
        "anomaly_by_device": anomaly_by_device,
        "exam_active": exam_active,
        "lockdown_active": lockdown_active,
    })


def _ai_context():
    return {"exam_active": exam_active, "lockdown_active": lockdown_active}


@app.route("/api/ai/chat", methods=["POST"])
@login_required
def api_ai_chat():
    """AI chat assistant endpoint used by the floating chat widget."""
    if not AI_CHAT_AVAILABLE:
        return jsonify({"answer": "The AI chat assistant module isn't available on this server.",
                        "source": "unavailable"}), 200
    data = request.get_json(silent=True) or {}
    admin_user = session.get("admin_user", "admin")
    try:
        result = ai_chat.answer(data.get("message", ""), admin_user=admin_user, injected_context=_ai_context())
        return jsonify(result)
    except Exception as e:
        log.error(f"AI chat error: {e}")
        return jsonify({"answer": "Something went wrong answering that - check the server logs.",
                        "source": "error"}), 200


@app.route("/api/ai/insights")
@login_required
def api_ai_insights():
    """Current proactive insights (the autopilot also pushes new ones over Socket.IO)."""
    if not AI_CHAT_AVAILABLE:
        return jsonify({"insights": []})
    try:
        return jsonify({"insights": ai_chat.current_insights(_ai_context())})
    except Exception as e:
        log.error(f"AI insights error: {e}")
        return jsonify({"insights": []})


@app.route("/api/ai/chat/reset", methods=["POST"])
@login_required
def api_ai_chat_reset():
    if AI_CHAT_AVAILABLE:
        ai_chat.reset_conversation(session.get("admin_user", "admin"))
    return jsonify({"success": True})


@app.route("/api/ai/action", methods=["POST"])
@login_required
def api_ai_action():
    """Execute an assistant-proposed action AFTER the admin confirmed it in the
    widget. Only this small allow-list runs here; exam / override / training
    use their existing endpoints."""
    data = request.get_json(silent=True) or {}
    kind, params = data.get("type"), data.get("params") or {}
    admin = session.get("admin_user", "admin")
    try:
        if kind == "allow_device":
            device_id = str(params.get("device_id") or "").strip()
            if not device_id:
                return jsonify({"success": False, "message": "device_id is required"}), 400
            db.add_allowed_device(device_id, params.get("device_name") or device_id, admin)
            db.add_audit_log(admin, "ai_assistant_allow_device", device_id[:120])
            return jsonify({"success": True, "message": f"Device {device_id} added to the allow-list."})
        if kind == "unblock_device":
            device_id = str(params.get("device_id") or "").strip()
            if not device_id:
                return jsonify({"success": False, "message": "device_id is required"}), 400
            db.remove_blocked_device(device_id)
            db.add_audit_log(admin, "ai_assistant_unblock_device", device_id[:120])
            return jsonify({"success": True, "message": f"Device {device_id} removed from the block-list."})
        if kind == "message_hub":
            import hub_client, messenger_media
            text = messenger_media.clean_text(params.get("text"), 2000)
            if not text:
                return jsonify({"success": False, "message": "Nothing to send."}), 400
            result = hub_client.send_messenger_message(config, db, text, "info", admin)
            if result.get("success"):
                db.add_audit_log(admin, "messenger_message_sent", f"to Hub (via AI assistant): {text[:100]}")
                return jsonify({"success": True, "message": "Message sent to the Hub."})
            return jsonify({"success": False, "message": result.get("error", "Could not send.")}), 503
        return jsonify({"success": False, "message": "Unsupported action."}), 400
    except Exception as e:
        log.error(f"AI action failed: {e}")
        return jsonify({"success": False, "message": str(e)}), 500


@app.route("/api/ai/train-simple", methods=["POST"])
@login_required
def api_train_simple():
    """Simple AI training - no external dependencies"""
    try:
        events = db.get_all_events(limit=1000)
        
        training_data = []
        for event in events:
            training_data.append({
                'device_id': event.get('device_instance_id'),
                'device_instance_id': event.get('device_instance_id'),
                'status': event.get('status'),
                'hostname': event.get('hostname'),
                'username': event.get('username'),
                'timestamp': event.get('timestamp'),
                'device_name': event.get('device_name')
            })
        
        from ai_enhanced import MLModelManager
        ml = MLModelManager()
        result = ml.train_anomaly_model(training_data)
        
        return jsonify({
            'success': result.get('success', True),
            'events_processed': len(events),
            'devices_trained': result.get('devices', 0),
            'message': f"Trained on {len(events)} events"
        })
    except Exception as e:
        log.error(f"Training error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ============================================================
# API ROUTES (Events, Devices, Agents, Override, Exam, Lockdown, etc.)
# ============================================================

@app.route("/api/events")
@login_required
def api_events():
    return jsonify(db.get_all_events())


@app.route("/api/devices")
@login_required
def api_devices():
    return jsonify(db.get_distinct_devices())


@app.route("/api/devices/<path:device_instance_id>/history")
@login_required
def api_device_history(device_instance_id):
    return jsonify(db.get_device_history(device_instance_id))


@app.route("/api/agents")
@login_required
def api_agents():
    agents = db.get_agents()
    for agent in agents:
        agent["exam_active"] = agent.get("hostname") in connected_agents and exam_active
        agent["lockdown_active"] = lockdown_active
    return jsonify(agents)


@app.route("/api/override/<int:event_id>", methods=["POST"])
@login_required
def api_override(event_id):
    event = db.get_event(event_id)
    if not event:
        return jsonify({"error": "event not found"}), 404
    if event["device_type"] != "storage" or event["status"] != "blocked":
        return jsonify({"error": "only blocked storage devices can be overridden"}), 400
    
    if exam_active or lockdown_active:
        return jsonify({"error": "Cannot override devices during exam or lockdown mode"}), 403

    hostname = event["hostname"]
    sid = connected_agents.get(hostname)
    if not sid:
        return jsonify({"error": "agent not currently connected"}), 409

    socketio.emit("override_device", {
        "event_id": event_id,
        "device_instance_id": event["device_instance_id"],
    }, room=sid)

    db.mark_overridden(event_id, session.get("admin_user", "admin"))
    
    if NOTIFICATIONS_AVAILABLE:
        event_data = db.get_event(event_id)
        if event_data:
            event_data["status"] = "overridden"
            try:
                notifications.send_alert(event_data)
            except Exception as e:
                log.error(f"Failed to send alert: {e}")
    
    return jsonify({"status": "override sent"})


@app.route("/api/exam/config", methods=["GET", "POST"])
@login_required
def api_exam_config():
    if request.method == "GET":
        config_data = db.get_exam_config()
        return jsonify(config_data)
    else:
        data = request.get_json() or {}
        db.save_exam_config(data)
        db.add_audit_log(session.get("admin_user"), "exam_config", "Updated exam configuration")
        if EXAM_SCHEDULER_AVAILABLE:
            try:
                exam_scheduler.sync_schedule()
            except Exception as e:
                log.error(f"Failed to reschedule exam: {e}")
        return jsonify({"status": "ok"})


@app.route("/api/exam/start", methods=["POST"])
@login_required
def api_exam_start():
    global exam_active
    
    data = request.get_json() or {}
    url = data.get("url", "")
    duration = data.get("duration", 3600)
    try:
        duration = max(60, min(int(duration or 3600), 24 * 60 * 60))
    except (TypeError, ValueError):
        return jsonify({"status": "error", "message": "Duration must be a valid number of seconds"}), 400

    exam_active = True
    
    socketio.emit("exam_start", {
        "url": url,
        "duration": duration,
        "issued_at": int(time.time()),
        "lease_expires_at": int(time.time()) + duration,
        "block_usb": True,
        "block_internet": True,
        "block_browsers": True,
        "block_copy_paste": True,
        "block_print_screen": True
    })
    
    db.add_audit_log(session.get("admin_user"), "exam_start", "Started exam")
    
    return jsonify({"status": "ok", "message": "Exam started"})


@app.route("/api/exam/stop", methods=["POST"])
@login_required
def api_exam_stop():
    global exam_active
    
    exam_active = False
    
    socketio.emit("exam_stop", {})
    
    db.add_audit_log(session.get("admin_user"), "exam_stop", "Stopped exam")
    
    return jsonify({"status": "ok", "message": "Exam stopped"})


@app.route("/api/exam/status")
@login_required
def api_exam_status():
    return jsonify({"active": exam_active})


@app.route("/api/exam/history")
@login_required
def api_exam_history():
    return jsonify(db.get_exam_history())


@app.route("/api/lockdown/apply", methods=["POST"])
@login_required
def api_lockdown_apply():
    global lockdown_active
    
    data = request.get_json() or {}
    browsers = data.get("browsers", [])
    
    if not browsers:
        return jsonify({"status": "error", "message": "No browsers selected"}), 400
    
    lockdown_active = True
    
    socketio.emit("lockdown_apply", data)
    
    db.add_audit_log(session.get("admin_user"), "lockdown_apply", 
                     f"Applied lockdown. Browsers: {', '.join(browsers)}")
    
    return jsonify({"status": "ok", "message": f"Lockdown applied. Blocking {len(browsers)} browsers"})


@app.route("/api/lockdown/remove", methods=["POST"])
@login_required
def api_lockdown_remove():
    global lockdown_active
    
    lockdown_active = False
    
    socketio.emit("lockdown_remove", {})
    
    db.add_audit_log(session.get("admin_user"), "lockdown_remove", "Removed lockdown")
    
    return jsonify({"status": "ok", "message": "Lockdown removed"})


@app.route("/api/lockdown/status")
@login_required
def api_lockdown_status():
    global lockdown_active
    
    agents = db.get_agents()
    online_agents = [a for a in agents if a.get("status") == "online"]
    
    return jsonify({
        "enabled": lockdown_active,
        "agents": len(agents),
        "online_agents": len(online_agents),
        "lockdown_active": lockdown_active
    })


@app.route("/api/health")
@login_required
def api_health():
    try:
        events = db.get_all_events(1)
        return jsonify({
            "status": "ok",
            "timestamp": datetime.utcnow().isoformat(),
            "connected_agents": len(connected_agents),
            "exam_active": exam_active,
            "lockdown_active": lockdown_active,
            "total_events": len(events),
            "version": "2.0.0"
        })
    except Exception as e:
        return jsonify({"status": "error", "error": str(e)}), 500


@app.route("/api/agents/health")
@login_required
def api_agents_health():
    agent_status = []
    for hostname, sid in connected_agents.items():
        agent_status.append({
            "hostname": hostname,
            "status": "online",
            "session_id": sid[:8] if sid else "unknown",
            "exam_active": exam_active,
            "lockdown_active": lockdown_active
        })
    return jsonify({
        "total": len(agent_status),
        "agents": agent_status,
        "timestamp": datetime.utcnow().isoformat()
    })


@app.route("/api/stats")
@login_required
def api_stats():
    events = db.get_all_events(10000)
    
    total = len(events)
    blocked = sum(1 for e in events if e.get("status") == "blocked")
    allowed = sum(1 for e in events if e.get("status") == "allowed")
    overridden = sum(1 for e in events if e.get("status") == "overridden")
    connected = sum(1 for e in events if e.get("status") == "connected")
    
    agents = db.get_agents()
    online_agents = sum(1 for a in agents if a.get("status") == "online")
    total_agents = len(agents)
    
    return jsonify({
        "total_events": total,
        "blocked_events": blocked,
        "allowed_events": allowed,
        "overridden_events": overridden,
        "connected_events": connected,
        "block_rate": round((blocked / total * 100) if total > 0 else 0, 1),
        "online_agents": online_agents,
        "total_agents": total_agents,
        "exam_active": exam_active,
        "lockdown_active": lockdown_active,
        "timestamp": datetime.utcnow().isoformat()
    })


@app.route("/api/report/pdf")
@login_required
def api_download_pdf():
    if not REPORTS_AVAILABLE:
        return jsonify({"error": "PDF reports not available"}), 500
    
    try:
        period = request.args.get("period", "week")
        pdf_data = generate_pdf_report(period)
        
        response = app.make_response(pdf_data)
        response.headers["Content-Type"] = "application/pdf"
        response.headers["Content-Disposition"] = f"attachment; filename=sentryusb_report_{period}_{datetime.now().strftime('%Y%m%d')}.pdf"
        return response
    except Exception as e:
        log.error(f"PDF generation failed: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/report/excel")
@login_required
def api_download_excel():
    if not REPORTS_AVAILABLE:
        return jsonify({"error": "Excel reports not available"}), 500
    
    try:
        period = request.args.get("period", "week")
        excel_data = generate_excel_report(period)
        
        response = app.make_response(excel_data)
        response.headers["Content-Type"] = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        response.headers["Content-Disposition"] = f"attachment; filename=sentryusb_report_{period}_{datetime.now().strftime('%Y%m%d')}.xlsx"
        return response
    except Exception as e:
        log.error(f"Excel generation failed: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/report/csv")
@login_required
def api_download_csv():
    try:
        period = request.args.get("period", "week")
        events = db.get_all_events(limit=100000)
        
        buf = io.StringIO()
        fieldnames = ["id", "timestamp", "hostname", "username", "device_name", "device_type",
                      "status", "vendor_id", "product_id", "serial_number", "admin_user",
                      "removed_at", "duration_seconds", "exam_mode", "lockdown_mode"]
        writer = csv.DictWriter(buf, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for e in events:
            writer.writerow(e)

        filename = f"sentryusb_events_{period}_{datetime.now().strftime('%Y%m%d')}.csv"
        return Response(
            buf.getvalue(),
            mimetype="text/csv",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
    except Exception as e:
        log.error(f"CSV export failed: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/admin/audit-logs/csv")
@login_required
def api_download_audit_csv():
    try:
        logs = db.get_audit_logs(limit=10000)
        buf = io.StringIO()
        fieldnames = ["id", "username", "action", "details", "timestamp"]
        writer = csv.DictWriter(buf, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in logs:
            writer.writerow(row)

        filename = f"sentryusb_audit_log_{datetime.now().strftime('%Y%m%d')}.csv"
        return Response(
            buf.getvalue(),
            mimetype="text/csv",
            headers={"Content-Disposition": f"attachment; filename={filename}"}
        )
    except Exception as e:
        log.error(f"Audit log CSV export failed: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/report/schedule", methods=["POST"])
@login_required
def api_schedule_report():
    try:
        data = request.get_json() or {}
        period = data.get("period", "daily")
        email = data.get("email", config.EMAIL_TO)
        
        if not email:
            return jsonify({"error": "Email address required"}), 400
        
        db.add_audit_log(session.get("admin_user"), "schedule_report", f"Scheduled {period} report to {email}")
        return jsonify({"status": "ok", "message": f"{period.capitalize()} report scheduled"})
    except Exception as e:
        log.error(f"Schedule report failed: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/alert/settings", methods=["GET"])
@login_required
def api_alert_settings():
    return jsonify({
        "email_enabled": config.EMAIL_ENABLED,
        "email_host": config.EMAIL_HOST,
        "email_port": config.EMAIL_PORT,
        "email_username": config.EMAIL_USERNAME,
        "email_to": config.EMAIL_TO,
        "telegram_enabled": config.TELEGRAM_ENABLED,
        "telegram_token": config.TELEGRAM_BOT_TOKEN or "",
        "telegram_chat_id": config.TELEGRAM_CHAT_ID or "",
        "slack_enabled": config.SLACK_ENABLED,
        "slack_webhook": config.SLACK_WEBHOOK_URL or "",
        "discord_enabled": config.DISCORD_ENABLED,
        "discord_webhook": config.DISCORD_WEBHOOK_URL or "",
        "alert_on_blocked": config.ALERT_ON_BLOCKED,
        "alert_on_allowed": config.ALERT_ON_ALLOWED,
        "alert_on_connected": config.ALERT_ON_CONNECTED,
        "alert_on_removed": config.ALERT_ON_REMOVED,
        "alert_on_overridden": config.ALERT_ON_OVERRIDDEN,
        "alert_cooldown": config.ALERT_COOLDOWN_SECONDS,
    })


@app.route("/api/alert/email", methods=["POST"])
@login_required
def api_save_email_settings():
    data = request.get_json() or {}
    config.EMAIL_ENABLED = data.get("enabled", True)
    config.EMAIL_HOST = data.get("host", "smtp.gmail.com")
    config.EMAIL_PORT = data.get("port", 587)
    config.EMAIL_USERNAME = data.get("username", "")
    config.EMAIL_PASSWORD = data.get("password", "")
    config.EMAIL_TO = data.get("to", "")
    
    db.add_audit_log(session.get("admin_user"), "alert_settings", "Updated email settings")
    return jsonify({"status": "ok", "message": "Email settings saved"})


@app.route("/api/alert/telegram", methods=["POST"])
@login_required
def api_save_telegram_settings():
    data = request.get_json() or {}
    config.TELEGRAM_ENABLED = data.get("enabled", False)
    config.TELEGRAM_BOT_TOKEN = data.get("token", "")
    config.TELEGRAM_CHAT_ID = data.get("chat_id", "")
    
    db.add_audit_log(session.get("admin_user"), "alert_settings", "Updated Telegram settings")
    return jsonify({"status": "ok", "message": "Telegram settings saved"})


@app.route("/api/alert/slack", methods=["POST"])
@login_required
def api_save_slack_settings():
    data = request.get_json() or {}
    config.SLACK_ENABLED = data.get("enabled", False)
    config.SLACK_WEBHOOK_URL = data.get("webhook", "")
    
    db.add_audit_log(session.get("admin_user"), "alert_settings", "Updated Slack settings")
    return jsonify({"status": "ok", "message": "Slack settings saved"})


@app.route("/api/alert/discord", methods=["POST"])
@login_required
def api_save_discord_settings():
    data = request.get_json() or {}
    config.DISCORD_ENABLED = data.get("enabled", False)
    config.DISCORD_WEBHOOK_URL = data.get("webhook", "")
    
    db.add_audit_log(session.get("admin_user"), "alert_settings", "Updated Discord settings")
    return jsonify({"status": "ok", "message": "Discord settings saved"})


@app.route("/api/alert/rules", methods=["POST"])
@login_required
def api_save_alert_rules():
    data = request.get_json() or {}
    config.ALERT_ON_BLOCKED = data.get("alert_on_blocked", True)
    config.ALERT_ON_ALLOWED = data.get("alert_on_allowed", True)
    config.ALERT_ON_CONNECTED = data.get("alert_on_connected", False)
    config.ALERT_ON_REMOVED = data.get("alert_on_removed", False)
    config.ALERT_ON_OVERRIDDEN = data.get("alert_on_overridden", True)
    config.ALERT_COOLDOWN_SECONDS = data.get("alert_cooldown", 300)
    
    db.add_audit_log(session.get("admin_user"), "alert_settings", "Updated alert rules")
    return jsonify({"status": "ok", "message": "Alert rules saved"})


@app.route("/api/alert/test", methods=["POST"])
@login_required
def api_test_alert():
    if not NOTIFICATIONS_AVAILABLE:
        return jsonify({"error": "Notifications module not available"}), 500
    
    data = request.get_json() or {}
    alert_type = data.get("type", "email")
    
    sent = False
    
    if alert_type == "email":
        sent = notifications.send_email_alert(
            "🧪 SentryUSB Test Alert", 
            """
            <html>
            <body style="font-family: Arial, sans-serif; padding: 20px;">
                <h2 style="color: #6366f1;">🧪 SentryUSB Test Alert</h2>
                <p>This is a test notification from SentryUSB.</p>
                <p>If you received this, your email configuration is working!</p>
                <hr>
                <p style="color: #666; font-size: 12px;">SentryUSB Security System</p>
            </body>
            </html>
            """,
            is_html=True
        )
    elif alert_type == "telegram":
        sent = notifications.send_telegram_alert(
            "🧪 <b>SentryUSB Test Alert</b>\n\nThis is a test notification from SentryUSB.\n\n✅ If you received this, your Telegram configuration is working!"
        )
    elif alert_type == "slack":
        sent = notifications.send_slack_alert(
            "*🧪 SentryUSB Test Alert*\n\nThis is a test notification from SentryUSB.\n\n✅ If you received this, your Slack configuration is working!"
        )
    elif alert_type == "discord":
        sent = notifications.send_discord_alert(
            "**🧪 SentryUSB Test Alert**\n\nThis is a test notification from SentryUSB.\n\n✅ If you received this, your Discord configuration is working!"
        )
    
    if sent:
        db.add_audit_log(session.get("admin_user"), "test_alert", f"Test {alert_type} alert sent")
        return jsonify({"success": True, "message": f"Test {alert_type} alert sent!"})
    else:
        return jsonify({"success": False, "error": f"Failed to send {alert_type} alert. Check your configuration."})


if SECURITY_AVAILABLE:
    @app.route("/api/2fa/setup", methods=["POST"])
    @login_required
    def api_2fa_setup():
        username = session.get("admin_user")
        secret = generate_2fa_secret(username)
        qr_code = get_2fa_qr_code(username)
        return jsonify({"secret": secret, "qr_code": qr_code})

    @app.route("/api/2fa/enable", methods=["POST"])
    @login_required
    def api_2fa_enable():
        data = request.get_json() or {}
        code = data.get("code")
        username = session.get("admin_user")
        
        if verify_2fa_code(username, code):
            enable_2fa(username)
            db.add_audit_log(username, "2fa_enable", "2FA enabled")
            return jsonify({"status": "ok", "message": "2FA enabled successfully"})
        else:
            return jsonify({"error": "Invalid verification code"}), 400

    @app.route("/api/2fa/disable", methods=["POST"])
    @login_required
    def api_2fa_disable():
        data = request.get_json() or {}
        code = data.get("code")
        username = session.get("admin_user")
        
        if verify_2fa_code(username, code):
            disable_2fa(username)
            db.add_audit_log(username, "2fa_disable", "2FA disabled")
            return jsonify({"status": "ok", "message": "2FA disabled successfully"})
        else:
            return jsonify({"error": "Invalid verification code"}), 400

    @app.route("/api/sessions")
    @login_required
    def api_get_sessions():
        username = session.get("admin_user")
        sessions = get_active_sessions(username)
        return jsonify(sessions)

    @app.route("/api/sessions/terminate/<session_id>", methods=["POST"])
    @login_required
    def api_terminate_session(session_id):
        username = session.get("admin_user")
        terminate_session(session_id)
        db.add_audit_log(username, "session_terminated", f"Terminated session: {session_id[:8]}")
        return jsonify({"status": "ok"})

    @app.route("/api/sessions/terminate-all", methods=["POST"])
    @login_required
    def api_terminate_all_sessions():
        username = session.get("admin_user")
        current_session = session.get("session_id")
        terminate_all_sessions(username, current_session)
        db.add_audit_log(username, "sessions_terminated", "All other sessions terminated")
        return jsonify({"status": "ok"})

    @app.route("/api/whitelist", methods=["GET"])
    @login_required
    def api_get_whitelist():
        return jsonify(get_whitelist())

    @app.route("/api/whitelist", methods=["POST"])
    @login_required
    def api_add_to_whitelist():
        data = request.get_json() or {}
        ip_address = data.get("ip_address")
        description = data.get("description")
        
        if not ip_address:
            return jsonify({"error": "IP address required"}), 400
        
        add_ip_to_whitelist(ip_address, description, session.get("admin_user"))
        db.add_audit_log(session.get("admin_user"), "ip_whitelist_add", f"Added IP: {ip_address}")
        return jsonify({"status": "ok"})

    @app.route("/api/whitelist/<ip_address>", methods=["DELETE"])
    @login_required
    def api_remove_from_whitelist(ip_address):
        remove_ip_from_whitelist(ip_address)
        db.add_audit_log(session.get("admin_user"), "ip_whitelist_remove", f"Removed IP: {ip_address}")
        return jsonify({"status": "ok"})


@app.route("/api/admin/users", methods=["GET"])
@login_required
def api_list_users():
    return jsonify(db.get_users())


@app.route("/api/admin/users", methods=["POST"])
@login_required
def api_add_user():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""
    role = data.get("role", "user")
    if not username or not password:
        return jsonify({"error": "username and password required"}), 400
    if len(password) < 8:
        return jsonify({"error": "password must be at least 8 characters"}), 400
    if db.get_user_by_username(username):
        return jsonify({"error": "username already exists"}), 409
    db.add_user(username, password, role)
    db.add_audit_log(session.get("admin_user"), "add_user", f"Added user: {username}")
    return jsonify({"status": "ok"})


@app.route("/api/admin/users/<username>", methods=["PUT"])
@login_required
def api_update_user(username):
    data = request.get_json(silent=True) or {}
    password = data.get("password") or ""
    if not password or len(password) < 8:
        return jsonify({"error": "password must be at least 8 characters"}), 400
    db.update_user_password(username, password)
    db.add_audit_log(session.get("admin_user"), "update_user", f"Updated password for: {username}")
    return jsonify({"status": "ok"})


@app.route("/api/admin/users/<username>", methods=["DELETE"])
@login_required
def api_delete_user(username):
    if username == "admin":
        return jsonify({"error": "cannot delete admin user"}), 400
    db.delete_user(username)
    db.add_audit_log(session.get("admin_user"), "delete_user", f"Deleted user: {username}")
    return jsonify({"status": "ok"})


@app.route("/api/admin/allowed", methods=["POST"])
@login_required
def api_add_allowed_device():
    data = request.get_json() or {}
    device_id = data.get("device_instance_id")
    device_name = data.get("device_name")
    if not device_id:
        return jsonify({"error": "device_instance_id required"}), 400
    db.add_allowed_device(device_id, device_name, session.get("admin_user"))
    db.add_audit_log(session.get("admin_user"), "add_allowed", f"Added allowed device: {device_name}")
    return jsonify({"status": "ok"})


@app.route("/api/admin/allowed/<path:device_id>", methods=["DELETE"])
@login_required
def api_remove_allowed_device(device_id):
    db.remove_allowed_device(device_id)
    db.add_audit_log(session.get("admin_user"), "remove_allowed", f"Removed allowed device: {device_id}")
    return jsonify({"status": "ok"})


@app.route("/api/admin/blocked", methods=["POST"])
@login_required
def api_add_blocked_device():
    data = request.get_json() or {}
    device_id = data.get("device_instance_id")
    device_name = data.get("device_name")
    if not device_id:
        return jsonify({"error": "device_instance_id required"}), 400
    db.add_blocked_device(device_id, device_name, session.get("admin_user"))
    db.add_audit_log(session.get("admin_user"), "add_blocked", f"Added blocked device: {device_name}")
    return jsonify({"status": "ok"})


@app.route("/api/admin/blocked/<path:device_id>", methods=["DELETE"])
@login_required
def api_remove_blocked_device(device_id):
    db.remove_blocked_device(device_id)
    db.add_audit_log(session.get("admin_user"), "remove_blocked", f"Removed blocked device: {device_id}")
    return jsonify({"status": "ok"})


@app.route("/api/admin/agents/<hostname>", methods=["DELETE"])
@login_required
def api_remove_agent(hostname):
    db.remove_agent(hostname)
    db.add_audit_log(session.get("admin_user"), "remove_agent", f"Removed agent: {hostname}")
    return jsonify({"status": "ok"})


@app.route("/api/admin/change-password", methods=["POST"])
@login_required
def api_change_password():
    data = request.get_json(silent=True) or {}
    current = data.get("current", "")
    new_password = data.get("new_password", "")
    username = session.get("admin_user")

    if not new_password or len(new_password) < 8:
        return jsonify({"error": "New password must be at least 8 characters"}), 400

    if not db.verify_user_credentials(username, current):
        return jsonify({"error": "Current password is incorrect"}), 401

    db.update_user_password(username, new_password)
    db.add_audit_log(username, "change_password", "Password changed")
    return jsonify({"status": "ok"})


@app.route("/api/admin/clear-data", methods=["DELETE"])
@login_required
def api_clear_data():
    db.clear_all_events()
    db.add_audit_log(session.get("admin_user"), "clear_data", "Cleared all event data")
    return jsonify({"status": "ok"})


@app.route("/api/admin/audit-logs")
@login_required
def api_audit_logs():
    return jsonify(db.get_audit_logs())


# ============================================================
# TOKEN ENDPOINT FOR AGENT AUTO-SYNC
# ============================================================

@app.route("/api/agent-token")
def api_agent_token():
    """Provide token to agents for auto-sync"""
    client_ip = request.remote_addr
    allowed_prefixes = ("127.", "192.168.", "10.", "172.16.", "172.17.", "172.18.", "172.19.", 
                        "172.20.", "172.21.", "172.22.", "172.23.", "172.24.", "172.25.", 
                        "172.26.", "172.27.", "172.28.", "172.29.", "172.30.", "172.31.")
    
    if not any(client_ip.startswith(prefix) for prefix in allowed_prefixes):
        log.warning(f"Token request from non-local IP: {client_ip}")
        return jsonify({"error": "Access denied"}), 403
    
    return jsonify({
        "token": config.AGENT_AUTH_TOKEN,
        "version": "2.0.0",
        "server_url": request.host_url
    })


# ============================================================
# AI ROUTES - BASIC AI
# ============================================================

@app.route("/api/ai/device-analysis/<device_id>")
@login_required
def api_device_analysis(device_id):
    if not AI_AVAILABLE:
        return jsonify({"error": "AI modules not available"}), 503
    
    try:
        events = db.get_device_history(device_id)
        profile = device_profiler.build_profile(
            device_id, 
            {'event_type': 'analysis', 'timestamp': datetime.now().isoformat()}
        )
        anomaly_score, status = device_profiler.predict_anomaly(device_id)
        
        recent_events = []
        for event in events[-20:]:
            recent_events.append({
                'timestamp': event.get('timestamp'),
                'status': event.get('status'),
                'hostname': event.get('hostname'),
                'device_name': event.get('device_name')
            })
        
        return jsonify({
            'device_id': device_id,
            'anomaly_score': anomaly_score,
            'profile_status': status,
            'features': profile.get('features', {}),
            'recent_events': recent_events,
            'total_events': len(events)
        })
    except Exception as e:
        log.error(f"AI device analysis error: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/ai/network-insights")
@login_required
def api_network_insights():
    if not AI_AVAILABLE:
        return jsonify({"error": "AI modules not available"}), 503
    
    try:
        events = db.get_all_events(limit=500)
        audit_logs = db.get_audit_logs(limit=200)
        
        analyzed_events = []
        for event in events:
            analyzed_events.append({
                'event_type': 'usb_event',
                'hostname': event.get('hostname'),
                'status': event.get('status'),
                'device_type': event.get('device_type'),
                'timestamp': event.get('timestamp')
            })
        
        for log_entry in audit_logs:
            analyzed_events.append({
                'event_type': 'login',
                'username': log_entry.get('username'),
                'action': log_entry.get('action'),
                'timestamp': log_entry.get('timestamp')
            })
        
        insights = network_analyzer.analyze_events(analyzed_events)
        
        return jsonify({
            'insights': insights,
            'total_analyzed': len(analyzed_events),
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        log.error(f"AI network insights error: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/ai/predictions")
@login_required
def api_ai_predictions():
    if not AI_AVAILABLE:
        return jsonify({
            'predicted_block_rate': 0,
            'risk_level': 'Unknown',
            'recommended_action': 'AI not available',
            'events_analyzed': 0
        })
    
    try:
        events = db.get_all_events(limit=1000)
        
        if len(events) < 10:
            return jsonify({
                'predicted_block_rate': 0,
                'risk_level': 'Learning',
                'recommended_action': 'Collecting data for AI analysis',
                'events_analyzed': len(events)
            })
        
        blocked = [e for e in events if e.get('status') == 'blocked']
        block_rate = len(blocked) / len(events) * 100
        
        if block_rate > 70:
            risk_level = "High"
            action = "Consider reviewing USB usage policies"
        elif block_rate > 40:
            risk_level = "Medium"
            action = "Monitor for unusual patterns"
        else:
            risk_level = "Low"
            action = "Normal activity detected"
        
        return jsonify({
            'predicted_block_rate': round(block_rate, 1),
            'risk_level': risk_level,
            'recommended_action': action,
            'events_analyzed': len(events)
        })
    except Exception as e:
        log.error(f"AI predictions error: {e}")
        return jsonify({
            'predicted_block_rate': 0,
            'risk_level': 'Error',
            'recommended_action': str(e),
            'events_analyzed': 0
        }), 500


@app.route("/api/ai/report/generate", methods=["POST"])
@login_required
def api_generate_ai_report():
    if not AI_AVAILABLE:
        return jsonify({"error": "AI modules not available"}), 503
    
    try:
        data = request.get_json() or {}
        period = data.get('period', 'week')
        
        events = db.get_all_events(limit=10000)
        
        now = datetime.now()
        if period == 'day':
            cutoff = now - timedelta(days=1)
        elif period == 'week':
            cutoff = now - timedelta(days=7)
        elif period == 'month':
            cutoff = now - timedelta(days=30)
        else:
            cutoff = now - timedelta(days=365)
        
        filtered_events = []
        for event in events:
            try:
                ts = datetime.fromisoformat(event.get('timestamp', ''))
                if ts >= cutoff:
                    filtered_events.append(event)
            except:
                continue
        
        report_generator = AIReportGenerator(use_local_llm=True)
        summary = report_generator.generate_summary(filtered_events, period)
        
        db.add_audit_log(
            session.get('admin_user'),
            'generate_ai_report',
            f"Generated AI report for {period}"
        )
        
        return jsonify({
            'summary': summary,
            'period': period,
            'events_analyzed': len(filtered_events),
            'generated_at': datetime.now().isoformat()
        })
    except Exception as e:
        log.error(f"AI report generation error: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/ai/train-model", methods=["POST"])
@login_required
def api_train_model():
    """Train AI model on current data"""
    try:
        events = db.get_all_events(limit=1000)
        trained_count = 0
        
        for event in events:
            device_id = event.get('device_instance_id')
            if device_id:
                device_profiler.build_profile(device_id, event)
                trained_count += 1
        
        device_profiler.train_anomaly_model({})
        
        return jsonify({
            'success': True,
            'events_processed': trained_count,
            'message': f"AI model trained on {trained_count} events"
        })
    except Exception as e:
        log.error(f"AI training error: {e}")
        return jsonify({
            'success': False,
            'error': str(e)
        }), 500


# ============================================================
# ENHANCED AI ROUTES
# ============================================================

@app.route("/api/ai/enhanced/status")
@login_required
def api_enhanced_status():
    """Check if Enhanced AI modules are available"""
    if AI_ENHANCED_AVAILABLE:
        return jsonify({
            'status': 'available',
            'version': __version__,
            'modules': ['malware', 'rdp', 'browser', 'threat_intel', 'ml', 'integrity']
        })
    else:
        return jsonify({
            'status': 'unavailable',
            'error': 'Enhanced AI modules not loaded',
            'modules': []
        }), 503


@app.route("/api/ai/enhanced/dashboard")
@login_required
def api_enhanced_dashboard_data():
    """Get enhanced AI dashboard data"""
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({
            'error': 'Enhanced AI not available',
            'timestamp': datetime.now().isoformat(),
            'ml_models': {'models': []},
            'malware_stats': {'total_scans': 0, 'malicious_found': 0},
            'rdp_sessions': [],
            'rdp_security_score': 1.0,
            'rdp_anomalies': [],
            'threat_intel': {'total_iocs': 0, 'feed_updates': 0},
            'integrity': {'verified': 0, 'modified': 0, 'missing': 0}
        }), 503
    
    try:
        rdp_summary = rdp_detector.analyze_rdp_connections(None)
        return jsonify({
            'malware_stats': malware_detector.get_stats(),
            'rdp_sessions': rdp_summary['active_sessions'],
            'rdp_security_score': rdp_detector.get_rdp_security_score(),
            'rdp_anomalies': rdp_summary['anomalies'],
            'rdp_known_hosts': rdp_detector.get_known_hosts(),
            'threat_intel': threat_intel.get_threat_intelligence_report(),
            'ml_models': ml_manager.get_model_status(),
            'integrity': integrity_checker.get_integrity_report(),
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({
            'error': str(e),
            'timestamp': datetime.now().isoformat(),
            'ml_models': {'models': []},
            'malware_stats': {'total_scans': 0, 'malicious_found': 0},
            'rdp_sessions': [],
            'rdp_security_score': 1.0,
            'rdp_anomalies': [],
            'threat_intel': {'total_iocs': 0, 'feed_updates': 0},
            'integrity': {'verified': 0, 'modified': 0, 'missing': 0}
        }), 500


@app.route("/api/ai/enhanced/malware/scan", methods=["POST"])
@login_required
def api_malware_scan():
    """Scan for malware"""
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({'error': 'Enhanced AI not available'}), 503
    
    try:
        data = request.get_json() or {}
        file_path = data.get('file_path', '')
        scan_type = data.get('type', 'file')
        max_files = data.get('max_files', 100)
        
        if not file_path:
            return jsonify({'error': 'file_path required'}), 400
        
        if not os.path.exists(file_path):
            return jsonify({'error': 'Path does not exist'}), 404
        
        if scan_type == 'directory':
            results = malware_detector.scan_directory(file_path, max_files)
            return jsonify({
                'scanned': len(results),
                'threats': [r.__dict__ for r in results if r.is_malicious],
                'all_results': [r.__dict__ for r in results],
                'stats': malware_detector.get_stats()
            })
        else:
            result = malware_detector.scan_file(file_path)
            return jsonify({
                'result': result.__dict__,
                'stats': malware_detector.get_stats()
            })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route("/api/ai/enhanced/malware/stats")
@login_required
def api_malware_stats():
    """Get malware detection statistics"""
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({'error': 'Enhanced AI not available'}), 503
    
    return jsonify(malware_detector.get_stats())


@app.route("/api/ai/enhanced/rdp/analyze")
@login_required
def api_rdp_analyze():
    """
    Analyze RDP/remote-access connections.
    hostname now actually scopes which agent's reported data is analyzed;
    omit it to analyze across every agent that has reported in.
    """
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({'error': 'Enhanced AI not available'}), 503

    hostname = request.args.get('hostname') or None
    result = rdp_detector.analyze_rdp_connections(hostname)
    return jsonify(result)


@app.route("/api/ai/enhanced/rdp/sessions")
@login_required
def api_rdp_sessions():
    """Get active RDP/remote-access sessions, optionally filtered by hostname"""
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({'error': 'Enhanced AI not available'}), 503

    hostname = request.args.get('hostname') or None
    sessions = rdp_detector.get_active_rdp_sessions(hostname)
    return jsonify({
        'sessions': sessions,
        'count': len(sessions),
        'security_score': rdp_detector.get_rdp_security_score(hostname),
        'known_hosts': rdp_detector.get_known_hosts()
    })


@app.route("/api/ai/enhanced/rdp/history")
@login_required
def api_rdp_history():
    """Get recent RDP/remote-access event history, optionally filtered by hostname"""
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({'error': 'Enhanced AI not available'}), 503

    hostname = request.args.get('hostname') or None
    limit = request.args.get('limit', 50, type=int)
    history = rdp_detector.get_history(hostname, limit)
    return jsonify({
        'history': history,
        'count': len(history)
    })


@app.route("/api/ai/enhanced/browser/analyze", methods=["POST"])
@login_required
def api_browser_analyze():
    """Analyze browser activity"""
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({'error': 'Enhanced AI not available'}), 503
    
    data = request.get_json() or {}
    browser_data = data.get('browser_data', [])

    # Ensure we always return a valid result, even for empty data
    if not browser_data:
        return jsonify({
            'browsers': [],
            'login_attempts': [],
            'summary': {
                'total_browsers': 0,
                'total_logins': 0,
                'suspicious_count': 0
            },
            'timestamp': datetime.now().isoformat()
        })

    result = browser_analyzer.analyze_browser_activity(browser_data)
    return jsonify(result)


@app.route("/api/ai/enhanced/browser/login-history")
@login_required
def api_browser_login_history():
    """Get browser login history"""
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({'error': 'Enhanced AI not available'}), 503
    
    limit = request.args.get('limit', 50, type=int)
    history = browser_analyzer.get_login_history(limit)
    return jsonify({
        'history': history,
        'count': len(history)
    })


@app.route("/api/ai/enhanced/threat-intel/report")
@login_required
def api_threat_intel_report():
    """Get threat intelligence report"""
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({'error': 'Enhanced AI not available'}), 503
    
    return jsonify(threat_intel.get_threat_intelligence_report())


@app.route("/api/ai/enhanced/threat-intel/check", methods=["POST"])
@login_required
def api_threat_intel_check():
    """Check IOC against threat intelligence"""
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({'error': 'Enhanced AI not available'}), 503
    
    data = request.get_json() or {}
    ioc_type = data.get('type')
    ioc_value = data.get('value')
    
    if not ioc_type or not ioc_value:
        return jsonify({'error': 'type and value required'}), 400
    
    check_functions = {
        'ip': threat_intel.check_ip,
        'domain': threat_intel.check_domain,
        'hash': threat_intel.check_hash,
        'url': threat_intel.check_url,
    }
    
    if ioc_type not in check_functions:
        return jsonify({'error': f'Invalid type: {ioc_type}'}), 400
    
    result = check_functions[ioc_type](ioc_value)
    return jsonify(result)


@app.route("/api/ai/enhanced/ml/models")
@login_required
def api_ml_models():
    """Get ML model status"""
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({
            'models': [],
            'total_models': 0,
            'scalers_available': 0,
            'model_metadata': {},
            'training_history': [],
            'timestamp': datetime.now().isoformat()
        })
    
    return jsonify(ml_manager.get_model_status())


@app.route("/api/ai/enhanced/ml/train/anomaly", methods=["POST"])
@login_required
def api_ml_train_anomaly():
    """Train anomaly detection model"""
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({
            'error': 'Enhanced AI not available',
            'detail': 'scikit-learn may not be installed',
            'success': False
        }), 503
    
    try:
        data = request.get_json() or {}
        training_data = data.get('data', [])
        
        # If no training data provided, use events from database
        if not training_data:
            events = db.get_all_events(limit=500)
            for event in events:
                training_data.append({
                    'connection_count': 1,
                    'unique_hosts': 1,
                    'block_rate': 1 if event.get('status') == 'blocked' else 0,
                    'override_rate': 1 if event.get('status') == 'overridden' else 0,
                    'avg_duration': event.get('duration_seconds', 0) or 0,
                    'hours_since_last': 0,
                    'device_age_days': 0,
                    'activity_variance': 0
                })
        
        result = ml_manager.train_anomaly_model(training_data)
        
        if isinstance(result, dict):
            return jsonify(result)
        else:
            return jsonify({
                'success': False,
                'error': 'Training failed - invalid result'
            }), 500
            
    except ImportError as e:
        return jsonify({
            'error': 'scikit-learn not installed',
            'detail': str(e),
            'success': False
        }), 503
    except Exception as e:
        log.error(f"ML training error: {e}")
        return jsonify({
            'error': str(e),
            'success': False
        }), 500


@app.route("/api/ai/enhanced/integrity/verify")
@login_required
def api_integrity_verify():
    """Verify system integrity"""
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({
            'verified': 0,
            'modified': 0,
            'missing': 0,
            'details': [],
            'timestamp': datetime.now().isoformat()
        })
    
    result = integrity_checker.verify_critical_files()
    return jsonify(result)


@app.route("/api/ai/enhanced/integrity/baseline", methods=["POST"])
@login_required
def api_integrity_create_baseline():
    """Create integrity baseline"""
    if not AI_ENHANCED_AVAILABLE:
        return jsonify({'error': 'Enhanced AI not available'}), 503
    
    data = request.get_json() or {}
    files = data.get('files')
    
    integrity_checker.create_baseline(files)
    return jsonify({
        'status': 'success',
        'entries': len(integrity_checker.baseline),
        'message': 'Baseline created successfully'
    })


# ============================================================
# USER ACTIVITY SUMMARY
# ============================================================

@app.route("/api/ai/user-activity-summary")
@login_required
def api_user_activity_summary():
    """Get user activity summary"""
    try:
        users = db.get_users()
        audit_logs = db.get_audit_logs(limit=100)
        
        user_actions = {}
        for log_entry in audit_logs:
            username = log_entry.get('username', 'unknown')
            user_actions[username] = user_actions.get(username, 0) + 1
        
        most_active = max(user_actions.items(), key=lambda x: x[1]) if user_actions else ('N/A', 0)
        
        action_counts = {}
        for log_entry in audit_logs:
            action = log_entry.get('action', 'unknown')
            action_counts[action] = action_counts.get(action, 0) + 1
        
        most_common = max(action_counts.items(), key=lambda x: x[1]) if action_counts else ('N/A', 0)
        
        return jsonify({
            'most_active_user': most_active[0],
            'most_active_count': most_active[1],
            'most_common_action': most_common[0],
            'most_common_count': most_common[1],
            'new_users': len(users)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route("/api/monitoring/metrics")
@login_required
def api_monitoring_metrics():
    """Get monitoring metrics for the dashboard panel"""
    try:
        stats = {}
        
        agents = db.get_agents()
        stats['active_agents'] = sum(1 for a in agents if a.get('status') == 'online')
        stats['total_agents'] = len(agents)
        
        events = db.get_all_events(limit=10000)
        stats['total_events'] = len(events)
        stats['blocked_devices'] = sum(1 for e in events if e.get('status') == 'blocked')
        
        stats['exam_active'] = exam_active
        stats['lockdown_active'] = lockdown_active
        stats['cache_enabled'] = getattr(config, 'DEVICE_CACHE_ENABLED', True)
        
        if stats['total_events'] > 0:
            stats['cache_hit_rate'] = min(round((stats['total_events'] - stats['blocked_devices']) / stats['total_events'] * 100), 100)
        else:
            stats['cache_hit_rate'] = 0
        
        try:
            import psutil
            stats['system'] = {
                'cpu': psutil.cpu_percent(interval=0.5),
                'memory': psutil.virtual_memory().percent,
                'disk': psutil.disk_usage('/').percent if os.name != 'nt' else psutil.disk_usage('C:').percent
            }
        except ImportError:
            stats['system'] = {'cpu': 0, 'memory': 0, 'disk': 0}
        
        stats['timestamp'] = datetime.now().isoformat()
        
        return jsonify(stats)
    except Exception as e:
        log.error(f"Monitoring metrics error: {e}")
        return jsonify({
            'active_agents': 0,
            'total_events': 0,
            'blocked_devices': 0,
            'exam_active': False,
            'lockdown_active': False,
            'cache_enabled': True,
            'cache_hit_rate': 0,
            'system': {'cpu': 0, 'memory': 0, 'disk': 0},
            'timestamp': datetime.now().isoformat(),
            'error': str(e)
        })


# ============================================================
# SOCKET.IO EVENT HANDLERS
# ============================================================

@socketio.on("agent_register")
def handle_agent_register(data):
    received_token = str(data.get("token", ""))
    expected_token = config.AGENT_AUTH_TOKEN
    
    hostname = data.get("hostname", "unknown")
    log.info(f"Agent registration attempt from {hostname}")
    
    is_valid = False
    
    if hmac.compare_digest(received_token, expected_token):
        is_valid = True
        log.info(f"Token validated (exact match) for {hostname}")
    elif hmac.compare_digest(received_token.strip(), expected_token.strip()):
        is_valid = True
        log.info(f"Token validated (trimmed) for {hostname}")
    elif received_token.lower() == expected_token.lower():
        is_valid = True
        log.info(f"Token validated (case-insensitive) for {hostname}")
    elif hasattr(config, 'BACKUP_AGENT_TOKEN') and hmac.compare_digest(received_token, config.BACKUP_AGENT_TOKEN):
        is_valid = True
        log.info(f"Token validated (backup token) for {hostname}")
    
    if not is_valid:
        log.warning(f"❌ Rejected agent registration with bad token from {hostname}")
        socketio.emit("registration_rejected", {"reason": "bad token"}, room=request.sid)
        return {"status": "rejected", "reason": "bad token"}

    ip = request.remote_addr
    if not _check_agent_rate_limit(ip):
        log.warning(f"Rate limit exceeded for agent registration from {ip}")
        socketio.emit("registration_rejected", {"reason": "rate limit exceeded"}, room=request.sid)
        return {"status": "rejected", "reason": "rate limit exceeded"}

    ip_address = data.get("ip_address")
    username = data.get("username")
    version = data.get("version", "1.0")

    connected_agents[hostname] = request.sid
    db.update_agent(hostname, ip_address, username, "online", version)

    # ---- Policy handshake (v20) -------------------------------------
    # The agent is connected and acknowledged IMMEDIATELY; it never waits on
    # an admin. Approval only decides whether it is under server control.
    policy = db.get_active_policy() or {}
    accepted_version = data.get("policy_accepted_version")
    req = db.get_policy_request(hostname)
    if accepted_version is not None and policy and int(accepted_version) == int(policy["version"]):
        req = db.upsert_policy_request(hostname, ip_address, username, int(accepted_version))
        if req["status"] == "pending" and getattr(config, "POLICY_AUTO_APPROVE", False):
            db.decide_policy_request(hostname, "approved", "auto-approve")
            req = db.get_policy_request(hostname)
    approval = "unaccepted"
    if req and policy and req["policy_version"] == policy["version"]:
        approval = req["status"]
    ack = {
        "status": "ok",
        "approval": approval,
        "policy": {"version": policy.get("version"), "title": policy.get("title"),
                   "body": policy.get("body"), "rules": json.loads(policy.get("rules") or "[]")} if policy else None,
        "server_time": time.time(),
    }
    log.info(f"✅ Agent registered: host={hostname} ip={ip_address} user={username} approval={approval}")
    socketio.emit("registration_ack", ack, room=request.sid)
    socketio.emit("agent_online", {"hostname": hostname, "ip_address": ip_address, "username": username,
                                   "version": version, "approval": approval})
    if approval == "pending":
        socketio.emit("policy_request", {"hostname": hostname, "ip_address": ip_address, "username": username,
                                         "policy_version": accepted_version})
    # Returning the ack makes sio.call() on the agent resolve instantly. Previously
    # this handler returned None, so call() always timed out after 10 s.
    return ack


@socketio.on("agent_policy_accept")
def handle_agent_policy_accept(data):
    """Agent user clicked Accept on the local policy dialog."""
    hostname = (data or {}).get("hostname")
    if not hostname or connected_agents.get(hostname) != request.sid:
        return {"status": "error", "reason": "not registered"}
    policy = db.get_active_policy()
    if not policy or int(data.get("version", -1)) != int(policy["version"]):
        return {"status": "stale", "policy": policy and {"version": policy["version"], "title": policy["title"],
                                                         "body": policy["body"], "rules": json.loads(policy.get("rules") or "[]")}}
    req = db.upsert_policy_request(hostname, data.get("ip_address"), data.get("username"), policy["version"])
    if req["status"] == "pending" and getattr(config, "POLICY_AUTO_APPROVE", False):
        db.decide_policy_request(hostname, "approved", "auto-approve")
        req = db.get_policy_request(hostname)
    db.add_audit_log(hostname, "policy_accepted_by_agent", f"v{policy['version']} -> {req['status']}")
    request_payload = {
        "hostname": hostname,
        "ip_address": data.get("ip_address"),
        "username": data.get("username"),
        "policy_version": policy["version"],
        "status": req["status"],
        "event_type": "agent_policy_consent",
        "message": (
            f"{hostname} wants to connect to SentryUSB. The user accepted policy "
            f"v{policy['version']}; review and approve this request in Policy Studio."
        ),
        "requested_at": req.get("requested_at"),
    }
    # This event is consumed by the server-side browser notification and Policy Studio.
    socketio.emit("policy_request", request_payload)
    if req["status"] == "approved":
        socketio.emit("policy_decision", {"status": "approved", "version": policy["version"]}, room=request.sid)
    return {"status": "ok", "approval": req["status"]}


@socketio.on("agent_health")
def handle_agent_health(data):
    hostname = data.get("hostname")
    if hostname and hostname in connected_agents:
        db.update_agent(hostname, None, None, "online")
        log.debug(f"💚 Health report from {hostname}")


def _save_evidence(hostname, session_id, screenshot_b64=None, webcam_b64=None):
    """
    Decode base64 evidence images sent by an agent and save them to disk
    under server/evidence/. Returns a JSON string like
    '{"screenshot": "evidence/HOST_SESSION_screenshot.jpg"}' (only the
    keys actually captured), or None if nothing was saved.
    """
    import base64
    import json as _json

    evidence_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "evidence")
    os.makedirs(evidence_dir, exist_ok=True)

    safe_host = "".join(c for c in (hostname or "host") if c.isalnum() or c in ("-", "_")) or "host"
    safe_session = "".join(c for c in (session_id or "session") if c.isalnum() or c in ("-", "_")) or "session"

    paths = {}
    for label, b64_data in (("screenshot", screenshot_b64), ("webcam", webcam_b64)):
        if not b64_data:
            continue
        try:
            filename = f"{safe_host}_{safe_session}_{label}.jpg"
            filepath = os.path.join(evidence_dir, filename)
            with open(filepath, "wb") as f:
                f.write(base64.b64decode(b64_data))
            paths[label] = os.path.join("evidence", filename)
        except Exception as e:
            log.error(f"Failed to save {label} evidence: {e}")

    return _json.dumps(paths) if paths else None


@socketio.on("usb_event")
def handle_usb_event(data):
    """Handle USB event from agent with deduplication and ML anomaly detection"""
    try:
        # --- DEDUPLICATION ---
        device_instance_id = data.get("device_instance_id")
        status = data.get("status")
        hostname = data.get("hostname")
        
        if device_instance_id and status and hostname:
            recent = db.get_recent_event(device_instance_id, status, hostname, seconds=1)
            if recent:
                log.debug(f"Ignoring duplicate event for {device_instance_id} ({status}) from {hostname}")
                return   # skip insertion and broadcasting

        # --- EVIDENCE CAPTURE (base64 from agent -> saved to disk, path only from here on) ---
        evidence_screenshot_b64 = data.pop("evidence_screenshot", None)
        evidence_webcam_b64 = data.pop("evidence_webcam", None)
        if evidence_screenshot_b64 or evidence_webcam_b64:
            data["evidence_path"] = _save_evidence(
                hostname,
                data.get("session_id"),
                evidence_screenshot_b64,
                evidence_webcam_b64,
            )
            log.info(f"📸 Evidence saved for {hostname}: {data['evidence_path']}")

        # Policy is evaluated centrally and recorded with the event. The
        # action is sent separately so the UI can distinguish a decision from
        # actual OS enforcement.
        default_action = getattr(config, "DEVICE_POLICY_DEFAULT_ACTION", "monitor")
        if default_action not in {"allow", "block", "approval_required", "monitor"}:
            default_action = "monitor"
        decision = evaluate_device_policy(data, db.list_device_policies(), default_action)
        risk_score, risk_signals = _device_risk(data, decision)
        data["policy_decision"] = decision
        data["risk_score"] = risk_score
        data["risk_signals"] = risk_signals

        event_id = db.insert_event(data)
        data["id"] = event_id
        data["evidence_chain_hash"] = _append_evidence(event_id, "usb_event", data)
        
        log.info("🔌 USB event logged: id=%s status=%s device=%s host=%s",
                  event_id, data.get("status", "unknown"),
                  data.get("device_name", "unknown"), data.get("hostname", "unknown"))
        
        if NOTIFICATIONS_AVAILABLE:
            status = data.get("status", "")
            if status in ["blocked", "allowed", "overridden"]:
                try:
                    notifications.send_alert(data)
                except Exception as e:
                    log.error(f"Failed to send alert: {e}")
        
        socketio.emit("new_event", data)
        _send_siem({"event_type": "usb_event", "event_id": event_id, "hostname": data.get("hostname"),
                    "status": data.get("status"), "risk_score": risk_score, "policy": decision})

        # A central policy can request a block; the agent reports the real
        # success/failure in a separate adaptive_response_result event.
        if decision["action"] == "block" and data.get("device_instance_id") and hostname in connected_agents:
            response = {"hostname": hostname, "action": "block_device", "device_instance_id": data["device_instance_id"],
                        "correlation_id": "response-" + uuid.uuid4().hex, "reason": decision["reason"]}
            socketio.emit("adaptive_response", response, room=connected_agents[hostname])
            db.add_audit_log("policy-engine", "adaptive_response_requested", json.dumps(response, sort_keys=True))
        if risk_score >= 80:
            bundle = _incident_capture(event_id, data, "high")
            if bundle:
                data["incident_id"] = bundle["incident_id"]
        log.info("📤 Broadcasted new_event to all clients")

        # ========== AI ANOMALY DETECTION (ENHANCED) ==========
        if AI_AVAILABLE:
            try:
                device_id = data.get("device_instance_id") or data.get("serial_number") or data.get("device_name")
                if device_id:
                    # Build profile using existing profiler (for history)
                    profile = device_profiler.build_profile(device_id, data)
                    
                    # Use ML detector if available and we have enough history
                    score = 0
                    status = "normal"
                    reasons = []
                    
                    if ML_ANOMALY_AVAILABLE:
                        # Get full history for this device
                        history = db.get_device_history(device_id)
                        if len(history) >= 10:
                            try:
                                ml_result = ml_anomaly_detector.predict_anomaly(device_id, history)
                                score = ml_result.get('anomaly_score', 0)
                                status = ml_result.get('status', 'unknown')
                                reasons = ml_result.get('reasons', [])
                            except Exception as e:
                                log.error(f"ML prediction error: {e}")
                                # Fallback to heuristic
                                score = profile.get("anomaly_score", 0)
                                status = profile.get("profile_status", "learning")
                        else:
                            # Fallback to heuristic profile score
                            score = profile.get("anomaly_score", 0)
                            status = profile.get("profile_status", "learning")
                    else:
                        # Use existing heuristic
                        score = profile.get("anomaly_score", 0)
                        status = profile.get("profile_status", "learning")
                    
                    threshold = getattr(config, "AI_LIVE_ALERT_THRESHOLD", 50)
                    if score >= threshold:
                        alert = {
                            "type": "device_anomaly",
                            "device_id": device_id,
                            "device_name": data.get("device_name"),
                            "hostname": data.get("hostname"),
                            "score": score,
                            "status": status,
                            "reasons": reasons,
                            "timestamp": data.get("timestamp") or datetime.now().isoformat(),
                        }
                        socketio.emit("ai_alert", alert)
                        log.info(f"🤖 AI alert: {device_id} scored {score} (>= {threshold}) reasons: {reasons}")
            except Exception as e:
                log.error(f"AI anomaly scoring failed: {e}")

    except Exception as e:
        log.error(f"Error processing USB event: {e}")
        import traceback
        log.error(traceback.format_exc())


@socketio.on("usb_event_removed")
def handle_usb_event_removed(data):
    try:
        duration = db.mark_removed(data.get("session_id"), data.get("hostname"))
        log.info("🔌 Device removed: %s on %s (session=%s, duration=%ss)",
                  data.get("device_name"), data.get("hostname"), 
                  data.get("session_id"), duration)
        data["duration_seconds"] = duration
        socketio.emit("device_removed", data)
    except Exception as e:
        log.error(f"Error processing USB removal: {e}")


@socketio.on("behavioral_metrics")
def handle_behavioral_metrics(data):
    """Record aggregate timing/mouse telemetry only; never accept raw input."""
    try:
        subject_token = str(data.get("subject_token", ""))[:128]
        if not subject_token:
            return
        allowed = {key: data.get(key) for key in ("dwell_ms", "flight_ms", "mouse_speed", "event_rate_hz")}
        baseline = db.get_behavioral_profile(subject_token)
        result = behavioral_risk(allowed, baseline)
        sample_count = int((baseline or {}).get("sample_count", 0))
        db.add_behavioral_observation(subject_token, str(data.get("hostname", ""))[:128], result["risk_score"], result["signals"])
        db.save_behavioral_profile(
            subject_token, sample_count + 1,
            update_mean((baseline or {}).get("dwell_mean"), sample_count, result["sample"]["dwell_ms"]),
            update_mean((baseline or {}).get("flight_mean"), sample_count, result["sample"]["flight_ms"]),
            update_mean((baseline or {}).get("mouse_speed_mean"), sample_count, result["sample"]["mouse_speed"]),
        )
        outcome = {"type": "behavioral_risk", "hostname": data.get("hostname"), "risk_score": result["risk_score"],
                   "signals": result["signals"], "privacy": "aggregate_only_no_raw_input"}
        _append_evidence(None, "behavioral_metrics", outcome)
        if result["risk_score"] >= 65:
            socketio.emit("ai_alert", outcome)
            _send_siem(outcome)
    except (TypeError, ValueError) as exc:
        log.warning("Invalid behavioural metrics ignored: %s", exc)
    except Exception as exc:
        log.error("Behavioural metrics processing failed: %s", exc)


@socketio.on("adaptive_response_result")
def handle_adaptive_response_result(data):
    _append_evidence(None, "adaptive_response_result", data)
    db.add_audit_log("agent:" + str(data.get("hostname", "unknown"))[:64], "adaptive_response_result", json.dumps(data, sort_keys=True))
    socketio.emit("adaptive_response_result", data)


@socketio.on("device_enable_result")
def handle_device_enable_result(data):
    log.info("Device enable result: %s", data)


@socketio.on("exam_status")
def handle_exam_status(data):
    log.info("📚 Exam status update from %s: %s", data.get("hostname"), data.get("status"))
    socketio.emit("exam_status", data)


@socketio.on("exam_status_response")
def handle_exam_status_response(data):
    log.info("📚 Exam status response from %s", data.get("hostname"))
    socketio.emit("exam_status_response", data)


@socketio.on("lockdown_apply_result")
def handle_lockdown_apply_result(data):
    log.info("🔒 Lockdown apply result from agent: %s", data)
    socketio.emit("lockdown_apply_result", data)


@socketio.on("lockdown_remove_result")
def handle_lockdown_remove_result(data):
    log.info("🔓 Lockdown remove result from agent: %s", data)
    socketio.emit("lockdown_remove_result", data)


@socketio.on("lockdown_status")
def handle_lockdown_status(data):
    log.info("🔒 Lockdown status from agent: %s", data)
    socketio.emit("lockdown_status", data)


@socketio.on("browser_status_response")
def handle_browser_status_response(data):
    hostname = data.get("hostname", "unknown")
    browser_count = data.get("browser_count", 0)
    log.info(f"📊 Browser status from {hostname}: {browser_count} browsers")
    socketio.emit("browser_status_update", data)


@socketio.on("rdp_status_response")
def handle_rdp_status_response(data):
    hostname = data.get("hostname", "unknown")
    session_count = data.get("session_count", 0)
    tool_count = data.get("remote_tool_count", 0)
    log.info(f"📊 RDP status from {hostname}: {session_count} sessions, {tool_count} remote tools")

    if AI_ENHANCED_AVAILABLE:
        try:
            rdp_detector.ingest_status(hostname, data)
        except Exception as e:
            log.error(f"Failed to ingest RDP status: {e}")

    socketio.emit("rdp_status_update", data)


@socketio.on("rdp_event")
def handle_rdp_event(data):
    hostname = data.get("hostname", "unknown")
    event_type = data.get("event", "unknown")
    detail = data.get("tool") or data.get("process") or data.get("type", "")
    log.info(f"🖥️ RDP event from {hostname}: {event_type} ({detail})")

    if AI_ENHANCED_AVAILABLE:
        try:
            rdp_detector.ingest_event(hostname, data)
        except Exception as e:
            log.error(f"Failed to ingest RDP event: {e}")

    socketio.emit("rdp_alert", data)
    _handle_rdp_escalation(hostname, event_type, data)


def _handle_rdp_escalation(hostname, event_type, data):
    """
    Escalate a newly-detected RDP session or third-party remote-access
    tool beyond the dashboard: audit log + real-time AI alert + external
    notification (email/Telegram/Slack/Discord), especially while an exam
    is active. Session-ended / tool-closed events are not escalated.
    """
    if event_type not in ("rdp_session_started", "remote_tool_detected"):
        return

    tool = data.get("tool") or ("Windows RDP" if event_type == "rdp_session_started" else "Remote access")
    description = f"{tool} detected on {hostname}" + (" during an active exam" if exam_active else "")

    try:
        db.add_audit_log("system", "rdp_detection", description)
    except Exception as e:
        log.error(f"Failed to write RDP audit log: {e}")

    alert = {
        "type": "rdp_detected",
        "hostname": hostname,
        "tool": tool,
        "event": event_type,
        "severity": "critical" if exam_active else "high",
        "description": description,
        "timestamp": data.get("timestamp") or datetime.now().isoformat(),
    }
    socketio.emit("ai_alert", alert)
    log.warning("🤖 RDP alert: %s", description)

    if NOTIFICATIONS_AVAILABLE:
        try:
            notifications.send_rdp_alert({**data, "exam_active": exam_active})
        except Exception as e:
            log.error(f"Failed to send RDP notification: {e}")


@socketio.on("login_detected")
def handle_login_detected(data):
    hostname = data.get("hostname", "unknown")
    service = data.get("service", "unknown")
    log.info(f"🔐 Login detected on {hostname}: {service}")
    socketio.emit("login_alert", data)

    if AI_AVAILABLE:
        try:
            result = login_detector.analyze_login(
                username=service,
                ip=request.remote_addr,
                hostname=hostname,
                browser=data.get("type", "unknown"),
                timestamp=data.get("timestamp") or datetime.now().isoformat(),
            )
            threshold = getattr(config, "AI_LIVE_ALERT_THRESHOLD", 50)
            if result.get("anomaly_score", 0) >= threshold:
                alert = {
                    "type": "login_anomaly",
                    "hostname": hostname,
                    "service": service,
                    "score": result["anomaly_score"],
                    "reasons": result.get("reasons", []),
                    "timestamp": data.get("timestamp") or datetime.now().isoformat(),
                }
                socketio.emit("ai_alert", alert)
                log.info("🤖 AI login alert: %s on %s scored %s (%s)",
                          service, hostname, result["anomaly_score"], result.get("reasons"))
        except Exception as e:
            log.error(f"AI login anomaly scoring failed: {e}")


@socketio.on("disconnect")
def handle_disconnect():
    sid = request.sid
    for hostname, agent_sid in list(connected_agents.items()):
        if agent_sid == sid:
            del connected_agents[hostname]
            db.update_agent(hostname, None, None, "offline")
            socketio.emit("agent_offline", {"hostname": hostname})
            log.info("Agent disconnected: %s", hostname)


@app.before_request
def before_request():
    if SECURITY_AVAILABLE and session.get("session_id"):
        try:
            update_session_activity(session.get("session_id"))
        except Exception:
            pass


# ============================================================
# DEBUG ENDPOINT
# ============================================================


# ============================================================
# ENTERPRISE COMMAND CENTER v11
# ============================================================
@app.route("/api/enterprise/topology")
def api_enterprise_topology():
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    return jsonify(enterprise_cc.topology_state())

@app.route("/api/enterprise/risk-history")
def api_enterprise_risk_history():
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    return jsonify(enterprise_cc.risk_snapshot())

@app.route("/api/enterprise/insights")
def api_enterprise_insights():
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    return jsonify({"insights": enterprise_cc.insights(int(request.args.get("limit", 30)))})

@app.route("/api/enterprise/replay")
def api_enterprise_replay():
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    return jsonify({"events": enterprise_cc.incident_timeline(request.args.get("hostname"), int(request.args.get("limit", 200)))})

@app.route("/api/enterprise/incidents")
def api_enterprise_incidents():
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    return jsonify({"incidents": enterprise_cc.incident_list(int(request.args.get("limit", 50)), request.args.get("hostname"))})


@app.route("/api/enterprise/trust")
def api_enterprise_trust():
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    return jsonify({"devices": enterprise_cc.device_trust(request.args.get("device_id"))})

@app.route("/api/enterprise/labs")
def api_enterprise_labs():
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    return jsonify({"labs": enterprise_cc.lab_health()})

@app.route("/api/enterprise/readiness")
def api_enterprise_readiness():
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    return jsonify(enterprise_cc.readiness_scan(request.args.get("lab")))

@app.route("/api/enterprise/incident/<incident_id>")
def api_enterprise_incident(incident_id):
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    return jsonify(enterprise_cc.incident_details(incident_id))

@app.route("/api/enterprise/incident/<incident_id>/claim", methods=["POST"])
def api_enterprise_claim(incident_id):
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    username = session.get("username", "admin")
    result = enterprise_cc.claim_incident(incident_id, username)
    if result.get("ok"):
        try: socketio.emit("incident_claimed", result["claim"])
        except Exception: pass
    return jsonify(result), (200 if result.get("ok") else 409)

@app.route("/api/enterprise/incident/<incident_id>/comments", methods=["POST"])
def api_enterprise_comment(incident_id):
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    body = request.get_json(silent=True) or {}
    result = enterprise_cc.add_comment(incident_id, session.get("username", "admin"), body.get("text"))
    if result.get("ok"):
        try: socketio.emit("incident_comment", result["comment"])
        except Exception: pass
    return jsonify(result), (200 if result.get("ok") else 400)

@app.route("/api/enterprise/incident/<incident_id>/report.pdf")
def api_enterprise_incident_report(incident_id):
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    try:
        pdf = enterprise_cc.generate_incident_pdf(incident_id)
        return send_file(io.BytesIO(pdf), mimetype="application/pdf", as_attachment=True,
                         download_name=f"sentryusb-incident-{secure_filename(str(incident_id))}.pdf")
    except Exception as exc:
        return jsonify({"error": str(exc)}), 500

@app.route("/api/enterprise/policy/from-text", methods=["POST"])
def api_enterprise_policy_from_text():
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    body = request.get_json(silent=True) or {}
    return jsonify(enterprise_cc.author_policy_from_text(body.get("text"), session.get("username", "admin")))

@app.route("/api/enterprise/notifications/test", methods=["POST"])
def api_enterprise_notification_test():
    if not ENTERPRISE_CC_AVAILABLE: return jsonify({"error": "enterprise layer unavailable"}), 503
    body = request.get_json(silent=True) or {}
    payload = {"source": "SentryUSB", "type": "test_alert", "severity": body.get("severity", "info"),
               "message": body.get("message", "Enterprise notification test"), "timestamp": utc_now() if 'utc_now' in globals() else datetime.now().isoformat()}
    return jsonify({"webhook": enterprise_cc.push_webhook(payload), "slack_or_teams": enterprise_cc.push_slack_or_teams(payload)})

@app.route("/api/debug/events")
@login_required
def debug_events():
    """Debug endpoint to check events in database"""
    events = db.get_all_events(limit=100)
    return jsonify({
        "count": len(events),
        "events": events
    })


@app.errorhandler(404)
def not_found(error):
    try:
        return render_template("404.html"), 404
    except Exception:
        return ("<html><head><title>404</title></head>"
                "<body><h1>404 - Page not found</h1></body></html>"), 404


@app.errorhandler(500)
def internal_error(error):
    log.error(f"Internal server error: {error}")
    try:
        return render_template("500.html"), 500
    except Exception:
        return ("<html><head><title>500</title></head>"
                "<body><h1>500 - Internal server error</h1></body></html>"), 500


# ============================================================
# SENTRYUSB HUB INTEGRATION (Tier 1 connectivity - optional)
# ============================================================
try:
    import hub_client
    hub_client.start(config, db)
except Exception as _hub_e:
    log.warning(f"SentryUSB Hub integration not started: {_hub_e}")


@app.route("/api/hub/status")
@login_required
def api_hub_status():
    """Local-only view of this lab server's connection to the central hub."""
    try:
        import hub_client
        return jsonify(hub_client.get_status())
    except Exception as e:
        return jsonify({"error": str(e)})


# ============================================================
# POLICY STUDIO (v20)
# ============================================================
@app.route("/policy-studio")
@login_required
def policy_studio_page():
    return render_template("policy_studio.html")


@app.route("/api/policy-studio/state")
@login_required
def api_policy_studio_state():
    reqs = db.list_policy_requests()
    for r in reqs:
        r["online"] = r["hostname"] in connected_agents
    return jsonify({"active": db.get_active_policy(), "policies": db.list_policies(), "requests": reqs,
                    "auto_approve": bool(getattr(config, "POLICY_AUTO_APPROVE", False))})


@app.route("/api/policy-studio/publish", methods=["POST"])
@login_required
def api_policy_studio_publish():
    body = request.get_json(silent=True) or {}
    title = (body.get("title") or "").strip()[:200]
    text = (body.get("body") or "").strip()[:8000]
    rules = [str(r).strip()[:200] for r in (body.get("rules") or []) if str(r).strip()][:30]
    if not title or not text:
        return jsonify({"error": "title and body are required"}), 400
    actor = session.get("admin_user") or session.get("username") or "admin"
    version = db.publish_policy(title, text, rules, actor)
    db.add_audit_log(actor, "policy_published", f"v{version}")
    pol = db.get_active_policy()
    payload = {"version": version, "title": pol["title"], "body": pol["body"], "rules": rules}
    # Push the new version to every connected agent right now; each must re-accept.
    for sid in list(connected_agents.values()):
        socketio.emit("policy_update", payload, room=sid)
    socketio.emit("policy_request", {"policy_version": version, "refresh": True})
    return jsonify({"success": True, "version": version})


@app.route("/api/policy-studio/decide", methods=["POST"])
@login_required
def api_policy_studio_decide():
    body = request.get_json(silent=True) or {}
    hostname = body.get("hostname")
    status = body.get("status")
    if status not in ("approved", "rejected", "pending"):
        return jsonify({"error": "invalid status"}), 400
    actor = session.get("admin_user") or session.get("username") or "admin"
    if not db.decide_policy_request(hostname, status, actor, (body.get("note") or "")[:300]):
        return jsonify({"error": "unknown agent"}), 404
    db.add_audit_log(actor, f"policy_{status}", hostname)
    pol = db.get_active_policy() or {}
    sid = connected_agents.get(hostname)
    if sid:
        # Immediate push so the agent flips to monitored state with no polling.
        socketio.emit("policy_decision", {"status": status, "version": pol.get("version")}, room=sid)
    socketio.emit("policy_request", {"hostname": hostname, "status": status, "refresh": True})
    return jsonify({"success": True})


@app.route("/api/policy-studio/auto-approve", methods=["POST"])
@login_required
def api_policy_studio_auto_approve():
    config.POLICY_AUTO_APPROVE = bool((request.get_json(silent=True) or {}).get("enabled"))
    return jsonify({"success": True, "auto_approve": config.POLICY_AUTO_APPROVE})


@app.route("/lab-registration")
@login_required
def lab_registration_page():
    """Guided lab registration UI - fill this in instead of hand-editing
    config.py to connect this lab server to the central SentryUSB Hub."""
    return render_template("lab_registration.html")


@app.route("/api/lab-registration/fields")
@login_required
def api_lab_registration_fields():
    """Current effective values (UI overrides > config.py defaults) to
    pre-fill the Lab Registration form, plus live hub connection status."""
    try:
        import hub_client
        fields = hub_client.get_registration_fields(config, db)
        # Never echo the raw secret back to the browser - just say whether
        # one is configured so the admin isn't tempted to re-type it blind.
        fields["HUB_REGISTRATION_SECRET_SET"] = bool(fields.get("HUB_REGISTRATION_SECRET"))
        fields.pop("HUB_REGISTRATION_SECRET", None)
        return jsonify({
            "fields": fields,
            "status": hub_client.get_status(),
        })
    except Exception as e:
        log.error(f"lab-registration fields failed: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/lab-registration/save", methods=["POST"])
@login_required
def api_lab_registration_save():
    """Save Lab Registration form values and immediately attempt
    registration with the hub, so the admin gets a pending/approved/error
    result on the spot instead of waiting for the background retry loop."""
    try:
        import hub_client
        data = request.get_json(force=True) or {}

        lab_name = (data.get("lab_name") or "").strip()
        hub_url = (data.get("hub_url") or "").strip()
        if not lab_name:
            return jsonify({"error": "Lab name is required"}), 400
        if not hub_url:
            return jsonify({"error": "Hub URL is required"}), 400

        fields = {
            "HUB_ENABLED": True,
            "HUB_LAB_NAME": lab_name,
            "HUB_URL": hub_url,
            "HUB_CONTACT_EMAIL": (data.get("contact_email") or "").strip(),
            "HUB_LOCATION": (data.get("location") or "").strip(),
        }
        public_url = (data.get("public_url") or "").strip()
        if public_url:
            fields["PUBLIC_URL"] = public_url

        # Only overwrite the shared registration secret if the admin actually
        # typed a new one - leave the existing one alone otherwise, since we
        # never send it back to the browser to pre-fill.
        secret = (data.get("registration_secret") or "").strip()
        if secret:
            fields["HUB_REGISTRATION_SECRET"] = secret

        hub_client.save_registration_fields(db, fields)
        # New identity (name/URL changed) - drop any cached lab_id/token so
        # this doesn't silently try to re-use a stale registration.
        hub_client.reset_registration()

        db.add_audit_log(session.get("admin_user", "admin"), "lab_registration_saved",
                          f"lab_name={lab_name} hub_url={hub_url}")

        result = hub_client.register_now(config, db)
        return jsonify({"success": True, "status": result})
    except Exception as e:
        log.error(f"lab-registration save failed: {e}")
        return jsonify({"error": str(e)}), 500


def _check_hub_auth():
    """Only the hub itself may call the two endpoints below - never a
    logged-in dashboard user, and never anyone without the exact token this
    server received at registration."""
    import hub_client
    token = request.headers.get("X-Hub-Token", "")
    return hub_client.verify_hub_token(token)


@app.route("/api/hub/live-snapshot")
def api_hub_live_snapshot():
    """Read-only feed for the Hub admin's monitoring screen. The hub can
    look at this lab's recent activity but this endpoint has no way to
    change anything here - it only ever returns data."""
    if not _check_hub_auth():
        return jsonify({"error": "unauthorized"}), 401
    try:
        events = db.get_all_events(limit=30)
        agents = db.get_agents()
        blocked = db.get_blocked_devices()
        return jsonify({
            "recent_events": [
                {
                    "timestamp": e.get("timestamp"),
                    "device_name": e.get("device_name") or e.get("device_instance_id"),
                    "status": e.get("status"),
                    "hostname": e.get("hostname"),
                    "username": e.get("username"),
                } for e in events
            ],
            "agents": [
                {
                    "hostname": a.get("hostname"),
                    "username": a.get("username"),
                    "status": a.get("status"),
                    "last_seen": a.get("last_seen"),
                } for a in agents
            ],
            "blocked_device_count": len(blocked),
            "exam_active": exam_active,
            "lockdown_active": lockdown_active,
        })
    except Exception as e:
        log.error(f"live-snapshot failed: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/api/hub/message", methods=["POST"])
def api_hub_message():
    """Live message pushed down FROM the Hub admin. It only ever lands as a
    banner on this server's dashboard - the hub cannot use this to trigger
    any action here. Whoever is monitoring this lab decides what to do."""
    if not _check_hub_auth():
        return jsonify({"error": "unauthorized"}), 401
    try:
        data = request.get_json(force=True) or {}
        message = (data.get("message") or "").strip()
        severity = data.get("severity") or "info"
        if severity not in ("info", "warning", "critical"):
            severity = "info"
        if not message:
            return jsonify({"error": "message is required"}), 400

        sent_by = data.get("sent_by") or "Hub Admin"
        msg_id = db.add_hub_message(message, severity, sent_by)
        socketio.emit("hub_message", {
            "id": msg_id,
            "message": message,
            "severity": severity,
            "sent_by": sent_by,
        })
        return jsonify({"success": True})
    except Exception as e:
        log.error(f"hub message failed: {e}")
        return jsonify({"error": str(e)}), 500


# ============================================================
# SENTRYUSB MESSENGER  (two-way, human-to-human Hub <-> Lab chat)
# ============================================================

_MESSENGER_SEVERITIES = {"info", "warning", "critical"}
_MESSENGER_KINDS = {"text", "image", "voice", "call"}
_MESSENGER_SIGNAL_KINDS = {"invite", "accept", "decline", "busy", "offer", "answer", "ice", "end", "typing"}


def _clean_messenger_body(value):
    import messenger_media
    return messenger_media.clean_text(value, 2000)


@app.route("/api/messenger/messages")
@login_required
def api_messenger_messages():
    """Refresh this lab's local conversation cache from its approved Hub.
    The Hub connection is initiated by the lab, so no chat endpoint exposes
    a control surface to the centralized tier."""
    try:
        import hub_client
        result = hub_client.sync_messenger_messages(config, db)
        if result.get("success"):
            result["messages"] = db.get_messenger_messages()
        return jsonify(result), 200 if result.get("success") else 503
    except Exception as e:
        log.error("Messenger sync failed: %s", e)
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/messenger/read", methods=["POST"])
@login_required
def api_messenger_read():
    """Mark Hub-originated messages read only after a Lab admin opens the
    conversation, rather than when a background sync merely receives them."""
    try:
        import hub_client
        if hub_client.acknowledge_messenger_read(config, db):
            return jsonify({"success": True})
        return jsonify({"success": False, "error": "Could not acknowledge messages to Hub."}), 503
    except Exception as e:
        log.error("Messenger read acknowledgement failed: %s", e)
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/messenger/send", methods=["POST"])
@login_required
def api_messenger_send():
    """Send text, an image, a voice note, or a call-log line to the Hub."""
    import messenger_media
    if request.files:
        form = request.form
        upload = request.files.get("file")
        file_bytes = upload.read(messenger_media.IMAGE_MAX_BYTES + 1) if upload else b""
        filename = secure_filename(upload.filename or "") if upload else ""
    else:
        form, file_bytes, filename = (request.get_json(silent=True) or {}), None, ""
    kind = str(form.get("kind") or "text")
    severity = str(form.get("severity") or "info")
    if kind not in _MESSENGER_KINDS:
        return jsonify({"error": "invalid message type"}), 400
    if severity not in _MESSENGER_SEVERITIES:
        return jsonify({"error": "invalid severity"}), 400
    duration = None
    if kind in ("image", "voice"):
        try:
            messenger_media.classify(kind, file_bytes or b"")          # validate before forwarding
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 400
        body = messenger_media.clean_text(form.get("body"), 500)
        if kind == "voice":
            try:
                duration = max(0.0, min(float(form.get("duration") or 0), float(messenger_media.VOICE_MAX_SECONDS)))
            except (TypeError, ValueError):
                duration = 0.0
    elif kind == "call":
        body = messenger_media.clean_text(form.get("body"), 80)
        file_bytes = None
    else:
        body = _clean_messenger_body(form.get("body"))
        file_bytes = None
    if kind in ("text", "call") and not body:
        return jsonify({"error": "message is required"}), 400
    try:
        import hub_client
        sender = session.get("admin_user", "Lab Admin")
        result = hub_client.send_messenger_message(config, db, body, severity, sender, kind=kind,
                                                   file_bytes=file_bytes, filename=filename, duration=duration)
        if result.get("success"):
            label = {"image": "[image] ", "voice": "[voice note] ", "call": "[call] "}.get(kind, "")
            db.add_audit_log(sender, "messenger_message_sent", f"to Hub: {label}{body[:100]}")
            socketio.emit("messenger_update", {"direction": "lab_to_hub"})
            return jsonify(result), 201
        return jsonify(result), 503
    except Exception as e:
        log.error("Messenger send failed: %s", e)
        return jsonify({"error": str(e)}), 500


@app.route("/api/messenger/media/<media_id>")
@login_required
def api_messenger_media(media_id):
    """Proxy an attachment from the Hub (the lab only ever holds its own token)."""
    import hub_client
    from flask import stream_with_context
    if not media_id.replace("_", "").isalnum():
        return jsonify({"error": "not found"}), 404
    upstream = hub_client.fetch_messenger_media(config, db, media_id, request.headers.get("Range", ""))
    if upstream is None or upstream.status_code not in (200, 206):
        return jsonify({"error": "media unavailable"}), 404
    resp = Response(stream_with_context(upstream.iter_content(65536)), status=upstream.status_code,
                    mimetype=upstream.headers.get("Content-Type", "application/octet-stream"))
    for header in ("Content-Length", "Content-Range", "Accept-Ranges"):
        if upstream.headers.get(header):
            resp.headers[header] = upstream.headers[header]
    resp.headers["Content-Disposition"] = "inline"
    resp.headers["Content-Security-Policy"] = "default-src 'none'; sandbox"
    resp.headers["Cache-Control"] = "private, max-age=3600"
    return resp


@app.route("/api/messenger/ice")
@login_required
def api_messenger_ice():
    import hub_client
    return jsonify({"iceServers": hub_client.get_ice_servers(config, db)})


@app.route("/api/messenger/signal", methods=["POST"])
@login_required
def api_messenger_signal():
    """Relay a call-signalling message (offer/answer/ICE/...) to the Hub."""
    data = request.get_json(silent=True) or {}
    kind = str(data.get("kind") or "")
    if kind not in _MESSENGER_SIGNAL_KINDS:
        return jsonify({"error": "invalid signal"}), 400
    call_id = str(data.get("call_id") or "")[:64]
    if kind != "typing" and not call_id:
        return jsonify({"error": "call_id is required"}), 400
    payload = data.get("payload") or {}
    if not isinstance(payload, dict):
        return jsonify({"error": "invalid payload"}), 400
    import hub_client
    result = hub_client.send_signal(config, db, call_id, kind, payload)
    if result.get("success") and kind == "invite":
        db.add_audit_log(session.get("admin_user", "Lab Admin"), "messenger_call_started", "call to Hub")
    return jsonify(result), 200 if result.get("success") else 503


@app.route("/api/messenger/signals")
@login_required
def api_messenger_signals():
    import hub_client
    try:
        after = int(request.args.get("after", "-1"))
    except ValueError:
        after = -1
    return jsonify(hub_client.get_signals(config, db, after))


if __name__ == "__main__":
    app.config['START_TIME'] = time.time()
    
    print("=" * 70)
    print("🔒 SENTRYUSB SECURITY SYSTEM v2.0")
    print("=" * 70)
    print(f"📍 Server: http://localhost:{config.PORT}")
    print(f"👤 Default login: {config.ADMIN_USERNAME} / {config.ADMIN_PASSWORD}")
    print("=" * 70)
    print("📋 Available Pages:")
    print(f"  📊 Dashboard:    http://localhost:{config.PORT}/")
    print(f"  🖥️ Browser Ctrl:  http://localhost:{config.PORT}/browser-control")
    print(f"  📚 Exam Ctrl:    http://localhost:{config.PORT}/exam")
    print(f"  🔐 Security:     http://localhost:{config.PORT}/security")
    print(f"  🤖 AI Security:  http://localhost:{config.PORT}/ai-enhanced")
    print(f"  ⚙️ Admin:        http://localhost:{config.PORT}/admin")
    print(f"  🔔 Alerts:       http://localhost:{config.PORT}/alerts")
    print(f"  📊 Reports:      http://localhost:{config.PORT}/reports")
    print("=" * 70)
    print("🚀 Features Enabled:")
    print("  ✅ USB Device Detection with Duplicate Prevention")
    print("  ✅ Browser Monitoring with Login Detection")
    print("  ✅ Exam Mode with Instant Blocking")
    print("  ✅ Health Monitoring & Reporting")
    print("  ✅ Rate Limiting & Security Headers")
    print("  ✅ 2FA Authentication")
    print("  ✅ IP Whitelisting")
    print("  ✅ LDAP Integration")
    print("  ✅ Multi-channel Alerts (Email, Telegram, Slack, Discord)")
    print("  ✅ Token Auto-Sync for Agents")
    if AI_ENHANCED_AVAILABLE:
        print("  ✅ AI Enhanced Security (Malware, RDP, Threat Intel, ML, Integrity)")
    if ML_ANOMALY_AVAILABLE:
        print("  ✅ ML Anomaly Detector (Isolation Forest)")
    print("=" * 70)
    
    if REPORTS_AVAILABLE:
        try:
            start_scheduler()
            print("📊 Report scheduler started")
        except Exception as e:
            log.error(f"Failed to start scheduler: {e}")

    if EXAM_SCHEDULER_AVAILABLE:
        try:
            exam_scheduler.init_scheduler(socketio, db)
            print("📅 Exam scheduler started (scheduled_start in exam_config, if set)")
        except Exception as e:
            log.error(f"Failed to start exam scheduler: {e}")

    if AI_CHAT_AVAILABLE:
        try:
            ai_chat.start_autopilot(socketio, _ai_context)
            print("🤖 AI autopilot started (proactive insights)")
        except Exception as e:
            log.error(f"Failed to start AI autopilot: {e}")

    print("🚀 Server starting...")
    print("=" * 70)
    
    socketio.run(app, host="0.0.0.0", port=config.PORT, debug=False, allow_unsafe_werkzeug=True)
