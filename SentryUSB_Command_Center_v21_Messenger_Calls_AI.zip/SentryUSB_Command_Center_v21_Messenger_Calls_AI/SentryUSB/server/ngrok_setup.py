"""
SentryUSB - ngrok Integration
Expose local server to the internet securely
"""
import subprocess
import requests
import json
import time
import os
import sys
import signal
import re

class NgrokSetup:
    def __init__(self, local_port=5000, auth_token=None):
        self.local_port = local_port
        self.auth_token = auth_token
        self.ngrok_process = None
        self.public_url = None
        self.is_running = False
    
    def install_ngrok(self):
        """Install ngrok if not present"""
        print("📦 Installing ngrok...")
        try:
            import urllib.request
            import zipfile
            
            # Detect OS
            import platform
            system = platform.system().lower()
            
            if system == "windows":
                url = "https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-windows-amd64.zip"
                exe_name = "ngrok.exe"
            elif system == "darwin":
                url = "https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-darwin-amd64.zip"
                exe_name = "ngrok"
            else:  # Linux
                url = "https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-amd64.zip"
                exe_name = "ngrok"
            
            zip_path = os.path.join(os.path.dirname(__file__), "ngrok.zip")
            
            print(f"   Downloading ngrok for {system}...")
            urllib.request.urlretrieve(url, zip_path)
            
            print("   Extracting...")
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(os.path.dirname(__file__))
            
            os.remove(zip_path)
            
            # Make executable on Unix
            if system != "windows":
                os.chmod(os.path.join(os.path.dirname(__file__), exe_name), 0o755)
            
            print(f"   ✅ ngrok installed successfully!")
            return True
        except Exception as e:
            print(f"   ❌ Failed to install ngrok: {e}")
            print("   Please download manually from: https://ngrok.com/download")
            return False
    
    def is_ngrok_installed(self):
        """Check if ngrok is installed"""
        ngrok_paths = [
            "ngrok.exe",
            "ngrok",
            os.path.join(os.path.dirname(__file__), "ngrok.exe"),
            os.path.join(os.path.dirname(__file__), "ngrok"),
        ]
        
        for path in ngrok_paths:
            if os.path.exists(path):
                return True
        
        # Try checking in PATH
        try:
            result = subprocess.run(
                ["ngrok", "--version"],
                capture_output=True,
                text=True,
                timeout=5
            )
            return result.returncode == 0
        except:
            pass
        
        return False
    
    def start_ngrok(self):
        """Start ngrok tunnel"""
        print("🚀 Starting ngrok tunnel...")
        
        # Check if ngrok is installed
        if not self.is_ngrok_installed():
            print("⚠️ ngrok not found!")
            response = input("Would you like to install ngrok automatically? (y/n): ")
            if response.lower() == 'y':
                if not self.install_ngrok():
                    return None
            else:
                print("Please download ngrok from: https://ngrok.com/download")
                print("Then run: ngrok http 5000")
                return None
        
        # Start ngrok process
        try:
            cmd = ["ngrok", "http", str(self.local_port)]
            
            # Add auth token if provided
            if self.auth_token:
                cmd.extend(["--authtoken", self.auth_token])
            
            # Determine platform
            import platform
            shell = platform.system().lower() == "windows"
            
            self.ngrok_process = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                shell=shell
            )
            
            print("⏳ Waiting for tunnel to establish...")
            time.sleep(3)
            
            # Get public URL
            self.public_url = self._get_public_url()
            
            if self.public_url:
                self.is_running = True
                print(f"✅ ngrok tunnel established!")
                print(f"🌐 Public URL: {self.public_url}")
                print(f"📡 Dashboard: {self.public_url}/")
                
                # Update server config
                self._update_server_config(self.public_url)
                
                # Save URL to file
                self._save_public_url(self.public_url)
                
                return self.public_url
            else:
                print("❌ Failed to get public URL")
                print("   Make sure ngrok is running properly")
                return None
                
        except Exception as e:
            print(f"❌ Failed to start ngrok: {e}")
            return None
    
    def _get_public_url(self):
        """Get public URL from ngrok API"""
        for attempt in range(10):
            try:
                response = requests.get("http://127.0.0.1:4040/api/tunnels", timeout=5)
                data = response.json()
                tunnels = data.get("tunnels", [])
                for tunnel in tunnels:
                    if tunnel.get("proto") == "https":
                        url = tunnel.get("public_url")
                        return url
                time.sleep(1)
            except Exception as e:
                print(f"   Attempt {attempt+1}/10: Waiting for ngrok...")
                time.sleep(1)
        return None
    
    def _update_server_config(self, public_url):
        """Update server config with public URL"""
        config_path = os.path.join(os.path.dirname(__file__), "config.py")
        
        try:
            with open(config_path, 'r') as f:
                content = f.read()
            
            # Update or add PUBLIC_URL
            if "PUBLIC_URL" in content:
                content = re.sub(
                    r'PUBLIC_URL = ".*?"',
                    f'PUBLIC_URL = "{public_url}"',
                    content
                )
            else:
                # Find a good place to insert
                insert_pos = content.find("# ========== 🌐 REMOTE ACCESS")
                if insert_pos == -1:
                    insert_pos = content.find("PORT =")
                if insert_pos != -1:
                    insert_line = f'\nPUBLIC_URL = "{public_url}"\n'
                    content = content[:insert_pos] + insert_line + content[insert_pos:]
                else:
                    content += f'\nPUBLIC_URL = "{public_url}"\n'
            
            # Ensure REMOTE_ACCESS_ENABLED is True
            if "REMOTE_ACCESS_ENABLED" in content:
                content = re.sub(
                    r'REMOTE_ACCESS_ENABLED = .*',
                    'REMOTE_ACCESS_ENABLED = True',
                    content
                )
            else:
                content += '\nREMOTE_ACCESS_ENABLED = True\n'
            
            with open(config_path, 'w') as f:
                f.write(content)
            
            print(f"✅ Config updated with PUBLIC_URL: {public_url}")
        except Exception as e:
            print(f"⚠️ Failed to update config: {e}")
    
    def _save_public_url(self, public_url):
        """Save public URL to file"""
        try:
            url_file = os.path.join(os.path.dirname(__file__), "public_url.txt")
            with open(url_file, 'w') as f:
                f.write(public_url)
            print(f"✅ Public URL saved to: {url_file}")
        except:
            pass
    
    def stop_ngrok(self):
        """Stop ngrok tunnel"""
        if self.ngrok_process:
            print("🛑 Stopping ngrok tunnel...")
            self.ngrok_process.terminate()
            time.sleep(2)
            self.ngrok_process = None
            self.is_running = False
            print("✅ ngrok stopped")
    
    def get_public_url(self):
        """Get current public URL"""
        if self.is_running:
            return self._get_public_url()
        return None

def main():
    """Main entry point"""
    print("=" * 60)
    print("🌐 SentryUSB - ngrok Setup")
    print("=" * 60)
    
    # Check for auth token
    auth_token = os.environ.get("NGROK_AUTH_TOKEN")
    if auth_token:
        print("🔑 Using ngrok auth token from environment")
    else:
        print("ℹ️  No ngrok auth token found (optional)")
    
    port = os.environ.get("SENTRYUSB_PORT", "5000")
    
    ngrok = NgrokSetup(local_port=int(port), auth_token=auth_token)
    
    # Handle Ctrl+C
    def signal_handler(sig, frame):
        print("\n🛑 Shutting down...")
        ngrok.stop_ngrok()
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    
    # Start ngrok
    url = ngrok.start_ngrok()
    
    if url:
        print("\n" + "=" * 60)
        print("✅ ngrok tunnel is running!")
        print("=" * 60)
        print(f"🌐 Public URL: {url}")
        print(f"📡 Dashboard: {url}/")
        print("")
        print("📝 Update agent/config.py with:")
        print(f"   REMOTE_SERVER_URL = \"{url}\"")
        print("")
        print("🔄 Or use auto-detect (recommended):")
        print("   AUTO_DETECT_SERVER = True")
        print("=" * 60)
        print("")
        print("Press Ctrl+C to stop ngrok tunnel")
        
        # Keep running
        while True:
            time.sleep(1)
    else:
        print("\n❌ Failed to start ngrok tunnel")
        print("Please install ngrok manually from: https://ngrok.com/download")
        print("Then run: ngrok http 5000")

if __name__ == "__main__":
    main()