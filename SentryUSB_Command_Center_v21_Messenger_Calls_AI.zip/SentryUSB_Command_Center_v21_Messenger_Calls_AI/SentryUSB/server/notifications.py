"""
SentryUSB - Notification System
Handles email, Telegram, Slack, and Discord alerts
"""
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime

import requests

import config

log = logging.getLogger("sentryusb.notifications")

# ============================================================
# COOLDOWN TRACKING
# ============================================================

_alert_cooldowns = {}

def _is_on_cooldown(device_id: str, event_type: str) -> bool:
    """Check if this device/event is on cooldown"""
    key = f"{device_id}_{event_type}"
    last_alert = _alert_cooldowns.get(key)
    if last_alert:
        elapsed = (datetime.now() - last_alert).total_seconds()
        if elapsed < config.ALERT_COOLDOWN_SECONDS:
            return True
    _alert_cooldowns[key] = datetime.now()
    return False

# ============================================================
# EMAIL NOTIFICATIONS
# ============================================================

def send_email_alert(subject: str, body: str, is_html: bool = False) -> bool:
    """Send email alert"""
    if not config.EMAIL_ENABLED:
        log.debug("Email alerts disabled")
        return False

    try:
        msg = MIMEMultipart()
        msg['Subject'] = subject
        msg['From'] = config.EMAIL_FROM
        msg['To'] = config.EMAIL_TO

        if is_html:
            msg.attach(MIMEText(body, 'html'))
        else:
            msg.attach(MIMEText(body, 'plain'))

        with smtplib.SMTP(config.EMAIL_HOST, config.EMAIL_PORT) as server:
            if config.EMAIL_USE_TLS:
                server.starttls()
            server.login(config.EMAIL_USERNAME, config.EMAIL_PASSWORD)
            server.send_message(msg)

        log.info("Email alert sent: %s", subject)
        return True

    except Exception as e:
        log.error("Failed to send email alert: %s", e)
        return False

# ============================================================
# TELEGRAM NOTIFICATIONS
# ============================================================

def send_telegram_alert(message: str) -> bool:
    """Send Telegram alert"""
    if not config.TELEGRAM_ENABLED:
        log.debug("Telegram alerts disabled")
        return False

    try:
        url = f"https://api.telegram.org/bot{config.TELEGRAM_BOT_TOKEN}/sendMessage"
        payload = {
            "chat_id": config.TELEGRAM_CHAT_ID,
            "text": message,
            "parse_mode": "HTML"
        }
        response = requests.post(url, json=payload, timeout=10)
        response.raise_for_status()
        log.info("Telegram alert sent")
        return True
    except Exception as e:
        log.error("Failed to send Telegram alert: %s", e)
        return False

# ============================================================
# SLACK NOTIFICATIONS
# ============================================================

def send_slack_alert(message: str) -> bool:
    """Send Slack alert via webhook"""
    if not config.SLACK_ENABLED:
        log.debug("Slack alerts disabled")
        return False

    try:
        payload = {"text": message, "mrkdwn": True}
        response = requests.post(config.SLACK_WEBHOOK_URL, json=payload, timeout=10)
        response.raise_for_status()
        log.info("Slack alert sent")
        return True
    except Exception as e:
        log.error("Failed to send Slack alert: %s", e)
        return False

# ============================================================
# DISCORD NOTIFICATIONS
# ============================================================

def send_discord_alert(message: str) -> bool:
    """Send Discord alert via webhook"""
    if not config.DISCORD_ENABLED:
        log.debug("Discord alerts disabled")
        return False

    try:
        payload = {"content": message}
        response = requests.post(config.DISCORD_WEBHOOK_URL, json=payload, timeout=10)
        response.raise_for_status()
        log.info("Discord alert sent")
        return True
    except Exception as e:
        log.error("Failed to send Discord alert: %s", e)
        return False

# ============================================================
# MAIN ALERT FUNCTION
# ============================================================

def send_alert(event_data: dict) -> bool:
    """
    Send alert for a USB event
    Returns: True if any alert was sent, False otherwise
    """
    event_type = event_data.get("status", "unknown")
    device_name = event_data.get("device_name", "Unknown Device")
    hostname = event_data.get("hostname", "Unknown Host")
    device_id = event_data.get("device_instance_id", "")
    username = event_data.get("username", "Unknown User")
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Check if we should alert on this event type
    alert_map = {
        "blocked": config.ALERT_ON_BLOCKED,
        "allowed": config.ALERT_ON_ALLOWED,
        "connected": config.ALERT_ON_CONNECTED,
        "removed": config.ALERT_ON_REMOVED,
        "overridden": config.ALERT_ON_OVERRIDDEN,
    }

    if not alert_map.get(event_type, True):
        log.debug("Alert disabled for event type: %s", event_type)
        return False

    # Check cooldown
    if _is_on_cooldown(device_id, event_type):
        log.debug("Alert on cooldown for device %s", device_id)
        return False

    # Build alert message
    emoji_map = {
        "blocked": "🚨",
        "allowed": "✅",
        "connected": "🔌",
        "removed": "🔌",
        "overridden": "⚠️",
    }
    emoji = emoji_map.get(event_type, "🔔")

    text_message = f"""{emoji} <b>SentryUSB Alert</b>
    
<b>Event:</b> {event_type.upper()}
<b>Device:</b> {device_name}
<b>Host:</b> {hostname}
<b>User:</b> {username}
<b>Time:</b> {timestamp}
<b>Device ID:</b> {device_id[:30]}..."""

    html_message = f"""
    <html>
    <head><style>
        body {{ font-family: Arial, sans-serif; }}
        .alert {{ padding: 20px; border-radius: 8px; background: #f8f9fa; border-left: 4px solid #6366f1; }}
        .title {{ color: #6366f1; font-size: 20px; font-weight: bold; }}
        .field {{ margin: 8px 0; }}
        .label {{ font-weight: bold; color: #555; }}
        .value {{ color: #222; }}
        .badge {{ display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: bold; }}
        .badge-blocked {{ background: #fee2e2; color: #dc2626; }}
        .badge-allowed {{ background: #dcfce7; color: #16a34a; }}
        .badge-connected {{ background: #dbeafe; color: #2563eb; }}
        .badge-overridden {{ background: #fef3c7; color: #d97706; }}
    </style></head>
    <body>
    <div class="alert">
        <div class="title">{emoji} SentryUSB Alert</div>
        <hr>
        <div class="field"><span class="label">Event:</span> <span class="badge badge-{event_type}">{event_type.upper()}</span></div>
        <div class="field"><span class="label">Device:</span> <span class="value">{device_name}</span></div>
        <div class="field"><span class="label">Host:</span> <span class="value">{hostname}</span></div>
        <div class="field"><span class="label">User:</span> <span class="value">{username}</span></div>
        <div class="field"><span class="label">Time:</span> <span class="value">{timestamp}</span></div>
        <div class="field"><span class="label">Device ID:</span> <span class="value" style="font-size:12px;color:#666;">{device_id[:30]}...</span></div>
        <hr>
        <div style="font-size:12px;color:#999;text-align:center;">
            <a href="http://localhost:5000">SentryUSB Dashboard</a>
        </div>
    </div>
    </body>
    </html>
    """

    sent = False

    # Send email
    if config.EMAIL_ENABLED:
        subject = f"{emoji} SentryUSB: {event_type.upper()} - {device_name} on {hostname}"
        if send_email_alert(subject, html_message, is_html=True):
            sent = True

    # Send Telegram
    if config.TELEGRAM_ENABLED:
        if send_telegram_alert(text_message):
            sent = True

    # Send Slack
    if config.SLACK_ENABLED:
        slack_msg = f"*{emoji} SentryUSB Alert*\n\n*Event:* {event_type.upper()}\n*Device:* {device_name}\n*Host:* {hostname}\n*User:* {username}\n*Time:* {timestamp}"
        if send_slack_alert(slack_msg):
            sent = True

    # Send Discord
    if config.DISCORD_ENABLED:
        discord_msg = f"**{emoji} SentryUSB Alert**\n\n**Event:** {event_type.upper()}\n**Device:** {device_name}\n**Host:** {hostname}\n**User:** {username}\n**Time:** {timestamp}"
        if send_discord_alert(discord_msg):
            sent = True

    return sent

# ============================================================
# RDP / REMOTE-ACCESS ALERT FUNCTION
# ============================================================

def send_rdp_alert(event_data: dict) -> bool:
    """
    Send alert for an agent-reported RDP / third-party remote-access event.
    Previously RDP detections only nudged a percentage on a dashboard
    widget and never reached email/Telegram/Slack/Discord - this closes
    that gap using the same channels as USB alerts.

    Returns: True if any alert was sent, False otherwise
    """
    event_type = event_data.get("event", "unknown")
    hostname = event_data.get("hostname", "Unknown Host")
    tool = event_data.get("tool") or ("Windows RDP" if "rdp" in event_type else "Remote Access")
    exam_active = event_data.get("exam_active", False)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # Only alert on the "started/detected" side of the pair, not on
    # every session-ended/tool-closed event
    if event_type not in ("rdp_session_started", "remote_tool_detected"):
        return False

    if not getattr(config, "ALERT_ON_RDP_DETECTED", True):
        log.debug("RDP alerts disabled")
        return False

    # Cooldown, keyed per host+tool rather than per USB device id
    cooldown_key = f"rdp_{hostname}_{tool}"
    if _is_on_cooldown(cooldown_key, event_type):
        log.debug("RDP alert on cooldown for %s / %s", hostname, tool)
        return False

    emoji = "🚨" if exam_active else "🖥️"
    severity_label = "DURING ACTIVE EXAM" if exam_active else "detected"

    text_message = f"""{emoji} <b>SentryUSB RDP/Remote-Access Alert</b>
    
<b>Status:</b> {tool} {severity_label}
<b>Host:</b> {hostname}
<b>Time:</b> {timestamp}"""

    html_message = f"""
    <html>
    <head><style>
        body {{ font-family: Arial, sans-serif; }}
        .alert {{ padding: 20px; border-radius: 8px; background: #f8f9fa; border-left: 4px solid #dc2626; }}
        .title {{ color: #dc2626; font-size: 20px; font-weight: bold; }}
        .field {{ margin: 8px 0; }}
        .label {{ font-weight: bold; color: #555; }}
        .value {{ color: #222; }}
    </style></head>
    <body>
    <div class="alert">
        <div class="title">{emoji} SentryUSB RDP/Remote-Access Alert</div>
        <hr>
        <div class="field"><span class="label">Tool:</span> <span class="value">{tool}</span></div>
        <div class="field"><span class="label">Host:</span> <span class="value">{hostname}</span></div>
        <div class="field"><span class="label">Exam active:</span> <span class="value">{"Yes" if exam_active else "No"}</span></div>
        <div class="field"><span class="label">Time:</span> <span class="value">{timestamp}</span></div>
        <hr>
        <div style="font-size:12px;color:#999;text-align:center;">
            <a href="http://localhost:5000">SentryUSB Dashboard</a>
        </div>
    </div>
    </body>
    </html>
    """

    sent = False

    if config.EMAIL_ENABLED:
        subject = f"{emoji} SentryUSB: {tool} {severity_label} on {hostname}"
        if send_email_alert(subject, html_message, is_html=True):
            sent = True

    if config.TELEGRAM_ENABLED:
        if send_telegram_alert(text_message):
            sent = True

    if config.SLACK_ENABLED:
        slack_msg = f"*{emoji} SentryUSB RDP Alert*\n\n*Tool:* {tool}\n*Host:* {hostname}\n*Exam active:* {'Yes' if exam_active else 'No'}\n*Time:* {timestamp}"
        if send_slack_alert(slack_msg):
            sent = True

    if config.DISCORD_ENABLED:
        discord_msg = f"**{emoji} SentryUSB RDP Alert**\n\n**Tool:** {tool}\n**Host:** {hostname}\n**Exam active:** {'Yes' if exam_active else 'No'}\n**Time:** {timestamp}"
        if send_discord_alert(discord_msg):
            sent = True

    return sent