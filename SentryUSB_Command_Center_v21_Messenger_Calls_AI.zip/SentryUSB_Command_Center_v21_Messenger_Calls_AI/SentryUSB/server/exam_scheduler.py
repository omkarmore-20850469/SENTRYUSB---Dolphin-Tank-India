"""
SentryUSB Server - Exam Scheduler
----------------------------------
Automatically broadcasts exam_start / exam_stop to all connected agents
based on exam_config's scheduled_start (ISO datetime) + duration (seconds),
instead of requiring someone to click the manual Start/Stop Exam buttons.

Call init_scheduler(socketio, db) once at server startup, and call
sync_schedule() again any time exam_config is saved from the dashboard.
"""
import logging
import datetime

log = logging.getLogger("sentryusb.exam_scheduler")

try:
    from apscheduler.schedulers.background import BackgroundScheduler
    APSCHEDULER_AVAILABLE = True
except ImportError:
    APSCHEDULER_AVAILABLE = False
    log.warning("APScheduler not installed — scheduled exam start/stop disabled (pip install APScheduler).")

_scheduler = None
_socketio = None
_db = None

JOB_START_ID = "sentryusb_scheduled_exam_start"
JOB_STOP_ID = "sentryusb_scheduled_exam_stop"


def init_scheduler(socketio, db_module):
    """Call once at server startup, right after db.init_db()."""
    global _scheduler, _socketio, _db
    _socketio = socketio
    _db = db_module

    if not APSCHEDULER_AVAILABLE:
        return None

    _scheduler = BackgroundScheduler(daemon=True)
    _scheduler.start()
    sync_schedule()
    log.info("📅 Exam scheduler started.")
    return _scheduler


def sync_schedule():
    """
    Re-read exam_config and (re)schedule the auto-start/auto-stop jobs.
    Safe to call repeatedly (e.g. every time exam_config is saved) — it
    clears any previously scheduled jobs first.
    """
    if _scheduler is None:
        return

    for job_id in (JOB_START_ID, JOB_STOP_ID):
        try:
            _scheduler.remove_job(job_id)
        except Exception:
            pass  # job didn't exist yet — fine

    cfg = _db.get_exam_config()
    scheduled_start = (cfg.get("scheduled_start") or "").strip()
    if not scheduled_start:
        return

    try:
        start_dt = datetime.datetime.fromisoformat(scheduled_start)
        duration = int(cfg.get("duration", 3600) or 3600)
    except (ValueError, TypeError) as e:
        log.error(f"Invalid scheduled_start/duration in exam_config ({scheduled_start!r}): {e}")
        return

    now = datetime.datetime.now()

    if start_dt > now:
        _scheduler.add_job(_fire_exam_start, "date", run_date=start_dt, id=JOB_START_ID, args=[cfg])
        log.info(f"📅 Exam auto-start scheduled for {start_dt.isoformat()}")
    else:
        log.info("Scheduled start time is in the past — not scheduling auto-start.")

    stop_dt = start_dt + datetime.timedelta(seconds=duration)
    if stop_dt > now:
        _scheduler.add_job(_fire_exam_stop, "date", run_date=stop_dt, id=JOB_STOP_ID)
        log.info(f"📅 Exam auto-stop scheduled for {stop_dt.isoformat()}")


def _fire_exam_start(cfg):
    log.info("📚 Auto-triggering exam_start (scheduled)")
    _socketio.emit("exam_start", {
        "url": cfg.get("exam_url", ""),
        "duration": cfg.get("duration", 3600),
        "block_usb": True,
        "block_internet": True,
        "block_browsers": True,
        "block_copy_paste": True,
        "block_print_screen": True
    })
    try:
        _db.add_audit_log("scheduler", "exam_start", "Auto-started exam (scheduled)")
    except Exception as e:
        log.debug(f"Audit log failed: {e}")


def _fire_exam_stop():
    log.info("📚 Auto-triggering exam_stop (scheduled)")
    _socketio.emit("exam_stop", {})
    try:
        _db.add_audit_log("scheduler", "exam_stop", "Auto-stopped exam (scheduled)")
    except Exception as e:
        log.debug(f"Audit log failed: {e}")
