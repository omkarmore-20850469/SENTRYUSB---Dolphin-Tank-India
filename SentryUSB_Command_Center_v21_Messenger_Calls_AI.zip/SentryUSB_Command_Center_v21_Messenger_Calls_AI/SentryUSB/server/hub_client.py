"""
SentryUSB Lab Server -> Hub client
----------------------------------
This is the piece that closes the gap between the centralized SentryUSB Hub
(tier 1) and this particular lab server (tier 2). It does NOT touch the
existing agent<->server ngrok flow at all - that keeps working exactly as
before. This module only talks *outbound* to the hub over plain HTTPS:

    1. On startup, if this lab server has no cached hub_id/hub_token, it
       calls the hub's POST /api/hub/register with this lab's name and its
       own public URL (config.PUBLIC_URL, the same ngrok URL agents use).
    2. The hub replies with a unique lab_id + hub_token. Those are cached
       locally in hub_registration.json so restarts don't create duplicate
       lab entries.
    3. If the hub reports "pending" (awaiting admin approval), this module
       keeps retrying registration in the background until it's approved.
    4. Once approved, a background thread sends a small heartbeat/stats
       payload to the hub every HUB_HEARTBEAT_INTERVAL seconds so the hub
       dashboard can show this lab as online with live counts.

Safe by design: every network call is wrapped so a hub outage/misconfig
never takes down the lab server itself - agents keep working either way.
"""
import json
import logging
import os
import threading
import time
import uuid
from urllib.parse import urlparse

import requests

log = logging.getLogger("sentryusb.hub_client")

CACHE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "hub_registration.json")

_state = {
    "lab_id": None,
    "hub_token": None,
    "status": None,       # pending | approved | revoked | rejected | None (not yet registered)
    "last_error": None,
}
_state_lock = threading.Lock()
_started = False


def _normalise_url(url: str) -> str:
    """Ensure URL has a scheme and a port if missing."""
    url = url.strip()
    if not url:
        return url
    # Add scheme if missing
    if not url.startswith(('http://', 'https://')):
        url = 'http://' + url
    # Parse and if no port, append :6800 (hub default)
    parsed = urlparse(url)
    if not parsed.port:
        # preserve path etc.
        netloc = parsed.netloc
        if ':' not in netloc:
            netloc = f"{netloc}:6800"
        url = f"{parsed.scheme}://{netloc}{parsed.path or ''}"
        if parsed.query:
            url += f"?{parsed.query}"
        if parsed.fragment:
            url += f"#{parsed.fragment}"
    return url


def _load_cache():
    try:
        if os.path.exists(CACHE_PATH):
            with open(CACHE_PATH, "r") as f:
                data = json.load(f)
                _state["lab_id"] = data.get("lab_id")
                _state["hub_token"] = data.get("hub_token")
                _state["status"] = data.get("status")
    except Exception as e:
        log.warning(f"Could not read hub_registration.json: {e}")


def _save_cache():
    try:
        with open(CACHE_PATH, "w") as f:
            json.dump({
                "lab_id": _state["lab_id"],
                "hub_token": _state["hub_token"],
                "status": _state["status"],
            }, f, indent=2)
    except Exception as e:
        log.warning(f"Could not write hub_registration.json: {e}")


def verify_hub_token(token: str) -> bool:
    """Used by app.py to authenticate inbound calls FROM the hub (live
    monitoring pull, live message push). The hub already holds this exact
    token because it's the one it issued us at registration - so a match
    here proves the caller really is our hub, not a random visitor."""
    if not token:
        return False
    with _state_lock:
        return bool(_state.get("hub_token")) and _state.get("hub_token") == token


def get_status() -> dict:
    """Read-only snapshot, safe to expose on a local admin page if wanted."""
    with _state_lock:
        return dict(_state)


# ============================================================
# EFFECTIVE CONFIG  (Lab Registration UI overrides > config.py defaults)
# ============================================================
# These are the only fields the Lab Registration page is allowed to
# override. Anything not in this list always comes straight from config.py.
OVERRIDABLE_FIELDS = [
    "HUB_ENABLED",
    "HUB_URL",
    "HUB_LAB_NAME",
    "HUB_REGISTRATION_SECRET",
    "HUB_CONTACT_EMAIL",
    "HUB_LOCATION",
    "PUBLIC_URL",
]
_SETTING_PREFIX = "hub_reg_"  # server_settings key = hub_reg_<FIELD>


class _EffectiveConfig:
    """Thin read-through wrapper: DB override (if set and non-empty) wins,
    otherwise falls back to the real config.py module. Re-reads the DB every
    time an attribute is accessed, so a save from the Lab Registration page
    is picked up on the very next registration/heartbeat tick - no restart
    needed."""

    def __init__(self, config, db_module):
        object.__setattr__(self, "_config", config)
        object.__setattr__(self, "_db", db_module)

    def __getattr__(self, name):
        db = object.__getattribute__(self, "_db")
        config = object.__getattribute__(self, "_config")
        if name in OVERRIDABLE_FIELDS and db is not None:
            try:
                override = db.get_setting(_SETTING_PREFIX + name)
            except Exception:
                override = None
            if override not in (None, ""):
                if name == "HUB_ENABLED":
                    return str(override).lower() == "true"
                return override
        return getattr(config, name)


def get_effective_config(config, db_module=None):
    """Build a view of config.py with any Lab Registration overrides applied."""
    return _EffectiveConfig(config, db_module)


def get_registration_fields(config, db_module=None) -> dict:
    """Current effective values for every overridable field, for the Lab
    Registration page to pre-fill its form with."""
    eff = get_effective_config(config, db_module)
    return {name: getattr(eff, name) for name in OVERRIDABLE_FIELDS}


def save_registration_fields(db_module, fields: dict):
    """Persist Lab Registration form values as overrides. Only known fields
    are accepted; unknown keys are silently ignored."""
    for name in OVERRIDABLE_FIELDS:
        if name in fields and fields[name] is not None:
            db_module.set_setting(_SETTING_PREFIX + name, fields[name])


def reset_registration():
    """Clear this lab's cached hub identity so the next registration attempt
    is treated as brand new (used after the lab name / hub URL changes from
    the UI, so a re-registration doesn't get silently tied to the old
    identity)."""
    with _state_lock:
        _state["lab_id"] = None
        _state["hub_token"] = None
        _state["status"] = None
        _state["last_error"] = None
    try:
        if os.path.exists(CACHE_PATH):
            os.remove(CACHE_PATH)
    except Exception as e:
        log.warning(f"Could not clear hub_registration.json: {e}")


def register_now(config, db_module) -> dict:
    """Synchronous one-off registration attempt, used by the Lab Registration
    page's 'Save & Register' button so the admin gets an immediate
    pending/approved/error result instead of waiting for the background
    retry loop."""
    eff = get_effective_config(config, db_module)
    _register(eff)
    return get_status()


def _check_hub_health(config) -> bool:
    """Quick probe to see if the hub is reachable. Logs a clear error if not."""
    hub_url = _normalise_url(config.HUB_URL)
    try:
        resp = requests.get(
            f"{hub_url.rstrip('/')}/api/health",
            timeout=5,
            headers={"ngrok-skip-browser-warning": "true"},
        )
        if resp.status_code == 200:
            log.info(f"✅ Hub health check passed: {hub_url}")
            return True
        else:
            log.warning(f"⚠️ Hub health check returned HTTP {resp.status_code} - check hub is running and {hub_url} is correct")
            return False
    except Exception as e:
        log.error(f"❌ Hub health check failed: {e} (URL: {hub_url})")
        return False


def _register(config) -> bool:
    hub_url = _normalise_url(config.HUB_URL)
    payload = {
        "lab_name": config.HUB_LAB_NAME,
        "server_url": config.PUBLIC_URL,
        "registration_secret": config.HUB_REGISTRATION_SECRET,
        "contact_email": getattr(config, "HUB_CONTACT_EMAIL", ""),
        "location": getattr(config, "HUB_LOCATION", ""),
        "server_version": getattr(config, "SERVER_VERSION", "2.0"),
    }
    with _state_lock:
        if _state["lab_id"] and _state["hub_token"]:
            payload["lab_id"] = _state["lab_id"]
            payload["hub_token"] = _state["hub_token"]

    try:
        resp = requests.post(
            f"{hub_url.rstrip('/')}/api/hub/register",
            json=payload, timeout=10,
            headers={"ngrok-skip-browser-warning": "true"},
        )
    except Exception as e:
        with _state_lock:
            _state["last_error"] = f"connection error: {e}"
        log.warning(f"Hub registration failed (connection): {e}")
        return False

    if resp.status_code in (200, 201):
        data = resp.json()
        with _state_lock:
            _state["lab_id"] = data.get("lab_id")
            _state["hub_token"] = data.get("hub_token")
            _state["status"] = data.get("status")
            _state["last_error"] = None
        _save_cache()
        log.info(f"Hub registration OK: lab_id={data.get('lab_id')} status={data.get('status')}")
        return True

    try:
        err = resp.json().get("error", resp.text)
    except Exception:
        err = resp.text
    with _state_lock:
        _state["last_error"] = f"HTTP {resp.status_code}: {err}"
    log.warning(f"Hub registration rejected: HTTP {resp.status_code}: {err}")
    return False


def _gather_stats(db_module) -> dict:
    """Small, cheap snapshot of this lab's activity for the hub dashboard.
    Wrapped in try/except per-field so a schema change in db.py can never
    break the heartbeat loop."""
    stats = {}
    try:
        stats["agents"] = len(db_module.get_agents())
    except Exception:
        pass
    try:
        stats["events_total"] = len(db_module.get_all_events(limit=100000))
    except Exception:
        pass
    try:
        stats["blocked_devices"] = len(db_module.get_blocked_devices())
    except Exception:
        pass
    return stats


def _heartbeat(config, db_module) -> bool:
    hub_url = _normalise_url(config.HUB_URL)
    with _state_lock:
        token = _state["hub_token"]
    if not token:
        return False

    payload = {
        "stats": _gather_stats(db_module),
        "server_url": config.PUBLIC_URL,
    }
    try:
        resp = requests.post(
            f"{hub_url.rstrip('/')}/api/hub/heartbeat",
            json=payload, timeout=10,
            headers={"X-Hub-Token": token, "ngrok-skip-browser-warning": "true"},
        )
    except Exception as e:
        with _state_lock:
            _state["last_error"] = f"connection error: {e}"
        log.debug(f"Hub heartbeat failed (connection): {e}")
        return False

    if resp.status_code == 200:
        with _state_lock:
            _state["status"] = "approved"
            _state["last_error"] = None
        return True

    try:
        data = resp.json()
    except Exception:
        data = {}
    with _state_lock:
        if data.get("status"):
            _state["status"] = data["status"]
        _state["last_error"] = data.get("error", f"HTTP {resp.status_code}")
    log.debug(f"Hub heartbeat not accepted: {_state['last_error']}")
    return False


# ============================================================
# SENTRYUSB MESSENGER  (outbound-only Lab -> Hub transport)
# ============================================================

def sync_messenger_messages(config, db_module) -> dict:
    """Pull the lab's conversation from the Hub and refresh the local cache.
    The Lab initiates every network call, which works cleanly behind NAT and
    does not turn the Hub into a remote-control service."""
    eff = get_effective_config(config, db_module)
    hub_url = _normalise_url(eff.HUB_URL)
    with _state_lock:
        token, status = _state.get("hub_token"), _state.get("status")
    if not token or status != "approved":
        return {"success": False, "error": "This lab is not connected to an approved Hub."}
    try:
        resp = requests.get(
            f"{hub_url.rstrip('/')}/api/hub/messenger/messages",
            timeout=10,
            headers={"X-Hub-Token": token, "ngrok-skip-browser-warning": "true"},
        )
        if resp.status_code != 200:
            return {"success": False, "error": f"Hub returned HTTP {resp.status_code}"}
        messages = (resp.json() or {}).get("messages", [])
        for message in messages:
            required = {"message_id", "direction", "sender", "body", "created_at"}
            if required.issubset(message) and message.get("direction") in ("hub_to_lab", "lab_to_hub"):
                db_module.upsert_messenger_message(message)
        return {"success": True, "messages": db_module.get_messenger_messages()}
    except Exception as e:
        log.debug("Messenger sync failed: %s", e)
        return {"success": False, "error": f"Could not reach Hub: {e}",
                "messages": db_module.get_messenger_messages()}


def _hub_auth(config, db_module):
    """Return (base_url, headers) for an approved lab, or (None, error_message)."""
    eff = get_effective_config(config, db_module)
    hub_url = _normalise_url(eff.HUB_URL)
    with _state_lock:
        token, status = _state.get("hub_token"), _state.get("status")
    if not token or status != "approved":
        return None, "This lab is not connected to an approved Hub."
    return hub_url.rstrip("/"), {"X-Hub-Token": token, "ngrok-skip-browser-warning": "true"}


def send_messenger_message(config, db_module, body: str, severity: str, sender: str,
                           kind: str = "text", file_bytes: bytes = None, filename: str = "",
                           duration=None) -> dict:
    """Relay a human lab-admin message (text / image / voice note / call log)
    to the Hub and cache its receipt."""
    base, headers = _hub_auth(config, db_module)
    if not base:
        return {"success": False, "error": headers}
    fields = {"message_id": "msg_" + uuid.uuid4().hex, "body": body, "severity": severity,
              "sender": sender, "kind": kind}
    try:
        if file_bytes is not None:
            if duration is not None:
                fields["duration"] = str(duration)
            resp = requests.post(f"{base}/api/hub/messenger/messages", data=fields, timeout=30, headers=headers,
                                 files={"file": (filename or "attachment", file_bytes)})
        else:
            resp = requests.post(f"{base}/api/hub/messenger/messages", json=fields, timeout=10, headers=headers)
        data = resp.json() if resp.content else {}
        if resp.status_code not in (200, 201):
            return {"success": False, "error": data.get("error", f"Hub returned HTTP {resp.status_code}")}
        message = data.get("message")
        if message:
            db_module.upsert_messenger_message(message)
        return {"success": True, "message": message}
    except Exception as e:
        log.debug("Messenger send failed: %s", e)
        return {"success": False, "error": f"Could not reach Hub: {e}"}


def fetch_messenger_media(config, db_module, media_id: str, range_header: str = ""):
    """Stream an attachment from the Hub for the lab browser. Returns the
    upstream `requests` response (stream=True) or None."""
    base, headers = _hub_auth(config, db_module)
    if not base:
        return None
    if range_header:
        headers = dict(headers, Range=range_header)
    try:
        return requests.get(f"{base}/api/hub/messenger/media/{media_id}", headers=headers,
                            timeout=20, stream=True)
    except Exception as e:
        log.debug("Messenger media fetch failed: %s", e)
        return None


def get_ice_servers(config, db_module) -> list:
    base, headers = _hub_auth(config, db_module)
    if not base:
        return [{"urls": ["stun:stun.l.google.com:19302"]}]
    try:
        resp = requests.get(f"{base}/api/hub/messenger/ice", headers=headers, timeout=8)
        if resp.status_code == 200:
            return (resp.json() or {}).get("iceServers") or []
    except Exception as e:
        log.debug("ICE config fetch failed: %s", e)
    return [{"urls": ["stun:stun.l.google.com:19302"]}]


# ---- Call signalling -------------------------------------------------------
# One background puller keeps a rolling local copy of the Hub's call signals,
# so any number of open browser tabs poll *this server* cheaply while only one
# outbound request per second ever goes to the Hub (and none when nobody is
# looking at a page).
_signals = []            # [{seq, call_id, kind, payload, created_at}]
_signals_lock = threading.Lock()
_signal_cursor = {"seq": None, "last_request": 0.0, "running": False}


def send_signal(config, db_module, call_id: str, kind: str, payload: dict) -> dict:
    base, headers = _hub_auth(config, db_module)
    if not base:
        return {"success": False, "error": headers}
    try:
        resp = requests.post(f"{base}/api/hub/messenger/signal", timeout=8, headers=headers,
                             json={"call_id": call_id, "kind": kind, "payload": payload})
        data = resp.json() if resp.content else {}
        if resp.status_code != 200:
            return {"success": False, "error": data.get("error", f"Hub returned HTTP {resp.status_code}")}
        return {"success": True}
    except Exception as e:
        return {"success": False, "error": f"Could not reach Hub: {e}"}


def _signal_pull_loop(config, db_module):
    while time.time() - _signal_cursor["last_request"] < 45:          # stop when nobody is polling
        base, headers = _hub_auth(config, db_module)
        if base:
            try:
                after = _signal_cursor["seq"] if _signal_cursor["seq"] is not None else -1
                resp = requests.get(f"{base}/api/hub/messenger/signals", params={"after": after},
                                    headers=headers, timeout=8)
                if resp.status_code == 200:
                    data = resp.json() or {}
                    with _signals_lock:
                        for sig in data.get("signals", []):
                            _signals.append(sig)
                        del _signals[:-300]
                    _signal_cursor["seq"] = data.get("latest", after)
            except Exception as e:
                log.debug("Signal pull failed: %s", e)
        time.sleep(1.0)
    _signal_cursor["running"] = False


def get_signals(config, db_module, after: int) -> dict:
    """Signals from the Hub newer than `after` (after=-1 -> just the cursor)."""
    _signal_cursor["last_request"] = time.time()
    if not _signal_cursor["running"]:
        _signal_cursor["running"] = True
        _signal_cursor["seq"] = None          # restart from "now" - never replay stale invites
        threading.Thread(target=_signal_pull_loop, args=(config, db_module), daemon=True, name="hub-signals").start()
    with _signals_lock:
        latest = _signal_cursor["seq"] or 0
        if after < 0:
            return {"signals": [], "latest": latest}
        return {"signals": [s for s in _signals if s["seq"] > after], "latest": latest}


def acknowledge_messenger_read(config, db_module) -> bool:
    """Tell the Hub that the lab admin has opened incoming messages."""
    eff = get_effective_config(config, db_module)
    hub_url = _normalise_url(eff.HUB_URL)
    with _state_lock:
        token, status = _state.get("hub_token"), _state.get("status")
    if not token or status != "approved":
        return False
    try:
        resp = requests.post(
            f"{hub_url.rstrip('/')}/api/hub/messenger/read", timeout=8,
            headers={"X-Hub-Token": token, "ngrok-skip-browser-warning": "true"},
        )
        if resp.status_code == 200:
            db_module.mark_messenger_read("hub_to_lab")
            return True
    except Exception as e:
        log.debug("Messenger read acknowledgement failed: %s", e)
    return False


def _run_loop(config, db_module):
    _load_cache()
    # Every tick re-resolves overrides from the Lab Registration UI on top of
    # config.py, so a save from the dashboard is picked up without a restart.
    eff = get_effective_config(config, db_module)
    # Do a one-time health check at start to give immediate feedback
    _check_hub_health(eff)

    while True:
        eff = get_effective_config(config, db_module)

        with _state_lock:
            have_identity = bool(_state["lab_id"] and _state["hub_token"])
            status = _state["status"]

        if not have_identity or status in (None, "pending"):
            ok = _register(eff)
            with _state_lock:
                status = _state["status"]
            if not ok or status == "pending":
                time.sleep(eff.HUB_REGISTER_RETRY_INTERVAL)
                continue

        if status == "approved":
            _heartbeat(eff, db_module)
            time.sleep(eff.HUB_HEARTBEAT_INTERVAL)
        elif status in ("revoked", "rejected"):
            # Back off and just keep checking in case an admin re-approves later.
            time.sleep(eff.HUB_REGISTER_RETRY_INTERVAL)
        else:
            time.sleep(eff.HUB_REGISTER_RETRY_INTERVAL)


def start(config, db_module):
    """Start the background hub-connectivity thread. Idempotent and
    completely optional - if config.HUB_ENABLED is false this is a no-op,
    and any failure here is caught so it can never prevent the lab server
    itself from starting."""
    global _started
    if _started:
        return
    if not getattr(config, "HUB_ENABLED", False):
        log.info("SentryUSB Hub integration disabled (HUB_ENABLED=false)")
        return
    try:
        t = threading.Thread(target=_run_loop, args=(config, db_module), daemon=True, name="hub-client")
        t.start()
        _started = True
        log.info(f"SentryUSB Hub integration started -> {config.HUB_URL}")
    except Exception as e:
        log.error(f"Failed to start hub client thread: {e}")
