"""Bounded file inspection and conservative CDR helpers.

The routines below are review aids, not a claim that steganography or malware
can be proved from one heuristic. CDR only reconstructs safe ZIP-based Office
documents by removing active parts; unsupported formats are left untouched.
"""
import hashlib
import math
import os
import shutil
import struct
import uuid
import zipfile
from collections import Counter


MAX_UPLOAD_BYTES = 50 * 1024 * 1024
ACTIVE_OFFICE_MARKERS = ("vbaproject.bin", "embeddings/", "activex/", "customui/")


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def entropy(path, max_bytes=2 * 1024 * 1024):
    counts, total = Counter(), 0
    with open(path, "rb") as stream:
        while total < max_bytes:
            block = stream.read(min(65536, max_bytes - total))
            if not block:
                break
            counts.update(block)
            total += len(block)
    if not total:
        return 0.0
    return -sum((count / total) * math.log2(count / total) for count in counts.values())


def inspect_file(path):
    size = os.path.getsize(path)
    if size > MAX_UPLOAD_BYTES:
        raise ValueError("File exceeds the 50 MiB inspection limit")
    filename = os.path.basename(path)
    with open(path, "rb") as stream:
        magic = stream.read(16)
    extension = os.path.splitext(filename)[1].lower()
    mime_hint = "unknown"
    if magic.startswith(b"MZ"):
        mime_hint = "pe_executable"
    elif magic.startswith(b"PK\\x03\\x04"):
        mime_hint = "zip_container"
    elif magic.startswith(b"%PDF-"):
        mime_hint = "pdf"
    elif magic.startswith(b"\\x89PNG"):
        mime_hint = "png"
    elif magic.startswith(b"\\xff\\xd8\\xff"):
        mime_hint = "jpeg"
    suspicious = []
    if extension in {".jpg", ".jpeg", ".png", ".gif", ".mp3", ".mp4", ".wav"} and mime_hint in {"pe_executable", "zip_container", "pdf"}:
        suspicious.append("extension_magic_mismatch")
    value = entropy(path)
    if value > 7.95 and extension in {".jpg", ".jpeg", ".png", ".wav", ".mp3", ".mp4"}:
        suspicious.append("high_entropy_media_review")
    if mime_hint == "pe_executable" and extension not in {".exe", ".dll", ".sys", ".scr"}:
        suspicious.append("embedded_or_renamed_executable")
    return {"filename": filename, "size": size, "sha256": sha256_file(path), "mime_hint": mime_hint,
            "entropy": round(value, 4), "risk": "suspicious" if suspicious else "no_heuristic_finding", "signals": suspicious}


def cdr_reconstruct(source_path, output_dir):
    """Remove active content from a ZIP-based Office document, otherwise copy unchanged."""
    os.makedirs(output_dir, exist_ok=True)
    filename = os.path.basename(source_path)
    stem, ext = os.path.splitext(filename)
    output_path = os.path.join(output_dir, "%s_cdr_%s%s" % (stem, uuid.uuid4().hex[:8], ext))
    removed = []
    if not zipfile.is_zipfile(source_path):
        shutil.copy2(source_path, output_path)
        return {"path": output_path, "modified": False, "removed": removed, "note": "Unsupported format copied unchanged"}
    with zipfile.ZipFile(source_path, "r") as input_zip, zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as output_zip:
        for member in input_zip.infolist():
            normalized = member.filename.replace("\\\\", "/").lower()
            if normalized.startswith("/") or ".." in normalized.split("/"):
                removed.append(member.filename + " (unsafe path)")
                continue
            if any(marker in normalized for marker in ACTIVE_OFFICE_MARKERS):
                removed.append(member.filename)
                continue
            output_zip.writestr(member, input_zip.read(member.filename))
    return {"path": output_path, "modified": bool(removed), "removed": removed, "note": "ZIP-based active components removed" if removed else "No removable active components found"}
