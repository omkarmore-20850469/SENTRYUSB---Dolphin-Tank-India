"""
SentryUSB Server - Configuration
Change these before real deployment.
"""
import os


SECRET_KEY = os.environ.get("SENTRYUSB_SECRET_KEY", "change-me-secret-key")

ADMIN_USERNAME = os.environ.get("SENTRYUSB_ADMIN_USER", "admin")
ADMIN_PASSWORD = os.environ.get("SENTRYUSB_ADMIN_PASSWORD", "change-me-admin-pass")

# Must match AUTH_TOKEN in agent/config.py on every lab PC
AGENT_AUTH_TOKEN = os.environ.get("SENTRYUSB_AGENT_TOKEN", "sentryusb-token-2024")

# ===== BACKUP TOKEN - If primary fails, try this =====
BACKUP_AGENT_TOKEN = os.environ.get("SENTRYUSB_BACKUP_AGENT_TOKEN", "sentryusb-backup-token-2024")

# ===== AUTO-SYNC TOKEN =====
# When true, agents can auto-sync their token from server
AUTO_SYNC_TOKEN_ENABLED = os.environ.get("SENTRYUSB_AUTO_SYNC_TOKEN", "true").lower() == "true"

PORT = int(os.environ.get("SENTRYUSB_PORT", "5000"))

# ========== EMAIL CONFIGURATION ==========
EMAIL_ENABLED = os.environ.get("SENTRYUSB_EMAIL_ENABLED", "false").lower() == "true"
EMAIL_HOST = os.environ.get("SENTRYUSB_EMAIL_HOST", "smtp.gmail.com")
EMAIL_PORT = int(os.environ.get("SENTRYUSB_EMAIL_PORT", "587"))
EMAIL_USE_TLS = os.environ.get("SENTRYUSB_EMAIL_USE_TLS", "true").lower() == "true"
EMAIL_USERNAME = os.environ.get("SENTRYUSB_EMAIL_USERNAME", "your-email@gmail.com")
EMAIL_PASSWORD = os.environ.get("SENTRYUSB_EMAIL_PASSWORD", "your-app-password")
EMAIL_FROM = os.environ.get("SENTRYUSB_EMAIL_FROM", "alerts@sentryusb.com")
EMAIL_TO = os.environ.get("SENTRYUSB_EMAIL_TO", "admin@company.com")

# ========== TELEGRAM CONFIGURATION ==========
TELEGRAM_ENABLED = os.environ.get("SENTRYUSB_TELEGRAM_ENABLED", "false").lower() == "true"
TELEGRAM_BOT_TOKEN = os.environ.get("SENTRYUSB_TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.environ.get("SENTRYUSB_TELEGRAM_CHAT_ID", "")

# ========== SLACK CONFIGURATION ==========
SLACK_ENABLED = os.environ.get("SENTRYUSB_SLACK_ENABLED", "false").lower() == "true"
SLACK_WEBHOOK_URL = os.environ.get("SENTRYUSB_SLACK_WEBHOOK_URL", "")

# ========== DISCORD CONFIGURATION ==========
DISCORD_ENABLED = os.environ.get("SENTRYUSB_DISCORD_ENABLED", "false").lower() == "true"
DISCORD_WEBHOOK_URL = os.environ.get("SENTRYUSB_DISCORD_WEBHOOK_URL", "")

# ========== ALERT RULES ==========
ALERT_ON_BLOCKED = os.environ.get("SENTRYUSB_ALERT_ON_BLOCKED", "true").lower() == "true"
ALERT_ON_ALLOWED = os.environ.get("SENTRYUSB_ALERT_ON_ALLOWED", "true").lower() == "true"
ALERT_ON_CONNECTED = os.environ.get("SENTRYUSB_ALERT_ON_CONNECTED", "false").lower() == "true"
ALERT_ON_REMOVED = os.environ.get("SENTRYUSB_ALERT_ON_REMOVED", "false").lower() == "true"
ALERT_ON_OVERRIDDEN = os.environ.get("SENTRYUSB_ALERT_ON_OVERRIDDEN", "true").lower() == "true"
ALERT_ON_RDP_DETECTED = os.environ.get("SENTRYUSB_ALERT_ON_RDP_DETECTED", "true").lower() == "true"
ALERT_COOLDOWN_SECONDS = int(os.environ.get("SENTRYUSB_ALERT_COOLDOWN", "300"))

# ========== IP WHITELISTING ==========
IP_WHITELIST_ENABLED = os.environ.get("SENTRYUSB_IP_WHITELIST_ENABLED", "false").lower() == "true"

# ========== LDAP CONFIGURATION ==========
LDAP_ENABLED = os.environ.get("SENTRYUSB_LDAP_ENABLED", "false").lower() == "true"
LDAP_SERVER = os.environ.get("SENTRYUSB_LDAP_SERVER", "ldap://localhost:389")
LDAP_BASE_DN = os.environ.get("SENTRYUSB_LDAP_BASE_DN", "dc=example,dc=com")
LDAP_BIND_DN = os.environ.get("SENTRYUSB_LDAP_BIND_DN", "")
LDAP_BIND_PASSWORD = os.environ.get("SENTRYUSB_LDAP_BIND_PASSWORD", "")
LDAP_USE_TLS = os.environ.get("SENTRYUSB_LDAP_USE_TLS", "false").lower() == "true"
LDAP_USER_ATTRIBUTE = os.environ.get("SENTRYUSB_LDAP_USER_ATTRIBUTE", "sAMAccountName")

# ========== 🔒 LOCKDOWN MODE (SERVER) ==========
LOCKDOWN_ENABLED = os.environ.get("SENTRYUSB_LOCKDOWN_ENABLED", "false").lower() == "true"
LOCKDOWN_BLOCK_USB = os.environ.get("SENTRYUSB_LOCKDOWN_BLOCK_USB", "false").lower() == "true"
LOCKDOWN_BLOCK_BROWSERS = os.environ.get("SENTRYUSB_LOCKDOWN_BLOCK_BROWSERS", "false").lower() == "true"
LOCKDOWN_BLOCK_INTERNET = os.environ.get("SENTRYUSB_LOCKDOWN_BLOCK_INTERNET", "false").lower() == "true"
LOCKDOWN_BLOCK_COPY_PASTE = os.environ.get("SENTRYUSB_LOCKDOWN_BLOCK_COPY_PASTE", "false").lower() == "true"
LOCKDOWN_BLOCK_PRINT_SCREEN = os.environ.get("SENTRYUSB_LOCKDOWN_BLOCK_PRINT_SCREEN", "false").lower() == "true"
LOCKDOWN_ALLOWED_USB_DEVICES = os.environ.get("SENTRYUSB_ALLOWED_USB_DEVICES", "").split(",")
LOCKDOWN_ALLOWED_WEBSITES = os.environ.get("SENTRYUSB_ALLOWED_WEBSITES", "").split(",")
LOCKDOWN_EXEMPT_PCS = os.environ.get("SENTRYUSB_EXEMPT_PCS", "").split(",")

# ========== 🛡️ RATE LIMITING ==========
LOGIN_MAX_ATTEMPTS = int(os.environ.get("SENTRYUSB_LOGIN_MAX_ATTEMPTS", "5"))
LOGIN_LOCKOUT_SECONDS = int(os.environ.get("SENTRYUSB_LOGIN_LOCKOUT_SECONDS", "300"))

# ========== 📊 DEVICE CACHE ==========
DEVICE_CACHE_ENABLED = os.environ.get("SENTRYUSB_DEVICE_CACHE_ENABLED", "true").lower() == "true"
DEVICE_CACHE_TTL = int(os.environ.get("SENTRYUSB_DEVICE_CACHE_TTL", "30"))

# ========== 🌐 CORS SETTINGS ==========
CORS_ALLOWED_ORIGINS = os.environ.get("SENTRYUSB_CORS_ALLOWED_ORIGINS", "*").split(",")

# ========== AI CONFIGURATION ==========
AI_ENABLED = os.environ.get("SENTRYUSB_AI_ENABLED", "true").lower() == "true"
AI_MODEL_PATH = os.environ.get("SENTRYUSB_AI_MODEL_PATH", "ai_models/")
AI_ANOMALY_THRESHOLD = float(os.environ.get("SENTRYUSB_AI_ANOMALY_THRESHOLD", "0.7"))
AI_AUTO_TRAIN = os.environ.get("SENTRYUSB_AI_AUTO_TRAIN", "true").lower() == "true"
AI_TRAIN_INTERVAL_HOURS = int(os.environ.get("SENTRYUSB_AI_TRAIN_INTERVAL", "24"))
AI_PREDICTION_WINDOW = int(os.environ.get("SENTRYUSB_AI_PREDICTION_WINDOW", "1000"))
AI_MIN_SAMPLES_FOR_PREDICTION = int(os.environ.get("SENTRYUSB_AI_MIN_SAMPLES", "50"))

# ========== AI CHAT ASSISTANT ==========
# Local mode answers from the live DB + AI subsystem only, no external calls.
# Set AI_CHAT_USE_ANTHROPIC=true and provide an API key to let the assistant
# fall back to a real Claude call for open-ended questions it can't answer
# locally. If that call fails for any reason, it silently falls back to the
# local answer engine so the chat never just breaks.
AI_CHAT_USE_ANTHROPIC = os.environ.get("SENTRYUSB_AI_CHAT_USE_ANTHROPIC", "false").lower() == "true"
AI_CHAT_ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
AI_CHAT_ANTHROPIC_MODEL = os.environ.get("SENTRYUSB_AI_CHAT_MODEL", "claude-sonnet-4-6")
AI_CHAT_MAX_HISTORY = int(os.environ.get("SENTRYUSB_AI_CHAT_MAX_HISTORY", "12"))

# ========== REAL-TIME ANOMALY ALERTS ==========
# Anomaly score (0-100) at/above which a live "ai_alert" socket event is
# broadcast to every connected dashboard client as soon as it's computed.
AI_LIVE_ALERT_THRESHOLD = int(os.environ.get("SENTRYUSB_AI_LIVE_ALERT_THRESHOLD", "50"))


# ========== 🌐 REMOTE ACCESS (ngrok) ==========

# The public URL of your server (set this to your ngrok HTTPS URL)
PUBLIC_URL = os.environ.get("SENTRYUSB_PUBLIC_URL", "https://outfit-favorable-scribing.ngrok-free.dev")
# When true, session cookies get the Secure flag (requires HTTPS)
REMOTE_ACCESS_ENABLED = os.environ.get("SENTRYUSB_REMOTE_ACCESS_ENABLED", "true").lower() == "true"

# ========== 🏢 SENTRYUSB HUB (Tier 1 - centralized admin) ==========
# This is the connection from THIS lab server up to the central SentryUSB
# Hub. It is completely separate from the agent<->server ngrok tunnel below
# this server. The lab server is an outbound HTTPS client to the hub - no
# tunnel needed on this side, which is what lets one hub sit behind a single
# stable URL while any number of labs (each behind their own NAT) reach it.
HUB_ENABLED = True
# Public URL of the SentryUSB Hub, e.g. https://hub.yourorg.com or the hub's
# own ngrok URL. Defaults to the hub's own default port (6800, see
# hub/hub_config.py -> PORT) — override with SENTRYUSB_HUB_URL if your hub
# runs elsewhere (different host, port, or behind ngrok/a real domain).
HUB_URL = os.environ.get("SENTRYUSB_HUB_URL", "http://localhost:6800")

# Human-readable name for this lab, shown on the hub dashboard. Also used to
# match re-registrations if the local hub_registration.json cache is lost.
HUB_LAB_NAME = os.environ.get("SENTRYUSB_HUB_LAB_NAME", "Unnamed Lab")

# Must match hub/hub_config.py -> REGISTRATION_SECRET on the hub. This is a
# shared bootstrap secret (not the per-lab token) that just stops random
# servers from self-registering into your hub.
HUB_REGISTRATION_SECRET = os.environ.get("SENTRYUSB_HUB_REGISTRATION_SECRET", "change-me-registration-secret")

HUB_CONTACT_EMAIL = os.environ.get("SENTRYUSB_HUB_CONTACT_EMAIL", "")
HUB_LOCATION = os.environ.get("SENTRYUSB_HUB_LOCATION", "")

# How often (seconds) this lab server sends a heartbeat + stats snapshot to
# the hub once approved.
HUB_HEARTBEAT_INTERVAL = int(os.environ.get("SENTRYUSB_HUB_HEARTBEAT_INTERVAL", "30"))
# How often (seconds) this lab server retries registration while it has no
# lab_id/token yet, or while it's still "pending" hub-admin approval.
HUB_REGISTER_RETRY_INTERVAL = int(os.environ.get("SENTRYUSB_HUB_REGISTER_RETRY", "60"))

SERVER_VERSION = os.environ.get("SENTRYUSB_SERVER_VERSION", "2.0")

# ========== V10 ZERO-TRUST / FORENSICS / INTEGRATIONS ==========
# All high-impact features are opt-in. Configure unique secrets before enabling
# them; the defaults preserve existing v9 behaviour.
DEVICE_POLICY_DEFAULT_ACTION = os.environ.get("SENTRYUSB_DEVICE_POLICY_DEFAULT", "monitor")
EVIDENCE_HMAC_KEY = os.environ.get("SENTRYUSB_EVIDENCE_HMAC_KEY", "")
AUTO_INCIDENT_CAPTURE = os.environ.get("SENTRYUSB_AUTO_INCIDENT_CAPTURE", "false").lower() == "true"
INCIDENT_CAPTURE_MIN_RISK = int(os.environ.get("SENTRYUSB_INCIDENT_CAPTURE_MIN_RISK", "80"))
CONTENT_UPLOAD_MAX_MB = int(os.environ.get("SENTRYUSB_CONTENT_UPLOAD_MAX_MB", "50"))
SIEM_SYSLOG_HOST = os.environ.get("SENTRYUSB_SIEM_SYSLOG_HOST", "")
SIEM_SYSLOG_PORT = int(os.environ.get("SENTRYUSB_SIEM_SYSLOG_PORT", "514"))
SIEM_SYSLOG_TCP = os.environ.get("SENTRYUSB_SIEM_SYSLOG_TCP", "false").lower() == "true"
PEER_SYNC_ENABLED = os.environ.get("SENTRYUSB_PEER_SYNC_ENABLED", "false").lower() == "true"

# Enterprise notifications
SENTRYUSB_TEAMS_WEBHOOK_URL = os.environ.get("SENTRYUSB_TEAMS_WEBHOOK_URL", "")
SENTRYUSB_WEBHOOK_URL = os.environ.get("SENTRYUSB_WEBHOOK_URL", "")
SENTRYUSB_PROACTIVE_AI_INTERVAL = int(os.environ.get("SENTRYUSB_PROACTIVE_AI_INTERVAL", "60"))
POLICY_AUTO_APPROVE = False  # v20: require server approval in Policy Studio
