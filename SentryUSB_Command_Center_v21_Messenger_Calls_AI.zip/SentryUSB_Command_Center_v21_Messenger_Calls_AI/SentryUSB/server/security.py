"""
SentryUSB - Security Module
Handles 2FA, session management, IP whitelisting, and LDAP authentication
"""
import logging
import datetime
import base64
from datetime import timedelta
from functools import wraps
from io import BytesIO

try:
    import pyotp
    PYOTP_AVAILABLE = True
except ImportError:
    PYOTP_AVAILABLE = False
    print("⚠️ pyotp not installed. 2FA features disabled.")

try:
    import qrcode
    QRCODE_AVAILABLE = True
except ImportError:
    QRCODE_AVAILABLE = False
    print("⚠️ qrcode not installed. QR code features disabled.")

from flask import request, jsonify

import config
import db

log = logging.getLogger("sentryusb.security")


# ============================================================
# TWO-FACTOR AUTHENTICATION (2FA)
# ============================================================

def generate_2fa_secret(username: str) -> str:
    """Generate a new 2FA secret for a user"""
    if not PYOTP_AVAILABLE:
        log.error("pyotp not available")
        return ""
    
    secret = pyotp.random_base32()
    
    conn = db.get_connection()
    cur = conn.cursor()
    now = datetime.datetime.utcnow().isoformat()
    
    cur.execute("""
        INSERT OR REPLACE INTO user_2fa (username, secret, enabled, created_at)
        VALUES (?, ?, ?, ?)
    """, (username, secret, 0, now))
    conn.commit()
    conn.close()
    
    return secret


def get_2fa_secret(username: str) -> str:
    """Get the 2FA secret for a user"""
    conn = db.get_connection()
    cur = conn.cursor()
    cur.execute("SELECT secret FROM user_2fa WHERE username = ?", (username,))
    row = cur.fetchone()
    conn.close()
    return row["secret"] if row else None


def enable_2fa(username: str) -> bool:
    """Enable 2FA for a user"""
    conn = db.get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE user_2fa SET enabled = 1 WHERE username = ?", (username,))
    conn.commit()
    conn.close()
    return True


def disable_2fa(username: str) -> bool:
    """Disable 2FA for a user"""
    conn = db.get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE user_2fa SET enabled = 0 WHERE username = ?", (username,))
    conn.commit()
    conn.close()
    return True


def is_2fa_enabled(username: str) -> bool:
    """Check if 2FA is enabled for a user"""
    if not PYOTP_AVAILABLE:
        return False
    conn = db.get_connection()
    cur = conn.cursor()
    cur.execute("SELECT enabled FROM user_2fa WHERE username = ?", (username,))
    row = cur.fetchone()
    conn.close()
    return bool(row["enabled"]) if row else False


def verify_2fa_code(username: str, code: str) -> bool:
    """Verify a 2FA code"""
    if not PYOTP_AVAILABLE:
        return False
    secret = get_2fa_secret(username)
    if not secret:
        return False
    
    totp = pyotp.TOTP(secret)
    return totp.verify(code)


def get_2fa_qr_code(username: str) -> str:
    """Generate a QR code for 2FA setup"""
    if not PYOTP_AVAILABLE or not QRCODE_AVAILABLE:
        return ""
    
    secret = get_2fa_secret(username)
    if not secret:
        secret = generate_2fa_secret(username)
    
    totp = pyotp.TOTP(secret)
    provisioning_uri = totp.provisioning_uri(name=username, issuer_name="SentryUSB")
    
    qr = qrcode.QRCode(version=1, box_size=10, border=5)
    qr.add_data(provisioning_uri)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    buffered = BytesIO()
    img.save(buffered, format="PNG")
    img_str = base64.b64encode(buffered.getvalue()).decode()
    
    return img_str


# ============================================================
# SESSION MANAGEMENT
# ============================================================

def create_session(username: str) -> str:
    """Create a new session for a user"""
    import uuid
    
    session_id = str(uuid.uuid4())
    now = datetime.datetime.utcnow().isoformat()
    expires_at = (datetime.datetime.utcnow() + timedelta(hours=8)).isoformat()
    
    conn = db.get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO user_sessions (username, session_id, ip_address, user_agent, created_at, last_active, expires_at, is_active)
        VALUES (?, ?, ?, ?, ?, ?, ?, 1)
    """, (
        username,
        session_id,
        request.remote_addr if hasattr(request, 'remote_addr') else "unknown",
        request.headers.get("User-Agent", "") if hasattr(request, 'headers') else "",
        now,
        now,
        expires_at
    ))
    conn.commit()
    conn.close()
    
    return session_id


def update_session_activity(session_id: str):
    """Update last active time for a session"""
    if not session_id:
        return
    conn = db.get_connection()
    cur = conn.cursor()
    now = datetime.datetime.utcnow().isoformat()
    cur.execute("""
        UPDATE user_sessions SET last_active = ? WHERE session_id = ?
    """, (now, session_id))
    conn.commit()
    conn.close()


def get_active_sessions(username: str) -> list:
    """Get all active sessions for a user"""
    conn = db.get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM user_sessions 
        WHERE username = ? AND is_active = 1 AND expires_at > datetime('now')
        ORDER BY last_active DESC
    """, (username,))
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def terminate_session(session_id: str) -> bool:
    """Terminate a specific session"""
    conn = db.get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE user_sessions SET is_active = 0 WHERE session_id = ?", (session_id,))
    conn.commit()
    conn.close()
    return True


def terminate_all_sessions(username: str, exclude_current: str = None):
    """Terminate all sessions for a user except current"""
    conn = db.get_connection()
    cur = conn.cursor()
    if exclude_current:
        cur.execute("""
            UPDATE user_sessions SET is_active = 0 
            WHERE username = ? AND session_id != ?
        """, (username, exclude_current))
    else:
        cur.execute("UPDATE user_sessions SET is_active = 0 WHERE username = ?", (username,))
    conn.commit()
    conn.close()


# ============================================================
# IP WHITELISTING
# ============================================================

def add_ip_to_whitelist(ip_address: str, description: str = None, added_by: str = None) -> bool:
    """Add an IP to the whitelist"""
    conn = db.get_connection()
    cur = conn.cursor()
    now = datetime.datetime.utcnow().isoformat()
    cur.execute("""
        INSERT OR REPLACE INTO ip_whitelist (ip_address, description, added_by, added_at, is_active)
        VALUES (?, ?, ?, ?, 1)
    """, (ip_address, description, added_by, now))
    conn.commit()
    conn.close()
    return True


def remove_ip_from_whitelist(ip_address: str) -> bool:
    """Remove an IP from the whitelist"""
    conn = db.get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM ip_whitelist WHERE ip_address = ?", (ip_address,))
    conn.commit()
    conn.close()
    return True


def is_ip_whitelisted(ip_address: str) -> bool:
    """Check if an IP is whitelisted"""
    conn = db.get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM ip_whitelist WHERE ip_address = ? AND is_active = 1", (ip_address,))
    row = cur.fetchone()
    conn.close()
    return bool(row)


def get_whitelist() -> list:
    """Get all whitelisted IPs"""
    conn = db.get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM ip_whitelist ORDER BY added_at DESC")
    rows = cur.fetchall()
    conn.close()
    return [dict(r) for r in rows]


def ip_whitelist_required(f):
    """Decorator to require IP whitelisting"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not config.IP_WHITELIST_ENABLED:
            return f(*args, **kwargs)
        
        client_ip = request.remote_addr
        if not is_ip_whitelisted(client_ip):
            log.warning(f"Blocked access from non-whitelisted IP: {client_ip}")
            return jsonify({"error": "Access denied. IP not whitelisted."}), 403
        return f(*args, **kwargs)
    return decorated_function


# ============================================================
# LDAP AUTHENTICATION
# ============================================================

def ldap_authenticate(username: str, password: str) -> bool:
    """Authenticate user against LDAP/Active Directory"""
    if not config.LDAP_ENABLED:
        return False
    
    try:
        import ldap
        
        conn = ldap.initialize(config.LDAP_SERVER)
        conn.set_option(ldap.OPT_REFERRALS, 0)
        
        if config.LDAP_USE_TLS:
            conn.start_tls_s()
        
        if config.LDAP_BIND_DN and config.LDAP_BIND_PASSWORD:
            conn.simple_bind_s(config.LDAP_BIND_DN, config.LDAP_BIND_PASSWORD)
        
        search_filter = f"(&(objectClass=user)(sAMAccountName={username}))"
        result = conn.search_s(
            config.LDAP_BASE_DN,
            ldap.SCOPE_SUBTREE,
            search_filter,
            ['dn']
        )
        
        if not result:
            return False
        
        user_dn = result[0][0]
        conn.simple_bind_s(user_dn, password)
        conn.unbind_s()
        
        return True
        
    except ImportError:
        log.warning("python-ldap not installed")
        return False
    except Exception as e:
        log.error(f"LDAP authentication failed for {username}: {e}")
        return False


def get_ldap_user_info(username: str) -> dict:
    """Get user info from LDAP"""
    if not config.LDAP_ENABLED:
        return {}
    
    try:
        import ldap
        
        conn = ldap.initialize(config.LDAP_SERVER)
        conn.set_option(ldap.OPT_REFERRALS, 0)
        
        if config.LDAP_USE_TLS:
            conn.start_tls_s()
        
        if config.LDAP_BIND_DN and config.LDAP_BIND_PASSWORD:
            conn.simple_bind_s(config.LDAP_BIND_DN, config.LDAP_BIND_PASSWORD)
        
        search_filter = f"(&(objectClass=user)(sAMAccountName={username}))"
        result = conn.search_s(
            config.LDAP_BASE_DN,
            ldap.SCOPE_SUBTREE,
            search_filter,
            ['displayName', 'mail', 'department', 'title']
        )
        
        conn.unbind_s()
        
        if result:
            attrs = result[0][1]
            return {
                'display_name': attrs.get('displayName', [b''])[0].decode() if attrs.get('displayName') else '',
                'email': attrs.get('mail', [b''])[0].decode() if attrs.get('mail') else '',
                'department': attrs.get('department', [b''])[0].decode() if attrs.get('department') else '',
                'title': attrs.get('title', [b''])[0].decode() if attrs.get('title') else '',
            }
        
    except ImportError:
        log.warning("python-ldap not installed")
    except Exception as e:
        log.error(f"Failed to get LDAP user info for {username}: {e}")
    
    return {}