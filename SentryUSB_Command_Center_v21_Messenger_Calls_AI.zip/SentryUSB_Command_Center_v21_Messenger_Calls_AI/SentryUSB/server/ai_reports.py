# server/ai_reports.py
"""
AI-powered report generation using NLP
Generates human-readable security summaries
"""
from datetime import datetime
import logging

log = logging.getLogger("sentryusb.ai_reports")

class AIReportGenerator:
    def __init__(self, use_local_llm=True):
        self.use_local_llm = use_local_llm
    
    def generate_summary(self, events, period="week"):
        """Generate a natural language summary of events"""
        
        # 1. Collect stats
        stats = self._calculate_stats(events, period)
        
        # 2. Detect significant events
        significant = self._detect_significant_events(events)
        
        # 3. Generate narrative
        return self._generate_narrative(stats, significant, period)
    
    def _calculate_stats(self, events, period):
        """Calculate statistics"""
        total = len(events)
        blocked = sum(1 for e in events if e.get('status') == 'blocked')
        allowed = sum(1 for e in events if e.get('status') == 'allowed')
        overridden = sum(1 for e in events if e.get('status') == 'overridden')
        connected = sum(1 for e in events if e.get('status') == 'connected')
        
        unique_devices = len(set(e.get('device_instance_id') for e in events if e.get('device_instance_id')))
        unique_hosts = len(set(e.get('hostname') for e in events if e.get('hostname')))
        
        # Device type distribution
        device_types = {}
        for e in events:
            dt = e.get('device_type', 'unknown')
            device_types[dt] = device_types.get(dt, 0) + 1
        
        return {
            'total': total,
            'blocked': blocked,
            'allowed': allowed,
            'overridden': overridden,
            'connected': connected,
            'block_rate': (blocked / total * 100) if total > 0 else 0,
            'unique_devices': unique_devices,
            'unique_hosts': unique_hosts,
            'period': period,
            'device_types': device_types
        }
    
    def _detect_significant_events(self, events):
        """Detect significant events for the report"""
        significant = []
        
        # Find devices with many blocks
        block_counts = {}
        for e in events:
            if e.get('status') == 'blocked':
                device = e.get('device_name', 'Unknown')
                block_counts[device] = block_counts.get(device, 0) + 1
        
        for device, count in block_counts.items():
            if count > 5:
                significant.append(f"Device '{device}' was blocked {count} times")
        
        # Find hosts with high activity
        host_counts = {}
        for e in events:
            host = e.get('hostname', 'Unknown')
            host_counts[host] = host_counts.get(host, 0) + 1
        
        for host, count in host_counts.items():
            if count > 20:
                significant.append(f"High activity on PC '{host}' ({count} events)")
        
        return significant[:10]  # Top 10 significant events
    
    def _generate_narrative(self, stats, significant, period):
        """Generate narrative report"""
        period_names = {
            'day': 'day',
            'week': 'week',
            'month': 'month',
            'year': 'year'
        }
        period_name = period_names.get(period, period)
        
        narrative = f"""
📊 **Security Summary ({period_name.capitalize()})**

Over the past {period_name}, the SentryUSB system monitored **{stats['total']}** USB device events across **{stats['unique_hosts']}** PCs.

**📈 Key Statistics:**
• 🚫 **{stats['blocked']}** devices were blocked ({stats['block_rate']:.1f}% of total)
• ✅ **{stats['allowed']}** devices were allowed
• ⚠️ **{stats['overridden']}** devices were manually overridden
• 🔌 **{stats['connected']}** devices were connected
• 💾 **{stats['unique_devices']}** unique devices were detected

**📊 Device Type Distribution:**
"""
        
        for device_type, count in stats['device_types'].items():
            percentage = (count / stats['total'] * 100) if stats['total'] > 0 else 0
            narrative += f"• {device_type.capitalize()}: {count} ({percentage:.1f}%)\n"
        
        if significant:
            narrative += """
            
**🔔 Notable Events:**
"""
            for item in significant:
                narrative += f"• {item}\n"
        
        # Recommendations
        narrative += f"""
            
**💡 Recommendations:**
{self._get_recommendation(stats)}
            
*Report generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*
"""
        return narrative
    
    def _get_recommendation(self, stats):
        """Generate recommendation based on stats"""
        if stats['block_rate'] > 80:
            return "🔴 **URGENT:** High block rate detected. Consider reviewing USB usage policies and investigating potential security threats."
        elif stats['block_rate'] > 50:
            return "🟡 **MODERATE:** Significant block rate. Monitor for unusual patterns and review device whitelist."
        elif stats['block_rate'] > 20:
            return "🟢 **NORMAL:** Typical activity detected. Continue monitoring."
        else:
            return "✅ **LOW RISK:** Normal activity detected. System is operating as expected."