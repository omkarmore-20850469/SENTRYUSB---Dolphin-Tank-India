# SentryUSB — v18 Expert 3D Simulation Upgrade

### v18 visual upgrade
- High-velocity telemetry pulse visualization with staggered endpoint shockwaves.
- Three-packet data-flow streams on hub/lab and agent/lab links.
- Live simulation HUD for pulse rate, active signals, and threat-vector state.
- Scanline, event-vignette and high-severity visual emphasis for incident bursts.
- Real security events remain event-driven; ambient pulses are visual telemetry only and do not create synthetic security records.

# SentryUSB — 3-Tier Multitenant System

> **v10 security upgrade:** This distribution adds a zero-trust device-policy
> API, HID/BadUSB risk telemetry, device-fingerprint change monitoring,
> adaptive block commands with acknowledgements, tamper-evident evidence
> chaining, aggregate-only behavioural-risk telemetry, content inspection/CDR,
> SIEM output and authenticated peer-event envelopes. See the v10 notes below
> before enabling any enforcement feature.

```
┌─────────────────┐   HTTPS (register / heartbeat)   ┌──────────────────┐   ngrok tunnel   ┌────────┐
│  SentryUSB HUB   │ <──────────────────────────────  │   Lab Server(s)   │ <──────────────  │ Agents │
│  (tier 1, one    │   Lab Server → Hub, outbound      │  (tier 2, one per  │  (tier 3, one     │ (tier 3,│
│  central admin)  │   only — no tunnel needed here    │  lab, unique URL   │  per lab, exists  │ Windows │
│                   │                                    │  + token)          │  already)          │ PCs)   │
└─────────────────┘                                    └──────────────────┘                   └────────┘
```

- **`hub/`** — the new centralized SentryUSB Hub admin (tier 1). Deploy this
  **once**, on its own machine/URL. It never talks to agents and never
  receives USB events — its only job is lab registration, approval, and
  lightweight health monitoring across every lab.
- **`server/`** — the existing per-lab Flask + Socket.IO server (tier 2),
  unchanged in behavior, with one addition: `hub_client.py`, which makes it
  register itself with the hub and send periodic heartbeats. Deploy **one
  copy of this per lab**, each with its own `config.py` (own DB, own
  `AGENT_AUTH_TOKEN`, own ngrok URL).
- **`agent/`** — the existing Windows lab-PC agent (tier 3), **completely
  unchanged**. It still talks only to its own lab server over the existing
  ngrok tunnel, exactly as before.

## The gap this closes

Previously there was no link between a central admin and however many
independent lab servers existed — each lab was an island with its own ngrok
URL and its own `AGENT_AUTH_TOKEN`, and nothing tied them together.

The hub closes that gap with a **registration + redirect** flow instead of
another layer of tunnels (which doesn't scale — you'd be managing N tunnels
terminating on one hub):

1. A lab server boots with `HUB_ENABLED=true` and no cached hub identity.
2. It calls `POST {HUB_URL}/api/hub/register` with its lab name, its own
   public URL (the same ngrok URL its agents already use), and a shared
   `HUB_REGISTRATION_SECRET`.
3. The hub creates a **pending** lab record, generates a unique `lab_id`
   (its folder/namespace) and a unique `hub_token`, and returns both. The
   lab server caches these in `server/hub_registration.json`.
4. A hub admin reviews pending labs at `/labs` and clicks **Approve**
   (or set `AUTO_APPROVE_LABS=true` on the hub to skip this step).
5. Once approved, the lab server sends a small heartbeat (agent count,
   event totals) to the hub every 30s using its `hub_token`.
6. The hub dashboard shows every lab, its live/offline state, and an
   **"Open Lab Dashboard →"** button that redirects straight to that lab's
   own unique server URL — this is the "redirect to that particular lab
   folder server" piece.

If a lab server restarts or its ngrok URL rotates, it re-registers with its
cached `lab_id`/`hub_token` and the hub just refreshes the URL — no
duplicate lab entries, no re-approval needed.

The existing agent↔server ngrok tunnel is untouched by any of this.

## 1. Deploy the Hub (once)

```
cd hub
pip install -r requirements.txt
```

Edit `hub/hub_config.py` (or set env vars) before real use:
- `HUB_ADMIN_USERNAME` / `HUB_ADMIN_PASSWORD` — hub dashboard login
- `REGISTRATION_SECRET` — shared bootstrap secret every lab server must send
- `SECRET_KEY`
- `AUTO_APPROVE_LABS` — `false` (recommended) means new labs sit pending
  until you approve them from `/labs`

```
python hub_app.py
```

Open `http://localhost:6000` (or your hub's ngrok/real URL) and log in.
Expose this with a stable URL (your own domain, or an ngrok tunnel just for
the hub) — lab servers point `HUB_URL` at it.

## 2. Deploy each Lab Server (one per lab)

Same as before (`cd server && pip install -r requirements.txt && python
app.py`), plus set these in `server/config.py` or via env vars:

```
SENTRYUSB_HUB_ENABLED=true
SENTRYUSB_HUB_URL=https://<your-hub-url>
SENTRYUSB_HUB_LAB_NAME=Computer Lab 3B
SENTRYUSB_HUB_REGISTRATION_SECRET=<same value as hub's REGISTRATION_SECRET>
SENTRYUSB_PUBLIC_URL=https://<this-lab's-ngrok-url>   # already used by agents
```

The lab server keeps running (and keeps serving agents) even if the hub is
unreachable — hub connectivity is a background, best-effort thread that
never blocks USB monitoring.

## 3. Deploy Agents (unchanged)

Exactly as documented in `README_SERVER_AGENT_ORIGINAL.md` — point each
agent's `SERVER_URL` at its own lab server's ngrok URL. Agents never talk to
the hub.

## Repository layout

```
SentryUSB/
├── hub/                          Tier 1 — centralized admin (NEW)
│   ├── hub_app.py                 Flask app: dashboard + register/heartbeat API
│   ├── hub_config.py              Hub settings
│   ├── hub_db.py                  SQLite: labs, hub admin users, audit log
│   ├── requirements.txt
│   ├── templates/
│   └── static/css/hub.css
├── server/                       Tier 2 — per-lab server (existing, +hub_client.py)
│   ├── app.py                     unchanged except a small optional hub hook at the bottom
│   ├── config.py                  + HUB_* settings appended
│   ├── hub_client.py               NEW — registers + heartbeats to the hub
│   └── ...                        (all original modules: db.py, security.py, ai_*, etc.)
├── agent/                        Tier 3 — Windows lab-PC agent (unchanged)
├── README_SERVER_AGENT_ORIGINAL.md   original server+agent-only README
└── CHANGELOG.md
```

## Security notes before real deployment

- Change `hub/hub_config.py`: `SECRET_KEY`, `HUB_ADMIN_PASSWORD`,
  `REGISTRATION_SECRET`.
- Change `server/config.py`: `AGENT_AUTH_TOKEN`, `ADMIN_PASSWORD`,
  `SECRET_KEY`, `HUB_REGISTRATION_SECRET` (must match the hub's).
- Keep `AUTO_APPROVE_LABS=false` on the hub for real deployments so a
  stranger who guesses your registration secret still can't get live data
  flowing without a human approving it.
- Put both the hub and every lab server behind HTTPS.

## v10 security upgrade

### Safe enablement order

1. Leave `SENTRYUSB_ZERO_TRUST_HID_MODE=monitor` during inventory and pilot.
   This is the default. Enroll every keyboard, mouse and accessibility device
   before considering `enforce`; a bad HID allow-list can lock out a PC.
2. Use `POST /api/v10/policies` to create centrally evaluated policies. A
   policy records an action (`allow`, `monitor`, `approval_required`, `block`),
   but only an agent acknowledgement confirms that a device was actually
   disabled. Set `SENTRYUSB_DEVICE_POLICY_DEFAULT=block` only after a staged
   deployment.
3. Set a unique `SENTRYUSB_EVIDENCE_HMAC_KEY`, then use
   `GET /api/v10/evidence/verify` to validate the evidence chain. The default
   development key must never be used for an evidentiary deployment.
4. Behavioural telemetry is disabled by default. If approved, set
   `SENTRYUSB_BEHAVIORAL_METRICS_ENABLED=true` and submit **aggregate timing
   values only** via the agent interface. SentryUSB does not collect raw keys,
   typed text, window titles or screen contents for this feature. Scores are
   review signals, not authentication or disciplinary decisions.
5. The content endpoints accept administrator-uploaded files only:
   `POST /api/v10/content/inspect` and `POST /api/v10/content/cdr` with a
   multipart `file` field. Inspection is bounded to 50 MiB by default; CDR
   conservatively removes active components from ZIP-based Office documents.
   It does not prove steganography detection or replace enterprise AV.

### Integration endpoints

- `GET /api/v10/siem/events?limit=200` exposes a stable JSON event envelope.
- Set `SENTRYUSB_SIEM_SYSLOG_HOST` (and optional port) for best-effort UDP
  syslog forwarding.
- Peer metadata replication is disabled until both
  `SENTRYUSB_PEER_SYNC_ENABLED=true` and `SENTRYUSB_PEER_SYNC_KEY` are set.
  `POST /api/v10/peer/events` requires a time-bounded HMAC signature and only
  accepts threat/health/policy notices; it cannot remotely execute actions.
- `SENTRYUSB_AUTO_INCIDENT_CAPTURE=true` writes a signed SentryUSB incident
  manifest for high-risk events. Full memory dumps and disk imaging are not
  performed by this application and should be delegated to approved endpoint
  forensic tooling under an explicit policy.

### Important limitations

The agent performs user-space PnP enforcement through supported Windows tools;
it is not a kernel driver. Fingerprint changes are PnP metadata changes, not a
firmware attestation. The included heuristics and aggregate behavioural scoring
have no claimed accuracy level and require local validation before use in any
automated decision.
