# SentryUSB

Real-time USB device monitoring for exam labs. Detects and blocks USB
mass-storage devices (pendrives), reports all USB activity (including
keyboards/mice as informational entries) to a live admin dashboard, and
tracks connect/remove timestamps with duration per device.

## Structure

```
SentryUSB/
├── server/     Flask + Socket.IO server, SQLite log, admin dashboard
└── agent/      Windows-only agent (WMI + pnputil), runs on each lab PC
```

## 1. Run the server (any OS)

```
cd server
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000 — log in with:
- Username: `admin`
- Password: `change-me-admin-pass`

**Change these in `server/config.py` before real deployment.**

## 2. Run the agent (Windows 10 1803+/11, elevated)

Open Command Prompt or PowerShell **as Administrator**:

```
cd agent
pip install -r requirements.txt
python agent.py
```

Before running, edit `agent/config.py`:
- `SERVER_URL` — the server machine's address (use its LAN IP for multi-PC
  deployment, e.g. `http://192.168.1.10:5000`; `127.0.0.1` only works if
  agent and server are on the same machine)
- `AUTH_TOKEN` — must match `AGENT_AUTH_TOKEN` in `server/config.py`

## What it does

- Plug in a USB pendrive → agent disables it instantly at the OS level,
  reports it to the server as `blocked`.
- Plug in a keyboard/mouse/other peripheral → agent reports it as
  `connected` (informational only, never blocked).
- Unplug any device → agent reports the removal; server calculates and
  stores the session duration.
- Dashboard shows live events, status/type charts, and an "Allow" button
  per blocked device (admin override → agent re-enables it).
- "Device Reports" page lists every unique device ever seen; click into
  one for its full connect/remove history and a duration-over-time chart.

## Before real deployment

- Change `AGENT_AUTH_TOKEN`, `ADMIN_USERNAME`/`ADMIN_PASSWORD`, and
  `SECRET_KEY` in `server/config.py`.
- Put the server behind HTTPS, and once it's on HTTPS set
  `SENTRYUSB_FORCE_HTTPS=true` so session cookies get the `Secure` flag —
  credentials/token still go over plain HTTP otherwise.
- Disclose this monitoring in your exam's written policy — the
  dashboard+override design assumes a human reviews every block.
- For packaging the agent as a single `.exe` and running it as an
  auto-start Windows service (no console window, survives reboot), build
  with PyInstaller (`pyinstaller --onefile --console --name agent agent.py`)
  and register it as a service using a tool like NSSM
  (https://nssm.cc/download).

See `CHANGELOG.md` for what changed in this revision (bug fixes, security
hardening, new features, and restyle/cleanup work).
