# SentryUSB v24 — offline exam persistence and call diagnostics

## Included
- Agent-local absolute exam deadline persisted atomically to `agent/runtime_state/exam_state.json`.
- On agent process restart, an active exam timer is recovered using the original deadline (remaining time is not reset).
- Append-only local JSONL audit journal and durable pending-event queue under `agent/runtime_state/`.
- Failed server notifications remain queued rather than being discarded. `OfflineExamRuntime.reconcile(sender)` is available for a future authenticated event-ID acknowledgement endpoint.
- Messenger now gives actionable browser-permission feedback when local media capture fails and distinguishes this from a user declining; temporary signalling errors are surfaced while retry continues.

## Validation / limits
- Python syntax and runtime unit tests were run on this package.
- JavaScript syntax checks were run for both messenger copies.
- This environment cannot verify actual microphone/camera permissions, NAT traversal, TURN availability, or calls between physical computers. Configure a TURN relay for networks where STUN alone cannot establish a peer connection.
- The queued audit events are durable locally, but server reconciliation is not end-to-end until the server accepts event IDs and acknowledges them. Events are deliberately retained until that protocol exists.
- A Python process cannot guarantee exam enforcement if the machine is powered off, the process is killed, or the OS is compromised. For high-stakes use, deploy a signed, visible, institution-managed agent/service and validate recovery on supported Windows builds. Provide an explicit exam policy notice and documented exit/recovery procedure.
