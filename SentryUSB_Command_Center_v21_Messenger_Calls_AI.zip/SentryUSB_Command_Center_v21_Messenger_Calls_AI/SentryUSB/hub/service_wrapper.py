"""
SentryUSB Hub - Windows Service Wrapper
Runs the hub behind waitress (production WSGI server) as a Windows service.
"""
import sys
import os
import threading
import win32serviceutil
import win32service
import win32event
import servicemanager

# Ensure we can import hub_app
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from hub_app import app
from waitress import serve

class SentryHubService(win32serviceutil.ServiceFramework):
    _svc_name_ = "SentryHub"
    _svc_display_name_ = "SentryUSB Hub"
    _svc_description_ = "Centralized lab management hub for SentryUSB"

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.stop_event = win32event.CreateEvent(None, 0, 0, None)
        self.server_thread = None

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.stop_event)
        if self.server_thread:
            self.server_thread.join(timeout=5)

    def SvcDoRun(self):
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, "")
        )
        import hub_config
        port = hub_config.PORT
        self.server_thread = threading.Thread(
            target=serve,
            args=(app,),
            kwargs={"host": "0.0.0.0", "port": port},
            daemon=True
        )
        self.server_thread.start()
        # Wait until stop
        win32event.WaitForSingleObject(self.stop_event, win32event.INFINITE)

if __name__ == "__main__":
    win32serviceutil.HandleCommandLine(SentryHubService)