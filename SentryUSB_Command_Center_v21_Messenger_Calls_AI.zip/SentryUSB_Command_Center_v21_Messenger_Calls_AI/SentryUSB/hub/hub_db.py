"""
SentryUSB HUB - Database layer
SQLite store for the centralized hub: lab registry, hub admin users, audit log.
This is a completely separate database from any lab server's sentryusb.db.
"""
import datetime
import json
import os
import secrets
import sqlite3

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sentryusb_hub.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _now():
    return datetime.datetime.now().isoformat()


def init_db():
    conn = get_connection()
    cur = conn.cursor()

    # ========== LABS TABLE ==========
    # Each row = one lab server (tier 2) that has registered with the hub.
    cur.execute("""
        CREATE TABLE IF NOT EXISTS labs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lab_id TEXT UNIQUE NOT NULL,
            lab_name TEXT NOT NULL,
            slug TEXT UNIQUE NOT NULL,
            server_url TEXT,
            hub_token TEXT UNIQUE NOT NULL,
            status TEXT DEFAULT 'pending',
            contact_email TEXT,
            location TEXT,
            notes TEXT,
            requested_at TEXT NOT NULL,
            approved_at TEXT,
            revoked_at TEXT,
            last_seen TEXT,
            last_ip TEXT,
            agent_version TEXT,
            server_version TEXT,
            stats_json TEXT,
            registration_count INTEGER DEFAULT 1,
            tags TEXT
        )
    """)

    # --- lightweight migration: add columns that may not exist on older DBs ---
    cur.execute("PRAGMA table_info(labs)")
    existing_cols = {row[1] for row in cur.fetchall()}
    if "tags" not in existing_cols:
        cur.execute("ALTER TABLE labs ADD COLUMN tags TEXT")

    # ========== HUB ADMIN USERS ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS hub_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'admin',
            created_at TEXT NOT NULL,
            last_login TEXT
        )
    """)
    cur.execute("PRAGMA table_info(hub_users)")
    existing_user_cols = {row[1] for row in cur.fetchall()}
    if "last_login" not in existing_user_cols:
        cur.execute("ALTER TABLE hub_users ADD COLUMN last_login TEXT")

    # ========== HUB SETTINGS (key/value store: org name, overrides, etc.) ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS hub_settings (
            key TEXT PRIMARY KEY,
            value TEXT
        )
    """)

    # ========== AUDIT LOG ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS hub_audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            actor TEXT,
            action TEXT,
            details TEXT,
            timestamp TEXT NOT NULL
        )
    """)

    # ========== HEARTBEAT HISTORY (lightweight, rolling) ==========
    cur.execute("""
        CREATE TABLE IF NOT EXISTS heartbeat_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lab_id TEXT NOT NULL,
            received_at TEXT NOT NULL,
            stats_json TEXT
        )
    """)

    # ========== SENTRYUSB MESSENGER ==========
    # The Hub is the durable relay for the two-way admin conversation.  A
    # message is never a command: it is only a human-readable operational
    # note between a Hub admin and the administrator of a registered lab.
    cur.execute("""
        CREATE TABLE IF NOT EXISTS messenger_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message_id TEXT UNIQUE NOT NULL,
            lab_id TEXT NOT NULL,
            direction TEXT NOT NULL CHECK(direction IN ('hub_to_lab', 'lab_to_hub')),
            sender TEXT NOT NULL,
            body TEXT NOT NULL,
            severity TEXT DEFAULT 'info',
            created_at TEXT NOT NULL,
            delivered_at TEXT,
            read_at TEXT
        )
    """)
    cur.execute("CREATE INDEX IF NOT EXISTS idx_messenger_lab_created ON messenger_messages(lab_id, created_at)")

    # --- Messenger v2: rich messages (image / voice / call log), media store, call signalling ---
    existing = {r[1] for r in cur.execute("PRAGMA table_info(messenger_messages)").fetchall()}
    for col, ddl in (
        ("kind", "TEXT DEFAULT 'text'"),          # text | image | voice | call
        ("media_id", "TEXT"),
        ("media_mime", "TEXT"),
        ("media_size", "INTEGER"),
        ("media_duration", "REAL"),
    ):
        if col not in existing:
            cur.execute(f"ALTER TABLE messenger_messages ADD COLUMN {col} {ddl}")
    cur.execute("""
        CREATE TABLE IF NOT EXISTS messenger_media (
            media_id TEXT PRIMARY KEY,
            lab_id TEXT NOT NULL,
            kind TEXT NOT NULL,
            mime TEXT NOT NULL,
            size INTEGER NOT NULL,
            path TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS messenger_signals (
            seq INTEGER PRIMARY KEY AUTOINCREMENT,
            lab_id TEXT NOT NULL,
            direction TEXT NOT NULL,
            call_id TEXT,
            kind TEXT NOT NULL,
            payload TEXT,
            created_at TEXT NOT NULL
        )
    """)
    cur.execute("CREATE INDEX IF NOT EXISTS idx_messenger_signals_lab ON messenger_signals(lab_id, seq)")

    # ========== default hub admin user ==========
    from werkzeug.security import generate_password_hash
    import hub_config as _config

    cur.execute("SELECT * FROM hub_users WHERE username = ?", (_config.HUB_ADMIN_USERNAME,))
    if not cur.fetchone():
        cur.execute(
            "INSERT INTO hub_users (username, password, role, created_at) VALUES (?, ?, ?, ?)",
            (_config.HUB_ADMIN_USERNAME, generate_password_hash(_config.HUB_ADMIN_PASSWORD), "admin", _now()),
        )

    conn.commit()
    conn.close()
    print("HUB database initialized")


# ============================================================
# LAB REGISTRY
# ============================================================

def _slugify(name: str) -> str:
    base = "".join(c.lower() if c.isalnum() else "-" for c in name).strip("-")
    while "--" in base:
        base = base.replace("--", "-")
    return base or "lab"


def find_lab_by_slug_prefix(slug_base: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT slug FROM labs WHERE slug = ? OR slug LIKE ?", (slug_base, f"{slug_base}-%"))
    rows = [r["slug"] for r in cur.fetchall()]
    conn.close()
    return rows


def get_lab_by_name(lab_name: str):
    """Used to detect re-registration of an existing lab (idempotent registration)."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM labs WHERE lab_name = ?", (lab_name,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_lab_by_token(hub_token: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM labs WHERE hub_token = ?", (hub_token,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def get_lab_by_id(lab_id: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM labs WHERE lab_id = ?", (lab_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


# ============================================================
# SENTRYUSB MESSENGER
# ============================================================

def add_messenger_message(message_id: str, lab_id: str, direction: str,
                          sender: str, body: str, severity: str = "info",
                          kind: str = "text", media_id: str = None, media_mime: str = None,
                          media_size: int = None, media_duration: float = None) -> dict:
    """Store an idempotent messenger message and return the canonical row."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT OR IGNORE INTO messenger_messages
        (message_id, lab_id, direction, sender, body, severity, created_at, delivered_at,
         kind, media_id, media_mime, media_size, media_duration)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (message_id, lab_id, direction, sender, body, severity, _now(),
          _now() if direction == "lab_to_hub" else None,
          kind, media_id, media_mime, media_size, media_duration))
    conn.commit()
    cur.execute("SELECT * FROM messenger_messages WHERE message_id = ?", (message_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row)


def unread_counts() -> dict:
    """{lab_id: unread lab_to_hub message count} for the Hub admin badges."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT lab_id, COUNT(*) AS n FROM messenger_messages
        WHERE direction = 'lab_to_hub' AND read_at IS NULL AND COALESCE(kind,'text') != 'call'
        GROUP BY lab_id
    """)
    out = {r["lab_id"]: r["n"] for r in cur.fetchall()}
    conn.close()
    return out


def list_messenger_messages(lab_id: str, limit: int = 100) -> list:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT * FROM messenger_messages WHERE lab_id = ?
        ORDER BY created_at DESC, id DESC LIMIT ?
    """, (lab_id, max(1, min(int(limit), 200))))
    rows = [dict(row) for row in cur.fetchall()]
    conn.close()
    return list(reversed(rows))


def mark_messenger_delivered(lab_id: str, direction: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        UPDATE messenger_messages SET delivered_at = COALESCE(delivered_at, ?)
        WHERE lab_id = ? AND direction = ?
    """, (_now(), lab_id, direction))
    conn.commit()
    conn.close()


def mark_messenger_read(lab_id: str, direction: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        UPDATE messenger_messages SET read_at = COALESCE(read_at, ?)
        WHERE lab_id = ? AND direction = ?
    """, (_now(), lab_id, direction))
    conn.commit()
    conn.close()


def create_lab(lab_name: str, server_url: str, contact_email: str = None,
                location: str = None, auto_approve: bool = False,
                agent_version: str = None, server_version: str = None,
                ip: str = None) -> dict:
    """Register a brand-new lab. Generates a unique lab_id (folder/namespace)
    and a unique hub_token (the credential the lab server will use for every
    future call to the hub, e.g. heartbeats)."""
    conn = get_connection()
    cur = conn.cursor()

    lab_id = "lab_" + secrets.token_hex(8)
    hub_token = "hub_" + secrets.token_urlsafe(32)

    slug_base = _slugify(lab_name)
    existing_slugs = set(find_lab_by_slug_prefix(slug_base))
    slug = slug_base
    n = 2
    while slug in existing_slugs:
        slug = f"{slug_base}-{n}"
        n += 1

    now = _now()
    status = "approved" if auto_approve else "pending"

    cur.execute("""
        INSERT INTO labs (
            lab_id, lab_name, slug, server_url, hub_token, status,
            contact_email, location, requested_at, approved_at,
            last_seen, last_ip, agent_version, server_version
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        lab_id, lab_name, slug, server_url, hub_token, status,
        contact_email, location, now, now if auto_approve else None,
        now, ip, agent_version, server_version,
    ))
    conn.commit()
    conn.close()

    return get_lab_by_id(lab_id)


def reregister_lab(lab_id: str, server_url: str, ip: str = None,
                    agent_version: str = None, server_version: str = None):
    """A previously-registered lab server called /api/hub/register again
    (e.g. restarted, or its ngrok URL changed). Keep the same lab_id/token,
    just refresh its reachable URL so the hub redirect link stays correct."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        UPDATE labs SET server_url = ?, last_seen = ?, last_ip = COALESCE(?, last_ip),
            agent_version = COALESCE(?, agent_version),
            server_version = COALESCE(?, server_version),
            registration_count = registration_count + 1
        WHERE lab_id = ?
    """, (server_url, _now(), ip, agent_version, server_version, lab_id))
    conn.commit()
    conn.close()
    return get_lab_by_id(lab_id)


def list_labs(status: str = None, search: str = None):
    conn = get_connection()
    cur = conn.cursor()
    clauses = []
    params = []
    if status:
        clauses.append("status = ?")
        params.append(status)
    if search:
        like = f"%{search.strip()}%"
        clauses.append("(lab_name LIKE ? OR location LIKE ? OR tags LIKE ? OR contact_email LIKE ?)")
        params.extend([like, like, like, like])
    sql = "SELECT * FROM labs"
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    sql += " ORDER BY requested_at DESC"
    cur.execute(sql, params)
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def update_lab_details(lab_id: str, lab_name: str = None, location: str = None,
                        contact_email: str = None, notes: str = None, tags: str = None):
    """Let a hub admin rename a lab and edit its metadata after registration."""
    conn = get_connection()
    cur = conn.cursor()
    fields, params = [], []
    if lab_name is not None:
        fields.append("lab_name = ?"); params.append(lab_name.strip())
    if location is not None:
        fields.append("location = ?"); params.append(location.strip())
    if contact_email is not None:
        fields.append("contact_email = ?"); params.append(contact_email.strip())
    if notes is not None:
        fields.append("notes = ?"); params.append(notes.strip())
    if tags is not None:
        fields.append("tags = ?"); params.append(tags.strip())
    if not fields:
        conn.close()
        return get_lab_by_id(lab_id)
    params.append(lab_id)
    cur.execute(f"UPDATE labs SET {', '.join(fields)} WHERE lab_id = ?", params)
    conn.commit()
    conn.close()
    return get_lab_by_id(lab_id)


def status_distribution():
    """Counts of labs by status, always including every known status key
    (even at 0) so charts don't need to special-case missing keys."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT status, COUNT(*) as c FROM labs GROUP BY status")
    counts = {row["status"]: row["c"] for row in cur.fetchall()}
    conn.close()
    for key in ("pending", "approved", "revoked", "rejected"):
        counts.setdefault(key, 0)
    return counts


def labs_growth_series(days: int = 14):
    """Labs newly registered per day (by requested_at) for the last N days,
    oldest -> newest. Used to draw the registration-trend bar chart."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT requested_at FROM labs")
    rows = [r["requested_at"] for r in cur.fetchall()]
    conn.close()

    today = datetime.date.today()
    buckets = {(today - datetime.timedelta(days=i)).isoformat(): 0 for i in range(days - 1, -1, -1)}
    for ts in rows:
        try:
            day = ts[:10]
        except Exception:
            continue
        if day in buckets:
            buckets[day] += 1
    return [{"date": d, "count": c} for d, c in buckets.items()]


def heartbeats_series(days: int = 14):
    """Number of heartbeats received per day, fleet-wide, for the last N
    days. A rough proxy for overall hub/lab activity over time."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT received_at FROM heartbeat_log")
    rows = [r["received_at"] for r in cur.fetchall()]
    conn.close()

    today = datetime.date.today()
    buckets = {(today - datetime.timedelta(days=i)).isoformat(): 0 for i in range(days - 1, -1, -1)}
    for ts in rows:
        try:
            day = ts[:10]
        except Exception:
            continue
        if day in buckets:
            buckets[day] += 1
    return [{"date": d, "count": c} for d, c in buckets.items()]


def top_labs_by_events(limit: int = 6):
    """Approved labs ranked by their last-reported events_total, for the
    'busiest labs' leaderboard on the analytics page."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT lab_name, lab_id, stats_json FROM labs WHERE status = 'approved'")
    rows = cur.fetchall()
    conn.close()
    ranked = []
    for r in rows:
        try:
            stats = json.loads(r["stats_json"] or "{}")
        except Exception:
            stats = {}
        ranked.append({
            "lab_name": r["lab_name"],
            "lab_id": r["lab_id"],
            "events_total": int(stats.get("events_total") or 0),
            "agents": int(stats.get("agents") or 0),
            "blocked_devices": int(stats.get("blocked_devices") or 0),
        })
    ranked.sort(key=lambda x: x["events_total"], reverse=True)
    return ranked[:limit]


def audit_action_breakdown(limit_days: int = 30):
    """Count of audit-log actions grouped by action name, most recent
    `limit_days` days only, for the activity-by-type chart."""
    conn = get_connection()
    cur = conn.cursor()
    cutoff = (datetime.datetime.now() - datetime.timedelta(days=limit_days)).isoformat()
    cur.execute("SELECT action, COUNT(*) as c FROM hub_audit_log WHERE timestamp >= ? GROUP BY action ORDER BY c DESC",
                (cutoff,))
    rows = [{"action": r["action"], "count": r["c"]} for r in cur.fetchall()]
    conn.close()
    return rows


def avg_response_health():
    """Very lightweight 'system health' style numbers: how many labs have
    ever registered, and total heartbeats ever received — used on the
    Analytics + Settings pages."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) c FROM labs")
    total = cur.fetchone()["c"]
    cur.execute("SELECT MIN(requested_at) a, MAX(requested_at) b FROM labs")
    row = cur.fetchone()
    cur.execute("SELECT COUNT(*) c FROM heartbeat_log")
    total_heartbeats = cur.fetchone()["c"]
    conn.close()
    return {
        "total_labs_ever": total,
        "first_registration": row["a"],
        "last_registration": row["b"],
        "total_heartbeats": total_heartbeats,
    }


def fleet_summary():
    """Aggregate the last-reported stats (agents / events_total / blocked_devices)
    across every approved lab, for the dashboard's fleet-wide totals."""
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT stats_json FROM labs WHERE status = 'approved'")
    totals = {"agents": 0, "events_total": 0, "blocked_devices": 0}
    for row in cur.fetchall():
        try:
            stats = json.loads(row["stats_json"] or "{}")
        except Exception:
            stats = {}
        for k in totals:
            totals[k] += int(stats.get(k) or 0)
    conn.close()
    return totals


def set_lab_status(lab_id: str, status: str):
    conn = get_connection()
    cur = conn.cursor()
    now = _now()
    if status == "approved":
        cur.execute("UPDATE labs SET status = ?, approved_at = ?, revoked_at = NULL WHERE lab_id = ?",
                     (status, now, lab_id))
    elif status == "revoked":
        cur.execute("UPDATE labs SET status = ?, revoked_at = ? WHERE lab_id = ?", (status, now, lab_id))
    else:
        cur.execute("UPDATE labs SET status = ? WHERE lab_id = ?", (status, lab_id))
    conn.commit()
    conn.close()


def regenerate_token(lab_id: str) -> str:
    """Invalidate the old hub_token and issue a new one. The lab server will
    need to be given the new token (shown once in the dashboard)."""
    conn = get_connection()
    cur = conn.cursor()
    new_token = "hub_" + secrets.token_urlsafe(32)
    cur.execute("UPDATE labs SET hub_token = ? WHERE lab_id = ?", (new_token, lab_id))
    conn.commit()
    conn.close()
    return new_token


def delete_lab(lab_id: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM labs WHERE lab_id = ?", (lab_id,))
    cur.execute("DELETE FROM heartbeat_log WHERE lab_id = ?", (lab_id,))
    conn.commit()
    conn.close()


def record_heartbeat(lab_id: str, stats: dict, ip: str = None):
    conn = get_connection()
    cur = conn.cursor()
    now = _now()
    stats_json = json.dumps(stats or {})
    cur.execute("""
        UPDATE labs SET last_seen = ?, last_ip = COALESCE(?, last_ip), stats_json = ?
        WHERE lab_id = ?
    """, (now, ip, stats_json, lab_id))
    cur.execute("INSERT INTO heartbeat_log (lab_id, received_at, stats_json) VALUES (?, ?, ?)",
                (lab_id, now, stats_json))
    # keep only the most recent 200 heartbeats per lab
    cur.execute("""
        DELETE FROM heartbeat_log WHERE lab_id = ? AND id NOT IN (
            SELECT id FROM heartbeat_log WHERE lab_id = ? ORDER BY id DESC LIMIT 200
        )
    """, (lab_id, lab_id))
    conn.commit()
    conn.close()


def get_heartbeat_history(lab_id: str, limit: int = 50):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM heartbeat_log WHERE lab_id = ? ORDER BY id DESC LIMIT ?", (lab_id, limit))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


# ============================================================
# HUB USERS (admin login)
# ============================================================

def get_hub_user(username: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM hub_users WHERE username = ?", (username,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


def verify_hub_credentials(username: str, password: str) -> bool:
    from werkzeug.security import check_password_hash
    user = get_hub_user(username)
    if not user:
        return False
    return check_password_hash(user["password"], password)


def set_hub_password(username: str, new_password: str):
    from werkzeug.security import generate_password_hash
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE hub_users SET password = ? WHERE username = ?",
                (generate_password_hash(new_password), username))
    conn.commit()
    conn.close()


# ============================================================
# AUDIT LOG
# ============================================================

def add_audit(actor: str, action: str, details: str = None):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("INSERT INTO hub_audit_log (actor, action, details, timestamp) VALUES (?, ?, ?, ?)",
                (actor, action, details, _now()))
    conn.commit()
    conn.close()


def get_audit_log(limit: int = 200, search: str = None):
    conn = get_connection()
    cur = conn.cursor()
    if search:
        like = f"%{search.strip()}%"
        cur.execute(
            "SELECT * FROM hub_audit_log WHERE actor LIKE ? OR action LIKE ? OR details LIKE ? "
            "ORDER BY id DESC LIMIT ?",
            (like, like, like, limit),
        )
    else:
        cur.execute("SELECT * FROM hub_audit_log ORDER BY id DESC LIMIT ?", (limit,))
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


# ============================================================
# HUB SETTINGS  (key/value store — org name, secret overrides, etc.)
# ============================================================

def get_setting(key: str, default=None):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT value FROM hub_settings WHERE key = ?", (key,))
    row = cur.fetchone()
    conn.close()
    return row["value"] if row else default


def set_setting(key: str, value: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        INSERT INTO hub_settings (key, value) VALUES (?, ?)
        ON CONFLICT(key) DO UPDATE SET value = excluded.value
    """, (key, value))
    conn.commit()
    conn.close()


def get_all_settings():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT key, value FROM hub_settings")
    rows = {r["key"]: r["value"] for r in cur.fetchall()}
    conn.close()
    return rows


# ============================================================
# HUB ADMIN USER MANAGEMENT (multi-admin support)
# ============================================================

def list_hub_users():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT id, username, role, created_at, last_login FROM hub_users ORDER BY created_at ASC")
    rows = [dict(r) for r in cur.fetchall()]
    conn.close()
    return rows


def create_hub_user(username: str, password: str, role: str = "admin"):
    from werkzeug.security import generate_password_hash
    conn = get_connection()
    cur = conn.cursor()
    cur.execute(
        "INSERT INTO hub_users (username, password, role, created_at) VALUES (?, ?, ?, ?)",
        (username.strip(), generate_password_hash(password), role, _now()),
    )
    conn.commit()
    conn.close()


def delete_hub_user(username: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("DELETE FROM hub_users WHERE username = ?", (username,))
    conn.commit()
    conn.close()


def count_hub_users() -> int:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT COUNT(*) as c FROM hub_users")
    n = cur.fetchone()["c"]
    conn.close()
    return n


def touch_last_login(username: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("UPDATE hub_users SET last_login = ? WHERE username = ?", (_now(), username))
    conn.commit()
    conn.close()


# ---- Messenger media (images / voice notes) -------------------------------
def add_messenger_media(media_id: str, lab_id: str, kind: str, mime: str, size: int, path: str):
    conn = get_connection()
    conn.execute("INSERT INTO messenger_media (media_id, lab_id, kind, mime, size, path, created_at) "
                 "VALUES (?, ?, ?, ?, ?, ?, ?)", (media_id, lab_id, kind, mime, size, path, _now()))
    conn.commit()
    conn.close()


def get_messenger_media(media_id: str):
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("SELECT * FROM messenger_media WHERE media_id = ?", (media_id,))
    row = cur.fetchone()
    conn.close()
    return dict(row) if row else None


# ---- Messenger call signalling (WebRTC offer/answer/ICE relay) -----------
SIGNAL_TTL_SECONDS = 15 * 60


def add_messenger_signal(lab_id: str, direction: str, call_id: str, kind: str, payload: str) -> int:
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("INSERT INTO messenger_signals (lab_id, direction, call_id, kind, payload, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)", (lab_id, direction, call_id, kind, payload, _now()))
    seq = cur.lastrowid
    # opportunistic pruning keeps the table tiny
    cutoff = (datetime.datetime.now() - datetime.timedelta(seconds=SIGNAL_TTL_SECONDS)).isoformat()
    cur.execute("DELETE FROM messenger_signals WHERE created_at < ?", (cutoff,))
    conn.commit()
    conn.close()
    return seq


def latest_signal_seq() -> int:
    conn = get_connection()
    row = conn.execute("SELECT COALESCE(MAX(seq), 0) FROM messenger_signals").fetchone()
    conn.close()
    return int(row[0])


def list_messenger_signals(after: int, lab_id: str = None, direction: str = None, limit: int = 200) -> list:
    sql, args = "SELECT * FROM messenger_signals WHERE seq > ?", [int(after)]
    if lab_id:
        sql += " AND lab_id = ?"; args.append(lab_id)
    if direction:
        sql += " AND direction = ?"; args.append(direction)
    sql += " ORDER BY seq ASC LIMIT ?"; args.append(int(limit))
    conn = get_connection()
    rows = [dict(r) for r in conn.execute(sql, args).fetchall()]
    conn.close()
    return rows
