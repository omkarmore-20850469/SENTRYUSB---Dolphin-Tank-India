/* SentryUSB Messenger v2 - shared Hub <-> Lab chat widget.
 * Text, images, voice notes, voice calls and video calls (WebRTC).
 * It is a human-to-human channel only: nothing here can trigger device, exam,
 * browser or system actions. Calls are peer-to-peer; the Hub relays signalling.
 * Same file is deployed on the Hub (mode 'hub') and on each Lab Server (mode 'lab'). */
(function () {
  'use strict';
  const MODE = 'hub';                       // replaced at build time: 'hub' | 'lab'
  if (document.getElementById('sentryusb-messenger-launcher')) return;

  const MINE = MODE === 'hub' ? 'hub_to_lab' : 'lab_to_hub';
  const enc = encodeURIComponent;
  const API = MODE === 'hub' ? {
    labs: '/api/messenger/labs',
    messages: (lab) => '/api/messenger/labs/' + enc(lab) + '/messages',
    send: (lab) => '/api/messenger/labs/' + enc(lab) + '/send',
    read: null,
    media: (id) => '/api/messenger/media/' + enc(id),
    ice: '/api/messenger/ice',
    signal: (lab) => '/api/messenger/labs/' + enc(lab) + '/signal',
    signals: '/api/messenger/signals',
  } : {
    messages: () => '/api/messenger/messages',
    send: () => '/api/messenger/send',
    read: '/api/messenger/read',
    media: (id) => '/api/messenger/media/' + enc(id),
    ice: '/api/messenger/ice',
    signal: () => '/api/messenger/signal',
    signals: '/api/messenger/signals',
  };
  const SELF_NAME = MODE === 'hub' ? 'Hub Admin' : 'Lab Admin';
  const PEER_DEFAULT = MODE === 'hub' ? 'Lab' : 'SentryUSB Hub';
  const CLIENT_ID = Array.from(crypto.getRandomValues(new Uint8Array(6))).map(b => b.toString(16).padStart(2, '0')).join('');
  const EMOJI = '😀 😂 😊 😉 😍 🤔 😅 🙏 👍 👎 👌 🙌 👏 💪 🔥 ✅ ❌ ⚠️ 🚨 🔒 🛡️ 💻 🖥️ 🔌 📎 📞 🎓 ⏰ 🚀 🎉 😴 😮 😢 😡 ❤️ 👀 🤝 ✔️ ❓ ❗'.split(' ');
  const QUICK = ['👍 Got it', 'On it', 'Give me 5 minutes', 'Can we call?'];

  // ---------- tiny DOM helpers ----------
  const ICON = {
    chat: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v8a2.5 2.5 0 0 1-2.5 2.5H11l-4.2 3.6a.6.6 0 0 1-1-.46V16h-.3A2.5 2.5 0 0 1 4 13.5Z" fill="currentColor"/><circle cx="9" cy="9.7" r="1.1" fill="#0b1224"/><circle cx="12.5" cy="9.7" r="1.1" fill="#0b1224"/><circle cx="16" cy="9.7" r="1.1" fill="#0b1224"/>',
    phone: '<path d="M6.6 3.2 9 3a1 1 0 0 1 1 .8l.7 3.2a1 1 0 0 1-.3.95L9 9.3a12 12 0 0 0 5.7 5.7l1.35-1.4a1 1 0 0 1 .95-.3l3.2.7a1 1 0 0 1 .8 1l-.2 2.4a1.8 1.8 0 0 1-1.9 1.7A15.6 15.6 0 0 1 4.9 5.1 1.8 1.8 0 0 1 6.6 3.2Z" fill="currentColor"/>',
    video: '<rect x="3" y="6.5" width="12.5" height="11" rx="2.6" fill="currentColor"/><path d="m16.8 10.6 4-2.4a.6.6 0 0 1 .9.5v6.6a.6.6 0 0 1-.9.5l-4-2.4Z" fill="currentColor"/>',
    videoOff: '<path d="M3 6.5h9.7l2.8 2.8v6.4a2.6 2.6 0 0 1-2.6 2.6H5.6A2.6 2.6 0 0 1 3 15.7Z" fill="currentColor"/><path d="m16.8 10.6 4-2.4a.6.6 0 0 1 .9.5v6.6a.6.6 0 0 1-.9.5l-4-2.4Z" fill="currentColor"/><path d="M4 4 20 20" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3" fill="currentColor"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round"/>',
    micOff: '<rect x="9" y="3" width="6" height="11" rx="3" fill="currentColor"/><path d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round"/><path d="M4 4 20 20" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>',
    send: '<path d="M3.4 11.3 19.8 4.2a.7.7 0 0 1 .96.8l-3.4 14.4a.7.7 0 0 1-1.1.4l-4.4-3.3-2.3 2.6a.6.6 0 0 1-1.05-.4v-3.5L18 7.2 7 13.5l-3.2-1.1a.7.7 0 0 1-.4-1.1Z" fill="currentColor"/>',
    image: '<rect x="3" y="4.5" width="18" height="15" rx="3" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="9" cy="10" r="1.8" fill="currentColor"/><path d="m4 17 5-4.4 3.5 3 3-2.6L20 16.5" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linejoin="round"/>',
    smile: '<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="9" cy="10" r="1.2" fill="currentColor"/><circle cx="15" cy="10" r="1.2" fill="currentColor"/><path d="M8 14.2a4.6 4.6 0 0 0 8 0" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round"/>',
    play: '<path d="M8 5.2v13.6a.8.8 0 0 0 1.2.7l11-6.8a.8.8 0 0 0 0-1.4L9.2 4.5a.8.8 0 0 0-1.2.7Z" fill="currentColor"/>',
    pause: '<rect x="6.5" y="4.8" width="4" height="14.4" rx="1.2" fill="currentColor"/><rect x="13.5" y="4.8" width="4" height="14.4" rx="1.2" fill="currentColor"/>',
    trash: '<path d="M5 7h14M10 7V4.8h4V7M7 7l.8 12.2h8.4L17 7M10.2 10.5v5.5M13.8 10.5v5.5" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
    hangup: '<path d="M2.6 14.6c2.6-3.2 6.2-4.4 9.4-4.4s6.8 1.2 9.4 4.4a1.4 1.4 0 0 1-.1 1.8l-1.8 1.8a1.4 1.4 0 0 1-1.7.2l-2.6-1.5a1.4 1.4 0 0 1-.7-1.2v-1.6a9.4 9.4 0 0 0-4.8 0v1.6c0 .5-.3 1-.7 1.2l-2.6 1.5a1.4 1.4 0 0 1-1.7-.2l-1.8-1.8a1.4 1.4 0 0 1-.1-1.8Z" fill="currentColor"/>',
    close: '<path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>',
    shield: '<path d="M12 2.6 4.6 5.4v5.6c0 5 3.1 8.7 7.4 10.4 4.3-1.7 7.4-5.4 7.4-10.4V5.4Z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M8.8 12.2l2.2 2.2 4.2-4.4" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
  };
  function icon(name, size) {
    const s = document.createElement('span');
    s.className = 'sm2-ico';
    s.innerHTML = '<svg viewBox="0 0 24 24" width="' + (size || 20) + '" height="' + (size || 20) + '" aria-hidden="true">' + ICON[name] + '</svg>';
    return s;
  }
  function h(tag, props) {
    const e = document.createElement(tag);
    if (props) for (const k in props) {
      if (k === 'class') e.className = props[k];
      else if (k === 'text') e.textContent = props[k];
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), props[k]);
      else e.setAttribute(k, props[k]);
    }
    for (let i = 2; i < arguments.length; i++) {
      const c = arguments[i];
      if (c == null) continue;
      (Array.isArray(c) ? c : [c]).forEach(x => x != null && e.append(x.nodeType ? x : document.createTextNode(x)));
    }
    return e;
  }
  const pad2 = (n) => String(n).padStart(2, '0');
  const fmtDur = (s) => { s = Math.max(0, Math.round(s || 0)); return Math.floor(s / 60) + ':' + pad2(s % 60); };
  const clock = (v) => { try { return new Date(v).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); } catch (_) { return ''; } };
  function dayLabel(v) {
    try {
      const d = new Date(v), t = new Date(), y = new Date(Date.now() - 864e5);
      if (d.toDateString() === t.toDateString()) return 'Today';
      if (d.toDateString() === y.toDateString()) return 'Yesterday';
      return d.toLocaleDateString([], { day: 'numeric', month: 'short', year: 'numeric' });
    } catch (_) { return ''; }
  }
  async function jfetch(url, opts) {
    const o = Object.assign({ credentials: 'same-origin' }, opts || {});
    o.headers = Object.assign({ Accept: 'application/json' }, o.headers || {});
    const r = await fetch(url, o);
    let data = {};
    try { data = await r.json(); } catch (_) { /* non-JSON */ }
    return { ok: r.ok, status: r.status, data };
  }
  const postJSON = (url, body) => jfetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  const secure = () => window.isSecureContext && navigator.mediaDevices && navigator.mediaDevices.getUserMedia;

  // ---------- state ----------
  const S = {
    open: false, labs: [], lab: '', labName: '', messages: [], pending: [], sig: '', unread: 0,
    known: new Set(), booted: false, severity: 'info', attach: null, recording: null,
    typingUntil: 0, lastTypingSent: 0, connected: true, peerOnline: null,
  };
  try { S.lab = localStorage.getItem('sm2-lab') || ''; } catch (_) { /* storage blocked */ }
  const voiceNodes = new Map();

  // ---------- build DOM ----------
  const launcher = h('button', { id: 'sentryusb-messenger-launcher', type: 'button', 'aria-label': 'Open SentryUSB Messenger' },
    icon('chat', 28), h('span', { class: 'sum-badge', text: '0' }));
  const badge = launcher.querySelector('.sum-badge');

  const labSelect = h('select', { class: 'sm2-lab', 'aria-label': 'Select lab' });
  const statusEl = h('div', { class: 'sm2-status' });
  const titleEl = h('div', { class: 'sm2-title', text: MODE === 'hub' ? 'SentryUSB Messenger' : PEER_DEFAULT });
  const avatar = h('div', { class: 'sm2-avatar' }, icon('shield', 22));
  const voiceBtn = h('button', { class: 'sm2-hbtn', type: 'button', 'aria-label': 'Start voice call', title: 'Voice call' }, icon('phone', 19));
  const videoBtn = h('button', { class: 'sm2-hbtn', type: 'button', 'aria-label': 'Start video call', title: 'Video call' }, icon('video', 21));
  const closeBtn = h('button', { class: 'sm2-hbtn sm2-x', type: 'button', 'aria-label': 'Close' }, icon('close', 18));
  const header = h('div', { class: 'sm2-head' },
    h('div', { class: 'sm2-head-row' }, avatar, h('div', { class: 'sm2-head-text' }, titleEl, statusEl), voiceBtn, videoBtn, closeBtn),
    MODE === 'hub' ? labSelect : null,
    h('div', { class: 'sm2-security', text: 'Human messages only · calls are peer-to-peer · no remote commands' }));

  const thread = h('div', { class: 'sm2-thread', role: 'log', 'aria-live': 'polite' });
  const quickRow = h('div', { class: 'sm2-quick' });
  const attachBar = h('div', { class: 'sm2-attach', hidden: '' });
  const emojiTray = h('div', { class: 'sm2-emoji', hidden: '' }, EMOJI.map(e => h('button', { type: 'button', text: e, onclick: () => insertAtCursor(e) })));
  const input = h('textarea', { class: 'sm2-input', maxlength: '2000', rows: '1', placeholder: 'Message', 'aria-label': 'Message' });
  const sevBtn = h('button', { class: 'sm2-sev info', type: 'button', title: 'Priority: tap to change', 'aria-label': 'Message priority', text: 'INFO' });
  const emojiBtn = h('button', { class: 'sm2-cbtn', type: 'button', 'aria-label': 'Emoji' }, icon('smile', 21));
  const fileInput = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/gif,image/webp', hidden: '' });
  const imgBtn = h('button', { class: 'sm2-cbtn', type: 'button', 'aria-label': 'Send an image', title: 'Send an image' }, icon('image', 21));
  const sendBtn = h('button', { class: 'sm2-send', type: 'button', 'aria-label': 'Record voice message' }, icon('mic', 22));
  const composeRow = h('div', { class: 'sm2-compose-row' }, emojiBtn, imgBtn, input, sevBtn, sendBtn);
  const recTime = h('span', { class: 'sm2-rec-time', text: '0:00' });
  const recBar = h('div', { class: 'sm2-rec', hidden: '' },
    h('button', { class: 'sm2-cbtn sm2-rec-cancel', type: 'button', 'aria-label': 'Discard recording', onclick: () => stopRecording(false) }, icon('trash', 21)),
    h('span', { class: 'sm2-rec-dot' }), recTime, h('span', { class: 'sm2-rec-hint', text: 'Recording…' }),
    h('button', { class: 'sm2-send', type: 'button', 'aria-label': 'Send voice message', onclick: () => stopRecording(true) }, icon('send', 20)));
  const drop = h('div', { class: 'sm2-drop', hidden: '', text: 'Drop an image to send' });
  const panel = h('section', { id: 'sentryusb-messenger-panel', 'aria-label': 'SentryUSB Messenger' },
    header, h('div', { class: 'sm2-body' }, thread, drop), quickRow, attachBar, emojiTray,
    h('div', { class: 'sm2-compose' }, composeRow, recBar), fileInput);
  document.body.append(launcher, panel);

  // ---------- helpers: toast / status ----------
  let toastTimer = 0;
  function toast(text) {
    statusEl.textContent = text; statusEl.classList.add('warn');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(updateStatus, 4500);
  }
  function peerName() { return MODE === 'hub' ? (S.labName || PEER_DEFAULT) : PEER_DEFAULT; }
  function updateStatus() {
    statusEl.classList.remove('warn');
    titleEl.textContent = MODE === 'hub' ? (S.labName || 'SentryUSB Messenger') : PEER_DEFAULT;
    let text, ok = true;
    if (Date.now() < S.typingUntil) text = 'typing…';
    else if (!S.connected) { text = MODE === 'hub' ? 'Hub connection problem' : 'Hub unreachable – retrying'; ok = false; }
    else if (MODE === 'hub') {
      if (!S.lab) text = 'Select a lab to start';
      else { ok = S.peerOnline !== false; text = ok ? 'Lab online' : 'Lab offline – messages will wait'; }
    } else text = 'Secure Hub connection';
    statusEl.textContent = text;
    statusEl.classList.toggle('offline', !ok);
    statusEl.classList.toggle('typing', text === 'typing…');
    const canCall = MODE === 'lab' || !!S.lab;
    voiceBtn.disabled = videoBtn.disabled = !canCall || CALL.state !== 'idle';
  }
  function setUnread(n) {
    S.unread = Math.max(0, n);
    badge.textContent = S.unread > 9 ? '9+' : String(S.unread);
    launcher.classList.toggle('has-unread', S.unread > 0);
  }
  function insertAtCursor(txt) {
    const a = input.selectionStart || input.value.length, b = input.selectionEnd || input.value.length;
    input.value = input.value.slice(0, a) + txt + input.value.slice(b);
    input.focus(); input.selectionStart = input.selectionEnd = a + txt.length; onInput();
  }

  // ---------- message rendering ----------
  function waveHeights(seed, n) {
    let x = 0; for (let i = 0; i < seed.length; i++) x = (x * 31 + seed.charCodeAt(i)) >>> 0;
    const out = [];
    for (let i = 0; i < n; i++) { x = (x * 1664525 + 1013904223) >>> 0; out.push(25 + (x % 70)); }
    return out;
  }
  function voiceNode(m) {
    if (voiceNodes.has(m.message_id)) return voiceNodes.get(m.message_id);
    const dur = Number(m.media_duration) || 0;
    const audio = new Audio(); audio.preload = 'none'; audio.src = API.media(m.media_id);
    const playBtn = h('button', { class: 'sm2-vbtn', type: 'button', 'aria-label': 'Play voice message' }, icon('play', 18));
    const wave = h('div', { class: 'sm2-wave' }, waveHeights(m.media_id, 30).map(v => h('i', { style: 'height:' + v + '%' })));
    const time = h('span', { class: 'sm2-vtime', text: fmtDur(dur) });
    const speed = h('button', { class: 'sm2-vspeed', type: 'button', text: '1×', title: 'Playback speed' });
    const node = h('div', { class: 'sm2-voice' }, playBtn, h('div', { class: 'sm2-vmid' }, wave, time), speed);
    function paint() {
      const total = dur || (isFinite(audio.duration) ? audio.duration : 0);
      const f = total ? Math.min(1, audio.currentTime / total) : 0;
      Array.from(wave.children).forEach((b, i) => b.classList.toggle('on', i / wave.children.length < f));
      time.textContent = fmtDur(audio.paused && audio.currentTime === 0 ? total : audio.currentTime);
    }
    function setBtn(playing) { playBtn.replaceChildren(icon(playing ? 'pause' : 'play', 18)); }
    playBtn.addEventListener('click', () => {
      if (audio.paused) {
        voiceNodes.forEach(n => n._audio !== audio && n._audio.pause());
        audio.play().catch(() => toast('Could not play this voice message'));
      } else audio.pause();
    });
    audio.addEventListener('play', () => setBtn(true));
    audio.addEventListener('pause', () => { setBtn(false); paint(); });
    audio.addEventListener('ended', () => { audio.currentTime = 0; setBtn(false); paint(); });
    audio.addEventListener('timeupdate', paint);
    wave.addEventListener('click', (e) => {
      const r = wave.getBoundingClientRect(), total = dur || audio.duration;
      if (total && isFinite(total)) { audio.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * total; paint(); }
    });
    speed.addEventListener('click', () => {
      const next = audio.playbackRate === 1 ? 1.5 : audio.playbackRate === 1.5 ? 2 : 1;
      audio.playbackRate = next; speed.textContent = next + '×';
    });
    node._audio = audio;
    voiceNodes.set(m.message_id, node);
    return node;
  }
  function ticks(m) {
    if (m.direction !== MINE) return null;
    const read = !!m.read_at, delivered = !!m.delivered_at;
    return h('span', { class: 'sm2-ticks' + (read ? ' read' : ''), title: read ? 'Seen' : delivered ? 'Delivered' : 'Sent', text: delivered || read ? '✓✓' : '✓' });
  }
  function callText(m) {
    const who = m.direction === MINE ? 'You' : (m.sender || peerName());
    return who + ' · ' + m.body;
  }
  function msgNode(m) {
    const kind = m.kind || 'text';
    if (kind === 'call') return h('div', { class: 'sm2-callline' }, icon('phone', 14), h('span', { text: callText(m) }), h('em', { text: clock(m.created_at) }));
    const mine = m.direction === MINE;
    const sev = m.severity && m.severity !== 'info' ? m.severity : '';
    const bubble = h('div', { class: 'sm2-bubble' + (sev ? ' sev-' + sev : '') });
    if (!mine) bubble.append(h('div', { class: 'sm2-sender', text: m.sender || peerName() }));
    if (sev) bubble.append(h('div', { class: 'sm2-sevtag ' + sev, text: sev === 'critical' ? '🚨 CRITICAL' : '⚠️ WARNING' }));
    if (kind === 'image' && m.media_id) {
      const img = h('img', { class: 'sm2-img', loading: 'lazy', alt: 'Image from ' + (m.sender || 'chat'), src: API.media(m.media_id) });
      img.addEventListener('click', () => lightbox(img.src));
      bubble.append(img);
      if (m.body) bubble.append(h('div', { class: 'sm2-text', text: m.body }));
    } else if (kind === 'voice' && m.media_id) {
      bubble.append(voiceNode(m));
    } else bubble.append(h('div', { class: 'sm2-text', text: m.body }));
    bubble.append(h('div', { class: 'sm2-meta' }, h('span', { text: clock(m.created_at) }), ticks(m)));
    return h('article', { class: 'sm2-msg ' + (mine ? 'out' : 'in') }, bubble);
  }
  function pendingNode(p) {
    const bubble = h('div', { class: 'sm2-bubble sm2-pending' + (p.state === 'failed' ? ' failed' : '') });
    if (p.kind === 'image' && p.url) bubble.append(h('img', { class: 'sm2-img', src: p.url, alt: 'Sending image' }));
    else if (p.kind === 'voice') bubble.append(h('div', { class: 'sm2-text', text: '🎤 Voice message · ' + fmtDur(p.duration) }));
    else bubble.append(h('div', { class: 'sm2-text', text: p.text }));
    const meta = h('div', { class: 'sm2-meta' }, h('span', { text: p.state === 'failed' ? 'Not sent – tap to retry' : 'Sending…' }));
    bubble.append(meta);
    if (p.state === 'failed') bubble.addEventListener('click', () => { p.state = 'sending'; S.sig = ''; renderThread(); p.retry(); });
    return h('article', { class: 'sm2-msg out' }, bubble);
  }
  function renderThread(force) {
    const sig = S.messages.map(m => m.message_id + ':' + (m.delivered_at ? 1 : 0) + (m.read_at ? 1 : 0)).join('|') +
      '#' + S.pending.map(p => p.id + p.state).join(',');
    if (!force && sig === S.sig) return;
    S.sig = sig;
    const atBottom = thread.scrollHeight - thread.scrollTop - thread.clientHeight < 80;
    const nodes = [];
    if (!S.messages.length && !S.pending.length) {
      nodes.push(h('div', { class: 'sm2-empty' },
        h('div', { class: 'sm2-empty-ico' }, icon('shield', 34)),
        h('div', { text: MODE === 'hub' && !S.lab ? 'Choose a lab above to open a secure conversation.' :
          'Your secure conversation appears here. Send messages, images and voice notes, or start a call.' })));
    }
    let lastDay = '';
    S.messages.forEach(m => {
      const d = dayLabel(m.created_at);
      if (d && d !== lastDay) { nodes.push(h('div', { class: 'sm2-day' }, h('span', { text: d }))); lastDay = d; }
      nodes.push(msgNode(m));
    });
    S.pending.forEach(p => nodes.push(pendingNode(p)));
    thread.replaceChildren(...nodes);
    if (atBottom || force !== undefined) thread.scrollTop = thread.scrollHeight;
    renderQuick();
  }
  function renderQuick() {
    const last = S.messages[S.messages.length - 1];
    const show = last && last.direction !== MINE && (last.kind || 'text') === 'text' && !input.value && !S.attach && !S.recording;
    quickRow.replaceChildren();
    quickRow.hidden = !show;
    if (show) QUICK.forEach(q => quickRow.append(h('button', { type: 'button', text: q, onclick: () => sendText(q) })));
  }
  function lightbox(src) {
    const box = h('div', { class: 'sm2-lightbox', onclick: () => box.remove() }, h('img', { src, alt: 'Full size image' }),
      h('button', { type: 'button', class: 'sm2-lb-close', 'aria-label': 'Close image' }, icon('close', 22)));
    const onKey = (e) => { if (e.key === 'Escape') { box.remove(); document.removeEventListener('keydown', onKey); } };
    document.addEventListener('keydown', onKey);
    document.body.append(box);
  }

  // ---------- data loading ----------
  async function loadLabs() {
    if (MODE !== 'hub') return;
    try {
      const r = await jfetch(API.labs);
      if (!r.ok) throw new Error();
      S.labs = r.data || [];
      S.connected = true;
      const total = S.labs.reduce((n, l) => n + (l.lab_id === S.lab && S.open ? 0 : (l.unread || 0)), 0);
      if (total > S.unread && !S.open) flashTitle('💬 New lab message');
      setUnread(total);
      labSelect.replaceChildren();
      if (!S.labs.length) labSelect.add(new Option('No approved labs available', ''));
      else {
        if (!S.lab || !S.labs.some(l => l.lab_id === S.lab)) S.lab = S.labs[0].lab_id;
        S.labs.forEach(l => labSelect.add(new Option((l.online ? '● ' : '○ ') + l.lab_name + (l.unread && l.lab_id !== S.lab ? '  (' + l.unread + ' new)' : ''), l.lab_id)));
        labSelect.value = S.lab;
      }
      const cur = S.labs.find(l => l.lab_id === S.lab);
      S.labName = cur ? cur.lab_name : ''; S.peerOnline = cur ? cur.online : null;
    } catch (_) { S.connected = false; }
    updateStatus();
  }
  async function refresh() {
    if (MODE === 'hub' && !S.lab) return;
    try {
      const r = await jfetch(API.messages(S.lab));
      const list = r.data.messages || [];
      let ok;
      if (MODE === 'hub') {
        if (!r.ok) throw new Error(r.data.error || 'error');
        if (r.data.lab) S.peerOnline = r.data.lab.online;
        ok = true;
      } else ok = r.ok && r.data.success !== false;
      S.connected = ok;
      if (!ok && !list.length) { updateStatus(); return; }
      const arrivals = list.filter(m => m.direction !== MINE && !S.known.has(m.message_id));
      arrivals.forEach(m => S.known.add(m.message_id));
      if (S.booted && !S.open && arrivals.some(m => (m.kind || 'text') !== 'call')) {
        setUnread(S.unread + arrivals.filter(m => (m.kind || 'text') !== 'call').length);
        flashTitle('💬 New message');
      }
      S.booted = true;
      S.messages = list;
      S.pending = S.pending.filter(p => p.state === 'failed');           // delivered ones now live in the list
      renderThread();
    } catch (_) { S.connected = false; }
    updateStatus();
  }
  async function markRead() { if (API.read) { try { await jfetch(API.read, { method: 'POST' }); } catch (_) { /* retried next open */ } } }
  let titleTimer = 0, origTitle = document.title;
  function flashTitle(text) {
    if (!document.hidden) return;
    clearInterval(titleTimer); let on = false;
    titleTimer = setInterval(() => { on = !on; document.title = on ? text : origTitle; }, 900);
    const stop = () => { clearInterval(titleTimer); document.title = origTitle; document.removeEventListener('visibilitychange', stop); };
    document.addEventListener('visibilitychange', stop);
  }

  // ---------- sending ----------
  async function sendText(text) {
    text = (text || '').trim();
    if (!text || (MODE === 'hub' && !S.lab)) return;
    const p = { id: 'p' + Date.now() + Math.random(), kind: 'text', text, state: 'sending' };
    const sev = S.severity;
    p.retry = async () => {
      const r = await postJSON(API.send(S.lab), { body: text, severity: sev, kind: 'text' });
      if (r.ok && r.data.success !== false) { await refresh(); } else { p.state = 'failed'; S.pending = S.pending.slice(); toast(r.data.error || 'Message was not sent'); renderThread(true); }
    };
    S.pending.push(p); renderThread(true);
    S.severity = 'info'; paintSeverity();
    await p.retry();
  }
  async function sendMedia(kind, blob, extra) {
    if (MODE === 'hub' && !S.lab) return;
    extra = extra || {};
    const caption = extra.caption || '';
    const p = { id: 'p' + Date.now() + Math.random(), kind, state: 'sending', duration: extra.duration, url: kind === 'image' ? URL.createObjectURL(blob) : null };
    const sev = S.severity;
    p.retry = async () => {
      const fd = new FormData();
      fd.append('file', blob, kind === 'image' ? (extra.name || 'image') : 'voice');
      fd.append('kind', kind); fd.append('severity', sev); fd.append('body', caption);
      if (extra.duration != null) fd.append('duration', String(extra.duration));
      try {
        const r = await jfetch(API.send(S.lab), { method: 'POST', body: fd });
        if (r.ok && r.data.success !== false) { if (p.url) URL.revokeObjectURL(p.url); await refresh(); return; }
        throw new Error(r.data.error || 'Not sent');
      } catch (e) { p.state = 'failed'; toast(e.message || 'Not sent'); renderThread(true); }
    };
    S.pending.push(p); renderThread(true);
    S.severity = 'info'; paintSeverity();
    await p.retry();
  }
  async function prepareImage(file) {
    if (!/^image\/(png|jpe?g|gif|webp)$/.test(file.type)) { toast('Only PNG, JPEG, GIF or WebP images'); return null; }
    if (file.type === 'image/gif' || (file.size < 1.2 * 1024 * 1024 && file.type !== 'image/png')) return file;
    try {                                    // shrink big photos/screenshots before upload
      const bmp = await createImageBitmap(file);
      const scale = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
      if (scale === 1 && file.size < 2 * 1024 * 1024) return file;
      const c = document.createElement('canvas'); c.width = Math.round(bmp.width * scale); c.height = Math.round(bmp.height * scale);
      const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(bmp, 0, 0, c.width, c.height);
      const blob = await new Promise(res => c.toBlob(res, 'image/jpeg', 0.86));
      return blob && blob.size < file.size ? new File([blob], (file.name || 'image').replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' }) : file;
    } catch (_) { return file; }
  }
  async function stageImage(file) {
    if (!file) return;
    const prepared = await prepareImage(file);
    if (!prepared) return;
    if (prepared.size > 8 * 1024 * 1024) { toast('Images are limited to 8 MB'); return; }
    if (S.attach) URL.revokeObjectURL(S.attach.url);
    S.attach = { blob: prepared, url: URL.createObjectURL(prepared), name: prepared.name };
    attachBar.hidden = false; attachBar.replaceChildren(
      h('img', { src: S.attach.url, alt: 'Selected image preview' }),
      h('span', { text: 'Add a caption (optional) and press send' }),
      h('button', { type: 'button', class: 'sm2-cbtn', 'aria-label': 'Remove image', onclick: clearAttach }, icon('close', 18)));
    input.focus(); onInput(); renderQuick();
  }
  function clearAttach() {
    if (S.attach) URL.revokeObjectURL(S.attach.url);
    S.attach = null; attachBar.hidden = true; attachBar.replaceChildren(); onInput(); renderQuick();
  }
  function paintSeverity() {
    sevBtn.className = 'sm2-sev ' + S.severity; sevBtn.textContent = S.severity.toUpperCase();
  }
  function onInput() {
    input.style.height = 'auto'; input.style.height = Math.min(input.scrollHeight, 96) + 'px';
    const has = input.value.trim() || S.attach;
    sendBtn.replaceChildren(icon(has ? 'send' : 'mic', 22));
    sendBtn.setAttribute('aria-label', has ? 'Send message' : 'Record voice message');
    sendBtn.classList.toggle('is-mic', !has);
    renderQuick();
    const now = Date.now();
    if (input.value && now - S.lastTypingSent > 3000 && (MODE === 'lab' || S.lab)) {
      S.lastTypingSent = now;
      postJSON(API.signal(S.lab), { kind: 'typing', payload: { client_id: CLIENT_ID } }).catch(() => {});
    }
  }
  function submit() {
    if (S.attach) { const a = S.attach; S.attach = null; attachBar.hidden = true; attachBar.replaceChildren(); const cap = input.value.trim(); input.value = ''; onInput(); sendMedia('image', a.blob, { caption: cap, name: a.name }); return; }
    const text = input.value.trim();
    if (!text) { startRecording(); return; }
    input.value = ''; onInput(); sendText(text);
  }

  // ---------- voice recording ----------
  function pickMime() {
    const list = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];
    return list.find(t => window.MediaRecorder && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(t)) || '';
  }
  async function startRecording() {
    if (S.recording) return;
    if (!secure() || !window.MediaRecorder) { toast(window.isSecureContext ? 'Voice recording is not supported in this browser' : 'Voice needs HTTPS or localhost'); return; }
    let stream;
    try { stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }); }
    catch (_) { toast('Microphone permission was denied'); return; }
    const mime = pickMime();
    const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
    const R = { rec, stream, chunks: [], start: Date.now(), timer: 0, send: false };
    rec.ondataavailable = (e) => { if (e.data && e.data.size) R.chunks.push(e.data); };
    rec.onstop = () => {
      stream.getTracks().forEach(t => t.stop());
      const dur = (Date.now() - R.start) / 1000;
      if (!R.send) return;
      if (dur < 0.7 || !R.chunks.length) { toast('Recording was too short'); return; }
      sendMedia('voice', new Blob(R.chunks, { type: rec.mimeType || 'audio/webm' }), { duration: Math.min(300, dur) });
    };
    rec.start(250);
    R.timer = setInterval(() => {
      const s = (Date.now() - R.start) / 1000; recTime.textContent = fmtDur(s);
      if (s >= 300) stopRecording(true);
    }, 200);
    S.recording = R; recTime.textContent = '0:00';
    recBar.hidden = false; composeRow.hidden = true; renderQuick();
  }
  function stopRecording(send) {
    const R = S.recording; if (!R) return;
    clearInterval(R.timer); R.send = !!send; S.recording = null;
    recBar.hidden = true; composeRow.hidden = false;
    try { R.rec.stop(); } catch (_) { R.stream.getTracks().forEach(t => t.stop()); }
    renderQuick();
  }

  // ---------- calls (WebRTC; Hub relays signalling only) ----------
  const CALL = { state: 'idle', id: null, media: 'audio', initiator: false, pc: null, local: null, pendingIce: [],
    lab: '', peer: '', connectedAt: 0, ringTimer: 0, tick: 0, muted: false, camOff: false, ice: null, endedReason: '' };
  let signalChain = Promise.resolve();
  const bc = ('BroadcastChannel' in window) ? new BroadcastChannel('sentryusb-messenger-' + MODE) : null;
  if (bc) bc.onmessage = (e) => { if (e.data && e.data.t === 'handled' && CALL.state === 'ringing' && CALL.id === e.data.id) dismissRinging(); };

  const callEls = {};
  function buildCallUI() {
    if (callEls.root) return;
    callEls.remote = h('video', { class: 'sm2-remote', autoplay: '', playsinline: '' });
    callEls.local = h('video', { class: 'sm2-local', autoplay: '', playsinline: '', muted: '' });
    callEls.local.muted = true;
    callEls.name = h('div', { class: 'sm2-call-name' });
    callEls.status = h('div', { class: 'sm2-call-status' });
    callEls.avatar = h('div', { class: 'sm2-call-avatar' }, icon('shield', 54));
    callEls.mute = h('button', { class: 'sm2-cc', type: 'button', 'aria-label': 'Mute microphone', onclick: toggleMute }, icon('mic', 24));
    callEls.cam = h('button', { class: 'sm2-cc', type: 'button', 'aria-label': 'Turn camera off', onclick: toggleCam }, icon('video', 24));
    callEls.hang = h('button', { class: 'sm2-cc hang', type: 'button', 'aria-label': 'End call', onclick: () => endCall('hangup') }, icon('hangup', 26));
    callEls.root = h('div', { class: 'sm2-call', hidden: '', role: 'dialog', 'aria-label': 'Call' },
      h('div', { class: 'sm2-call-stage' }, callEls.remote, h('div', { class: 'sm2-call-center' }, callEls.avatar, callEls.name, callEls.status), callEls.local),
      h('div', { class: 'sm2-call-controls' }, callEls.mute, callEls.cam, callEls.hang));
    document.body.append(callEls.root);
  }
  function buildRingUI() {
    if (callEls.ring) return;
    callEls.ringName = h('div', { class: 'sm2-ring-name' });
    callEls.ringKind = h('div', { class: 'sm2-ring-kind' });
    callEls.ring = h('div', { class: 'sm2-ring', hidden: '', role: 'alertdialog', 'aria-label': 'Incoming call' },
      h('div', { class: 'sm2-ring-av' }, icon('phone', 26)),
      h('div', { class: 'sm2-ring-text' }, callEls.ringKind, callEls.ringName),
      h('button', { class: 'sm2-cc hang small', type: 'button', 'aria-label': 'Decline call', onclick: declineCall }, icon('hangup', 22)),
      h('button', { class: 'sm2-cc accept small', type: 'button', 'aria-label': 'Accept call', onclick: acceptCall }, icon('phone', 22)));
    document.body.append(callEls.ring);
  }
  const callKind = (media) => media === 'video' ? 'Video call' : 'Voice call';
  function paintCall() {
    buildCallUI();
    const video = CALL.media === 'video';
    callEls.root.hidden = CALL.state === 'idle' || CALL.state === 'ringing';
    callEls.root.classList.toggle('audio-only', !video);
    callEls.root.classList.toggle('connected', CALL.state === 'connected');
    callEls.name.textContent = CALL.peer || PEER_DEFAULT;
    const labels = { calling: 'Calling…', connecting: 'Connecting…', connected: fmtDur((Date.now() - CALL.connectedAt) / 1000) };
    callEls.status.textContent = labels[CALL.state] || '';
    callEls.cam.hidden = !video;
    callEls.mute.replaceChildren(icon(CALL.muted ? 'micOff' : 'mic', 24));
    callEls.mute.classList.toggle('off', CALL.muted);
    callEls.cam.replaceChildren(icon(CALL.camOff ? 'videoOff' : 'video', 24));
    callEls.cam.classList.toggle('off', CALL.camOff);
    updateStatus();
  }
  function toggleMute() { CALL.muted = !CALL.muted; (CALL.local ? CALL.local.getAudioTracks() : []).forEach(t => { t.enabled = !CALL.muted; }); paintCall(); }
  function toggleCam() { CALL.camOff = !CALL.camOff; (CALL.local ? CALL.local.getVideoTracks() : []).forEach(t => { t.enabled = !CALL.camOff; }); paintCall(); }

  // ringtone (WebAudio - no asset files)
  let toneCtx = null, toneTimer = 0;
  function startTone(kind) {
    stopTone();
    try {
      toneCtx = new (window.AudioContext || window.webkitAudioContext)();
      const gain = toneCtx.createGain(); gain.gain.value = 0.06; gain.connect(toneCtx.destination);
      const beep = () => {
        [0, 0.22].forEach((off, i) => {
          const o = toneCtx.createOscillator(); o.type = 'sine';
          o.frequency.value = kind === 'in' ? (i ? 988 : 784) : 440;
          o.connect(gain); o.start(toneCtx.currentTime + off); o.stop(toneCtx.currentTime + off + 0.18);
        });
      };
      beep(); toneTimer = setInterval(beep, kind === 'in' ? 1600 : 2400);
    } catch (_) { /* audio blocked until the user interacts - the visual ring still shows */ }
  }
  function stopTone() { clearInterval(toneTimer); toneTimer = 0; if (toneCtx) { try { toneCtx.close(); } catch (_) { /* already closed */ } toneCtx = null; } }

  async function postSignal(kind, payload, callId, lab) {
    const body = { kind, call_id: callId || CALL.id || '', payload: Object.assign({ client_id: CLIENT_ID }, payload || {}) };
    try { return await postJSON(API.signal(lab || CALL.lab || S.lab), body); } catch (_) { return { ok: false, data: {} }; }
  }
  async function getIce() {
    if (CALL.ice) return CALL.ice;
    try { const r = await jfetch(API.ice); CALL.ice = (r.data && r.data.iceServers) || []; } catch (_) { CALL.ice = []; }
    if (!CALL.ice.length) CALL.ice = [{ urls: ['stun:stun.l.google.com:19302'] }];
    return CALL.ice;
  }
  async function getMedia(media) {
    const audio = { echoCancellation: true, noiseSuppression: true };
    if (media !== 'video') return navigator.mediaDevices.getUserMedia({ audio, video: false });
    try { return await navigator.mediaDevices.getUserMedia({ audio, video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' } }); }
    catch (e) { toast('Camera unavailable – continuing with audio only'); CALL.media = 'audio'; return navigator.mediaDevices.getUserMedia({ audio, video: false }); }
  }
  async function createPC() {
    const pc = new RTCPeerConnection({ iceServers: await getIce() });
    CALL.pc = pc;
    (CALL.local ? CALL.local.getTracks() : []).forEach(t => pc.addTrack(t, CALL.local));
    pc.onicecandidate = (e) => { if (e.candidate) postSignal('ice', { candidate: e.candidate.toJSON() }); };
    pc.ontrack = (e) => {
      if (callEls.remote.srcObject !== e.streams[0]) callEls.remote.srcObject = e.streams[0];
      callEls.remote.play().catch(() => {});
    };
    pc.onconnectionstatechange = () => {
      if (pc !== CALL.pc) return;
      if (pc.connectionState === 'connected' && CALL.state !== 'connected') {
        CALL.state = 'connected'; CALL.connectedAt = Date.now(); stopTone();
        clearInterval(CALL.tick); CALL.tick = setInterval(paintCall, 1000); paintCall();
      } else if (pc.connectionState === 'failed') {
        toast('Call could not connect – a TURN relay may be needed on this network'); endCall('failed');
      } else if (pc.connectionState === 'disconnected') {
        setTimeout(() => { if (pc === CALL.pc && pc.connectionState === 'disconnected') endCall('failed'); }, 8000);
      }
    };
    return pc;
  }
  function callGuard() {
    if (CALL.state !== 'idle') return false;
    if (MODE === 'hub' && !S.lab) { toast('Select a lab first'); return false; }
    if (!secure() || !window.RTCPeerConnection) {
      toast(window.isSecureContext ? 'Calls are not supported in this browser' : 'Calls need HTTPS or localhost (microphone access)');
      return false;
    }
    return true;
  }
  async function startCall(media) {
    if (!callGuard()) return;
    CALL.media = media; CALL.initiator = true; CALL.lab = S.lab; CALL.peer = peerName();
    CALL.id = 'call_' + CLIENT_ID + Date.now().toString(36); CALL.muted = CALL.camOff = false; CALL.pendingIce = [];
    try { CALL.local = await getMedia(media); }
    catch (_) { toast('Could not access the microphone' + (media === 'video' ? '/camera' : '')); CALL.id = null; return; }
    CALL.state = 'calling'; buildCallUI();
    callEls.local.srcObject = CALL.local; callEls.local.play().catch(() => {});
    paintCall(); startTone('out');
    const r = await postSignal('invite', { media: CALL.media, from: SELF_NAME });
    if (!r.ok) { toast((r.data && r.data.error) || 'Could not reach the other side'); return finishCall('failed'); }
    CALL.ringTimer = setTimeout(() => endCall('missed'), 45000);
  }
  function onInvite(sig) {
    if (CALL.state !== 'idle') { postSignal('busy', {}, sig.call_id, sig.lab_id || CALL.lab); return; }
    CALL.id = sig.call_id; CALL.media = (sig.payload && sig.payload.media) === 'video' ? 'video' : 'audio';
    CALL.initiator = false; CALL.state = 'ringing'; CALL.lab = sig.lab_id || S.lab; CALL.pendingIce = [];
    const lab = MODE === 'hub' ? S.labs.find(l => l.lab_id === sig.lab_id) : null;
    CALL.peer = MODE === 'hub' ? (lab ? lab.lab_name : 'A lab') : ((sig.payload && sig.payload.from) || 'SentryUSB Hub');
    buildRingUI();
    callEls.ringName.textContent = CALL.peer; callEls.ringKind.textContent = 'Incoming ' + callKind(CALL.media).toLowerCase();
    callEls.ring.hidden = false; startTone('in'); flashTitle('📞 Incoming call');
    CALL.ringTimer = setTimeout(dismissRinging, 45000);
  }
  function dismissRinging() {
    clearTimeout(CALL.ringTimer); stopTone();
    if (callEls.ring) callEls.ring.hidden = true;
    if (CALL.state === 'ringing') { CALL.state = 'idle'; CALL.id = null; }
    updateStatus();
  }
  async function acceptCall() {
    if (CALL.state !== 'ringing') return;
    clearTimeout(CALL.ringTimer); stopTone(); callEls.ring.hidden = true;
    if (bc) bc.postMessage({ t: 'handled', id: CALL.id });
    if (MODE === 'hub' && CALL.lab && CALL.lab !== S.lab) { S.lab = CALL.lab; labSelect.value = S.lab; S.messages = []; S.sig = ''; await refresh(); }
    if (!secure() || !window.RTCPeerConnection) { toast('Calls need HTTPS or localhost'); await postSignal('decline', {}); return finishCall('failed'); }
    try { CALL.local = await getMedia(CALL.media); }
    catch (err) { toast('Call could not start: allow microphone/camera access in browser site settings, then try again.'); await postSignal('end', { reason: 'media_permission_denied' }); return finishCall('failed'); }
    CALL.state = 'connecting'; CALL.muted = CALL.camOff = false; buildCallUI();
    callEls.local.srcObject = CALL.local; callEls.local.play().catch(() => {});
    await createPC(); paintCall();
    await postSignal('accept', { media: CALL.media });
  }
  async function declineCall() {
    if (CALL.state !== 'ringing') return;
    if (bc) bc.postMessage({ t: 'handled', id: CALL.id });
    await postSignal('decline', {});
    dismissRinging();
  }
  async function endCall(reason) {
    if (CALL.state === 'idle' || CALL.state === 'ringing') return;
    await postSignal('end', { reason });
    finishCall(reason);
  }
  function finishCall(reason) {
    if (CALL.state === 'idle') return;
    const wasConnected = CALL.state === 'connected', secs = wasConnected ? (Date.now() - CALL.connectedAt) / 1000 : 0;
    const initiator = CALL.initiator, media = CALL.media, lab = CALL.lab;
    clearTimeout(CALL.ringTimer); clearInterval(CALL.tick); stopTone();
    if (CALL.local) CALL.local.getTracks().forEach(t => t.stop());
    if (CALL.pc) { try { CALL.pc.close(); } catch (_) { /* closed */ } }
    if (callEls.remote) callEls.remote.srcObject = null;
    if (callEls.local) callEls.local.srcObject = null;
    Object.assign(CALL, { state: 'idle', id: null, pc: null, local: null, pendingIce: [], connectedAt: 0 });
    if (callEls.root) callEls.root.hidden = true;
    if (callEls.ring) callEls.ring.hidden = true;
    if (initiator) {                       // exactly one side (the caller) writes the call-log line
      const k = callKind(media);
      const text = wasConnected ? k + ' · ' + fmtDur(secs) :
        ({ missed: 'Missed ' + k.toLowerCase(), declined: 'Declined ' + k.toLowerCase(), busy: 'Line busy – ' + k.toLowerCase(), failed: k + ' failed' })[reason] || 'Cancelled ' + k.toLowerCase();
      postJSON(API.send(lab), { kind: 'call', body: text, severity: 'info' }).then(refresh).catch(() => {});
    }
    toast(wasConnected ? 'Call ended · ' + fmtDur(secs) : 'Call ended');
    updateStatus();
  }
  async function flushIce() {
    const q = CALL.pendingIce.splice(0);
    for (const c of q) { try { await CALL.pc.addIceCandidate(c); } catch (_) { /* stale candidate */ } }
  }
  async function handleSignal(sig) {
    const p = sig.payload || {};
    if (sig.kind === 'typing') {
      if (MODE === 'lab' || sig.lab_id === S.lab) { S.typingUntil = Date.now() + 4500; updateStatus(); setTimeout(updateStatus, 4600); }
      return;
    }
    if (p.client_id === CLIENT_ID) return;
    if (sig.kind === 'invite') return onInvite(sig);
    if (sig.call_id !== CALL.id) return;
    if (sig.kind === 'accept' && CALL.initiator && CALL.state === 'calling') {
      clearTimeout(CALL.ringTimer); stopTone(); CALL.state = 'connecting'; paintCall();
      const pc = await createPC();
      const offer = await pc.createOffer(); await pc.setLocalDescription(offer);
      await postSignal('offer', { sdp: pc.localDescription.toJSON ? pc.localDescription.toJSON() : { type: offer.type, sdp: offer.sdp } });
    } else if (sig.kind === 'offer' && !CALL.initiator && CALL.pc) {
      await CALL.pc.setRemoteDescription(p.sdp); await flushIce();
      const answer = await CALL.pc.createAnswer(); await CALL.pc.setLocalDescription(answer);
      await postSignal('answer', { sdp: { type: answer.type, sdp: answer.sdp } });
    } else if (sig.kind === 'answer' && CALL.initiator && CALL.pc) {
      await CALL.pc.setRemoteDescription(p.sdp); await flushIce();
    } else if (sig.kind === 'ice' && p.candidate) {
      if (CALL.pc && CALL.pc.remoteDescription) { try { await CALL.pc.addIceCandidate(p.candidate); } catch (_) { /* ignore */ } }
      else CALL.pendingIce.push(p.candidate);
    } else if (sig.kind === 'decline') { finishCall('declined'); }
    else if (sig.kind === 'busy') { finishCall('busy'); }
    else if (sig.kind === 'end') { CALL.state === 'ringing' ? dismissRinging() : finishCall(p.reason === 'missed' ? 'missed' : 'ended'); }
  }
  const queueSignal = (sig) => { signalChain = signalChain.then(() => handleSignal(sig)).catch((e) => console.warn('call signal error', e)); };
  let sigCursor = null;
  let lastSignalErrorToast = 0;
  async function signalLoop() {
    try {
      const r = await jfetch(API.signals + '?after=' + (sigCursor === null ? -1 : sigCursor));
      if (r.ok) {
        const list = r.data.signals || [];
        if (sigCursor === null) sigCursor = r.data.latest || 0;       // first call = "start listening from now"
        else {
          list.forEach(s => { sigCursor = Math.max(sigCursor, s.seq); queueSignal(s); });
          if (!list.length && typeof r.data.latest === 'number' && r.data.latest > sigCursor) sigCursor = r.data.latest;
        }
      }
    } catch (_) { if (CALL.state !== 'idle' && Date.now() - lastSignalErrorToast > 12000) { lastSignalErrorToast = Date.now(); toast('Call signalling connection interrupted; retrying…'); } }
    setTimeout(signalLoop, CALL.state !== 'idle' ? 700 : (S.open ? 1000 : 2000));
  }

  // ---------- wiring ----------
  launcher.addEventListener('click', async () => {
    S.open = !S.open; panel.classList.toggle('open', S.open);
    if (S.open) {
      document.dispatchEvent(new CustomEvent('sentryusb:messenger-open'));
      if (MODE === 'hub') await loadLabs();
      setUnread(0); await refresh(); renderThread(true); markRead(); input.focus();
    }
  });
  closeBtn.addEventListener('click', () => { S.open = false; panel.classList.remove('open'); if (S.recording) stopRecording(false); });
  document.addEventListener('sentryusb:ai-open', () => { if (S.open) { S.open = false; panel.classList.remove('open'); } });
  labSelect.addEventListener('change', async () => {
    S.lab = labSelect.value; try { localStorage.setItem('sm2-lab', S.lab); } catch (_) { /* ignore */ }
    S.messages = []; S.pending = []; S.sig = ''; S.known = new Set(); S.booted = false;
    const cur = S.labs.find(l => l.lab_id === S.lab); S.labName = cur ? cur.lab_name : ''; S.peerOnline = cur ? cur.online : null;
    await refresh(); renderThread(true); updateStatus();
  });
  voiceBtn.addEventListener('click', () => startCall('audio'));
  videoBtn.addEventListener('click', () => startCall('video'));
  sendBtn.addEventListener('click', submit);
  imgBtn.addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', () => { stageImage(fileInput.files[0]); fileInput.value = ''; });
  emojiBtn.addEventListener('click', () => { emojiTray.hidden = !emojiTray.hidden; });
  sevBtn.addEventListener('click', () => { S.severity = S.severity === 'info' ? 'warning' : S.severity === 'warning' ? 'critical' : 'info'; paintSeverity(); });
  input.addEventListener('input', onInput);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); } });
  input.addEventListener('paste', (e) => {
    const f = Array.from((e.clipboardData && e.clipboardData.files) || []).find(x => x.type.startsWith('image/'));
    if (f) { e.preventDefault(); stageImage(f); }
  });
  ['dragenter', 'dragover'].forEach(ev => panel.addEventListener(ev, (e) => { if (e.dataTransfer && Array.from(e.dataTransfer.types).includes('Files')) { e.preventDefault(); drop.hidden = false; } }));
  ['dragleave', 'drop'].forEach(ev => panel.addEventListener(ev, (e) => {
    if (ev === 'drop') { e.preventDefault(); const f = e.dataTransfer && e.dataTransfer.files[0]; if (f) stageImage(f); }
    drop.hidden = true;
  }));
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && S.open && !S.recording) { S.open = false; panel.classList.remove('open'); } });
  window.addEventListener('pagehide', () => {               // closing the tab mid-call hangs up for the other side
    if (CALL.id && CALL.state !== 'idle' && CALL.state !== 'ringing' && navigator.sendBeacon) {
      const body = new Blob([JSON.stringify({ kind: 'end', call_id: CALL.id, payload: { client_id: CLIENT_ID, reason: 'hangup' } })], { type: 'application/json' });
      navigator.sendBeacon(API.signal(CALL.lab || S.lab), body);
    }
  });

  paintSeverity(); onInput(); updateStatus();
  if (MODE === 'hub') loadLabs(); else refresh();
  setInterval(() => { if (document.hidden) return; if (MODE === 'hub') { loadLabs(); if (S.open) refresh(); } else refresh(); }, 6000);
  setInterval(() => { if (S.open && !document.hidden) refresh(); }, 2500);
  signalLoop();
  window.SentryMessenger = { startCall, version: 2 };
})();
