// SentryUSB HUB - client-side helpers (vanilla JS, no dependencies)

function toggleEditPanel(id) {
  const el = document.getElementById(id);
  if (el) el.classList.toggle('open');
}

function copyText(text, btn) {
  navigator.clipboard.writeText(text).then(() => {
    if (btn) {
      const original = btn.textContent;
      btn.textContent = 'Copied!';
      setTimeout(() => { btn.textContent = original; }, 1500);
    }
  });
}

function toggleReveal(spanId, btn) {
  const el = document.getElementById(spanId);
  if (!el) return;
  const isMasked = el.dataset.masked === 'true';
  el.textContent = isMasked ? el.dataset.full : el.dataset.hidden;
  el.dataset.masked = isMasked ? 'false' : 'true';
  btn.textContent = isMasked ? 'Hide' : 'Show';
}

function filterTable(inputEl, tableSelector) {
  const q = inputEl.value.trim().toLowerCase();
  const table = document.querySelector(tableSelector);
  if (!table) return;
  const rows = table.querySelectorAll('tbody tr');
  rows.forEach(row => {
    const haystack = (row.dataset.search || row.textContent).toLowerCase();
    row.style.display = haystack.includes(q) ? '' : 'none';
  });
}

function toggleAllChecks(masterCheckbox, name) {
  document.querySelectorAll(`input[type=checkbox][name="${name}"]`).forEach(cb => {
    cb.checked = masterCheckbox.checked;
  });
}

// Auto-dismiss toasts after a few seconds
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.toast').forEach((toast, i) => {
    setTimeout(() => { toast.style.transition = 'opacity .4s'; toast.style.opacity = '0'; setTimeout(() => toast.remove(), 400); }, 4200 + i * 250);
  });
});

// Live dashboard refresh: poll /api/hub/summary every 15s and patch stat cards
// + online dots in place, so the hub admin doesn't need to hit F5 to see a
// lab come online or a heartbeat land.
function startLiveSummary() {
  const els = {
    total: document.querySelector('[data-live="total"]'),
    pending: document.querySelector('[data-live="pending"]'),
    approved: document.querySelector('[data-live="approved"]'),
    online: document.querySelector('[data-live="online"]'),
    agents: document.querySelector('[data-live="fleet-agents"]'),
    events: document.querySelector('[data-live="fleet-events"]'),
    blocked: document.querySelector('[data-live="fleet-blocked"]'),
  };
  const hasAnyTarget = Object.values(els).some(Boolean);
  if (!hasAnyTarget) return;

  async function poll() {
    try {
      const res = await fetch('/api/hub/summary', { credentials: 'same-origin' });
      if (!res.ok) return;
      const data = await res.json();
      if (els.total) els.total.textContent = data.summary.total;
      if (els.pending) els.pending.textContent = data.summary.pending;
      if (els.approved) els.approved.textContent = data.summary.approved;
      if (els.online) els.online.textContent = data.summary.online;
      if (els.agents) els.agents.textContent = data.fleet.agents;
      if (els.events) els.events.textContent = data.fleet.events_total;
      if (els.blocked) els.blocked.textContent = data.fleet.blocked_devices;

      document.querySelectorAll('[data-lab-online]').forEach(dot => {
        const labId = dot.getAttribute('data-lab-online');
        const isOnline = data.online_lab_ids.includes(labId);
        dot.classList.toggle('online', isOnline);
        dot.classList.toggle('offline', !isOnline);
      });
    } catch (e) { /* silent - network hiccup, try again next tick */ }
  }
  poll();
  setInterval(poll, 15000);
}

document.addEventListener('DOMContentLoaded', startLiveSummary);

// ============================================================
// PRO UI ENHANCEMENTS v2.1
// ============================================================

// Mobile sidebar toggle
function toggleSidebar() {
  const sb = document.querySelector('.sidebar');
  if (sb) sb.classList.toggle('open');
}

// Bulk-selection floating action bar for the Labs table
function initBulkBar() {
  const bar = document.getElementById('bulk-bar');
  if (!bar) return;
  const checkboxes = () => Array.from(document.querySelectorAll('input[type=checkbox][name="lab_ids"]'));
  const countEl = document.getElementById('bulk-count');

  function refresh() {
    const checked = checkboxes().filter(cb => cb.checked);
    if (checked.length > 0) {
      bar.classList.add('show');
      if (countEl) countEl.textContent = checked.length;
    } else {
      bar.classList.remove('show');
    }
  }
  checkboxes().forEach(cb => cb.addEventListener('change', refresh));
  const master = document.getElementById('master-check');
  if (master) master.addEventListener('change', refresh);
  refresh();
}

// Generic client-side table sort (works on any <table> with sortable <th data-sort-key>)
function initSortableTables() {
  document.querySelectorAll('table').forEach(table => {
    const headers = table.querySelectorAll('th.sortable');
    if (!headers.length) return;
    headers.forEach((th, idx) => {
      th.addEventListener('click', () => {
        const tbody = table.querySelector('tbody');
        if (!tbody) return;
        const rows = Array.from(tbody.querySelectorAll('tr'));
        const key = th.dataset.sortKey || idx;
        const asc = !th.classList.contains('sort-asc');
        headers.forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
        th.classList.add(asc ? 'sort-asc' : 'sort-desc');

        const cellIndex = Array.from(th.parentNode.children).indexOf(th);
        rows.sort((a, b) => {
          const av = (a.children[cellIndex]?.dataset.sortVal ?? a.children[cellIndex]?.textContent ?? '').trim();
          const bv = (b.children[cellIndex]?.dataset.sortVal ?? b.children[cellIndex]?.textContent ?? '').trim();
          const an = parseFloat(av), bn = parseFloat(bv);
          let cmp;
          if (!isNaN(an) && !isNaN(bn)) cmp = an - bn;
          else cmp = av.localeCompare(bv);
          return asc ? cmp : -cmp;
        });
        rows.forEach(r => tbody.appendChild(r));
      });
    });
  });
}

// "/" focuses the nearest search box, Escape blurs it
document.addEventListener('keydown', (e) => {
  if (e.key === '/' && document.activeElement.tagName !== 'INPUT' && document.activeElement.tagName !== 'TEXTAREA') {
    const box = document.querySelector('.search-box input');
    if (box) { e.preventDefault(); box.focus(); }
  }
  if (e.key === 'Escape' && document.activeElement.tagName === 'INPUT') {
    document.activeElement.blur();
  }
});

document.addEventListener('DOMContentLoaded', () => {
  initBulkBar();
  initSortableTables();
});
