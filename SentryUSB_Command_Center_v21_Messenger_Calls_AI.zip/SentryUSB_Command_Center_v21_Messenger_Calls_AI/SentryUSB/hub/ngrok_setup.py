"""
SentryUSB Hub - ngrok tunnel with permanent static domain
Uses ngrok's free static domain (one per account) that never rotates.
"""
import os
import sys
import time
import subprocess
import signal
import requests
import json
import platform
import threading

class HubNgrokTunnel:
    def __init__(self, local_port=6800, static_domain=None, auth_token=None):
        self.local_port = local_port
        self.static_domain = static_domain  # e.g. "myhub.ngrok-free.dev"
        self.auth_token = auth_token
        self.ngrok_process = None
        self.public_url = None
        self.is_running = False
        self.watchdog_thread = None
        self.stop_event = threading.Event()

    def is_ngrok_installed(self):
        try:
            result = subprocess.run(["ngrok", "--version"], capture_output=True, timeout=5)
            return result.returncode == 0
        except:
            return False

    def install_ngrok(self):
        print("📦 Installing ngrok...")
        import urllib.request
        import zipfile
        system = platform.system().lower()
        if system == "windows":
            url = "https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-windows-amd64.zip"
            exe = "ngrok.exe"
        elif system == "darwin":
            url = "https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-darwin-amd64.zip"
            exe = "ngrok"
        else:
            url = "https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-amd64.zip"
            exe = "ngrok"

        zip_path = os.path.join(os.path.dirname(__file__), "ngrok.zip")
        urllib.request.urlretrieve(url, zip_path)
        with zipfile.ZipFile(zip_path, 'r') as zf:
            zf.extractall(os.path.dirname(__file__))
        os.remove(zip_path)
        if system != "windows":
            os.chmod(os.path.join(os.path.dirname(__file__), exe), 0o755)
        print("✅ ngrok installed")

    def start_tunnel(self):
        if not self.is_ngrok_installed():
            self.install_ngrok()

        if not self.static_domain:
            print("❌ static_domain is required. Set it in hub_config.py or env var SENTRYHUB_NGROK_DOMAIN")
            return False

        cmd = ["ngrok", "http", str(self.local_port), "--url=" + self.static_domain]
        if self.auth_token:
            cmd = ["ngrok", "config", "add-authtoken", self.auth_token] + cmd  # or use --authtoken

        # Use --authtoken if provided
        if self.auth_token:
            cmd = ["ngrok", "http", str(self.local_port), "--authtoken=" + self.auth_token, "--url=" + self.static_domain]

        # Start ngrok process
        shell = platform.system().lower() == "windows"
        self.ngrok_process = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, shell=shell)
        self.is_running = True
        print(f"🚀 Starting ngrok tunnel for {self.static_domain}...")

        # Wait and get URL
        for attempt in range(15):
            time.sleep(2)
            url = self._get_public_url()
            if url:
                self.public_url = url
                print(f"✅ Tunnel established: {url}")
                return True
        print("❌ Failed to get public URL from ngrok API")
        return False

    def _get_public_url(self):
        try:
            resp = requests.get("http://127.0.0.1:4040/api/tunnels", timeout=5)
            data = resp.json()
            for tunnel in data.get("tunnels", []):
                if tunnel.get("proto") == "https":
                    return tunnel.get("public_url")
        except:
            pass
        return None

    def _watchdog(self):
        while not self.stop_event.is_set():
            time.sleep(30)
            if not self.is_running:
                continue
            # Check if ngrok still running
            if self.ngrok_process and self.ngrok_process.poll() is not None:
                print("⚠️ ngrok process died, restarting...")
                self.stop_event.set()  # stop watchdog
                self.start_tunnel()
                # restart watchdog
                self.stop_event.clear()
                self.watchdog_thread = threading.Thread(target=self._watchdog, daemon=True)
                self.watchdog_thread.start()

    def run(self):
        if not self.start_tunnel():
            sys.exit(1)
        # Start watchdog
        self.watchdog_thread = threading.Thread(target=self._watchdog, daemon=True)
        self.watchdog_thread.start()
        print("🔄 ngrok tunnel running. Press Ctrl+C to stop.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("🛑 Shutting down...")
            self.stop()
            sys.exit(0)

    def stop(self):
        self.stop_event.set()
        if self.ngrok_process:
            self.ngrok_process.terminate()
            time.sleep(2)
            if self.ngrok_process.poll() is None:
                self.ngrok_process.kill()
        self.is_running = False
        print("✅ ngrok stopped")

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--domain", help="Static domain from ngrok (e.g., myhub.ngrok-free.dev)", required=True)
    parser.add_argument("--port", type=int, default=6800, help="Local port of hub (default 6800)")
    parser.add_argument("--auth", help="ngrok auth token (optional)")
    args = parser.parse_args()

    tunnel = HubNgrokTunnel(local_port=args.port, static_domain=args.domain, auth_token=args.auth)
    tunnel.run()