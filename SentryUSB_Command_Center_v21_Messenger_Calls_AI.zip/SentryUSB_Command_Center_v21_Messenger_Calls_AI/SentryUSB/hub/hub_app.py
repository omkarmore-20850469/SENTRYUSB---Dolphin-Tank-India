"""
SentryUSB HUB
-------------
Tier 1 of the 3-tier SentryUSB system.

    SentryUSB HUB  <----HTTPS (register/heartbeat)----  Lab Servers  <--ngrok tunnel-->  Agents

This is the centralized admin. It does NOT talk to agents directly and does
NOT receive USB events. Its only job is:

  1. Let lab servers self-register and receive a unique lab_id + hub_token
     (closing the "gap" between the hub and however many lab servers exist).
  2. Let a hub admin approve/reject/revoke labs from one dashboard.
  3. Receive lightweight heartbeats/stats from approved lab servers.
  4. Redirect the hub admin, per-lab, to that lab's own server dashboard
     using the unique URL the lab reported at registration time.

Run standalone:
    cd hub
    pip install -r requirements.txt
    python hub_app.py
"""
import csv
import functools
import io
import json
import os
import time
import uuid
import requests
from datetime import datetime, timedelta

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, Response, send_file

import hub_config as config
import hub_db as db
import messenger_media as mm

app = Flask(__name__)
app.config["SECRET_KEY"] = config.SECRET_KEY
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(hours=8)
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"
app.config["SESSION_COOKIE_SECURE"] = config.FORCE_HTTPS

db.init_db()

_failed_logins = {}
_register_rate = {}
_heartbeat_rate = {}
_messenger_rate = {}

HUB_VERSION = "2.1.0-pro"


# ============================================================
# HELPERS
# ============================================================

def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def flash(message: str, category: str = "info"):
    """Generic one-shot flash message, rendered as a toast in base.html.
    Distinct from the sensitive one-off token flash used for new hub tokens."""
    flashes = session.get("_flashes", [])
    flashes.append({"message": message, "category": category})
    session["_flashes"] = flashes[-5:]
    session.modified = True


def pop_flashes():
    flashes = session.pop("_flashes", [])
    return flashes


def org_name() -> str:
    return db.get_setting("org_name", config.ORG_NAME)


def effective_registration_secret() -> str:
    """A registration secret changed from the Settings page (stored in the
    DB) always wins over the one baked into hub_config/env vars."""
    return db.get_setting("registration_secret_override") or config.REGISTRATION_SECRET


@app.context_processor
def inject_globals():
    pending_count = 0
    try:
        pending_count = len(db.list_labs("pending"))
    except Exception:
        pass
    return {
        "org_name": org_name(),
        "hub_version": HUB_VERSION,
        "pending_count": pending_count,
        "current_user": session.get("username"),
        "flashes": pop_flashes(),
    }


def _rate_limited(bucket: dict, key: str, limit_per_minute: int) -> bool:
    now = time.time()
    count, window_start = bucket.get(key, (0, now))
    if now - window_start > 60:
        bucket[key] = (1, now)
        return False
    if count >= limit_per_minute:
        return True
    bucket[key] = (count + 1, window_start)
    return False


def _login_key():
    return f"{request.form.get('username', '')}|{request.remote_addr}"


def _is_locked_out(key):
    entry = _failed_logins.get(key)
    if not entry or not entry.get("locked_until"):
        return 0
    remaining = entry["locked_until"] - time.time()
    return max(0, int(remaining))


def _record_failed_login(key):
    entry = _failed_logins.setdefault(key, {"count": 0, "locked_until": None})
    entry["count"] += 1
    if entry["count"] >= config.LOGIN_MAX_ATTEMPTS:
        entry["locked_until"] = time.time() + config.LOGIN_LOCKOUT_SECONDS


def _clear_failed_logins(key):
    _failed_logins.pop(key, None)


def _lab_is_online(lab: dict) -> bool:
    if not lab.get("last_seen"):
        return False
    try:
        last_seen = datetime.fromisoformat(lab["last_seen"])
    except Exception:
        return False
    return (datetime.now() - last_seen).total_seconds() < config.LAB_OFFLINE_THRESHOLD_SECONDS


def _enrich_lab(lab: dict) -> dict:
    lab = dict(lab)
    lab["online"] = _lab_is_online(lab)
    try:
        lab["stats"] = json.loads(lab.get("stats_json") or "{}")
    except Exception:
        lab["stats"] = {}
    return lab


@app.after_request
def after_request(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["ngrok-skip-browser-warning"] = "true"
    return response


# ============================================================
# AUTH
# ============================================================

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        key = _login_key()
        locked = _is_locked_out(key)
        if locked:
            return render_template("login.html", error=f"Too many attempts. Try again in {locked}s.")

        username = request.form.get("username", "")
        password = request.form.get("password", "")

        if db.verify_hub_credentials(username, password):
            _clear_failed_logins(key)
            session.clear()
            session.permanent = True
            session["logged_in"] = True
            session["username"] = username
            db.touch_last_login(username)
            db.add_audit(username, "login", f"from {request.remote_addr}")
            flash(f"Welcome back, {username}.", "success")
            return redirect(url_for("dashboard"))

        _record_failed_login(key)
        db.add_audit(username or "unknown", "login_failed", f"from {request.remote_addr}")
        return render_template("login.html", error="Invalid credentials.")

    return render_template("login.html")


@app.route("/logout")
def logout():
    if session.get("username"):
        db.add_audit(session["username"], "logout", None)
    session.clear()
    return redirect(url_for("login"))


# ============================================================
# DASHBOARD / UI
# ============================================================

@app.route("/")
@login_required
def dashboard():
    labs = [_enrich_lab(l) for l in db.list_labs()]
    summary = {
        "total": len(labs),
        "pending": sum(1 for l in labs if l["status"] == "pending"),
        "approved": sum(1 for l in labs if l["status"] == "approved"),
        "revoked": sum(1 for l in labs if l["status"] == "revoked"),
        "online": sum(1 for l in labs if l["online"] and l["status"] == "approved"),
    }
    fleet = db.fleet_summary()
    recent_activity = db.get_audit_log(limit=6)
    return render_template("dashboard.html", labs=labs, summary=summary, fleet=fleet,
                            config=config, recent_activity=recent_activity)


@app.route("/api/hub/summary")
@login_required
def api_summary():
    """Polled by the dashboard's live-refresh JS so online/offline status and
    headline numbers update without a full page reload."""
    labs = [_enrich_lab(l) for l in db.list_labs()]
    summary = {
        "total": len(labs),
        "pending": sum(1 for l in labs if l["status"] == "pending"),
        "approved": sum(1 for l in labs if l["status"] == "approved"),
        "revoked": sum(1 for l in labs if l["status"] == "revoked"),
        "online": sum(1 for l in labs if l["online"] and l["status"] == "approved"),
    }
    online_ids = [l["lab_id"] for l in labs if l["online"]]
    return jsonify({"summary": summary, "fleet": db.fleet_summary(), "online_lab_ids": online_ids})


@app.route("/labs")
@login_required
def labs_page():
    status_filter = request.args.get("status")
    search = request.args.get("q")
    labs = [_enrich_lab(l) for l in db.list_labs(status_filter, search)]
    return render_template("labs.html", labs=labs, status_filter=status_filter, search=search or "")


@app.route("/labs/export.csv")
@login_required
def export_labs_csv():
    labs = db.list_labs()
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["lab_id", "lab_name", "status", "location", "contact_email",
                      "server_url", "last_seen", "agent_version", "server_version", "tags"])
    for l in labs:
        writer.writerow([l["lab_id"], l["lab_name"], l["status"], l.get("location") or "",
                          l.get("contact_email") or "", l.get("server_url") or "",
                          l.get("last_seen") or "", l.get("agent_version") or "",
                          l.get("server_version") or "", l.get("tags") or ""])
    db.add_audit(session["username"], "export_labs_csv", None)
    return Response(buf.getvalue(), mimetype="text/csv",
                     headers={"Content-Disposition": "attachment; filename=sentryusb_labs.csv"})


@app.route("/labs/bulk-approve", methods=["POST"])
@login_required
def bulk_approve_labs():
    lab_ids = request.form.getlist("lab_ids")
    approved = 0
    for lab_id in lab_ids:
        lab = db.get_lab_by_id(lab_id)
        if lab and lab["status"] == "pending":
            db.set_lab_status(lab_id, "approved")
            db.add_audit(session["username"], "lab_approved", f"{lab['lab_name']} ({lab_id}) [bulk]")
            approved += 1
    flash(f"Approved {approved} lab(s).", "success" if approved else "info")
    return redirect(request.referrer or url_for("labs_page"))


def _sparkline_points(history: list, key: str, width=280, height=48) -> str:
    """Turn a list of heartbeat rows (newest-first) into an SVG polyline
    'x,y x,y ...' string for a given numeric stats key, oldest-first."""
    values = []
    for h in reversed(history):
        try:
            values.append(float(json.loads(h.get("stats_json") or "{}").get(key) or 0))
        except Exception:
            values.append(0.0)
    if not values:
        return ""
    lo, hi = min(values), max(values)
    span = (hi - lo) or 1
    n = len(values)
    step = width / max(n - 1, 1)
    pts = []
    for i, v in enumerate(values):
        x = round(i * step, 1)
        y = round(height - ((v - lo) / span) * height, 1)
        pts.append(f"{x},{y}")
    return " ".join(pts)


@app.route("/labs/<lab_id>")
@login_required
def lab_detail(lab_id):
    lab = db.get_lab_by_id(lab_id)
    if not lab:
        return render_template("404.html"), 404
    lab = _enrich_lab(lab)
    history = db.get_heartbeat_history(lab_id, limit=50)
    sparkline = _sparkline_points(history, "events_total")
    return render_template("lab_detail.html", lab=lab, history=history, sparkline=sparkline)


@app.route("/api/hub/labs/<lab_id>/live")
@login_required
def api_lab_live_snapshot(lab_id):
    """Proxies a read-only pull from the lab server's own live-snapshot
    endpoint. The lab server's hub_token never reaches the admin's browser -
    it stays here on the hub side. This is look-only: nothing sent to the
    lab server here can change anything on it."""
    lab = db.get_lab_by_id(lab_id)
    if not lab:
        return jsonify({"error": "lab not found"}), 404
    if not lab.get("server_url"):
        return jsonify({"error": "this lab hasn't reported a server URL yet"}), 400
    try:
        resp = requests.get(
            lab["server_url"].rstrip("/") + "/api/hub/live-snapshot",
            headers={"X-Hub-Token": lab["hub_token"]},
            timeout=8,
        )
        if resp.status_code != 200:
            return jsonify({"error": f"lab server returned {resp.status_code}"}), 502
        return jsonify(resp.json())
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"could not reach lab server: {e}"}), 502


@app.route("/api/hub/labs/<lab_id>/message", methods=["POST"])
@login_required
def api_lab_send_message(lab_id):
    """Sends a live message down to this lab's server. This is the ONLY
    thing the hub can push to a lab - a message someone there has to read
    and act on themselves. There is no remote-control path from here."""
    lab = db.get_lab_by_id(lab_id)
    if not lab:
        return jsonify({"error": "lab not found"}), 404
    if not lab.get("server_url"):
        return jsonify({"error": "this lab hasn't reported a server URL yet"}), 400

    data = request.get_json(force=True) or {}
    message = (data.get("message") or "").strip()
    severity = data.get("severity") or "info"
    if not message:
        return jsonify({"error": "message is required"}), 400

    try:
        resp = requests.post(
            lab["server_url"].rstrip("/") + "/api/hub/message",
            headers={"X-Hub-Token": lab["hub_token"]},
            json={"message": message, "severity": severity, "sent_by": session.get("username", "Hub Admin")},
            timeout=8,
        )
        if resp.status_code != 200:
            return jsonify({"error": f"lab server returned {resp.status_code}"}), 502
        db.add_audit(session["username"], "hub_message_sent",
                      f"to {lab['lab_name']} ({lab_id}): {message[:120]}")
        return jsonify({"success": True})
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"could not reach lab server: {e}"}), 502


# ============================================================
# SENTRYUSB MESSENGER  (two-way Hub <-> Lab chat: text, images, voice notes, calls)
# ------------------------------------------------------------
# Still a *human-to-human* channel: nothing sent here can trigger a device,
# exam, browser or system action on a lab. Labs reach the Hub with their own
# outbound, token-authenticated requests, so this works through NAT/tunnels and
# the Hub never gains an inbound control channel. Voice/video calls are WebRTC
# peer-to-peer; the Hub only relays small signalling messages.
# ============================================================

_MESSENGER_SEVERITIES = {"info", "warning", "critical"}
_MESSENGER_KINDS = {"text", "image", "voice", "call"}
_SIGNAL_KINDS = {"invite", "accept", "decline", "busy", "offer", "answer", "ice", "end", "typing"}
_signal_rate = {}
_MESSENGER_UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "uploads", "messenger")
app.config["MAX_CONTENT_LENGTH"] = config.MESSENGER_UPLOAD_LIMIT_BYTES


def _clean_messenger_body(value):
    """Keep chat payloads bounded: plain text, line breaks preserved, no HTML
    interpretation anywhere (the UI renders with textContent)."""
    return mm.clean_text(value, 2000)


def _parse_message_request():
    """Read a message from JSON (text / call log) or multipart (image / voice).
    Returns a dict; raises ValueError with a user-safe message."""
    if request.files:
        form = request.form
        upload = request.files.get("file")
        data = upload.read(config.MESSENGER_UPLOAD_LIMIT_BYTES + 1) if upload else b""
    else:
        form = request.get_json(silent=True) or {}
        data = b""
    kind = str(form.get("kind") or "text")
    severity = str(form.get("severity") or "info")
    if kind not in _MESSENGER_KINDS:
        raise ValueError("invalid message type")
    if severity not in _MESSENGER_SEVERITIES:
        raise ValueError("invalid severity")
    out = {"kind": kind, "severity": severity, "data": data, "mime": None, "ext": None, "duration": None}
    if kind in ("image", "voice"):
        out["mime"], out["ext"] = mm.classify(kind, data)
        out["body"] = mm.clean_text(form.get("body"), 500)
        if kind == "voice":
            try:
                out["duration"] = max(0.0, min(float(form.get("duration") or 0), float(mm.VOICE_MAX_SECONDS)))
            except (TypeError, ValueError):
                out["duration"] = 0.0
    elif kind == "call":
        out["body"] = mm.clean_text(form.get("body"), 80)
        if not out["body"]:
            raise ValueError("message is required")
    else:
        out["body"] = _clean_messenger_body(form.get("body"))
        if not out["body"]:
            raise ValueError("message is required")
    return out


def _persist_message(lab, direction, sender, parsed, message_id=None):
    media_id = None
    if parsed["kind"] in ("image", "voice"):
        media_id = "med_" + uuid.uuid4().hex
        folder = os.path.join(_MESSENGER_UPLOAD_DIR, "".join(c for c in lab["lab_id"] if c.isalnum() or c in "-_"))
        os.makedirs(folder, exist_ok=True)
        path = os.path.join(folder, media_id + "." + parsed["ext"])
        with open(path, "wb") as fh:
            fh.write(parsed["data"])
        db.add_messenger_media(media_id, lab["lab_id"], parsed["kind"], parsed["mime"], len(parsed["data"]), path)
    return db.add_messenger_message(
        message_id or "msg_" + uuid.uuid4().hex, lab["lab_id"], direction, sender,
        parsed["body"], parsed["severity"], kind=parsed["kind"], media_id=media_id,
        media_mime=parsed["mime"], media_size=len(parsed["data"]) if media_id else None,
        media_duration=parsed["duration"])


def _audit_text(parsed):
    label = {"image": "[image] ", "voice": "[voice note] ", "call": "[call] "}.get(parsed["kind"], "")
    return (label + parsed["body"])[:120]


def _serve_media(media):
    if not media:
        return jsonify({"error": "not found"}), 404
    real = os.path.realpath(media["path"])
    if not real.startswith(os.path.realpath(_MESSENGER_UPLOAD_DIR) + os.sep) or not os.path.isfile(real):
        return jsonify({"error": "not found"}), 404
    resp = send_file(real, mimetype=media["mime"], conditional=True, max_age=3600)
    resp.headers["Content-Disposition"] = "inline"
    resp.headers["Content-Security-Policy"] = "default-src 'none'; sandbox"
    resp.headers["Cache-Control"] = "private, max-age=3600"
    return resp


def _parse_signal():
    data = request.get_json(silent=True) or {}
    kind = str(data.get("kind") or "")
    if kind not in _SIGNAL_KINDS:
        raise ValueError("invalid signal")
    call_id = str(data.get("call_id") or "")[:64]
    if kind != "typing" and not call_id:
        raise ValueError("call_id is required")
    payload = data.get("payload") or {}
    if not isinstance(payload, dict):
        raise ValueError("invalid payload")
    raw = json.dumps(payload)
    if len(raw) > 40000:
        raise ValueError("payload too large")
    return call_id, kind, raw


def _signal_rows(rows):
    out = []
    for r in rows:
        try:
            payload = json.loads(r.get("payload") or "{}")
        except ValueError:
            payload = {}
        out.append({"seq": r["seq"], "lab_id": r["lab_id"], "call_id": r["call_id"], "kind": r["kind"],
                    "payload": payload, "created_at": r["created_at"]})
    return out


def _lab_from_token():
    lab = db.get_lab_by_token(request.headers.get("X-Hub-Token", ""))
    return lab if lab and lab.get("status") == "approved" else None


# ---- Hub administrator side ------------------------------------------------

@app.route("/api/messenger/labs")
@login_required
def api_messenger_labs():
    unread = db.unread_counts()
    return jsonify([{
        "lab_id": lab["lab_id"], "lab_name": lab["lab_name"],
        "online": _lab_is_online(lab), "location": lab.get("location") or "",
        "unread": unread.get(lab["lab_id"], 0),
    } for lab in db.list_labs("approved")])


@app.route("/api/messenger/labs/<lab_id>/messages")
@login_required
def api_messenger_messages(lab_id):
    lab = db.get_lab_by_id(lab_id)
    if not lab:
        return jsonify({"error": "lab not found"}), 404
    # Opening the Hub conversation acknowledges only replies sent by the Lab.
    db.mark_messenger_read(lab_id, "lab_to_hub")
    return jsonify({"lab": {"lab_id": lab_id, "lab_name": lab["lab_name"], "online": _lab_is_online(lab)},
                    "messages": db.list_messenger_messages(lab_id)})


@app.route("/api/messenger/labs/<lab_id>/send", methods=["POST"])
@login_required
def api_messenger_send(lab_id):
    lab = db.get_lab_by_id(lab_id)
    if not lab or lab.get("status") != "approved":
        return jsonify({"error": "approved lab not found"}), 404
    if _rate_limited(_messenger_rate, "hub:" + session.get("username", "admin"), 30):
        return jsonify({"error": "message limit reached; try again in a minute"}), 429
    try:
        parsed = _parse_message_request()
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    sender = session.get("username", "Hub Admin")
    message = _persist_message(lab, "hub_to_lab", sender, parsed)
    db.add_audit(sender, "messenger_message_sent", f"to {lab['lab_name']} ({lab_id}): {_audit_text(parsed)}")
    # The lab pulls via its already-authenticated outbound Hub connection.
    return jsonify({"success": True, "message": message}), 201


@app.route("/api/messenger/media/<media_id>")
@login_required
def api_messenger_media(media_id):
    return _serve_media(db.get_messenger_media(media_id))


@app.route("/api/messenger/ice")
@login_required
def api_messenger_ice():
    return jsonify({"iceServers": config.ice_servers()})


@app.route("/api/messenger/labs/<lab_id>/signal", methods=["POST"])
@login_required
def api_messenger_signal_send(lab_id):
    lab = db.get_lab_by_id(lab_id)
    if not lab or lab.get("status") != "approved":
        return jsonify({"error": "approved lab not found"}), 404
    if _rate_limited(_signal_rate, "hub:" + lab_id, 600):
        return jsonify({"error": "too many call signals"}), 429
    try:
        call_id, kind, raw = _parse_signal()
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    seq = db.add_messenger_signal(lab_id, "hub_to_lab", call_id, kind, raw)
    if kind == "invite":
        db.add_audit(session.get("username", "Hub Admin"), "messenger_call_started", f"to {lab['lab_name']} ({lab_id})")
    return jsonify({"success": True, "seq": seq})


@app.route("/api/messenger/signals")
@login_required
def api_messenger_signals():
    """Signals sent by labs (all labs), so an incoming call rings whichever
    lab conversation is currently open. after=-1 returns only the cursor."""
    try:
        after = int(request.args.get("after", "-1"))
    except ValueError:
        after = -1
    if after < 0:
        return jsonify({"signals": [], "latest": db.latest_signal_seq()})
    rows = db.list_messenger_signals(after, direction="lab_to_hub")
    latest = max([r["seq"] for r in rows], default=after)
    return jsonify({"signals": _signal_rows(rows), "latest": latest})


# ---- Lab Server side (authenticated with the lab's registration token) -----

@app.route("/api/hub/messenger/messages", methods=["GET", "POST"])
def api_lab_messenger_messages():
    """GET syncs the lab inbox; POST relays a lab-admin message to the Hub."""
    lab = _lab_from_token()
    if not lab:
        return jsonify({"error": "unauthorized"}), 401

    if request.method == "GET":
        db.mark_messenger_delivered(lab["lab_id"], "hub_to_lab")
        return jsonify({"messages": db.list_messenger_messages(lab["lab_id"])})

    if _rate_limited(_messenger_rate, "lab:" + lab["lab_id"], 30):
        return jsonify({"error": "message limit reached; try again in a minute"}), 429
    try:
        parsed = _parse_message_request()
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    form = request.form if request.files else (request.get_json(silent=True) or {})
    message_id = str(form.get("message_id") or "msg_" + uuid.uuid4().hex)[:80]
    sender = str(form.get("sender") or "Lab Admin")[:80]
    message = _persist_message(lab, "lab_to_hub", sender, parsed, message_id)
    db.add_audit(sender, "messenger_message_received", f"from {lab['lab_name']} ({lab['lab_id']}): {_audit_text(parsed)}")
    return jsonify({"success": True, "message": message}), 201


@app.route("/api/hub/messenger/read", methods=["POST"])
def api_lab_messenger_read():
    lab = _lab_from_token()
    if not lab:
        return jsonify({"error": "unauthorized"}), 401
    db.mark_messenger_read(lab["lab_id"], "hub_to_lab")
    return jsonify({"success": True})


@app.route("/api/hub/messenger/media/<media_id>")
def api_lab_messenger_media(media_id):
    lab = _lab_from_token()
    if not lab:
        return jsonify({"error": "unauthorized"}), 401
    media = db.get_messenger_media(media_id)
    if not media or media["lab_id"] != lab["lab_id"]:      # a lab can only read its own conversation's media
        return jsonify({"error": "not found"}), 404
    return _serve_media(media)


@app.route("/api/hub/messenger/ice")
def api_lab_messenger_ice():
    if not _lab_from_token():
        return jsonify({"error": "unauthorized"}), 401
    return jsonify({"iceServers": config.ice_servers()})


@app.route("/api/hub/messenger/signal", methods=["POST"])
def api_lab_messenger_signal_send():
    lab = _lab_from_token()
    if not lab:
        return jsonify({"error": "unauthorized"}), 401
    if _rate_limited(_signal_rate, "lab:" + lab["lab_id"], 600):
        return jsonify({"error": "too many call signals"}), 429
    try:
        call_id, kind, raw = _parse_signal()
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    seq = db.add_messenger_signal(lab["lab_id"], "lab_to_hub", call_id, kind, raw)
    if kind == "invite":
        db.add_audit(lab["lab_name"], "messenger_call_started", f"from {lab['lab_name']} ({lab['lab_id']})")
    return jsonify({"success": True, "seq": seq})


@app.route("/api/hub/messenger/signals")
def api_lab_messenger_signals():
    lab = _lab_from_token()
    if not lab:
        return jsonify({"error": "unauthorized"}), 401
    try:
        after = int(request.args.get("after", "-1"))
    except ValueError:
        after = -1
    if after < 0:
        return jsonify({"signals": [], "latest": db.latest_signal_seq()})
    rows = db.list_messenger_signals(after, lab_id=lab["lab_id"], direction="hub_to_lab")
    latest = max([r["seq"] for r in rows], default=after)
    return jsonify({"signals": _signal_rows(rows), "latest": latest})


@app.route("/labs/<lab_id>/approve", methods=["POST"])
@login_required
def approve_lab(lab_id):
    lab = db.get_lab_by_id(lab_id)
    if lab:
        db.set_lab_status(lab_id, "approved")
        db.add_audit(session["username"], "lab_approved", f"{lab['lab_name']} ({lab_id})")
        flash(f"{lab['lab_name']} approved.", "success")
    return redirect(request.referrer or url_for("labs_page"))


@app.route("/labs/<lab_id>/reject", methods=["POST"])
@login_required
def reject_lab(lab_id):
    lab = db.get_lab_by_id(lab_id)
    if lab:
        db.set_lab_status(lab_id, "rejected")
        db.add_audit(session["username"], "lab_rejected", f"{lab['lab_name']} ({lab_id})")
        flash(f"{lab['lab_name']} rejected.", "warning")
    return redirect(request.referrer or url_for("labs_page"))


@app.route("/labs/<lab_id>/revoke", methods=["POST"])
@login_required
def revoke_lab(lab_id):
    lab = db.get_lab_by_id(lab_id)
    if lab:
        db.set_lab_status(lab_id, "revoked")
        db.add_audit(session["username"], "lab_revoked", f"{lab['lab_name']} ({lab_id})")
        flash(f"Access revoked for {lab['lab_name']}.", "danger")
    return redirect(request.referrer or url_for("labs_page"))


@app.route("/labs/<lab_id>/regenerate-token", methods=["POST"])
@login_required
def regenerate_token(lab_id):
    lab = db.get_lab_by_id(lab_id)
    if lab:
        new_token = db.regenerate_token(lab_id)
        db.add_audit(session["username"], "token_regenerated", f"{lab['lab_name']} ({lab_id})")
        session["_new_token_flash"] = new_token
    return redirect(url_for("lab_detail", lab_id=lab_id))


@app.route("/labs/<lab_id>/edit", methods=["POST"])
@login_required
def edit_lab(lab_id):
    """Lets a hub admin rename a lab and update its metadata (location,
    contact, tags, notes) after the fact — the lab_id/token never change."""
    lab = db.get_lab_by_id(lab_id)
    if not lab:
        return render_template("404.html"), 404
    lab_name = request.form.get("lab_name", "").strip()
    if not lab_name:
        flash("Lab name cannot be empty.", "danger")
        return redirect(url_for("lab_detail", lab_id=lab_id))
    db.update_lab_details(
        lab_id,
        lab_name=lab_name,
        location=request.form.get("location", ""),
        contact_email=request.form.get("contact_email", ""),
        notes=request.form.get("notes", ""),
        tags=request.form.get("tags", ""),
    )
    db.add_audit(session["username"], "lab_edited", f"{lab_name} ({lab_id})")
    flash("Lab details updated.", "success")
    return redirect(url_for("lab_detail", lab_id=lab_id))


@app.route("/labs/<lab_id>/delete", methods=["POST"])
@login_required
def delete_lab(lab_id):
    lab = db.get_lab_by_id(lab_id)
    if lab:
        db.delete_lab(lab_id)
        db.add_audit(session["username"], "lab_deleted", f"{lab['lab_name']} ({lab_id})")
        flash(f"{lab['lab_name']} deleted.", "warning")
    return redirect(url_for("labs_page"))


@app.route("/audit-log")
@login_required
def audit_log_page():
    search = request.args.get("q")
    entries = db.get_audit_log(limit=300, search=search)
    return render_template("audit_log.html", entries=entries, search=search or "")


@app.route("/audit-log/export.csv")
@login_required
def export_audit_csv():
    entries = db.get_audit_log(limit=2000)
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["timestamp", "actor", "action", "details"])
    for e in entries:
        writer.writerow([e["timestamp"], e["actor"], e["action"], e.get("details") or ""])
    return Response(buf.getvalue(), mimetype="text/csv",
                     headers={"Content-Disposition": "attachment; filename=sentryusb_audit_log.csv"})


# ============================================================
# ANALYTICS
# ============================================================

@app.route("/analytics")
@login_required
def analytics_page():
    days = request.args.get("range", "14")
    try:
        days = max(7, min(60, int(days)))
    except ValueError:
        days = 14

    labs = [_enrich_lab(l) for l in db.list_labs()]
    summary = {
        "total": len(labs),
        "pending": sum(1 for l in labs if l["status"] == "pending"),
        "approved": sum(1 for l in labs if l["status"] == "approved"),
        "revoked": sum(1 for l in labs if l["status"] == "revoked"),
        "online": sum(1 for l in labs if l["online"] and l["status"] == "approved"),
    }

    return render_template(
        "analytics.html",
        summary=summary,
        fleet=db.fleet_summary(),
        status_dist=db.status_distribution(),
        growth=db.labs_growth_series(days),
        heartbeats=db.heartbeats_series(days),
        top_labs=db.top_labs_by_events(6),
        audit_breakdown=db.audit_action_breakdown(30),
        health=db.avg_response_health(),
        range_days=days,
    )


# ============================================================
# INTEGRATION / API DOCS
# ============================================================

@app.route("/integration")
@login_required
def integration_page():
    current_secret = effective_registration_secret()
    masked_secret = current_secret[:6] + "…" + current_secret[-4:] if len(current_secret) > 12 else "••••••••"
    hub_public_url = config.PUBLIC_URL.rstrip("/")
    return render_template(
        "integration.html",
        masked_secret=masked_secret,
        hub_public_url=hub_public_url,
        config=config,
    )


# ============================================================
# SETTINGS / ADMIN USERS
# ============================================================

@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings_page():
    if request.method == "POST":
        action = request.form.get("action")

        if action == "org_name":
            new_name = request.form.get("org_name", "").strip()
            if new_name:
                db.set_setting("org_name", new_name)
                db.add_audit(session["username"], "org_name_changed", new_name)
                flash("Organization name updated.", "success")

        elif action == "change_password":
            current_pw = request.form.get("current_password", "")
            new_pw = request.form.get("new_password", "")
            confirm_pw = request.form.get("confirm_password", "")
            if not db.verify_hub_credentials(session["username"], current_pw):
                flash("Current password is incorrect.", "danger")
            elif len(new_pw) < 8:
                flash("New password must be at least 8 characters.", "danger")
            elif new_pw != confirm_pw:
                flash("New password and confirmation do not match.", "danger")
            else:
                db.set_hub_password(session["username"], new_pw)
                db.add_audit(session["username"], "password_changed", None)
                flash("Password updated.", "success")

        elif action == "registration_secret":
            new_secret = request.form.get("registration_secret", "").strip()
            if new_secret:
                db.set_setting("registration_secret_override", new_secret)
                db.add_audit(session["username"], "registration_secret_changed", None)
                flash("Registration secret updated. Existing lab servers must be given the new value.", "warning")

        return redirect(url_for("settings_page"))

    current_secret = effective_registration_secret()
    masked_secret = current_secret[:6] + "…" + current_secret[-4:] if len(current_secret) > 12 else "••••••••"
    return render_template("settings.html", masked_secret=masked_secret, config=config,
                            health=db.avg_response_health(), hub_version=HUB_VERSION)


@app.route("/admins")
@login_required
def admins_page():
    users = db.list_hub_users()
    return render_template("admins.html", users=users)


@app.route("/admins/create", methods=["POST"])
@login_required
def create_admin():
    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    if not username or len(password) < 8:
        flash("Username is required and password must be at least 8 characters.", "danger")
    elif db.get_hub_user(username):
        flash("That username already exists.", "danger")
    else:
        db.create_hub_user(username, password)
        db.add_audit(session["username"], "admin_created", username)
        flash(f"Admin '{username}' created.", "success")
    return redirect(url_for("admins_page"))


@app.route("/admins/<username>/delete", methods=["POST"])
@login_required
def delete_admin(username):
    if username == session.get("username"):
        flash("You can't delete your own account while logged in as it.", "danger")
    elif db.count_hub_users() <= 1:
        flash("Can't delete the last remaining hub admin.", "danger")
    else:
        db.delete_hub_user(username)
        db.add_audit(session["username"], "admin_deleted", username)
        flash(f"Admin '{username}' deleted.", "warning")
    return redirect(url_for("admins_page"))


# ============================================================
# LAB-FACING API  (called by server/hub_client.py on each lab server)
# ============================================================

@app.route("/api/hub/register", methods=["POST"])
def api_register():
    """A lab server calls this on startup (and periodically retries while
    pending) to register itself with the hub. This is what closes the gap:
    the hub hands back a unique lab_id + hub_token that the lab server then
    uses for every future authenticated call."""
    ip = request.remote_addr
    if _rate_limited(_register_rate, ip, config.REGISTER_RATE_LIMIT_PER_MINUTE):
        return jsonify({"error": "rate limit exceeded"}), 429

    data = request.get_json(silent=True) or {}

    if data.get("registration_secret") != effective_registration_secret():
        return jsonify({"error": "invalid registration secret"}), 403

    lab_name = (data.get("lab_name") or "").strip()
    server_url = (data.get("server_url") or "").strip()
    existing_lab_id = (data.get("lab_id") or "").strip()
    existing_token = (data.get("hub_token") or "").strip()

    if not lab_name or not server_url:
        return jsonify({"error": "lab_name and server_url are required"}), 400

    # Case 1: this lab server already has a lab_id + hub_token cached from a
    # previous registration (e.g. it restarted, or its ngrok URL changed).
    # Re-use the same identity instead of minting a brand-new one.
    if existing_lab_id and existing_token:
        lab = db.get_lab_by_id(existing_lab_id)
        if lab and lab["hub_token"] == existing_token and lab["status"] != "revoked":
            lab = db.reregister_lab(
                existing_lab_id, server_url, ip=ip,
                agent_version=data.get("agent_version"),
                server_version=data.get("server_version"),
            )
            return jsonify({
                "lab_id": lab["lab_id"], "hub_token": lab["hub_token"],
                "status": lab["status"], "message": "re-registered",
            }), 200
        # stale/invalid cached credentials -> fall through and mint a new identity

    # Case 2: idempotency guard on first-ever registration - if a lab with
    # this exact name already exists and is still live, don't create a
    # duplicate; just refresh its URL.
    existing = db.get_lab_by_name(lab_name)
    if existing and existing["status"] != "revoked":
        lab = db.reregister_lab(
            existing["lab_id"], server_url, ip=ip,
            agent_version=data.get("agent_version"),
            server_version=data.get("server_version"),
        )
        return jsonify({
            "lab_id": lab["lab_id"], "hub_token": lab["hub_token"],
            "status": lab["status"], "message": "re-registered (matched by name)",
        }), 200

    lab = db.create_lab(
        lab_name=lab_name,
        server_url=server_url,
        contact_email=data.get("contact_email"),
        location=data.get("location"),
        auto_approve=config.AUTO_APPROVE_LABS,
        agent_version=data.get("agent_version"),
        server_version=data.get("server_version"),
        ip=ip,
    )
    db.add_audit("system", "lab_registered", f"{lab['lab_name']} ({lab['lab_id']}) from {ip}")

    return jsonify({
        "lab_id": lab["lab_id"],
        "hub_token": lab["hub_token"],
        "status": lab["status"],
        "message": "registered" if lab["status"] == "approved" else "registered, pending admin approval",
    }), 201


@app.route("/api/hub/heartbeat", methods=["POST"])
def api_heartbeat():
    """Approved lab servers call this periodically with a small stats
    payload (agent count, event counts, etc). Powers the 'online/offline'
    and per-lab stats shown on the hub dashboard."""
    token = request.headers.get("X-Hub-Token") or (request.get_json(silent=True) or {}).get("hub_token")
    if not token:
        return jsonify({"error": "missing hub token"}), 401

    ip = request.remote_addr
    if _rate_limited(_heartbeat_rate, token, config.HEARTBEAT_RATE_LIMIT_PER_MINUTE):
        return jsonify({"error": "rate limit exceeded"}), 429

    lab = db.get_lab_by_token(token)
    if not lab:
        return jsonify({"error": "unknown token"}), 401
    if lab["status"] == "revoked":
        return jsonify({"error": "lab access revoked"}), 403
    if lab["status"] == "rejected":
        return jsonify({"error": "lab registration was rejected"}), 403
    if lab["status"] == "pending":
        return jsonify({"error": "lab is pending admin approval", "status": "pending"}), 403

    data = request.get_json(silent=True) or {}
    stats = data.get("stats") or {}

    # allow the lab to report a fresh server_url on heartbeat too, in case
    # its ngrok tunnel restarted and the URL changed
    server_url = data.get("server_url")
    if server_url:
        db.reregister_lab(lab["lab_id"], server_url, ip=ip)

    db.record_heartbeat(lab["lab_id"], stats, ip=ip)
    return jsonify({"status": "ok"}), 200


@app.route("/api/hub/status/<lab_id>")
def api_lab_status(lab_id):
    """Lets a lab server (or its admin) self-check current approval status
    using its own lab_id, without exposing anyone else's data."""
    token = request.headers.get("X-Hub-Token")
    lab = db.get_lab_by_id(lab_id)
    if not lab or lab["hub_token"] != token:
        return jsonify({"error": "not found"}), 404
    return jsonify({"lab_id": lab["lab_id"], "status": lab["status"]}), 200


@app.route("/api/health")
def api_health():
    return jsonify({"status": "ok", "service": "sentryusb-hub", "time": datetime.now().isoformat()})


# ============================================================
# ERROR HANDLERS
# ============================================================

@app.errorhandler(404)
def not_found(error):
    return render_template("404.html"), 404


@app.errorhandler(500)
def internal_error(error):
    return render_template("500.html"), 500


if __name__ == "__main__":
    print("=" * 70)
    print("SENTRYUSB HUB  (Tier 1 - centralized admin)")
    print("=" * 70)
    print(f"Dashboard:        http://localhost:{config.PORT}/")
    print(f"Default login:    {config.HUB_ADMIN_USERNAME} / {config.HUB_ADMIN_PASSWORD}")
    print(f"Register API:     POST /api/hub/register")
    print(f"Heartbeat API:    POST /api/hub/heartbeat")
    print(f"Auto-approve:     {config.AUTO_APPROVE_LABS}")
    print("=" * 70)
    if config.SECRET_KEY == "change-me-hub-secret-key":
        print("WARNING: SECRET_KEY is still the default.")
    if config.HUB_ADMIN_PASSWORD == "change-me-hub-admin-pass":
        print("WARNING: default hub admin password is still active.")
    if config.REGISTRATION_SECRET == "change-me-registration-secret":
        print("WARNING: REGISTRATION_SECRET is still the default.")
    print("=" * 70)
    app.run(host="0.0.0.0", port=config.PORT, debug=False)
