"""SentryUSB Messenger - attachment validation (shared by Hub and Lab Server).

Attachments are validated by *content* (magic bytes), never by the filename or
the browser-supplied MIME type, and the stored MIME type is chosen by us. SVG
and HTML are deliberately not accepted, so an attachment can never carry script.
"""

IMAGE_MAX_BYTES = 8 * 1024 * 1024
VOICE_MAX_BYTES = 5 * 1024 * 1024
VOICE_MAX_SECONDS = 300


def sniff_image(data: bytes):
    if data[:8] == b"\x89PNG\r\n\x1a\n":
        return "image/png", "png"
    if data[:3] == b"\xff\xd8\xff":
        return "image/jpeg", "jpg"
    if data[:6] in (b"GIF87a", b"GIF89a"):
        return "image/gif", "gif"
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp", "webp"
    return None


def sniff_voice(data: bytes):
    if data[:4] == b"\x1a\x45\xdf\xa3":                      # Matroska/WebM (Chrome, Firefox, Edge)
        return "audio/webm", "webm"
    if data[:4] == b"OggS":                                  # Ogg/Opus (Firefox)
        return "audio/ogg", "ogg"
    if data[4:8] == b"ftyp":                                 # MP4/AAC (Safari)
        return "audio/mp4", "m4a"
    if data[:4] == b"RIFF" and data[8:12] == b"WAVE":
        return "audio/wav", "wav"
    if data[:3] == b"ID3" or (len(data) > 1 and data[0] == 0xFF and (data[1] & 0xE0) == 0xE0):
        return "audio/mpeg", "mp3"
    return None


def classify(kind: str, data: bytes):
    """Return (mime, extension) for a valid attachment or raise ValueError."""
    if not data:
        raise ValueError("The attachment is empty.")
    if kind == "image":
        if len(data) > IMAGE_MAX_BYTES:
            raise ValueError("Images are limited to 8 MB.")
        found = sniff_image(data)
        if not found:
            raise ValueError("Only PNG, JPEG, GIF or WebP images can be sent.")
        return found
    if kind == "voice":
        if len(data) > VOICE_MAX_BYTES:
            raise ValueError("Voice messages are limited to 5 MB.")
        found = sniff_voice(data)
        if not found:
            raise ValueError("Unsupported voice message format.")
        return found
    raise ValueError("Unsupported attachment type.")


def clean_text(value, limit=2000) -> str:
    """Normalise chat text: keep line breaks, drop control characters, cap length."""
    text = str(value or "").replace("\r\n", "\n").replace("\r", "\n")
    text = "".join(ch for ch in text if ch == "\n" or ch >= " ")
    lines = [ln.rstrip() for ln in text.strip().split("\n")]
    out, blank = [], 0
    for ln in lines:                       # collapse 3+ blank lines to 1
        blank = blank + 1 if not ln else 0
        if blank <= 1:
            out.append(ln)
    return "\n".join(out)[:limit]
