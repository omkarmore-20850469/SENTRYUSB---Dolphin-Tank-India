"""
SentryUSB HUB - Configuration
Change these before real deployment.
"""
import os

SECRET_KEY = os.environ.get("SENTRYHUB_SECRET_KEY", "change-me-hub-secret-key")

HUB_ADMIN_USERNAME = os.environ.get("SENTRYHUB_ADMIN_USER", "hubadmin")
HUB_ADMIN_PASSWORD = os.environ.get("SENTRYHUB_ADMIN_PASSWORD", "change-me-hub-admin-pass")

# Default display name shown in the sidebar / browser title. Overridable at
# runtime from the Settings page (stored in hub_settings, takes priority over
# this env default — see hub_app.py's org_name() helper).
ORG_NAME = os.environ.get("SENTRYHUB_ORG_NAME", "SentryUSB")

PORT = int(os.environ.get("SENTRYHUB_PORT", "6800"))

# ========== LAB REGISTRATION ==========
# Shared secret that every lab server must present when it first registers
# (server/hub_config.py -> HUB_REGISTRATION_SECRET must match this). This is
# NOT the per-lab token - it just stops randoms from spamming the public
# registration endpoint. Change this before real deployment.
REGISTRATION_SECRET = os.environ.get("SENTRYHUB_REGISTRATION_SECRET", "change-me-registration-secret")

# When true, newly-registered labs are auto-approved and can start sending
# heartbeats immediately. When false (recommended for real deployments), new
# labs sit in "pending" status until a hub admin approves them from the
# dashboard.
AUTO_APPROVE_LABS = os.environ.get("SENTRYHUB_AUTO_APPROVE", "false").lower() == "true"

# A lab is considered "offline" in the dashboard if no heartbeat has been
# received for this many seconds.
LAB_OFFLINE_THRESHOLD_SECONDS = int(os.environ.get("SENTRYHUB_OFFLINE_THRESHOLD", "120"))

# ========== RATE LIMITING ==========
REGISTER_RATE_LIMIT_PER_MINUTE = int(os.environ.get("SENTRYHUB_REGISTER_RATE_LIMIT", "10"))
HEARTBEAT_RATE_LIMIT_PER_MINUTE = int(os.environ.get("SENTRYHUB_HEARTBEAT_RATE_LIMIT", "30"))

LOGIN_MAX_ATTEMPTS = int(os.environ.get("SENTRYHUB_LOGIN_MAX_ATTEMPTS", "5"))
LOGIN_LOCKOUT_SECONDS = int(os.environ.get("SENTRYHUB_LOGIN_LOCKOUT_SECONDS", "300"))

# ========== REMOTE ACCESS ==========
# The public URL the hub itself is reachable at (e.g. your own ngrok URL, or
# a real domain once deployed). Lab servers point their HUB_URL at this.
# Defaults to this machine's PORT above so it never silently drifts out of
# sync with the port the hub is actually listening on — override with
# SENTRYHUB_PUBLIC_URL for a real LAN IP, domain, or ngrok tunnel.
PUBLIC_URL = "https://providing-wronged-province.ngrok-free.dev"

# When true, session cookies get the Secure flag (requires HTTPS in front)
FORCE_HTTPS = os.environ.get("SENTRYHUB_FORCE_HTTPS", "false").lower() == "true"

# ========== MESSENGER: CALLS & ATTACHMENTS ==========
# STUN is enough for most networks. Behind strict NAT / campus firewalls add a
# TURN relay (e.g. coturn) so voice & video calls can still connect:
#   SENTRYHUB_TURN_URL=turn:turn.example.edu:3478  SENTRYHUB_TURN_USER=...  SENTRYHUB_TURN_PASS=...
STUN_URLS = [u.strip() for u in os.environ.get(
    "SENTRYHUB_STUN_URLS", "stun:stun.l.google.com:19302,stun:stun1.l.google.com:19302").split(",") if u.strip()]
TURN_URL = os.environ.get("SENTRYHUB_TURN_URL", "")
TURN_USER = os.environ.get("SENTRYHUB_TURN_USER", "")
TURN_PASS = os.environ.get("SENTRYHUB_TURN_PASS", "")


def ice_servers():
    servers = [{"urls": STUN_URLS}] if STUN_URLS else []
    if TURN_URL:
        servers.append({"urls": [u.strip() for u in TURN_URL.split(",") if u.strip()],
                        "username": TURN_USER, "credential": TURN_PASS})
    return servers


# Attachments are stored under hub/uploads/messenger/<lab_id>/ (outside static/, never served directly).
MESSENGER_UPLOAD_LIMIT_BYTES = 12 * 1024 * 1024
