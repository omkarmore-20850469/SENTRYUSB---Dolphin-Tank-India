# Agent Startup Voice Alarm

Each Windows SentryUSB agent now plays one local voice announcement after its USB watcher starts:

> Welcome to SentryUSB. Security monitoring is active.

The announcement uses Windows SAPI (`System.Speech`), so it is local to the PC and does not call a cloud AI/TTS service.

## Configuration

Set these environment variables before launching the agent if you want to customize it:

| Variable | Default | Purpose |
| --- | --- | --- |
| `SENTRYUSB_STARTUP_VOICE` | `true` | Set to `false` to mute the startup announcement. |
| `SENTRYUSB_STARTUP_VOICE_MESSAGE` | Welcome message | Replace the spoken wording. |
| `SENTRYUSB_STARTUP_VOICE_NAME` | `Zira` | Preferred installed Windows voice; it falls back safely if unavailable. |
| `SENTRYUSB_STARTUP_VOICE_RATE` | `-1` | Speaking speed from `-10` (slowest) to `10` (fastest). |
| `SENTRYUSB_STARTUP_VOICE_VOLUME` | `88` | Voice volume from `0` to `100`. |

Example:

```powershell
$env:SENTRYUSB_STARTUP_VOICE_MESSAGE = 'Welcome to SentryUSB. This workstation is protected.'
$env:SENTRYUSB_STARTUP_VOICE_NAME = 'Zira'
python agent.py
```

## Important deployment note

Windows services run in Session 0, which is isolated from the signed-in desktop. The monitoring agent will still run securely as a service, but its speech cannot be heard by the logged-in user. Deploy the agent in the user session (for example through a user-context scheduled task) when audible startup confirmation is required.
