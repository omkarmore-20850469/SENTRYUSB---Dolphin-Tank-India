# SentryUSB upgrade notes — 2026-10-10

## Implemented in this patch
- Exam Control duration presets (1h / 2h / 3h) and custom duration in minutes.
- Server validates exam duration and broadcasts an issued timestamp and expiry timestamp.
- Agent starts a local exam lease after applying Exam Control restrictions. The watchdog runs independently of Socket.IO connectivity and releases exam-only restrictions when the lease expires.
- Local lease state is written to `agent/exam_lease.json` for diagnostics and removed when the exam ends.
- Manual exam stop invalidates the local watchdog so it cannot later interfere with a subsequent session.

## Important operational notes
- Test first on a disposable Windows VM with administrator privileges. OS policy/firewall changes can vary by Windows edition and policy configuration.
- The local timer requires the agent process to remain running. A process crash, forced termination, power loss, or system clock manipulation can affect enforcement; production deployment should use a signed Windows service and a monotonic-time watchdog plus startup recovery.
- This patch does not claim that every requested feature is complete. Policy Studio approvals, reliable 3D map topology, browser rule enforcement coverage, end-to-end Hub/Server video calls and voice recordings, and AI assistant quality/latency still require separate implementation and integration tests.
- Do not expose the server publicly without authentication, TLS, restricted CORS, secure secret management, and firewall review.
