SentryUSB v23 implementation notes

Included in this patch:
- Messenger call window remains compact so the dashboard is visible; responsive controls and visual polish.
- Improved call setup response checks, acceptance acknowledgement error handling, and ring timeout guard.
- Exam dashboard stores its countdown deadline locally and queues browser-level connectivity/timer audit events in localStorage.
- Policy alert and shared panel visual polish.

Important validation limits:
- Real Hub-to-Server WebRTC calls require testing on two actual machines and may need a TURN server for restrictive NAT/firewall networks. A successful JavaScript syntax check is not proof of call connectivity.
- Browser localStorage audit events are not tamper-proof and are not a substitute for a durable server-side event queue.
- The exam dashboard countdown does not itself guarantee operating-system lockdown during network loss. That requires an agent-side watchdog/service which persists a signed exam deadline locally, enforces only the explicitly configured exam policy, records a durable local audit journal, and reconciles it after reconnection.
- Monitoring and policy consent should remain transparent to the monitored user and auditable by the invigilator.
