# SentryUSB Messenger

SentryUSB Messenger adds a durable, two-way operational conversation between a Hub administrator and each approved Lab Server administrator. It is deliberately a message-only channel: messages cannot trigger device, exam, browser, or system actions.

## What is included

- Floating Messenger panel on the Hub, with approved-lab selection.
- Floating Messenger panel on every authenticated Lab Server page.
- Hub-to-Lab and Lab-to-Hub replies over the existing `X-Hub-Token` trust relationship.
- Durable SQLite history at both tiers, delivery/read receipts, severity labels, timestamps, character limits, and 30-message-per-minute rate limits.
- Lab-initiated message synchronization. This works with NAT and tunnels, and never creates a general Hub-to-Lab control endpoint.
- Messenger-specific audit records for sent and received communications.

## User flow

1. Approve and connect a Lab in the Hub as normal.
2. On the Hub, open the floating **SentryUSB Messenger**, choose a Lab, and send a message.
3. The Lab Server's Messenger synchronizes from its Hub connection and displays the note.
4. A Lab administrator replies in its own Messenger panel. The reply is stored by the Hub and appears in the Hub conversation automatically.

## Security design

- The Hub stores the canonical relay history in `hub/sentryusb_hub.db`.
- The Lab stores a local resilient cache in `server/sentryusb.db`.
- All Lab API calls use the registration token already issued by the Hub.
- Input is treated as plain text, bounded to 2,000 characters, and rendered without HTML injection.
- `critical` is a visual escalation flag, not an automatic action.

## Production roadmap

Prioritize these before using the system for high-stakes operations:

1. Replace static registration tokens with short-lived, rotated, scoped credentials and mutual TLS.
2. Add role-based access control: Hub operator, security analyst, lab supervisor, and read-only auditor.
3. Encrypt message content at rest with managed keys; add retention, legal hold, export, and secure deletion policies.
4. Add offline outbox/retry with idempotency keys and an explicit delivery-failure UI.
5. Add message search, filters, threaded incident conversations, assignment, acknowledgements, and SLA/escalation timers.
6. Send alert-linked messages: safely attach a reference to an existing event, device, or incident—not an executable action.
7. Add WebSocket/SSE fan-out behind an authenticated reverse proxy for sub-second delivery; retain polling as the safe fallback.
8. Centralize logs in a SIEM, make audit logs tamper-evident, and alert on unusual messaging patterns.
9. Add automated tests, database migrations, health checks, backups, dependency scanning, and deployment hardening.
10. Add accessibility review, mobile-responsive testing, localization, and a documented incident-response runbook.

## Files changed

- `hub/hub_app.py` and `hub/hub_db.py`: authoritative relay APIs and storage.
- `server/app.py`, `server/db.py`, and `server/hub_client.py`: Lab-side transport, cache, and APIs.
- `hub/static/*/messenger_widget.*` and `server/static/*/messenger_widget.*`: floating interfaces.

---

# Messenger v2 (v21.0.0) - images, voice notes, voice & video calls

The same widget (`static/js/messenger_widget.js`, identical on Hub and Lab Server except for one `MODE` line) now supports:

| Feature | How it works |
|---|---|
| Text | Line breaks preserved (Shift+Enter), emoji tray, priority chip (INFO / WARNING / CRITICAL), typing indicator, quick-reply chips |
| Images | Picker, paste (Ctrl+V) or drag-and-drop; big photos are down-scaled in the browser; caption; click for full-size viewer. PNG/JPEG/GIF/WebP only, max 8 MB, validated by file signature (SVG/HTML are rejected) |
| Voice notes | Mic button records in the browser (MediaRecorder), waveform player with seek and 1x/1.5x/2x speed. Max 5 min / 5 MB |
| Voice & video calls | WebRTC, peer-to-peer. The Hub only relays small signalling messages (offer / answer / ICE). Mute, camera on/off, call timer, ringing card with ringtone, busy/decline/missed handling, call-log lines in the chat |
| Delivery ticks | Sent / delivered / seen |
| Sending state | Pending bubble, "tap to retry" when a send fails |

## Where things live
- Hub stores attachments in `hub/uploads/messenger/<lab_id>/` (never under `static/`). They are served only to the authenticated Hub admin or to *that lab's* token, with `nosniff` and a sandbox CSP.
- A Lab Server never stores the file itself: `/api/messenger/media/<id>` proxies it from the Hub (Range requests supported, so audio seeking works).
- New tables: `messenger_media`, `messenger_signals` (auto-pruned after 15 min); `messenger_messages` gains `kind`, `media_id`, `media_mime`, `media_size`, `media_duration`. Migrations run automatically at start-up - existing history is kept.
- New Hub endpoints: `/api/messenger/media/<id>`, `/api/messenger/ice`, `/api/messenger/labs/<id>/signal`, `/api/messenger/signals`, and lab-token equivalents under `/api/hub/messenger/...`.

## Requirements for calls & voice notes (important)
1. **Browsers only allow microphone/camera on HTTPS or `http://localhost`.** The Hub is fine through its ngrok https URL. For a Lab Server open it as `http://localhost:5000` on the lab machine, or put it behind HTTPS (e.g. its own ngrok URL). On plain `http://<LAN-IP>` the buttons will explain this instead of failing silently.
2. **STUN is configured by default** (Google public STUN). On strict campus/corporate networks calls may not connect without a **TURN** relay - set `SENTRYHUB_TURN_URL`, `SENTRYHUB_TURN_USER`, `SENTRYHUB_TURN_PASS` on the Hub (coturn works well). Lab Servers receive these from the Hub automatically.
3. Ringtones use the browser's audio, which some browsers block until the page has had a click; the ringing card and flashing tab title always appear.
4. Signalling is polled (1 s during a call, 2 s idle) to stay NAT/tunnel-friendly and keep the Hub from having an inbound control channel. Lab Servers poll the Hub at most once per second regardless of how many tabs are open.

Still a message-only channel: nothing sent over Messenger can trigger a device, exam, browser or system action.
