SentryUSB Suite v22 - Polish Patch Notes

Changes included in this build
- Removed the COMMAND CENTER subtitle from the Server sidebar brand; the brand now displays SentryUSB only.
- Changed the Hub and Server messenger call surface from a full-screen overlay to a compact floating call window so the underlying dashboard remains visible.
- Added responsive sizing for smaller screens and constrained remote/local video sizing.
- Kept the existing policy-request alert flow in place.

Validation
- ZIP integrity check passed.
- This is a UI-focused patch. It has not been run end-to-end on two physical Windows machines.
- Voice/video call signalling, microphone/camera permissions, and automatic-decline behaviour still require live testing; this patch does not claim to fix the signalling bug.

Important implementation notes
- Policy approval should remain auditable and consistent with the notice presented to the monitored agent.
- Any exam lockdown should be explicitly authorised, time-bounded, visible to the user, and have a documented recovery path. Offline events should be queued locally and synced when connectivity returns.
